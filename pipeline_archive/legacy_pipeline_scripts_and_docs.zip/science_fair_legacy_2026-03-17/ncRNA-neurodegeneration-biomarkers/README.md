# Convergent Non-Coding RNA Biomarkers Across Neurodegenerative Diseases

## Overview
This project identifies shared non-coding RNA (ncRNA) biomarkers across Alzheimer's disease (AD) and amyotrophic lateral sclerosis (ALS) using public RNA-seq datasets from GEO.

The analysis pipeline performs:
1. Data download and metadata setup
2. Preprocessing and normalization (log2-CPM)
3. Differential expression analysis (Welch t-test + FDR)
4. PCA analysis and cohort separation check
5. Cross-dataset overlap analysis
6. Machine learning classification
7. Figure generation for poster/report use

## Datasets
- `GSE203206` (AD)
- `GSE48350` (AD validation)
- `GSE153960` (ALS)

See `data/dataset_metadata.csv` and `data/dataset_links.txt` for details.

## Key Result
Five shared ncRNA biomarkers were identified across independent datasets:
- `MEG9`
- `ZMIZ1-AS1`
- `SLC12A5-AS1`
- `GUSBP1`
- `STRCP1`

## Repository Structure
- `scripts/`: numbered pipeline steps
- `figures/`: publication and poster figures
- `results/`: CSV outputs and model metrics
- `data/`: dataset metadata and links (not raw GEO dumps)
- `notebooks/`: exploratory analysis
- `docs/`: summary report PDFs

## Reproducibility
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python scripts/run_pipeline.py
```

Equivalent step-by-step execution:

```bash
python scripts/01_data_download.py
python scripts/02_preprocessing.py
python scripts/03_differential_expression.py
python scripts/04_pca_analysis.py
python scripts/05_overlap_analysis.py
python scripts/06_machine_learning_classifier.py
python scripts/07_plot_generation.py
```

## Notes
- This repo intentionally excludes large raw datasets to keep version control clean.
- Use GEO accession links in `data/dataset_links.txt` for complete raw data access.
