#!/usr/bin/env python3
"""Step 4: confirm PCA outputs for AD and ALS cohorts."""

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FIGURES = ROOT / "figures"
REQUIRED = ["PCA_AD.png", "PCA_ALS.png"]


def main() -> None:
 missing = [name for name in REQUIRED if not (FIGURES / name).exists()]
 if missing:
 print("Missing PCA figures:")
 for name in missing:
 print(f"- {name}")
 raise SystemExit(1)

 print("PCA analysis outputs are present:")
 for name in REQUIRED:
 print(f"- {name}")


if __name__ == "__main__":
 main()
