#!/usr/bin/env python3
"""Step 3: differential expression summary for ncRNA biomarkers."""

from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results" / "differential_expression_results.csv"


def main() -> None:
 df = pd.read_csv(RESULTS)
 col = "fdr" if "fdr" in df.columns else "padj"
 sig = df[df[col] < 0.05].copy() if col in df.columns else df
 print(f"Loaded {len(df)} rows from {RESULTS.name}")
 print(f"Significant rows (threshold 0.05 on {col}): {len(sig)}")


if __name__ == "__main__":
 main()
