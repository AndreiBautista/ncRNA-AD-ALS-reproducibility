#!/usr/bin/env python3
"""Step 6: report classifier performance metrics."""

from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
METRICS = ROOT / "results" / "classifier_metrics.csv"


def main() -> None:
 df = pd.read_csv(METRICS)
 expected = {"GSE203206", "GSE153960"}
 if "dataset_id" in df.columns:
 present = set(df["dataset_id"].astype(str).tolist())
 missing = expected - present
 if missing:
 raise SystemExit(f"Missing expected classifier dataset IDs: {sorted(missing)}")

 print("Classifier metrics:")
 print(df.to_string(index=False))


if __name__ == "__main__":
 main()
