#!/usr/bin/env python3
"""Step 1: dataset manifest and download instructions for GEO cohorts."""

from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"


def main() -> None:
 metadata = pd.read_csv(DATA_DIR / "dataset_metadata.csv")
 print("Configured datasets:")
 print(metadata[["dataset_id", "disease", "role", "sample_count"]].to_string(index=False))
 print("\nUse links in data/dataset_links.txt to fetch raw data from GEO.")


if __name__ == "__main__":
 main()
