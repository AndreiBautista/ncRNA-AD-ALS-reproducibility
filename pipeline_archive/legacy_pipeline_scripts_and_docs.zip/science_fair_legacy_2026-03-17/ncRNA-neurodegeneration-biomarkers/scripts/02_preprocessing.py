#!/usr/bin/env python3
"""Step 2: preprocessing and normalization wrapper."""

from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
SCRIPT = ROOT / "scripts" / "run_pipeline.py"


def main() -> None:
 if not SCRIPT.exists():
 raise FileNotFoundError(f"Missing expected pipeline script: {SCRIPT}")

 print("Preprocessing uses project pipeline modules (filter ncRNA + log2-CPM).")
 print("Run the full pipeline command with your local counts/metadata/annotation files.")
 print(f"Example entry point: {SCRIPT}")


if __name__ == "__main__":
 main()
