#!/usr/bin/env python3
"""Step 6: verify required figure outputs are present."""

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FIGURES = ROOT / "figures"
REQUIRED = [
 "PCA_AD.png",
 "PCA_ALS.png",
 "volcano_AD.png",
 "volcano_ALS.png",
 "heatmap_AD.png",
 "heatmap_ALS.png",
 "venn_overlap.png",
 "roc_curve_AD.png",
 "roc_curve_ALS.png",
]


def main() -> None:
 missing = [name for name in REQUIRED if not (FIGURES / name).exists()]
 if missing:
 print("Missing figure files:")
 for name in missing:
 print(f"- {name}")
 raise SystemExit(1)

 print("All required figures are present.")


if __name__ == "__main__":
 main()
