#!/usr/bin/env python3
"""Step 4: cross-dataset shared biomarker overlap summary."""

from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
SHARED = ROOT / "results" / "shared_ncRNA_biomarkers.csv"


def main() -> None:
 df = pd.read_csv(SHARED)
 id_col = "gene_id" if "gene_id" in df.columns else df.columns[0]
 genes = sorted(df[id_col].dropna().astype(str).unique())
 print(f"Shared biomarkers listed: {len(genes)}")
 for gene in genes[:20]:
 print(f"- {gene}")


if __name__ == "__main__":
 main()
