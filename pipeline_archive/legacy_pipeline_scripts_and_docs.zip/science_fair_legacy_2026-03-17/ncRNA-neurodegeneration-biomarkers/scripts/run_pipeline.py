#!/usr/bin/env python3
"""Run the full numbered pipeline in sequence."""

from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = [
 "01_data_download.py",
 "02_preprocessing.py",
 "03_differential_expression.py",
 "04_pca_analysis.py",
 "05_overlap_analysis.py",
 "06_machine_learning_classifier.py",
 "07_plot_generation.py",
]


def main() -> None:
 scripts_dir = ROOT / "scripts"

 for script in SCRIPTS:
 script_path = scripts_dir / script
 if not script_path.exists():
 raise FileNotFoundError(f"Missing pipeline step: {script_path}")

 print(f"\n=== Running {script} ===")
 result = subprocess.run([sys.executable, str(script_path)], cwd=str(ROOT))
 if result.returncode != 0:
 raise SystemExit(result.returncode)

 print("\nPipeline completed successfully.")


if __name__ == "__main__":
 main()
