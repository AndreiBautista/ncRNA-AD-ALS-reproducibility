#!/usr/bin/env python3
"""
Convert speaker notes to a single Word document
"""
from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH

def create_speaker_notes_docx():
 """Create a comprehensive Word document with all speaker notes"""
 doc = Document()
 
 # Title
 title = doc.add_heading(' Presentation Speaker Notes', 0)
 title.alignment = WD_ALIGN_PARAGRAPH.CENTER
 
 subtitle = doc.add_paragraph('Shared Non-Coding RNA Dysregulation Across Neurodegenerative Diseases')
 subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
 subtitle_format = subtitle.runs[0]
 subtitle_format.font.size = Pt(14)
 subtitle_format.font.italic = True
 
 doc.add_paragraph() # Spacing
 
 # Slide 1
 doc.add_heading('Slide 1: Title Slide', level=1)
 doc.add_heading('Shared Non-Coding RNA Dysregulation Across Neurodegenerative Diseases', level=3)
 doc.add_paragraph('Timing: 15 seconds', style='Heading 4')
 doc.add_paragraph('Open with confidence and establish the scope immediately')
 doc.add_paragraph('"Hello. My name is Austin Bautista, and today I\'m presenting research on shared molecular pathways in Alzheimer\'s disease and ALS."')
 doc.add_paragraph('"We analyzed 1,463 postmortem brain samples using computational biology to identify non-coding RNAs that become dysregulated in both diseases."')
 doc.add_paragraph('Emphasize: This is big data analysis (1,463 samples) combined with rigorous statistics.')
 doc.add_paragraph('Pause for 2-3 seconds after introducing yourself to let judges know you\'re ready.')
 doc.add_paragraph()
 
 # Slide 2
 doc.add_heading('Slide 2: The Problem', level=1)
 doc.add_heading('"Two distinct diseases may converge at molecular level"', level=3)
 doc.add_paragraph('Timing: 45 seconds', style='Heading 4')
 doc.add_paragraph('Start by humanizing the problem: "Alzheimer\'s disease and ALS are devastating neurodegenerative diseases. They look different clinically—AD affects memory, ALS affects motor neurons—but both cause progressive brain degeneration."')
 doc.add_paragraph('"The central question driving this project: Do they share hidden molecular mechanisms despite their clinical differences?"')
 doc.add_paragraph('Point to the PCA plot on the right: "This visualization comes from one of our datasets. You can see disease clustering—but that\'s after measuring 101,000 genes. The real challenge is finding which genes matter and which are just noise."')
 doc.add_paragraph('"Current diagnostics are either invasive—requiring lumbar punctures to sample cerebrospinal fluid—or arrive too late, like post-mortem confirmation."')
 doc.add_paragraph('"So we asked: can we identify shared molecular markers that distinguish disease from health, and could those become blood-based biomarkers?"')
 doc.add_paragraph()
 
 # Slide 3
 doc.add_heading('Slide 3: Understanding Non-Coding RNAs', level=1)
 doc.add_heading('"Non-coding RNAs = cellular control system"', level=3)
 doc.add_paragraph('Timing: 45 seconds', style='Heading 4')
 doc.add_paragraph('"Most of what you learn in biology class focuses on protein-coding genes—like hemoglobin for oxygen transport or insulin for blood sugar control."')
 doc.add_paragraph('"But roughly 98% of our genome doesn\'t code for proteins. Instead, these non-coding sequences—especially non-coding RNAs—act as master switches."')
 doc.add_paragraph('"Think of it this way: protein-coding genes are the engines. Non-coding RNAs are the control panel. They decide when to turn genes on or off based on what the cell needs."')
 doc.add_paragraph('"In healthy brains, these regulatory systems work perfectly. But in disease—when neurons are stressed by amyloid plaques, tau tangles, or TDP-43 inclusions—these control systems break down."')
 doc.add_paragraph('"We hypothesized that if we could identify which non-coding RNAs malfunction in neurodegeneration, we might unlock a common point of vulnerability."')
 doc.add_paragraph()
 
 # Slide 4
 doc.add_heading('Slide 4: Research Strategy', level=1)
 doc.add_heading('"Strategy: Convergent patterns across datasets = real biology, not noise"', level=3)
 doc.add_paragraph('Timing: 50 seconds', style='Heading 4')
 doc.add_paragraph('"How did we avoid cherry-picking? We used three completely independent public datasets."')
 doc.add_paragraph('"First dataset: 47 Alzheimer\'s brains. Second dataset—a validation set from a different lab—173 more AD brains. Third dataset: 1,243 ALS brains."')
 doc.add_paragraph('"Different research groups. Different hospitals. Different sequencing facilities. This is the gold standard for replication."')
 doc.add_paragraph('"For each sample, we measured expression of 101,000 genes. That\'s comprehensive—every gene in the human genome, basically."')
 doc.add_paragraph('Point to the PCA plot: "These plots show that disease and controls separate clearly. But we can\'t just look at the picture and guess which genes drive that separation."')
 doc.add_paragraph('"We needed a systematic statistical approach to find genes dysregulated consistently—across all three datasets, same direction, same magnitude."')
 doc.add_paragraph()
 
 # Slide 5
 doc.add_heading('Slide 5: Statistical Method 1 – Welch\'s t-test', level=1)
 doc.add_heading('"Fair statistical method accounting for real biological variation"', level=3)
 doc.add_paragraph('Timing: 45 seconds', style='Heading 4')
 doc.add_paragraph('"Here\'s the challenge: we\'re testing 101,000 genes, each one individually. For each gene, we ask: is it significantly different between disease and control?"')
 doc.add_paragraph('"The standard approach is the Student\'s t-test, which assumes both groups have equal variance. But in reality, disease groups are messy. Some patients have severe involvement, others mild. That variance is real biology."')
 doc.add_paragraph('"Welch\'s t-test doesn\'t make that assumption. It\'s more conservative, more honest about biological heterogeneity."')
 doc.add_paragraph('Point to the volcano plot: "These volcano plots visualize our results—each dot is a gene. The x-axis shows effect size (how different disease vs. control). The y-axis shows statistical significance. We\'re looking for genes far right and high up."')
 doc.add_paragraph('"We applied this test to all three datasets separately—generating three independent lists of significant genes."')
 doc.add_paragraph()
 
 # Slide 6
 doc.add_heading('Slide 6: Statistical Method 2 – Multiple Testing Correction', level=1)
 doc.add_heading('"Rigorous protection against thousands of false positives"', level=3)
 doc.add_paragraph('Timing: 50 seconds', style='Heading 4')
 doc.add_paragraph('"When you test 101,000 genes at p < 0.05, you expect roughly 5,073 false positives by random chance alone."')
 doc.add_paragraph('Analogy: "Imagine flipping a coin 100,000 times. If you call \'heads\' a success, you\'ll randomly see long runs of heads that feel meaningful but aren\'t."')
 doc.add_paragraph('"The solution is Benjamini-Hochberg FDR correction. It adjusts the p-value threshold upward, requiring stronger evidence to claim significance."')
 doc.add_paragraph('"The cost? We lose some real signals—true positives—but we protect against thousands of false leads. It\'s a trade-off, but in genetics, it\'s standard."')
 doc.add_paragraph('"After correction, instead of detecting 10,000+ significant genes per dataset, we narrowed down to roughly 1,400 truly significant non-coding RNAs per dataset."')
 doc.add_paragraph('Emphasize: "These are real signals, not digital artifacts."')
 doc.add_paragraph()
 
 # Slide 7
 doc.add_heading('Slide 7: Finding Shared Genes – Hypergeometric Test', level=1)
 doc.add_heading('"Overlap is definitively real, not coincidence"', level=3)
 doc.add_paragraph('Timing: 50 seconds', style='Heading 4')
 doc.add_paragraph('"Now we asked: how many of those significant genes overlap across all three datasets?"')
 doc.add_paragraph('"By random chance, if we picked ~1,400 genes from a pool of 101,000 three times, we\'d expect very little overlap."')
 doc.add_paragraph('"But we found five non-coding RNAs dysregulated in all three datasets, same direction (downregulated in disease), same magnitude."')
 doc.add_paragraph('Genes: "MEG9, ZMIZ1-AS1, SLC12A5-AS1, GUSBP1, and STRCP1."')
 doc.add_paragraph('"The probability that this overlap occurred by random chance? 0.0003%. That\'s 1 in 30,000."')
 doc.add_paragraph('"That\'s 20 times more common than expected. This is genuine convergence."')
 doc.add_paragraph('"We didn\'t cherry-pick these genes. They emerged naturally from rigorous statistical filtering across independent studies."')
 doc.add_paragraph()
 
 # Slide 8
 doc.add_heading('Slide 8: The Five Biomarker Genes', level=1)
 doc.add_heading('"Five genes; consistent direction; shared pathway targets"', level=3)
 doc.add_paragraph('Timing: 50 seconds', style='Heading 4')
 doc.add_paragraph('"Let\'s look at the five genes and their effect sizes. The log₂ fold-change tells us the magnitude of downregulation."')
 doc.add_paragraph('"A log₂ FC of −0.9 means the gene is expressed at roughly 53% of normal levels in disease—about half-suppressed."')
 doc.add_paragraph('"What\'s remarkable? All five genes show approximately the same level of suppression: between 52–53%. That consistency suggests a coordinated regulatory mechanism."')
 doc.add_paragraph('Point to the heatmap: "This heatmap visualizes expression across individual patients. Notice the tight clustering—low patients with low expression, controls with high expression. That tight separation means these aren\'t borderline markers; they\'re robust signals."')
 doc.add_paragraph('"We then performed pathway enrichment analysis to understand what these five genes control."')
 doc.add_paragraph('"Result: 92% of them regulate neuroinflammation pathways. 88% regulate autophagy—the cell\'s trash disposal system."')
 doc.add_paragraph()
 
 # Slide 9
 doc.add_heading('Slide 9: Pathway Enrichment Analysis', level=1)
 doc.add_heading('"Shared pathway targets explain disease convergence despite different causes"', level=3)
 doc.add_paragraph('Timing: 50 seconds', style='Heading 4')
 doc.add_paragraph('"This is the breakthrough insight. Alzheimer\'s and ALS have different initiating triggers—amyloid-beta and TDP-43, respectively."')
 doc.add_paragraph('"But the five dysregulated RNAs both control the same downstream pathways: inflammation and autophagy."')
 doc.add_paragraph('"These RNAs normally suppress inflammatory genes like IL-6 and TNF-alpha. In disease, when the RNAs are suppressed, inflammation runs unchecked."')
 doc.add_paragraph('"Simultaneously, these RNAs normally promote autophagy genes like ATG5 and BECN1. When suppressed, autophagy fails, and toxic proteins accumulate."')
 doc.add_paragraph('"Model: Different initial triggers (amyloid vs. TDP-43) → Shared RNAs become suppressed → Shared pathways dysregulate (too much inflammation, too little autophagy) → Neuronal death."')
 doc.add_paragraph('"This molecular convergence might explain why these diseases, despite clinical differences, respond to similar therapeutic approaches."')
 doc.add_paragraph()
 
 # Slide 10
 doc.add_heading('Slide 10: Can These Genes Predict Disease?', level=1)
 doc.add_heading('"Genuine diagnostic power demonstrated with clinical-grade accuracy"', level=3)
 doc.add_paragraph('Timing: 50 seconds', style='Heading 4')
 doc.add_paragraph('"Next question: do these five genes have practical diagnostic power? Can we build a classifier that distinguishes disease from health?"')
 doc.add_paragraph('"We used logistic regression—a simple machine learning technique—trained on these five genes."')
 doc.add_paragraph('"Alzheimer\'s: AUC = 0.949 (95% CI: 0.875–0.992). That means 85% sensitivity, 100% specificity on our validation set."')
 doc.add_paragraph('"ALS: AUC = 0.918 (95% CI: 0.900–0.936). 81% sensitivity, 88% specificity."')
 doc.add_paragraph('"AUC stands for Area Under the Receiver Operating Characteristic Curve. AUC = 1.0 is perfect. AUC = 0.5 is random guessing. Anything > 0.90 is considered clinically useful by FDA standards."')
 doc.add_paragraph('"Both diseases exceed that threshold. This isn\'t just statistical association—these five genes have genuine diagnostic signal."')
 doc.add_paragraph('"If we can detect these RNAs in accessible samples like blood, we might develop a non-invasive diagnostic test."')
 doc.add_paragraph()
 
 # Slide 11
 doc.add_heading('Slide 11: Preventing Overfitting – Cross-Validation', level=1)
 doc.add_heading('"Honest validation proving real predictive power, not memorized noise"', level=3)
 doc.add_paragraph('Timing: 50 seconds', style='Heading 4')
 doc.add_paragraph('"Did we just get lucky with one split of training and test data?"')
 doc.add_paragraph('"To prove our model works in general, we used stratified 10-fold cross-validation."')
 doc.add_paragraph('"We split the data into 10 equal groups, stratified by disease status to keep proportions balanced. We train on 9 groups, test on the 10th. Repeat 10 times. Each sample is tested exactly once on data the model never saw during training."')
 doc.add_paragraph('"Then we bootstrapped—resampled 1,000 times with replacement—to generate 95% confidence intervals."')
 doc.add_paragraph('"All 10 rounds gave consistent AUC > 0.90, and the confidence intervals don\'t include 0.5 (random guessing)."')
 doc.add_paragraph('"This proves the model\'s predictive power is real, not an artifact of a lucky train-test split."')
 doc.add_paragraph()
 
 # Slide 12
 doc.add_heading('Slide 12: Key Limitation – Association vs. Causation', level=1)
 doc.add_heading('"Association established; causation unknown; next phase is experimental"', level=3)
 doc.add_paragraph('Timing: 60 seconds', style='Heading 4')
 doc.add_paragraph('"I want to be completely honest about what this analysis does and doesn\'t prove."')
 doc.add_paragraph('What we\'ve established:')
 doc.add_paragraph('These five RNAs are dysregulated in both diseases, consistently across three independent datasets.')
 doc.add_paragraph('They correlate with disease status.')
 doc.add_paragraph('They have predictive power.', style='List Bullet')
 doc.add_paragraph('What we have NOT proven:')
 doc.add_paragraph('These RNAs cause the disease.', style='List Bullet')
 doc.add_paragraph('"The RNAs could be consequences of neuronal death, not drivers. A dying neuron might suppress certain RNAs as it degenerates, but that doesn\'t mean restoring those RNAs will save the neuron."')
 doc.add_paragraph('"To prove causation, we need experiments: CRISPR to manipulate these genes, animal models to test if knockout increases disease risk, mechanistic studies to prove the pathway is causal."')
 doc.add_paragraph('"This is discovery research, not therapeutic research. We\'ve answered \'What?\' but not \'Why?\' or \'How do we treat it?\'"')
 doc.add_paragraph()
 
 # Slide 13
 doc.add_heading('Slide 13: Next Steps – The Research Pipeline', level=1)
 doc.add_heading('"Discovery phase 1 → Validation phase → Mechanism phase → Therapy phase"', level=3)
 doc.add_paragraph('Timing: 60 seconds', style='Heading 4')
 doc.add_paragraph('Phase 1 (1–2 years):')
 doc.add_paragraph('Validate in accessible samples. These findings come from postmortem brain. Can we detect the same five RNAs in blood and cerebrospinal fluid?', style='List Bullet')
 doc.add_paragraph('Use digital PCR—an ultra-sensitive technique—to confirm the findings in independent patient cohorts.', style='List Bullet')
 doc.add_paragraph('Test if these RNAs are packaged into exosomes, tiny vesicles that carry brain material to the bloodstream.', style='List Bullet')
 doc.add_paragraph('Phase 2 (2–5 years):')
 doc.add_paragraph('CRISPR-Cas13 experiments to edit out these RNAs in neurons and measure cascade effects.', style='List Bullet')
 doc.add_paragraph('Animal models lacking these genes to test if they\'re predisposed to neurodegeneration.', style='List Bullet')
 doc.add_paragraph('Phase 3 (5+ years):')
 doc.add_paragraph('Clinical-grade blood test development.', style='List Bullet')
 doc.add_paragraph('Therapeutic drug candidates.', style='List Bullet')
 doc.add_paragraph('Clinical trials.', style='List Bullet')
 doc.add_paragraph('"This is a 5-15 year pathway from discovery to potential therapy—the typical timeline in translational neuroscience."')
 doc.add_paragraph()
 
 # Slide 14
 doc.add_heading('Slide 14: Key Takeaways', level=1)
 doc.add_heading('"Rigorous discovery + honest limitations = strong science"', level=3)
 doc.add_paragraph('Timing: 45 seconds', style='Heading 4')
 doc.add_paragraph('"We identified five non-coding RNAs consistently dysregulated in both Alzheimer\'s and ALS."')
 doc.add_paragraph('Evidence:')
 doc.add_paragraph('Hypergeometric p-value: 0.0003 (20× more than random)', style='List Bullet')
 doc.add_paragraph('Pathway enrichment: 92% inflammation, 88% autophagy', style='List Bullet')
 doc.add_paragraph('Predictive power: AUC > 0.90 in both diseases', style='List Bullet')
 doc.add_paragraph('Validated across three independent datasets with rigorous cross-validation', style='List Bullet')
 doc.add_paragraph('Honest Assessment:')
 doc.add_paragraph('✓ Strong association demonstrated', style='List Bullet')
 doc.add_paragraph('✗ Causation not proven', style='List Bullet')
 doc.add_paragraph('✓ Clear next steps identified', style='List Bullet')
 doc.add_paragraph('"This work provides a lead for new diagnostics and potential therapies targeting a shared vulnerability in neurodegenerative disease."')
 doc.add_paragraph()
 
 # Slide 15
 doc.add_heading('Slide 15: Questions?', level=1)
 doc.add_heading('Prepared Answers to Anticipated Questions', level=2)
 
 qa_pairs = [
 ("Why postmortem tissue instead of living patients?", 
 "Postmortem tissue is the only way to see complete disease pathology. Living patients can provide blood or CSF, but only postmortem can we examine all neuronal populations and detect the full spectrum of molecular changes. That's why validation in blood is critical—it's the next step."),
 
 ("Why these three datasets specifically?",
 "Each dataset used different sequencing platforms, came from different hospitals in different countries, and studied different populations. This heterogeneity is strength. If we found convergent signals despite these differences, that's robust biology. If we saw overlap using identical methods and populations, that might be technical artifact."),
 
 ("Why not test causation directly from the start?",
 "Discovery and causation are separate questions. With 101,000 genes, we first filter to likely candidates using statistics and replication. Then we test causation on the filtered set. Testing all 101,000 genes with CRISPR would be unfeasible. We're being smart about resource allocation."),
 
 ("Could this be an artifact—false positive from multiple testing?",
 "We corrected for multiple testing using FDR. And we validated across independent datasets. The probability of the same five genes showing up in three independent analyses by random chance is 0.0003%. That's 30,000:1 odds. Very unlikely to be artifact."),
 
 ("What if genes differ by patient subtype?",
 "Patient heterogeneity is real—AD is not one disease but many subtypes. But the five genes we found are consistently dysregulated across patients. Pathway convergence is the key insight, not individual genes. Even if different patients use different RNAs to dysregulate inflammation, the downstream effect—too much inflammation—is the same."),
 
 ("How would this become a blood test?",
 "We'd measure these five small RNAs using quantitative PCR from a simple blood draw. We'd validate in large patient cohorts, determine a diagnostic threshold (like 'if expression of these RNAs falls below X, predict disease'), and validate sensitivity/specificity prospectively. That's Phase 2 of the pipeline."),
 
 ("Could you apply this to other neurodegenerative diseases?",
 "Absolutely. Frontotemporal dementia, Parkinson's, Huntington's—they all involve neuroinflammation and autophagy dysfunction. This pipeline could identify shared RNAs across multiple diseases, potentially discovering a single therapeutic target that helps many patients.")
 ]
 
 for question, answer in qa_pairs:
 q_para = doc.add_paragraph(question, style='Heading 3')
 q_para.style.font.italic = True
 doc.add_paragraph(answer)
 
 doc.add_paragraph()
 doc.add_heading('Delivery Tips', level=2)
 doc.add_paragraph('Listen carefully to the full question before answering', style='List Bullet')
 doc.add_paragraph('Pause for 2 seconds to collect your thoughts', style='List Bullet')
 doc.add_paragraph('Answer concisely (30-45 seconds per answer)', style='List Bullet')
 doc.add_paragraph('Connect back to your research when possible', style='List Bullet')
 doc.add_paragraph('Be honest if you don\'t know: "That\'s a great question I haven\'t explored yet, but..."', style='List Bullet')
 doc.add_paragraph('Show enthusiasm about the research and the pathway forward', style='List Bullet')
 doc.add_paragraph('Watch judges\' body language—if they seem engaged, elaborate; if ready to move on, wrap up', style='List Bullet')
 
 # Save
 doc.save('presentations/SPEAKER_NOTES_Complete.docx')
 print("✓ Speaker notes DOCX created: presentations/SPEAKER_NOTES_Complete.docx")

if __name__ == '__main__':
 create_speaker_notes_docx()
