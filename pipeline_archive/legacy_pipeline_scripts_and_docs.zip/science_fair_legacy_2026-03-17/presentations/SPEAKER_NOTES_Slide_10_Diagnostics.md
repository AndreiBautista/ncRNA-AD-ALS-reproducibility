# Slide 10: Can These Genes Predict Disease?
**"Genuine diagnostic power demonstrated with clinical-grade accuracy"**

## Timing
50 seconds

## Notes
- "Next question: do these five genes have practical diagnostic power? Can we build a classifier that distinguishes disease from health?"
- "We used logistic regression—a simple machine learning technique—trained on these five genes."
- State the results: "Alzheimer's: AUC = 0.949 (95% CI: 0.875–0.992). That means 85% sensitivity, 100% specificity on our validation set."
- "ALS: AUC = 0.918 (95% CI: 0.900–0.936). 81% sensitivity, 88% specificity."
- Explain AUC: "AUC stands for Area Under the Receiver Operating Characteristic Curve. AUC = 1.0 is perfect. AUC = 0.5 is random guessing. Anything > 0.90 is considered clinically useful by FDA standards."
- "Both diseases exceed that threshold. This isn't just statistical association—these five genes have genuine diagnostic signal."
- Implication: "If we can detect these RNAs in accessible samples like blood, we might develop a non-invasive diagnostic test."

## Key Points
- Explain the test setup: logistic regression on five genes
- State specific AUC values and confidence intervals
- Translate AUC: 0.5 = random, 1.0 = perfect, > 0.90 = clinical grade
- Emphasize: exceeds FDA diagnostic threshold
- Turn to practical application: blood test potential
- Point to ROC curve visuals showing the curves
