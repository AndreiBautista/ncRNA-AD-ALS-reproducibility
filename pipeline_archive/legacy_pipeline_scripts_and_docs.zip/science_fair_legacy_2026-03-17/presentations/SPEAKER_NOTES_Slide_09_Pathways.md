# Slide 9: Pathway Enrichment Analysis
**"Shared pathway targets explain disease convergence despite different causes"**

## Timing
50 seconds

## Notes
- "This is the breakthrough insight. Alzheimer's and ALS have different initiating triggers—amyloid-beta and TDP-43, respectively."
- "But the five dysregulated RNAs both control the same downstream pathways: inflammation and autophagy."
- Explain the mechanism: "These RNAs normally suppress inflammatory genes like IL-6 and TNF-alpha. In disease, when the RNAs are suppressed, inflammation runs unchecked."
- "Simultaneously, these RNAs normally promote autophagy genes like ATG5 and BECN1. When suppressed, autophagy fails, and toxic proteins accumulate."
- "So the model: Different initial triggers (amyloid vs. TDP-43) → Shared RNAs become suppressed → Shared pathways dysregulate (too much inflammation, too little autophagy) → Neuronal death."
- "This molecular convergence might explain why these diseases, despite clinical differences, respond to similar therapeutic approaches."

## Key Points
- Contrast different triggers (amyloid vs. TDP-43)
- Show convergence at RNA level
- Explain mechanism: RNAs suppress inflammation genes; when RNAs suppressed, inflammation increases
- Draw the causal model: trigger → RNA suppression → pathway dysregulation → neuronal death
- Highlight the therapeutic implication: shared mechanism = potential for shared treatment
- Use the figure to point to specific pathways
