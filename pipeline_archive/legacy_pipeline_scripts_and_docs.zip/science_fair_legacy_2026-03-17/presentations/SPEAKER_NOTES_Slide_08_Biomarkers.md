# Slide 8: The Five Biomarker Genes
**"Five genes; consistent direction; shared pathway targets"**

## Timing
50 seconds

## Notes
- "Let's look at the five genes and their effect sizes. The log₂ fold-change tells us the magnitude of downregulation."
- Explain log₂ FC: "A log₂ FC of −0.9 means the gene is expressed at roughly 53% of normal levels in disease—about half-suppressed."
- "What's remarkable? All five genes show approximately the same level of suppression: between 52–53%. That consistency suggests a coordinated regulatory mechanism."
- Point to the heatmap: "This heatmap visualizes expression across individual patients. Notice the tight clustering—low patients with low expression, controls with high expression. That tight separation means these aren't borderline markers; they're robust signals."
- "We then performed pathway enrichment analysis to understand what these five genes control."
- "Result: 92% of them regulate neuroinflammation pathways. 88% regulate autophagy—the cell's trash disposal system."

## Key Points
- Translate log₂ FC (−0.9 = 53% of normal = ~half-suppressed)
- Emphasize consistency across genes (52–53% range)
- Interpret heatmap: tight clustering = robust signal
- Connect to pathway analysis preview
- Show table with specific numbers
- Highlight the surprise: coordinated suppression suggests common mechanism
