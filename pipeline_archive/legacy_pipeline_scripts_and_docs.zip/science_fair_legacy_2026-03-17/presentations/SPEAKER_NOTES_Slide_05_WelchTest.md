# Slide 5: Statistical Method 1 – Welch's t-test
**"Fair statistical method accounting for real biological variation"**

## Timing
45 seconds

## Notes
- "Here's the challenge: we're testing 101,000 genes, each one individually. For each gene, we ask: is it significantly different between disease and control?"
- "The standard approach is the Student's t-test, which assumes both groups have equal variance. But in reality, disease groups are messy. Some patients have severe involvement, others mild. That variance is real biology."
- "Welch's t-test doesn't make that assumption. It's more conservative, more honest about biological heterogeneity."
- Point to the volcano plot: "These volcano plots visualize our results—each dot is a gene. The x-axis shows effect size (how different disease vs. control). The y-axis shows statistical significance. We're looking for genes far right and high up."
- "We applied this test to all three datasets separately—generating three independent lists of significant genes."

## Key Points
- Explain why standard t-test doesn't work (assumes equal variance)
- Show how Welch's handles real-world messiness
- Use volcano plot visual: point to dots, axes
- Emphasize: applied separately to each dataset
- Connect to biological reality (heterogeneous patients)
