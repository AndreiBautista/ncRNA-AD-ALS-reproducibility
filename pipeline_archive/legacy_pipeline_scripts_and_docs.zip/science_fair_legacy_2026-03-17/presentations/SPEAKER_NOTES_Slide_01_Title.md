# Slide 1: Title Slide
**Shared Non-Coding RNA Dysregulation Across Neurodegenerative Diseases**

## Timing
15 seconds

## Notes
- Open with confidence and establish the scope immediately
- "Hello. My name is Austin Bautista, and today I'm presenting research on shared molecular pathways in Alzheimer's disease and ALS."
- "We analyzed 1,463 postmortem brain samples using computational biology to identify non-coding RNAs that become dysregulated in both diseases."
- Emphasize: This is big data analysis (1,463 samples) combined with rigorous statistics.
- Pause for 2-3 seconds after introducing yourself to let judges know you're ready.

## Key Points
- Establish credibility immediately (your name, research scope)
- Use number anchors (1,463 samples) to demonstrate scale
- Show enthusiasm for the intersection of computation + neurobiology
