# Slide 13: Next Steps – The Research Pipeline
**"Discovery phase 1 → Validation phase → Mechanism phase → Therapy phase"**

## Timing
60 seconds

## Notes
- "So what comes next? We've identified candidate biomarkers. The pipeline has four phases."
- **Phase 1 (1–2 years):** "First, we validate in accessible samples. These findings come from postmortem brain. Can we detect the same five RNAs in blood and cerebrospinal fluid?"
- "We'll use digital PCR—an ultra-sensitive technique—to confirm the findings in independent patient cohorts."
- "We'll test if these RNAs are packaged into exosomes, tiny vesicles that carry brain material to the bloodstream. This would explain how brain signals reach the blood."
- **Phase 2 (2–5 years):** "Next, we prove mechanism. CRISPR-Cas13 experiments to edit out these RNAs in neurons and measure cascade effects. Animal models lacking these genes to test if they're predisposed to neurodegeneration."
- **Phase 3 (5+ years):** "Finally, translation. Clinical-grade blood test development. Identification of drugs that restore these RNAs. Clinical trials."
- "This is a 5-15 year pathway from discovery to potential therapy—the typical timeline in translational neuroscience."

## Key Points
- Break into clear phases with timelines
- Explain each phase's objectives
- Use specific techniques: digital PCR, exosomes, CRISPR-Cas13
- Show progression: blood validation → mechanism → translation to therapy
- Set realistic expectations (5-15 years)
- Emphasize each phase is separate, rigorous, and necessary
- End with perspective on typical neuroscience timeline
