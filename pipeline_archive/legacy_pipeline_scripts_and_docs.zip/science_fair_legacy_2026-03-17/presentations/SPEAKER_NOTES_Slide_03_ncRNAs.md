# Slide 3: Understanding Non-Coding RNAs
**"Non-coding RNAs = cellular control system"**

## Timing
45 seconds

## Notes
- "Most of what you learn in biology class focuses on protein-coding genes—like hemoglobin for oxygen transport or insulin for blood sugar control."
- "But roughly 98% of our genome doesn't code for proteins. Instead, these non-coding sequences—especially non-coding RNAs—act as master switches."
- "Think of it this way: protein-coding genes are the engines. Non-coding RNAs are the control panel. They decide when to turn genes on or off based on what the cell needs."
- "In healthy brains, these regulatory systems work perfectly. But in disease—when neurons are stressed by amyloid plaques, tau tangles, or TDP-43 inclusions—these control systems break down."
- "We hypothesized that if we could identify which non-coding RNAs malfunction in neurodegeneration, we might unlock a common point of vulnerability."

## Key Points
- Use relatable analogy (engines vs. control panel)
- Explain percentage (98% non-coding) to show it's major part of genome
- Connect to disease mechanism (stress → control system breakdown)
- Set up hypothesis for why this matters
