# Presentation Delivery Guide

## Timing Breakdown (7–8 minutes total)

| Slide | Title | Timing | Cumulative |
|-------|-------|--------|-----------|
| Title | Opening | 15 sec | 0:15 |
| 1 | The Problem | 50 sec | 1:05 |
| 2 | What Are ncRNAs? | 60 sec | 2:05 |
| 3 | My Approach | 45 sec | 2:50 |
| 4 | Welch's t-test | 55 sec | 3:45 |
| 5 | FDR Correction | 50 sec | 4:35 |
| 6 | Hypergeometric Test | 60 sec | 5:35 |
| 7 | Five Biomarkers | 40 sec | 6:15 |
| 8 | Machine Learning & AUC | 50 sec | 7:05 |
| 9 | Cross-Validation | 45 sec | 7:50 |
| 10 | Limitations | 60 sec | 8:50 |
| 11 | Next Steps | 50 sec | 9:40 |
| 12 | Key Takeaways | 40 sec | 10:20 |
| Q&A | Questions | 1–2 min | 11:20–12:20 |

**Target: 10–11 minutes with a natural pace leaves room for judge questions.**

---

## Delivery Tips – Sound Confident Without Overconfidence

### Before You Start
1. **Pause and breathe** before speaking
2. **Look at judges** not the screen
3. **Stand still** – avoid swaying or pacing
4. **Let your hands rest** until you naturally gesture

### Tone & Pacing
- **Slow down on technical terms** (Benjamini-Hochberg, hypergeometric, AUC)
- **Speed up slightly on familiar concepts** (genes, disease, samples)
- **Pause for 1 second after stating a key finding** (gives it weight)
- **Use "and" not "um"** – when you pause, just pause silently

### Personality Without Hype
- ✅ "This is a striking pattern" → conveys excitement, academic
- ❌ "This is mind-blowing" → sounds immature
- ✅ "This is statistically unlikely" → lets data speak
- ❌ "We crushed this" → undermines rigor
- ✅ "I need to be honest about what I don't know" → shows maturity
- ❌ "I'm pretty sure we figured it out" → sounds uncertain

### When Judge Interrupts
1. **Stop mid-sentence** – show you're listening
2. **Answer the question completely** – don't rush back to slides
3. **Ask "Does that answer your question?"** – checks understanding
4. **Return to the slide naturally** – "As I was saying..."

---

## Pronunciation Guide

**Gene Names (judges will definitely ask you to repeat these):**
- MEG9 → "M-E-G nine"
- ZMIZ1-AS1 → "ZMIZ-one, A-S one" (or just use numbers)
- SLC12A5-AS1 → "SLC twelve A five, A-S one"
- GUSBP1 → "GUSBP one"
- STRCP1 → "STRCP one"

**Statistical Terms:**
- Welch's t-test → "Welch'" (rhymes with "wet each")
- Benjamini-Hochberg → "Ben-YAH-mee-nee HOH-berg"
- Hypergeometric → "HY-per-gee-uh-MET-rik"
- FDR → "F-D-R" or "False Discovery Rate"
- AUC → "A-U-C" or "Area Under the Curve"
- Cross-validation → "cross val-uh-DAY-shun"

---

## Handling Nervousness

**Physical symptoms + Solutions:**
- **Shaky hands** → Hold the podium/table edge; holds you steady
- **Racing heart/mouth dry** → Pause between slides, take sips of water
- **Mind goes blank** → You have speaker notes on cards; refer to them confidently
- **Voice cracks** → Completely normal; power through with confidence

**Mental resets:**
- If you stumble: "Let me say that again more clearly"
- If you lose your place: "I want to make sure I'm covering the important concepts—let me circle back"
- If judge asks something unexpected: "That's a really good question. Let me think through that..."

---

## Slide Highlighting Strategy

**Slides judges will spend most time on:**

1. **Slide 6 (Hypergeometric Test)** – Judges want to understand the overlap
 - **Have ready:** "1 in 33,000 chance by random probability"
 - **Analogy:** "Finding the same five genes dysregulated in two diseases is like two doctors independently diagnosing the same exact rare condition"

2. **Slide 8 (Machine Learning & AUC)** – Judges want to know if this is clinically useful
 - **Have ready:** Sensitivity/specificity trade-offs
 - **Emphasis:** "This is discovery research, not a finished clinical test"

3. **Slide 10 (Limitations)** – Judges respect honesty more than claiming everything is perfect
 - **Have ready:** "Association vs. causation" explanation
 - **Emphasis:** "I know what I don't know"

---

## Practice Script – Full 7-Minute Run-Through

**Practice out loud, time yourself, then do it again:**

"Good morning, judges. I'm Austin Bautista, and my project explores shared molecular mechanisms underlying two very different neurodegenerative diseases: Alzheimer's disease and amyotrophic lateral sclerosis, or ALS.

Here's the question I started with: These are distinct diseases—different symptoms, different genetics. But inside the brain, could they be more similar than we think? Specifically, could the same genes be dysregulated in both? The motivation was dual: understanding disease mechanisms and potentially identifying biomarkers that work across diseases.

To answer this, I analyzed RNA sequencing data—a snapshot of which genes are being expressed—from 1,463 postmortem brain samples. I downloaded these from three public repositories in the Gene Expression Omnibus. The datasets included 47 Alzheimer's brains, 173 different Alzheimer's brains for validation, and 1,243 ALS brains.

For each dataset, I measured the expression of over 101,000 genes in disease samples versus healthy control samples. To decide which genes showed real differences, I used a statistical test called Welch's t-test. This test compares average expression between two groups while accounting for how spread out each group is. It gives me a p-value for each gene—basically, the probability that the difference I'm seeing happened by random chance.

But there's a problem: I tested 101,000 genes. By random chance alone, I'd expect thousands to pass my significance threshold. So I applied a correction called Benjamini-Hochberg FDR correction. This looks at all my tests and adjusts the cutoff so that only truly significant genes pass. After this correction, I had approximately 1,400 significantly dysregulated non-coding RNAs.

Now here's the key question: Do the same genes appear dysregulated in all three datasets? I found five: MEG9, ZMIZ1-AS1, SLC12A5-AS1, GUSBP1, and STRCP1. That seems like it could be coincidence. So I used a hypergeometric test to ask: what's the probability of finding five or more shared genes by random chance? The answer: 0.0003 percent—that's 1 in 33,000. This overlap is far too large to be random.

What makes this even more interesting is what these five genes do. Pathway analysis showed that 92% of them regulate genes involved in neuroinflammation—immune activation in the brain—and 88% regulate autophagy, the cell's trash-disposal system. Both systems are broken in neurodegenerative disease. So these aren't random genes; they're genes that control the exact processes that fail in both diseases.

At this point, I had a strong candidate biomarker signature. But could I actually use it to diagnose disease? I built a machine learning classifier—a logistic regression model—using just these five genes. I trained it on part of the data and tested it on data the classifier had never seen. The evaluation metric is called AUC, or Area Under the Curve. It ranges from 0.5, which is random guessing, to 1.0, which is perfect prediction. In real medicine, over 0.90 is the gold standard. My classifier achieved 0.949 for Alzheimer's disease and 0.918 for ALS. Both exceed the clinical threshold.

To make sure this wasn't just memorization, I used cross-validation. I split the data into 10 pieces, trained on 9, and tested on the 10th. I repeated this so every sample was tested exactly once on data the classifier hadn't seen. The results were consistent.

Now I need to be honest about what I haven't proven. These findings come from brain tissue, but we can't biopsy living brains for diagnosis. Blood biomarkers are the goal, but I haven't validated these genes in blood yet. Second, I found association: these genes are dysregulated in disease. That doesn't prove they cause the disease. They could be consequences of neuronal damage. Proving causation requires experimental studies—CRISPR gene editing, animal models. Third, neurodegeneration involves selective neuron death. Some of the apparent ncRNA suppression could reflect cell loss, not just lower expression within surviving cells. These aren't flaws in my work—they're honest limitations that point to future research.

The next steps are clear: validate these genes in blood plasma and cerebrospinal fluid, run experimental studies to test causation, and expand to other neurodegenerative diseases. If this pattern holds up, we might be able to detect neurodegeneration earlier and develop treatments that work across multiple diseases.

In summary, I've identified five non-coding RNA biomarkers shared across Alzheimer's and ALS. This overlap is statistically robust, functionally meaningful, and predictively strong. It suggests that despite their clinical differences, these diseases converge at the molecular level. This is discovery research—early-stage, honest about limitations, but pointing toward real clinical applications if subsequent validation succeeds."

---

**Read time: ~8 minutes**

---

## Energy Management During Presentation

**Minutes 0–2:** Energy high, pace moderate – introduce problem clearly 
**Minutes 2–4:** Energy maintained, pace steady – explain statistics (judges checking for understanding) 
**Minutes 4–6:** Energy stable, small gestures – show data and results 
**Minutes 6–8:** Energy reflective, slower pace – limitations and next steps (judges assessing maturity) 

**If you feel energy dropping:** Smile, pause, then reset. Judges appreciate the restart.

---

## Red Flags to Avoid

- ❌ Reading directly from slides (judges can see those)
- ❌ Saying "basically" or "I think" constantly (shows uncertainty)
- ❌ Ignoring judges who look confused (ask if they want clarification)
- ❌ Rushing through limitations (spend time here—judges respect it)
- ❌ Using jargon without explaining it first
- ❌ Claiming your work is "the first" or "revolutionary" without evidence
- ❌ Defensive tone when asked tough questions

---

## Green Flags That Show Maturity

- ✅ Saying "That's a great question" genuinely
- ✅ Pausing to think before answering
- ✅ Using "I don't know, but here's how I'd test it"
- ✅ Acknowledging ambiguity in results
- ✅ Explaining trade-offs (sensitivity vs. specificity)
- ✅ Clearly separating discovery from clinical application
- ✅ Speaking with quiet confidence, not loudness

---

## One Week Before 

**Day 5 before:**
- Record yourself presenting
- Watch the recording and note:
 - Where you pause too long
 - Where you rush
 - Unclear explanations
- Re-record specific sections

**Day 3 before:**
- Present to two people you trust
- Have them ask questions from the judge Q&A list
- Time yourself

**Day 1 before:**
- Light review of notes
- Get good sleep
- Eat a proper breakfast
- Arrive early to your booth

**Morning of:**
- Don't over-prepare
- Take deep breaths
- Remember: judges want you to succeed

---

## You've Got This

This project is solid. Your data is real. Your statistics are sound. Your limitations are honest. Judges respond to that. Speak clearly, answer directly, and let the work speak for itself.

When you walk into that booth, you're not defending your work—you're sharing a discovery. That's a fundamentally different energy, and judges feel it.
