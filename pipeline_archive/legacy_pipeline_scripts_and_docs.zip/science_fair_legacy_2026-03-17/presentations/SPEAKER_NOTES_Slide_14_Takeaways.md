# Slide 14: Key Takeaways
**"Rigorous discovery + honest limitations = strong science"**

## Timing
45 seconds

## Notes
- "Let me summarize the key findings:"
- "We identified five non-coding RNAs consistently dysregulated in both Alzheimer's and ALS."
- "Evidence: Hypergeometric p-value of 0.0003. Pathway analysis showing 92% regulate inflammation, 88% regulate autophagy. Predictive power exceeding FDA diagnostic standards (AUC > 0.90). Validation across three independent datasets with rigorous cross-validation."
- "Honest assessment: We've shown strong association. We haven't proven causation. We have clear next steps."
- "Why should you care? This work provides a lead for new diagnostics and potential therapies targeting a shared vulnerability in neurodegenerative disease."

## Key Points
- Keep it concise: this is the final summary
- Anchor with key statistics: p-value, pathway percentages, AUC
- Emphasize: strong association, not causation
- Show impact: diagnostics + potential therapies
- End on forward-looking note
- Connect to clinical/therapeutic relevance
