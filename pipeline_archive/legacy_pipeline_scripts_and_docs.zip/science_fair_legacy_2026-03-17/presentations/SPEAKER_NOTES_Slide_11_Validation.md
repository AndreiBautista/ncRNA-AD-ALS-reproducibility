# Slide 11: Preventing Overfitting – Cross-Validation
**"Honest validation proving real predictive power, not memorized noise"**

## Timing
50 seconds

## Notes
- "But here's the skepticism we anticipated: Did we just get lucky with one split of training and test data?"
- "To prove our model works in general, not just on this specific dataset, we used stratified 10-fold cross-validation."
- Explain the method: "We split the data into 10 equal groups, stratified by disease status to keep proportions balanced. We train on 9 groups, test on the 10th. Repeat 10 times. Each sample is tested exactly once on data the model never saw during training."
- "Then we bootstrapped—resampled 1,000 times with replacement—to generate 95% confidence intervals."
- "The result? All 10 rounds gave consistent AUC > 0.90, and the confidence intervals don't include 0.5 (random guessing)."
- "This proves the model's predictive power is real, not an artifact of a lucky train-test split."

## Key Points
- Address the skepticism head-on: "Did we just get lucky?"
- Explain 10-fold CV step-by-step (stratified, repeated)
- Explain bootstrap (1,000 resamples)
- State the result: consistent AUC > 0.90 across all folds
- Point out: confidence intervals don't include 0.5
- Drive home: this is genuine predictive power
