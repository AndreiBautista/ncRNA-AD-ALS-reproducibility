# Slide 15: Questions?
**Final talking points (if asked)**

## Timing
2-3 minutes (or longer if judges are engaged)

## Prepared Answers to Anticipated Questions

### Q: Why postmortem tissue instead of living patients?
**A:** "Postmortem tissue is the only way to see complete disease pathology. Living patients can provide blood or CSF, but only postmortem can we examine all neuronal populations and detect the full spectrum of molecular changes. That's why validation in blood is critical—it's the next step."

### Q: Why these three datasets specifically?
**A:** "Each dataset used different sequencing platforms, came from different hospitals in different countries, and studied different populations. This heterogeneity is strength. If we found convergent signals despite these differences, that's robust biology. If we saw overlap using identical methods and populations, that might be technical artifact."

### Q: Why not test causation directly from the start?
**A:** "Discovery and causation are separate questions. With 101,000 genes, we first filter to likely candidates using statistics and replication. Then we test causation on the filtered set. Testing all 101,000 genes with CRISPR would be unfeasible. We're being smart about resource allocation."

### Q: Could this be an artifact—false positive from multiple testing?
**A:** "We corrected for multiple testing using FDR. And we validated across independent datasets. The probability of the same five genes showing up in three independent analyses by random chance is 0.0003%. That's 30,000:1 odds. Very unlikely to be artifact."

### Q: What if genes differ by patient subtype?
**A:** "Great question. Patient heterogeneity is real—AD is not one disease but many subtypes. But the five genes we found are consistently dysregulated across patients. And pathway convergence is the key insight, not individual genes. Even if different patients use different RNAs to dysregulate inflammation, the downstream effect—too much inflammation—is the same."

### Q: How would this become a blood test?
**A:** "We'd measure these five small RNAs using quantitative PCR from a simple blood draw. We'd validate in large patient cohorts, determine a diagnostic threshold (like 'if expression of these RNAs falls below X, predict disease'), and validate sensitivity/specificity prospectively. That's Phase 2 of the pipeline."

### Q: Could you apply this to other neurodegenerative diseases?
**A:** "Absolutely. Frontotemporal dementia, Parkinson's, Huntington's—they all involve neuroinflammation and autophagy dysfunction. This pipeline could identify shared RNAs across multiple diseases, potentially discovering a single therapeutic target that helps many patients."

## Delivery Tips
- **Listen carefully** to the full question before answering
- **Pause for 2 seconds** to collect your thoughts
- **Answer concisely** (30-45 seconds per answer)
- **Connect back** to your research when possible
- **Be honest** if you don't know: "That's a great question I haven't explored yet, but..."
- **Show enthusiasm** about the research and the pathway forward
- **Watch judges' body language** — if they seem engaged, elaborate; if they're ready to move on, wrap up
