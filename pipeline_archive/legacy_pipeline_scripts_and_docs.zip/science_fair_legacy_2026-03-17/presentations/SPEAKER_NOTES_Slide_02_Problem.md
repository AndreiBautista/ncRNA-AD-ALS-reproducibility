# Slide 2: The Problem
**"Two distinct diseases may converge at molecular level"**

## Timing
45 seconds

## Notes
- Start by humanizing the problem: "Alzheimer's disease and ALS are devastating neurodegenerative diseases. They look different clinically—AD affects memory, ALS affects motor neurons—but both cause progressive brain degeneration."
- "The central question driving this project: Do they share hidden molecular mechanisms despite their clinical differences?"
- Point to the PCA plot on the right: "This visualization comes from one of our datasets. You can see disease clustering—but that's after measuring 101,000 genes. The real challenge is finding which genes matter and which are just noise."
- "Current diagnostics are either invasive—requiring lumbar punctures to sample cerebrospinal fluid—or arrive too late, like post-mortem confirmation."
- Conclusion: "So we asked: can we identify shared molecular markers that distinguish disease from health, and could those become blood-based biomarkers?"

## Key Points
- Humanize the diseases (mention specific symptoms)
- Show the clinical unmet need (invasive diagnostics, late diagnosis)
- Use the visual: point to the PCA plot clustering
- Frame the central research question clearly
