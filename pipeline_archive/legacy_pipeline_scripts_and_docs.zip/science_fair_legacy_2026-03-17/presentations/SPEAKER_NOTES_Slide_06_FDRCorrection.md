# Slide 6: Statistical Method 2 – Multiple Testing Correction
**"Rigorous protection against thousands of false positives"**

## Timing
50 seconds

## Notes
- "Now here's the catch: when you test 101,000 genes at p < 0.05, you expect roughly 5,073 false positives by random chance alone."
- Use an analogy: "Imagine flipping a coin 100,000 times. If you call 'heads' a success, you'll randomly see long runs of heads that feel meaningful but aren't."
- "The solution is Benjamini-Hochberg FDR correction. It adjusts the p-value threshold upward, requiring stronger evidence to claim significance."
- "The cost? We lose some real signals—true positives—but we protect against thousands of false leads. It's a trade-off, but in genetics, it's standard."
- "After correction, instead of detecting 10,000+ significant genes per dataset, we narrowed down to roughly 1,400 truly significant non-coding RNAs per dataset."
- Emphasize: "These are real signals, not digital artifacts."

## Key Points
- State the problem clearly (5,073 expected false positives)
- Use coin-flip analogy for relatability
- Explain FDR correction conceptually (not the math)
- Acknowledge the trade-off (lose true positives to avoid false positives)
- Show the dramatic reduction (10,000+ to 1,400)
- Emphasize rigor and conservatism
