# Slide 7: Finding Shared Genes – Hypergeometric Test
**"Overlap is definitively real, not coincidence"**

## Timing
50 seconds

## Notes
- "Now we asked: how many of those significant genes overlap across all three datasets?"
- "By random chance, if we picked ~1,400 genes from a pool of 101,000 three times, we'd expect very little overlap."
- "But we found five non-coding RNAs dysregulated in all three datasets, same direction (downregulated in disease), same magnitude."
- List the genes: "MEG9, ZMIZ1-AS1, SLC12A5-AS1, GUSBP1, and STRCP1."
- State the statistic: "The probability that this overlap occurred by random chance? 0.0003%. That's 1 in 30,000."
- "To put that in perspective: that's 20 times more common than expected. This is genuine convergence."
- Drive home the point: "We didn't cherry-pick these genes. They emerged naturally from rigorous statistical filtering across independent studies."

## Key Points
- Explain the null hypothesis: random overlap would be minimal
- List the five genes (helps judges remember)
- State the p-value clearly: 0.0003% = 1 in 30,000
- Use perspective: "20 times more common than expected"
- Emphasize: emerged naturally, not cherry-picked
- Point to Venn diagram visual
