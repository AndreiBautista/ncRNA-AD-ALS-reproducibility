# Slide 4: Research Strategy
**"Strategy: Convergent patterns across datasets = real biology, not noise"**

## Timing
50 seconds

## Notes
- "How did we avoid cherry-picking? We used three completely independent public datasets."
- Break down the numbers: "First dataset: 47 Alzheimer's brains. Second dataset—a validation set from a different lab—173 more AD brains. Third dataset: 1,243 ALS brains."
- "Different research groups. Different hospitals. Different sequencing facilities. This is the gold standard for replication."
- "For each sample, we measured expression of 101,000 genes. That's comprehensive—every gene in the human genome, basically."
- Point to the PCA plot: "These plots show that disease and controls separate clearly. But we can't just look at the picture and guess which genes drive that separation."
- "We needed a systematic statistical approach to find genes dysregulated consistently—across all three datasets, same direction, same magnitude."

## Key Points
- Emphasize independence: different labs, hospitals, sequencing platforms
- Explain the scale (101,000 genes per sample)
- Show the visual clustering (disease vs. control separation)
- Explain why visual inspection is insufficient (need statistics)
- Use specific numbers to anchor credibility
