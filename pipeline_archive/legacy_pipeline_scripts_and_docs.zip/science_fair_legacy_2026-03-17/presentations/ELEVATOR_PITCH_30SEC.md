# Presentation: 30-Second Elevator Pitch

## 30-Second Version (Judge version—calm, confident):

"I analyzed RNA sequencing data from 1,463 postmortem brains to ask whether Alzheimer's disease and ALS, two distinct diseases, share dysregulated genes. I found five non-coding RNAs—regulatory molecules—that are consistently suppressed in both diseases. The odds of this overlap are 1 in 33,000. These genes control cellular processes that fail in both diseases: immune response and protein clearance. Using just these five RNAs, I built a classifier that correctly identifies diseased brains 92% of the time. My work suggests that despite their clinical differences, these diseases might converge at the molecular level, pointing toward shared diagnostic or therapeutic targets."

---

## Word count: 95 words 
## Time: ~30 seconds when spoken at natural pace

---

## Optional: 60-Second Extended Version

"I analyzed RNA sequencing data from 1,463 postmortem brain samples across three independent datasets to ask whether Alzheimer's disease and amyotrophic lateral sclerosis, despite appearing as distinct diseases, might share dysregulated genes. Using rigorous statistical testing with FDR correction to control for false positives, I identified nearly 1,400 significantly dysregulated non-coding RNAs. When I looked for genes dysregulated in all three datasets, I found five: MEG9, ZMIZ1-AS1, SLC12A5-AS1, GUSBP1, and STRCP1. A hypergeometric test showed this overlap has a p-value of 0.0003, meaning it's 20 times more common than random chance would predict. Importantly, these five genes regulate the exact cellular pathways that fail in neurodegeneration: neuroinflammation and autophagy. Building a machine learning classifier using just these five RNAs, I achieved an AUC of 0.949 in Alzheimer's disease and 0.918 in ALS, exceeding the 0.90 threshold for clinical-grade diagnostics. While my work demonstrates association and predictive value, I emphasize that proving causation requires experimental validation. This discovery suggests that despite their clinical distinction, these diseases may share common regulatory defects, opening the door to shared diagnostic and potential therapeutic approaches."

---

## Word count: 233 words 
## Time: ~55–65 seconds when spoken at natural pace
