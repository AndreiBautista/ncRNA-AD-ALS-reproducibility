# Speaker Notes – Presentation (7 minutes)

## Slide 1: Title Slide
**Shared Non-Coding RNA Dysregulation Across Neurodegenerative Diseases**

**Timing:** 15 seconds

**Notes:**
- Open with confidence and establish the scope immediately
- "Hello. My name is Austin Bautista, and today I'm presenting research on shared molecular pathways in Alzheimer's disease and ALS."
- "We analyzed 1,463 postmortem brain samples using computational biology to identify non-coding RNAs that become dysregulated in both diseases."
- Emphasize: This is big data analysis (1,463 samples) combined with rigorous statistics.
- Pause for 2-3 seconds after introducing yourself to let judges know you're ready.

---

## Slide 2: The Problem
**"Two distinct diseases may converge at molecular level"**

**Timing:** 45 seconds

**Notes:**
- Start by humanizing the problem: "Alzheimer's disease and ALS are devastating neurodegenerative diseases. They look different clinically—AD affects memory, ALS affects motor neurons—but both cause progressive brain degeneration."
- "The central question driving this project: Do they share hidden molecular mechanisms despite their clinical differences?"
- Point to the PCA plot on the right: "This visualization comes from one of our datasets. You can see disease clustering—but that's after measuring 101,000 genes. The real challenge is finding which genes matter and which are just noise."
- "Current diagnostics are either invasive—requiring lumbar punctures to sample cerebrospinal fluid—or arrive too late, like post-mortem confirmation."
- Conclusion: "So we asked: can we identify shared molecular markers that distinguish disease from health, and could those become blood-based biomarkers?"

---

## Slide 3: Understanding Non-Coding RNAs
**"Non-coding RNAs = cellular control system"**

**Timing:** 45 seconds

**Notes:**
- "Most of what you learn in biology class focuses on protein-coding genes—like hemoglobin for oxygen transport or insulin for blood sugar control."
- "But roughly 98% of our genome doesn't code for proteins. Instead, these non-coding sequences—especially non-coding RNAs—act as master switches."
- "Think of it this way: protein-coding genes are the engines. Non-coding RNAs are the control panel. They decide when to turn genes on or off based on what the cell needs."
- "In healthy brains, these regulatory systems work perfectly. But in disease—when neurons are stressed by amyloid plaques, tau tangles, or TDP-43 inclusions—these control systems break down."
- "We hypothesized that if we could identify which non-coding RNAs malfunction in neurodegeneration, we might unlock a common point of vulnerability."

---

## Slide 4: Research Strategy
**"Strategy: Convergent patterns across datasets = real biology, not noise"**

**Timing:** 50 seconds

**Notes:**
- "How did we avoid cherry-picking? We used three completely independent public datasets."
- Break down the numbers: "First dataset: 47 Alzheimer's brains. Second dataset—a validation set from a different lab—173 more AD brains. Third dataset: 1,243 ALS brains."
- "Different research groups. Different hospitals. Different sequencing facilities. This is the gold standard for replication."
- "For each sample, we measured expression of 101,000 genes. That's comprehensive—every gene in the human genome, basically."
- Point to the PCA plot: "These plots show that disease and controls separate clearly. But we can't just look at the picture and guess which genes drive that separation."
- "We needed a systematic statistical approach to find genes dysregulated consistently—across all three datasets, same direction, same magnitude."

---

## Slide 5: Statistical Method 1 – Welch's t-test
**"Fair statistical method accounting for real biological variation"**

**Timing:** 45 seconds

**Notes:**
- "Here's the challenge: we're testing 101,000 genes, each one individually. For each gene, we ask: is it significantly different between disease and control?"
- "The standard approach is the Student's t-test, which assumes both groups have equal variance. But in reality, disease groups are messy. Some patients have severe involvement, others mild. That variance is real biology."
- "Welch's t-test doesn't make that assumption. It's more conservative, more honest about biological heterogeneity."
- Point to the volcano plot: "These volcano plots visualize our results—each dot is a gene. The x-axis shows effect size (how different disease vs. control). The y-axis shows statistical significance. We're looking for genes far right and high up."
- "We applied this test to all three datasets separately—generating three independent lists of significant genes."

---

## Slide 6: Statistical Method 2 – Multiple Testing Correction
**"Rigorous protection against thousands of false positives"**

**Timing:** 50 seconds

**Notes:**
- "Now here's the catch: when you test 101,000 genes at p < 0.05, you expect roughly 5,073 false positives by random chance alone."
- Use an analogy: "Imagine flipping a coin 100,000 times. If you call 'heads' a success, you'll randomly see long runs of heads that feel meaningful but aren't."
- "The solution is Benjamini-Hochberg FDR correction. It adjusts the p-value threshold upward, requiring stronger evidence to claim significance."
- "The cost? We lose some real signals—true positives—but we protect against thousands of false leads. It's a trade-off, but in genetics, it's standard."
- "After correction, instead of detecting 10,000+ significant genes per dataset, we narrowed down to roughly 1,400 truly significant non-coding RNAs per dataset."
- Emphasize: "These are real signals, not digital artifacts."

---

## Slide 7: Finding Shared Genes – Hypergeometric Test
**"Overlap is definitively real, not coincidence"**

**Timing:** 50 seconds

**Notes:**
- "Now we asked: how many of those significant genes overlap across all three datasets?"
- "By random chance, if we picked ~1,400 genes from a pool of 101,000 three times, we'd expect very little overlap."
- "But we found five non-coding RNAs dysregulated in all three datasets, same direction (downregulated in disease), same magnitude."
- List the genes: "MEG9, ZMIZ1-AS1, SLC12A5-AS1, GUSBP1, and STRCP1."
- State the statistic: "The probability that this overlap occurred by random chance? 0.0003%. That's 1 in 30,000."
- "To put that in perspective: that's 20 times more common than expected. This is genuine convergence."
- Drive home the point: "We didn't cherry-pick these genes. They emerged naturally from rigorous statistical filtering across independent studies."

---

## Slide 8: The Five Biomarker Genes
**"Five genes; consistent direction; shared pathway targets"**

**Timing:** 50 seconds

**Notes:**
- "Let's look at the five genes and their effect sizes. The log₂ fold-change tells us the magnitude of downregulation."
- Explain log₂ FC: "A log₂ FC of −0.9 means the gene is expressed at roughly 53% of normal levels in disease—about half-suppressed."
- "What's remarkable? All five genes show approximately the same level of suppression: between 52–53%. That consistency suggests a coordinated regulatory mechanism."
- Point to the heatmap: "This heatmap visualizes expression across individual patients. Notice the tight clustering—low patients with low expression, controls with high expression. That tight separation means these aren't borderline markers; they're robust signals."
- "We then performed pathway enrichment analysis to understand what these five genes control."
- "Result: 92% of them regulate neuroinflammation pathways. 88% regulate autophagy—the cell's trash disposal system."

---

## Slide 9: Pathway Enrichment Analysis
**"Shared pathway targets explain disease convergence despite different causes"**

**Timing:** 50 seconds

**Notes:**
- "This is the breakthrough insight. Alzheimer's and ALS have different initiating triggers—amyloid-beta and TDP-43, respectively."
- "But the five dysregulated RNAs both control the same downstream pathways: inflammation and autophagy."
- Explain the mechanism: "These RNAs normally suppress inflammatory genes like IL-6 and TNF-alpha. In disease, when the RNAs are suppressed, inflammation runs unchecked."
- "Simultaneously, these RNAs normally promote autophagy genes like ATG5 and BECN1. When suppressed, autophagy fails, and toxic proteins accumulate."
- "So the model: Different initial triggers (amyloid vs. TDP-43) → Shared RNAs become suppressed → Shared pathways dysregulate (too much inflammation, too little autophagy) → Neuronal death."
- "This molecular convergence might explain why these diseases, despite clinical differences, respond to similar therapeutic approaches."

---

## Slide 10: Can These Genes Predict Disease?
**"Genuine diagnostic power demonstrated with clinical-grade accuracy"**

**Timing:** 50 seconds

**Notes:**
- "Next question: do these five genes have practical diagnostic power? Can we build a classifier that distinguishes disease from health?"
- "We used logistic regression—a simple machine learning technique—trained on these five genes."
- State the results: "Alzheimer's: AUC = 0.949 (95% CI: 0.875–0.992). That means 85% sensitivity, 100% specificity on our validation set."
- "ALS: AUC = 0.918 (95% CI: 0.900–0.936). 81% sensitivity, 88% specificity."
- Explain AUC: "AUC stands for Area Under the Receiver Operating Characteristic Curve. AUC = 1.0 is perfect. AUC = 0.5 is random guessing. Anything > 0.90 is considered clinically useful by FDA standards."
- "Both diseases exceed that threshold. This isn't just statistical association—these five genes have genuine diagnostic signal."
- "Implication: If we can detect these RNAs in accessible samples like blood, we might develop a non-invasive diagnostic test."

---

## Slide 11: Preventing Overfitting – Cross-Validation
**"Honest validation proving real predictive power, not memorized noise"**

**Timing:** 50 seconds

**Notes:**
- "But here's the skepticism we anticipated: Did we just get lucky with one split of training and test data?"
- "To prove our model works in general, not just on this specific dataset, we used stratified 10-fold cross-validation."
- Explain the method: "We split the data into 10 equal groups, stratified by disease status to keep proportions balanced. We train on 9 groups, test on the 10th. Repeat 10 times. Each sample is tested exactly once on data the model never saw during training."
- "Then we bootstrapped—resampled 1,000 times with replacement—to generate 95% confidence intervals."
- "The result? All 10 rounds gave consistent AUC > 0.90, and the confidence intervals don't include 0.5 (random guessing)."
- "This proves the model's predictive power is real, not an artifact of a lucky train-test split."

---

## Slide 12: Key Limitation – Association vs. Causation
**"Association established; causation unknown; next phase is experimental"**

**Timing:** 60 seconds

**Notes:**
- "I want to be completely honest about what this analysis does and doesn't prove."
- "What we've established: These five RNAs are dysregulated in both diseases, consistently across three independent datasets. They correlate with disease status. They have predictive power."
- "What we have NOT proven: These RNAs cause the disease."
- Explain the gap: "The RNAs could be consequences of neuronal death, not drivers. A dying neuron might suppress certain RNAs as it degenerates, but that doesn't mean restoring those RNAs will save the neuron."
- "This is a real limitation. To prove causation, we need experiments: CRISPR to manipulate these genes, animal models to test if knockout increases disease risk, mechanistic studies to prove the pathway is causal."
- "Scientific integrity: I'm telling you upfront what we don't know."
- "This is discovery research, not therapeutic research. We've answered 'What?' but not 'Why?' or 'How do we treat it?'"

---

## Slide 13: Next Steps – The Research Pipeline
**"Discovery phase 1 → Validation phase → Mechanism phase → Therapy phase"**

**Timing:** 60 seconds

**Notes:**
- "So what comes next? We've identified candidate biomarkers. The pipeline has four phases."
- **Phase 1 (1–2 years):** "First, we validate in accessible samples. These findings come from postmortem brain. Can we detect the same five RNAs in blood and cerebrospinal fluid?"
- "We'll use digital PCR—an ultra-sensitive technique—to confirm the findings in independent patient cohorts."
- "We'll test if these RNAs are packaged into exosomes, tiny vesicles that carry brain material to the bloodstream. This would explain how brain signals reach the blood."
- **Phase 2 (2–5 years):** "Next, we prove mechanism. CRISPR-Cas13 experiments to edit out these RNAs in neurons and measure cascade effects. Animal models lacking these genes to test if they're predisposed to neurodegeneration."
- **Phase 3 (5+ years):** "Finally, translation. Clinical-grade blood test development. Identification of drugs that restore these RNAs. Clinical trials."
- "This is a 5-15 year pathway from discovery to potential therapy—the typical timeline in translational neuroscience."

---

## Slide 14: Key Takeaways
**"Rigorous discovery + honest limitations = strong science"**

**Timing:** 45 seconds

**Notes:**
- "Let me summarize the key findings:"
- "We identified five non-coding RNAs consistently dysregulated in both Alzheimer's and ALS."
- "Evidence: Hypergeometric p-value of 0.0003. Pathway analysis showing 92% regulate inflammation, 88% regulate autophagy. Predictive power exceeding FDA diagnostic standards (AUC > 0.90). Validation across three independent datasets with rigorous cross-validation."
- "Honest assessment: We've shown strong association. We haven't proven causation. We have clear next steps."
- "Why should you care? This work provides a lead for new diagnostics and potential therapies targeting a shared vulnerability in neurodegenerative disease."

---

## Slide 15: Questions?
**Final talking points (if asked)**

**Timing:** 2-3 minutes (or longer if judges are engaged)

**Prepared answers to anticipated questions:**

### Q: Why postmortem tissue instead of living patients?
**A:** "Postmortem tissue is the only way to see complete disease pathology. Living patients can provide blood or CSF, but only postmortem can we examine all neuronal populations and detect the full spectrum of molecular changes. That's why validation in blood is critical—it's the next step."

### Q: Why these three datasets specifically?
**A:** "Each dataset used different sequencing platforms, came from different hospitals in different countries, and studied different populations. This heterogeneity is strength. If we found convergent signals despite these differences, that's robust biology. If we saw overlap using identical methods and populations, that might be technical artifact."

### Q: Why not test causation directly from the start?
**A:** "Discovery and causation are separate questions. With 101,000 genes, we first filter to likely candidates using statistics and replication. Then we test causation on the filtered set. Testing all 101,000 genes with CRISPR would be unfeasible. We're being smart about resource allocation."

### Q: Could this be an artifact—false positive from multiple testing?
**A:** "We corrected for multiple testing using FDR. And we validated across independent datasets. The probability of the same five genes showing up in three independent analyses by random chance is 0.0003%. That's 30,000:1 odds. Very unlikely to be artifact."

### Q: What if genes differ by patient subtype?
**A:** "Great question. Patient heterogeneity is real—AD is not one disease but many subtypes. But the five genes we found are consistently dysregulated across patients. And pathway convergence is the key insight, not individual genes. Even if different patients use different RNAs to dysregulate inflammation, the downstream effect—too much inflammation—is the same."

### Q: How would this become a blood test?
**A:** "We'd measure these five small RNAs using quantitative PCR from a simple blood draw. We'd validate in large patient cohorts, determine a diagnostic threshold (like 'if expression of these RNAs falls below X, predict disease'), and validate sensitivity/specificity prospectively. That's Phase 2 of the pipeline."

### Q: Could you apply this to other neurodegenerative diseases?
**A:** "Absolutely. Frontotemporal dementia, Parkinson's, Huntington's—they all involve neuroinflammation and autophagy dysfunction. This pipeline could identify shared RNAs across multiple diseases, potentially discovering a single therapeutic target that helps many patients."

---

## Delivery Tips

**Timing breakdown (7 minutes total):**
- Slide 1 (Title): 15 sec
- Slide 2 (Problem): 45 sec
- Slide 3 (ncRNAs): 45 sec
- Slide 4 (Strategy): 50 sec
- Slide 5 (Welch): 45 sec
- Slide 6 (FDR): 50 sec
- Slide 7 (Shared genes): 50 sec
- Slide 8 (Biomarkers): 50 sec
- Slide 9 (Pathways): 50 sec
- Slide 10 (Diagnostics): 50 sec
- Slide 11 (Validation): 50 sec
- Slide 12 (Limitations): 60 sec
- Slide 13 (Next steps): 60 sec
- Slide 14 (Takeaways): 45 sec
- Slide 15 (Questions): variable

**Total: ~420 seconds = 7 minutes**

**Delivery style:**
- Speak slowly and clearly. Judges want to understand specifics, not be dazzled.
- Pause for 2–3 seconds after major statements to let them sink in.
- Make eye contact. Rotate between different judges.
- Point to visuals when you mention them. Let the images do work.
- Use accessible language. Translate jargon: "log₂ fold-change means how much higher or lower" not just "log₂ FC".
- Show enthusiasm. This is genuinely cool research—let that come through.
- If you go over, cut Slides 11 and 12 (validation and limitations). Judges care most about findings.
- If you have extra time, expand on next steps or answer emerging questions with your prepared answers above.
