# Slide 12: Key Limitation – Association vs. Causation
**"Association established; causation unknown; next phase is experimental"**

## Timing
60 seconds

## Notes
- "I want to be completely honest about what this analysis does and doesn't prove."
- "What we've established: These five RNAs are dysregulated in both diseases, consistently across three independent datasets. They correlate with disease status. They have predictive power."
- "What we have NOT proven: These RNAs cause the disease."
- Explain the gap: "The RNAs could be consequences of neuronal death, not drivers. A dying neuron might suppress certain RNAs as it degenerates, but that doesn't mean restoring those RNAs will save the neuron."
- "This is a real limitation. To prove causation, we need experiments: CRISPR to manipulate these genes, animal models to test if knockout increases disease risk, mechanistic studies to prove the pathway is causal."
- "Scientific integrity: I'm telling you upfront what we don't know."
- "This is discovery research, not therapeutic research. We've answered 'What?' but not 'Why?' or 'How do we treat it?'"

## Key Points
- Show scientific integrity (acknowledge limitations upfront)
- Distinguish association from causation clearly
- Explain the correlation conundrum: RNAs suppressed because dying, or dying because RNAs suppressed?
- List what's needed for causation: CRISPR, animal models, mechanistic studies
- Frame honestly: discovery phase, not therapy phase
- Show judges you're thinking critically
