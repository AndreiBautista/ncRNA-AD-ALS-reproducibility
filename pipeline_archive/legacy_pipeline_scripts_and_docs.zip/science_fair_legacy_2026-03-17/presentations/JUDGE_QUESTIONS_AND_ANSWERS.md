# Presentation: 5 Likely Judge Questions & Answers

## Question 1: Why did you focus on non-coding RNAs instead of protein-coding genes?

**What the judge is really asking:** "Why is this category of genes important? Isn't most disease caused by proteins?"

**Your answer:**

"That's a great question. Historically, we've focused on protein-coding genes because we understood them better. But non-coding RNAs regulate the expression of protein-coding genes—they're like the control systems. Recent evidence shows they're dysregulated early in neurodegenerative disease, sometimes before obvious protein changes show up. Second, the field is moving toward developing therapies that modulate RNA rather than proteins—drugs that target RNA are often safer because they're reversible. And practically speaking, if I had focused on all 20,000 protein-coding genes instead of 18,000 non-coding RNAs, I'd have had a bigger search space and higher false discovery burden. Focusing on ncRNAs was both scientifically motivated and statistically prudent."

**Keep it concise. Real time: 30 seconds.**

---

## Question 2: You found association, not causation. How do you know these RNAs aren't just markers of cell death rather than drivers of disease?

**What the judge is really asking:** "Is this discovery meaningful, or did you find the cellular equivalent of firefighters at fires?"

**Your answer:**

"Excellent question, and honestly, I don't know yet. That's exactly why I included the 'limitations' slide. Here's what makes me think it's more than just a marker of cell death: First, the five RNAs show tight clustering within disease groups—low variation from patient to patient. If they were just random consequences of neuronal death, I'd expect more scatter. Second, these specific RNAs control pathways—neuroinflammation and autophagy—that are known to execute neurodegeneration. They're not just any genes; they're genes with plausible mechanism. Third, cross-validation shows the signature is predictive across independent datasets, which suggests robustness. But you're right to push back. The gold standard would be CRISPR experiments: turn these RNAs up or down in neurons and measure whether that actually changes disease outcomes. That's the next step. What I've done is identify a pattern worth testing experimentally."

**Keep it concise. Real time: 50 seconds.**

---

## Question 3: Why use Welch's t-test instead of a Mann-Whitney U test or another statistical approach?

**What the judge is really asking:** "Did you pick a reasonable method, or did you just use the default?"

**Your answer:**

"Good catch. I chose Welch's t-test for a specific reason: it doesn't assume equal variances between disease and control groups, which is important because neurodegenerative disease causes heterogeneous damage—some brains are more affected than others. The disease group often has higher variance. A standard t-test would penalize me for that heterogeneity; Welch's doesn't. I also checked my results using Mann-Whitney U test, which makes no distributional assumptions at all, and the results were consistent—same genes remained significant. So Welch's t-test was appropriate for the data and conservative in that it controls for multiple sources of variance. I could have used other methods, but the biological interpretation stays the same."

**Keep it concise. Real time: 40 seconds.**

---

## Question 4: Your classifier achieves high AUC, but what's the false positive rate? If a doctor used this, how often would they misdiagnose someone?

**What the judge is really asking:** "Is this actually clinically useful, or is it impressive in theory but dangerous in practice?"

**Your answer:**

"That's the question that should be asked before any clinical test is deployed. In my classifier, I optimized the decision threshold to balance sensitivity and specificity. For Alzheimer's disease, I achieved 82% sensitivity and 100% specificity—meaning 82% of diseased samples are caught, and zero healthy samples are falsely called diseased. For ALS, it's 81% sensitivity and 88% specificity. So the false positive rate in ALS is about 12% if we set the threshold standard. That's too high for standalone diagnosis, but reasonable for a screening tool that identifies candidates for further testing. The point is, this is discovery research, not a clinical test. Before deploying any diagnostic tool, you'd need prospective validation in a new population and clinical trials designed specifically to measure real-world performance. What I've shown is that the signal exists and is worth developing further."

**Keep it concise. Real time: 45 seconds.**

---

## Question 5: How do you know your results aren't specific to these three datasets? What if they don't replicate in other neurodegenerative diseases or other patient populations?

**What the judge is really asking:** "How generalizable is this? Or did you just find a pattern specific to your data?"

**Your answer:**

"That's the most important question. I designed my study to test exactly that concern. The three datasets I used are independent—different research groups, different tissues, different sequencing platforms. GSE203206 used brain tissue from UCLA; GSE48350 is a different hospital's Alzheimer's cohort; GSE153960 is ALS samples. If my finding were specific to one lab's methods or patient population, it wouldn't replicate across all three. The fact that the same five genes dysregulate in all three datasets is strong evidence the pattern is real and not a technical artifact. But you're absolutely right to ask about generalization beyond these datasets. I can't fully answer that without testing in new populations and other diseases. That's why my 'next steps' slide includes validation as the immediate priority. I'd also predict these genes should show dysregulation in other neurodegenerative diseases like Parkinson's disease or frontotemporal dementia, if they truly reflect a shared mechanism. That prediction is testable and falsifiable—which is good science."

**Keep it concise. Real time: 55 seconds.**

---

## Bonus: Judge testing your confidence

**"If your findings are right, why hasn't anyone found this before?"**

Answer: "That's honest skepticism. A few reasons: First, most ncRNA studies focus on disease-specific findings—researchers look for what's unique to Alzheimer's, then separately what's unique to ALS. They don't often compare across diseases. Second, this required combining three large datasets, which isn't trivial. Third, these specific five genes might not have been the focus of previous studies—genomics moves fast, and as sequencing gets cheaper and tools improve, new patterns become visible. I'm not claiming I discovered something revolutionary; I'm claiming I found a reproducible pattern that previous researchers might have missed or not emphasized. That's the nature of data reanalysis—it's not inventing new data; it's asking old data new questions."

**Keep it concise. Real time: 35 seconds.**

---

## Tips for Delivering Judge Questions

1. **Pause and think.** It's okay to take 2 seconds before answering. Shows you're thoughtful.
2. **Use "That's a great question" language.** Makes judges feel heard.
3. **Stay honest about limitations.** Judges respect researchers who know what they don't know.
4. **Distinguish between discovery, validation, and clinical translation.** Use these terms clearly.
5. **Have a confident closing statement.** End with "This is the next step in the pipeline" type language.
6. **If you don't know the answer:** "That's a really good question, and I haven't tested that specifically. My prediction would be X, and here's how I'd test it..." Judges love seeing how future experiments are designed.

---

## Pre-Presentation Checklist

- [ ] Memorize the 30-second pitch
- [ ] Know what all five gene names are and how to pronounce them
- [ ] Understand the difference between AUC, sensitivity, specificity
- [ ] Have an explanation ready for "Why postmortem tissue?"
- [ ] Know why three datasets was the right choice
- [ ] Practice explaining one concept (Welch's t-test or FDR) out loud to a friend
- [ ] Rehearse in front of a mirror or with video
- [ ] Time yourself—aim for 6–8 minutes of presentation, leaving 1–2 minutes for questions
- [ ] Print your speaker notes and bring them to the booth (judges will see them; that's normal)
