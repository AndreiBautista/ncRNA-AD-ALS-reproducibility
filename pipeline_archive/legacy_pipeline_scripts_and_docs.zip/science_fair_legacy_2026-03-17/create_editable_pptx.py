#!/usr/bin/env python3
"""
Convert markdown presentation to editable PPTX with preserved styling and images
"""
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.dml.color import RGBColor
import re
import os

# Colors matching Marp theme
BLUE_DARK = RGBColor(26, 84, 144) # #1a5490
BG_LIGHT = RGBColor(248, 249, 250) # #f8f9fa
LIGHT_BLUE = RGBColor(232, 244, 248) # #e8f4f8
TEXT_DARK = RGBColor(0, 0, 0)

def add_background(slide):
 """Add light background to slide"""
 background = slide.background
 fill = background.fill
 fill.solid()
 fill.fore_color.rgb = BG_LIGHT

def add_text_box(slide, left, top, width, height, text, font_size=22, bold=False, color=TEXT_DARK, alignment=PP_ALIGN.LEFT, italic=False):
 """Helper to add text box with consistent styling"""
 if not text or not text.strip():
 return None
 
 textbox = slide.shapes.add_textbox(Inches(left), Inches(top), Inches(width), Inches(height))
 text_frame = textbox.text_frame
 text_frame.word_wrap = True
 
 for paragraph in text_frame.paragraphs:
 paragraph.text = text.strip()
 paragraph.font.size = Pt(font_size)
 paragraph.font.bold = bold
 paragraph.font.italic = italic
 paragraph.font.color.rgb = color
 paragraph.alignment = alignment
 
 return textbox

def extract_image_from_line(line):
 """Extract image path from markdown image syntax"""
 match = re.search(r'!\[.*?\]\((.*?)\)', line)
 return match.group(1) if match else None

def get_image_width(line):
 """Extract width percentage from image markdown"""
 match = re.search(r'width:(\d+)%', line)
 return int(match.group(1)) / 100 * 4.5 if match else 4.0 # Convert to inches

def parse_slides(md_content):
 """Parse markdown into structured slide data"""
 slides_text = md_content.split('\n---\n')[1:] # Skip YAML front matter
 
 slides = []
 for slide_content in slides_text:
 lines = slide_content.strip().split('\n')
 slides.append(lines)
 
 return slides

def create_presentation():
 """Create editable PPTX with images and proper styling"""
 prs = Presentation()
 prs.slide_width = Inches(10)
 prs.slide_height = Inches(7.5)
 
 # Read markdown
 with open('presentations/ISEF_presentation_7min.md', 'r') as f:
 md_content = f.read()
 
 slides_data = parse_slides(md_content)
 
 for slide_num, lines in enumerate(slides_data):
 # Create slide
 blank_slide_layout = prs.slide_layouts[6]
 slide = prs.slides.add_slide(blank_slide_layout)
 add_background(slide)
 
 # Add slide number
 footer_box = slide.shapes.add_textbox(Inches(9.2), Inches(7.2), Inches(0.7), Inches(0.3))
 footer_frame = footer_box.text_frame
 footer_frame.text = str(slide_num + 1)
 footer_frame.paragraphs[0].font.size = Pt(14)
 footer_frame.paragraphs[0].font.color.rgb = RGBColor(150, 150, 150)
 
 # Process slide content
 has_right_image = False
 has_left_image = False
 image_y_start = 1.2
 
 # First pass: detect images and their positions
 for line in lines:
 if line.startswith('!['):
 if 'bg right' in line:
 has_right_image = True
 elif 'bg left' in line:
 has_left_image = True
 
 y_pos = 0.4
 line_idx = 0
 
 while line_idx < len(lines):
 line = lines[line_idx]
 line_idx += 1
 
 if not line.strip():
 continue
 
 try:
 # Title (h1)
 if line.startswith('# '):
 title_text = line[2:].strip()
 title_box = slide.shapes.add_textbox(Inches(0.35), Inches(y_pos), Inches(9.3), Inches(1.2))
 tf = title_box.text_frame
 tf.word_wrap = True
 tf.text = title_text
 for para in tf.paragraphs:
 para.font.size = Pt(48)
 para.font.bold = True
 para.font.color.rgb = BLUE_DARK
 y_pos += 1.3
 
 # Heading (h2)
 elif line.startswith('## '):
 heading_text = line[3:].strip()
 heading_box = slide.shapes.add_textbox(Inches(0.35), Inches(y_pos), Inches(6.0), Inches(0.7))
 tf = heading_box.text_frame
 tf.word_wrap = True
 tf.text = heading_text
 for para in tf.paragraphs:
 para.font.size = Pt(34)
 para.font.bold = True
 para.font.color.rgb = BLUE_DARK
 y_pos += 0.9
 
 # Subheading (h3)
 elif line.startswith('### '):
 sub_text = line[4:].strip()
 sub_box = slide.shapes.add_textbox(Inches(0.35), Inches(y_pos), Inches(9.3), Inches(0.5))
 tf = sub_box.text_frame
 tf.text = sub_text
 for para in tf.paragraphs:
 para.font.size = Pt(26)
 para.font.bold = True
 para.font.color.rgb = BLUE_DARK
 y_pos += 0.6
 
 # Images
 elif line.startswith('!['):
 img_path = extract_image_from_line(line)
 if img_path and os.path.exists(img_path):
 img_width = get_image_width(line)
 
 if 'bg right' in line:
 x_pos = 5.3
 y_pos_img = image_y_start
 try:
 slide.shapes.add_picture(img_path, Inches(x_pos), Inches(y_pos_img), width=Inches(img_width))
 except Exception as e:
 print(f" Warning: Could not load image {img_path}: {e}")
 elif 'bg left' in line:
 x_pos = 0.35
 y_pos_img = image_y_start
 try:
 slide.shapes.add_picture(img_path, Inches(x_pos), Inches(y_pos_img), width=Inches(img_width))
 except Exception as e:
 print(f" Warning: Could not load image {img_path}: {e}")
 else:
 x_pos = 2.0
 try:
 slide.shapes.add_picture(img_path, Inches(x_pos), Inches(y_pos), width=Inches(6))
 except Exception as e:
 print(f" Warning: Could not load image {img_path}: {e}")
 y_pos += 3.0
 
 # Bullet points
 elif line.startswith('- '):
 bullet_text = line[2:].strip()
 bullet_text = bullet_text.replace('**', '')
 
 # Adjust width based on whether there's an image
 width = 4.5 if has_right_image else 9.0
 x_pos = 0.5 if has_right_image else 0.5
 
 bullet_box = slide.shapes.add_textbox(Inches(x_pos), Inches(y_pos), Inches(width), Inches(0.4))
 tf = bullet_box.text_frame
 tf.word_wrap = True
 tf.text = '• ' + bullet_text
 for para in tf.paragraphs:
 para.font.size = Pt(22)
 para.space_before = Pt(3)
 para.space_after = Pt(3)
 y_pos += 0.38
 
 # Takeaway boxes
 elif '<div class="take-away">' in line:
 takeaway_lines = []
 while line_idx < len(lines):
 current_line = lines[line_idx]
 line_idx += 1
 if '</div>' in current_line:
 break
 if current_line.strip():
 takeaway_lines.append(current_line.strip())
 
 takeaway_text = ' '.join(takeaway_lines).replace('</div>', '').strip()
 
 if takeaway_text:
 # Add background shape for takeaway
 shape = slide.shapes.add_shape(1, Inches(0.45), Inches(y_pos - 0.05), Inches(9.1), Inches(0.75))
 shape.fill.solid()
 shape.fill.fore_color.rgb = LIGHT_BLUE
 shape.line.color.rgb = BLUE_DARK
 shape.line.width = Pt(1.5)
 
 # Add text
 ta_box = slide.shapes.add_textbox(Inches(0.6), Inches(y_pos), Inches(8.8), Inches(0.65))
 tf = ta_box.text_frame
 tf.word_wrap = True
 tf.text = takeaway_text
 for para in tf.paragraphs:
 para.font.size = Pt(19)
 para.font.italic = True
 para.font.color.rgb = TEXT_DARK
 y_pos += 0.85
 
 # Skip table delimiters and HTML divs
 elif '|' in line or '<' in line or '```' in line:
 continue
 
 # Regular text paragraphs
 else:
 text = line.strip()
 if text and not text.startswith('!['):
 text = text.replace('**', '')
 if len(text) > 3 and text not in ['---', '']:
 p_box = slide.shapes.add_textbox(Inches(0.5), Inches(y_pos), Inches(9), Inches(0.35))
 tf = p_box.text_frame
 tf.word_wrap = True
 tf.text = text
 for para in tf.paragraphs:
 para.font.size = Pt(22)
 para.space_after = Pt(3)
 y_pos += 0.35
 
 except Exception as e:
 print(f" Line {line_idx}: {str(e)[:60]}")
 continue
 
 # Save
 output_path = 'presentations/ISEF_presentation_7min_editable.pptx'
 prs.save(output_path)
 print(f"✓ Editable PPTX created: {output_path}")
 print(f" Slides: {len(prs.slides)}")
 print(f" Format: 16:9, 10\" x 7.5\"")
 print(f" All text is editable, images preserved")

if __name__ == '__main__':
 try:
 create_presentation()
 except Exception as e:
 print(f"Error: {e}")
 import traceback
 traceback.print_exc()
