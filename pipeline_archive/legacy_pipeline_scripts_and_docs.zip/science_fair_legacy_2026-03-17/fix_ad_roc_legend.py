#!/usr/bin/env python3
"""
Fix the AD ROC curve legend position so it doesn't cover the specificity text
"""
from PIL import Image, ImageDraw, ImageFont
import sys

# Load the original AD ROC curve
img_path = '/Users/austinbautista/ncrna_pipeline/figures/ad_roc_curve.png'
output_path = '/Users/austinbautista/ncrna_pipeline/all_figures_consolidated/05_POSTER_AD_ROC.png'

# Open image
img = Image.open(img_path)
draw = ImageDraw.Draw(img)

print(f"Image size: {img.width} x {img.height}")

# Cover old legend with white rectangle
# Legend appears to be in bottom right corner
# Estimated position based on typical matplotlib layout
legend_x = int(img.width * 0.70) # Start at 70% width
legend_y = int(img.height * 0.85) # Start at 85% height
legend_width = int(img.width * 0.28)
legend_height = int(img.height * 0.13)

# Draw white rectangle over old legend
draw.rectangle([legend_x, legend_y, legend_x + legend_width, img.height],
 fill='white', outline=None)

# Try to load a font, or use default
try:
 # Try to find a system font
 font = ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", 40)
 font_small = ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", 35)
except:
 font = ImageFont.load_default()
 font_small = font

# Draw new legend box at better position (moved up)
new_legend_x = int(img.width * 0.72)
new_legend_y = int(img.height * 0.25) # Much higher - at 25% height
box_width = int(img.width * 0.23)
box_height = int(img.height * 0.20)

# Draw white box with black border
draw.rectangle([new_legend_x, new_legend_y, new_legend_x + box_width, new_legend_y + box_height],
 fill='white', outline='black', width=3)

# Add legend text
text_x = new_legend_x + 20
text_y = new_legend_y + 15
line_spacing = 65

legend_lines = [
 "AUC = 0.949",
 "[95% CI: (0.875, 0.992)]",
 "Sensitivity: 82%",
 "Specificity: 100%",
 "─── ROC curve",
 "- - - Random classifier"
]

for i, line in enumerate(legend_lines):
 draw.text((text_x, text_y + i * line_spacing), line, fill='black', font=font_small)

# Save
img.save(output_path, 'PNG', dpi=(300, 300))
print(f"✓ Fixed AD ROC curve saved to: {output_path}")
