#!/usr/bin/env python3
"""
Create a clean, professional Venn diagram for the presentation
"""
import matplotlib.pyplot as plt
from matplotlib_venn import venn3, venn3_circles
import matplotlib.patches as mpatches

def create_clean_venn_diagram():
 """Generate a clear Venn diagram showing the 5 shared ncRNAs"""
 
 fig, ax = plt.subplots(figsize=(10, 8))
 
 # Create Venn diagram with three sets
 # Format: (Abc, aBc, ABc, abC, AbC, aBC, ABC)
 # A = AD dataset 1, B = AD dataset 2, C = ALS dataset
 # Using equal-sized circles without numbers for visual clarity
 
 venn = venn3(subsets=(1, 1, 1, 1, 1, 1, 1),
 set_labels=('Alzheimer\'s Disease\n(GSE203206)\n47 samples', 
 'Alzheimer\'s Disease\n(Validation, GSE48350)\n173 samples',
 'ALS\n(GSE153960)\n1,243 samples'),
 ax=ax)
 
 # Color the circles with clear, distinct colors
 venn.get_patch_by_id('100').set_color('#E8F4F8') # Light blue
 venn.get_patch_by_id('010').set_color('#FFE8E8') # Light red
 venn.get_patch_by_id('110').set_color('#E8E8FF') # Light purple
 venn.get_patch_by_id('001').set_color('#E8FFE8') # Light green
 venn.get_patch_by_id('101').set_color('#FFF8E8') # Light yellow
 venn.get_patch_by_id('011').set_color('#FFE8FF') # Light pink
 venn.get_patch_by_id('111').set_color('#FFD700') # Gold for the center (our 5 genes!)
 
 # Set transparency
 for patch_id in ['100', '010', '110', '001', '101', '011', '111']:
 patch = venn.get_patch_by_id(patch_id)
 if patch:
 patch.set_alpha(0.6)
 patch.set_edgecolor('black')
 patch.set_linewidth(1.5)
 
 # Add circles outline
 venn3_circles(subsets=(1, 1, 1, 1, 1, 1, 1), 
 linewidth=2, linestyle='solid', color='black', ax=ax)
 
 # Hide all subset labels (the numbers)
 for label_id in ['100', '010', '110', '001', '101', '011', '111']:
 label = venn.get_label_by_id(label_id)
 if label:
 label.set_text('')
 
 # Add the five gene names in the center - LARGER and more prominent
 genes_text = "Shared ncRNA\nBiomarkers (n=5)\n\nMEG9\nZMIZ1-AS1\nSLC12A5-AS1\nGUSBP1\nSTRCP1"
 ax.text(0, 0, genes_text, 
 ha='center', va='center',
 fontsize=16, fontweight='bold',
 bbox=dict(boxstyle='round,pad=0.8', facecolor='white', 
 edgecolor='black', linewidth=2.5, alpha=0.95))
 
 # Simplified title
 ax.set_title('Cross-Dataset ncRNA Biomarker Overlap',
 fontsize=18, fontweight='bold', pad=20)
 
 # Simplified caption
 caption = ('Hypergeometric test: p = 0.0003\n'
 'Five ncRNAs replicated across three independent datasets')
 fig.text(0.5, 0.02, caption, ha='center', fontsize=11, 
 style='italic', wrap=True)
 
 plt.tight_layout(rect=[0, 0.05, 1, 0.97])
 
 # Save
 output_path = 'all_figures_consolidated/03_POSTER_Venn_Shared5_CLEAN.png'
 plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white')
 print(f"✓ Clean Venn diagram saved: {output_path}")
 
 plt.close()

if __name__ == '__main__':
 create_clean_venn_diagram()
