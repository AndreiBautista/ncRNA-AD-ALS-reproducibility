# Cross-Disease ncRNA Biomarker Discovery
## Dataset Collection Guide

### TARGET DATASETS

**Goal:** ~200+ samples per disease (brain tissue preferred, bulk RNA-seq)

---

## ALZHEIMER'S DISEASE (AD) ✓ READY
Already have: **GSE203206** (47 samples, 39 AD + 8 control)
- Status: ✅ Downloaded, ready to use
- Currently your primary dataset

**Candidates to supplement AD:**
- GSE33000: 624 samples (but gene symbols, low match rate)
- GSE173955: 18 samples (too small)
- Option: Search GEO for "Alzheimer's RNA-seq brain" dated 2015-2024

---

## PARKINSON'S DISEASE (PD) - NEED TO FIND

### Search Strategy:
Go to **https://www.ncbi.nlm.nih.gov/geo/**

**Search term:**
```
"Parkinson's disease" OR "Parkinson disease" 
AND 
"RNA-seq" 
AND 
"brain" 
AND 
"homo sapiens"
```

### Target Criteria:
- ✅ Bulk RNA-seq (NOT single-cell)
- ✅ Brain tissue (striatum, substantia nigra, prefrontal cortex)
- ✅ Raw count matrix available
- ✅ Clear disease vs control metadata
- ✅ Minimum 30 samples

### Promising GEO Series to Check:
- GSE111932 (likely: PD brain tissue)
- GSE54282 (likely: PD midbrain)
- GSE40967 (likely: PD postmortem brain)
- Search results will reveal more

**Action:** Browse GEO, download series_matrix.txt or supplementary files

---

## ALS (Amyotrophic Lateral Sclerosis) - NEED TO FIND

### Search Strategy on GEO:
```
"amyotrophic lateral sclerosis" OR "ALS" 
AND 
"RNA-seq" 
AND 
("brain" OR "spinal cord" OR "motor cortex")
AND 
"homo sapiens"
```

### Target Criteria:
- ✅ Bulk RNA-seq
- ✅ Nervous system tissue (motor neurons, spinal cord, motor cortex)
- ✅ Raw counts or processed counts
- ✅ Disease vs control metadata
- ✅ Minimum 30 samples

### Promising GEO Series to Check:
- GSE153960 (likely: ALS motor cortex)
- GSE112119 (likely: ALS spinal cord)
- GSE27894 (likely: ALS postmortem)
- Search results will reveal more

**Action:** Browse GEO, download series_matrix.txt or supplementary files

---

## DATASET CONSOLIDATION STRATEGY

### Organization Structure:
```
data/
└── neurodegenerative_diseases/
 ├── alzheimers/
 │ ├── GSE203206/
 │ │ ├── counts.tsv
 │ │ └── metadata.csv
 │ └── ...
 ├── parkinsons/
 │ ├── GSE111932/
 │ │ ├── counts.tsv
 │ │ └── metadata.csv
 │ └── ...
 └── als/
 ├── GSE153960/
 │ ├── counts.tsv
 │ └── metadata.csv
 └── ...
```

### Key Steps for Each Dataset:
1. Download raw counts matrix
2. Standardize column headers (sample names)
3. Create metadata.csv with:
 - sample_id
 - disease_status (Disease / Control)
 - tissue_type
 - study_id
4. Convert gene IDs to Ensembl if needed
5. Verify sample counts match

---

## TIMELINE ESTIMATE

- **Dataset Discovery:** 1-2 hours (browse GEO, read papers)
- **Download & Formatting:** 2-3 hours (depends on file sizes)
- **Harmonization:** 4-6 hours (gene ID conversion, merging)
- **Within-Disease Analysis:** 3-4 hours (DESeq2 per disease)
- **Cross-Disease Analysis:** 2-3 hours (overlap identification)
- **Visualization & Report:** 2-3 hours
- **Total:** 14-21 hours

---

## IMMEDIATE NEXT STEPS

1. Search GEO for Parkinson's datasets (target: 2-3 studies, 200+ total samples)
2. Search GEO for ALS datasets (target: 2-3 studies, 200+ total samples)
3. Download all files locally
4. Organize into folder structure above
5. Send me the GEO accessions and confirm data structure
