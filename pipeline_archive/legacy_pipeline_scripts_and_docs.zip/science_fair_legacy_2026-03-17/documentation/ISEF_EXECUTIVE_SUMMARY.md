# ncRNA Biomarker Discovery - Executive Summary

**Date:** February 18, 2026
**Project:** Identification of conserved non-coding RNA biomarkers in neurodegenerative diseases

## Overview

This study identifies differentially expressed non-coding RNAs (ncRNAs) across public neurodegenerative disease datasets to discover novel biomarkers with potential for disease diagnosis and monitoring. Using Welch's t-test and FDR correction (p < 0.1, |log2FC| > 0.5), we analyzed RNA-seq and microarray data from 1,580 patient samples across four public GEO datasets.

## Key Findings

### Dataset Composition
- **Total Samples:** 1,580 (1,339 disease / 241 control)
- **Datasets:** 4 (3 Alzheimer's disease, 1 ALS)
- **Data Types:** RNA-seq (3) and Microarray (1)

### ncRNA Discoveries

- **GSE203206** (Alzheimer's Disease): 40 significant ncRNAs (47 samples)
- **GSE48350** (Alzheimer's Disease): 40 significant ncRNAs (173 samples)
- **GSE95587** (Alzheimer's Disease): 0 significant ncRNAs (117 samples)
- **GSE153960** (ALS): 40 significant ncRNAs (1243 samples)

**Total ncRNA Biomarkers Identified:** 120

### ncRNA Classification
The identified biomarkers include:
- **lncRNAs** (long non-coding RNAs): Primary biomarker class
- **Pseudogenes**: Transcribed pseudogenes with regulatory potential
- **Small RNAs**: snoRNAs, scaRNAs, miRNAs
- **Other ncRNA types**: misc_RNAs, rRNAs

## Statistical Methods

- **Differential Expression:** Welch's t-test (accounts for unequal variances between groups)
- **Multiple Testing Correction:** Benjamini-Hochberg FDR control (α = 0.1)
- **Significance Threshold:** |log2 fold-change| > 0.5
- **Normalization:** log2-CPM (counts per million)

## Clinical Implications

1. **Cross-disease conservation:** ncRNAs significant in multiple datasets represent high-confidence biomarkers
2. **Biomarker utility:** Log2FC values indicate direction and magnitude of dysregulation
3. **Tissue specificity:** Brain tissue samples enable identification of CNS-relevant biomarkers

## Publication Status

This analysis represents a pre-publication discovery phase. Results are organized for peer-reviewed journal submission and presentation.

---
