ncrna_pipeline GEO integration
=============================

This module provides a lightweight GEO (GSE) integration for the ncRNA pipeline implemented in `ISEFRNA.py`.

Purpose
- Fetch a GEO Series (GSE) using `GEOparse`.
- Parse expression/count matrix, sample metadata, and (when available) platform annotation.
- Coerce counts to numeric, align samples with metadata, filter for non-coding RNAs, and run the existing pipeline functions.

Files
- `ncrna_pipeline/geo_integration.py`: main module with `fetch_geo()` and `run_pipeline_on_gse()`.

Usage (library)
----------------
Import and call the high-level wrapper (do not run the example automatically):

```python
from ncrna_pipeline.geo_integration import run_pipeline_on_gse
# Example (do not run automatically):
# run_pipeline_on_gse('GSEXXXX', results_base='results')
```

Important notes
- GEO datasets vary widely in format. The module first attempts the series_matrix table, then per-GSM tables, then supplementary files.
- If the function cannot detect a grouping column automatically, pass `group_col_hint='<column_name>'` to `run_pipeline_on_gse()`.
- The module uses the pipeline functions in `ISEFRNA.py` and preserves the scientific logic.

Outputs
- Saved under `results/<GSE_ID>/`:
 - `counts.csv`
 - `metadata.csv`
 - `differential_results.csv`
 - `heatmap.png`
 - `violin_top_genes.png` (when possible)

Dependencies
- See top-level `requirements.txt`. Install via:

```bash
pip install -r requirements.txt
```

If you prefer a virtualenv, create one and install into it before running the pipeline.

Troubleshooting
- If no counts are found, try manually inspecting the downloaded supplementary files under `results/<GSE_ID>/`.
- If sample names don't align, provide `group_col_hint` and/or adjust metadata before calling the pipeline.
# ncRNA Differential Expression Pipeline

This pipeline identifies differentially expressed non-coding RNAs (lncRNA, miRNA, snoRNA, etc.) from bulk RNA-seq expression matrices, supports automatic data download (GEO / Synapse), and generates publication-quality figures.

Key features
- Modular Python package for reproducibility and clarity
- Supports GEO (via `GEOparse`) and Synapse (via `synapseclient`) downloads
- Per-dataset differential analysis (log2-CPM + Welch t-test)
- FDR correction and reporting
- Visualizations: volcano, heatmap, per-disease summary, UpSet overlap plot
- Output folder structure: `data/`, `results/per_dataset/`, `results/conserved_ncrnas/`, `results/figures/`

Requirements
- Python 3.8+
- See `requirements.txt` for Python package dependencies.

Quick start
1. Install dependencies:
```bash
python3 -m pip install -r requirements.txt
```
2. Run the pipeline for a GEO accession (example):
```bash
python3 run_pipeline.py --datasets GSEXXXXX --outdir results
```

Notes
- This project does not fabricate datasets. The pipeline will attempt to download real, public datasets.
- If `GEOparse` or `synapseclient` are not installed, the relevant download functions will print instructions.
