# Detailed ncRNA Biomarker Results

**Generated:** 2026-02-18 10:42:39

## Per-Dataset Summary


### GSE203206: Alzheimer's Disease (RNA-seq)
- **Samples:** 47 total (39 disease / 8 control)
- **ncRNA Biomarkers:** 40
- **Analysis Date:** Completed Feb 18, 2026

#### Top 5 Upregulated ncRNAs

- TGFB2-OT1 (lncRNA, log2FC=1.62, FDR=1.00e-04)
- nan (processed_pseudogene, log2FC=1.43, FDR=1.71e-02)
- nan (lncRNA, log2FC=1.27, FDR=9.27e-02)
- nan (lncRNA, log2FC=1.27, FDR=9.27e-02)
- nan (lncRNA, log2FC=1.27, FDR=9.27e-02)

#### Top 5 Downregulated ncRNAs

- COPG2IT1 (lncRNA, log2FC=-1.21, FDR=6.30e-03)
- TLK2P1 (processed_pseudogene, log2FC=-1.22, FDR=2.20e-03)
- ZNF101P2 (processed_pseudogene, log2FC=-1.23, FDR=1.50e-03)
- ZNF204P (transcribed_unprocessed_pseudogene, log2FC=-1.23, FDR=3.00e-04)
- LINC02217 (lncRNA, log2FC=-1.23, FDR=5.00e-04)
### GSE48350: Alzheimer's Disease (Microarray)
- **Samples:** 173 total (33 disease / 140 control)
- **ncRNA Biomarkers:** 40
- **Analysis Date:** Completed Feb 18, 2026

#### Top 5 Upregulated ncRNAs

- LINC00507 (lncRNA, log2FC=1.09, FDR=1.48e-02)
- LINC01007 (lncRNA, log2FC=1.04, FDR=2.10e-03)
- LINC00641 (lncRNA, log2FC=0.87, FDR=1.70e-03)
- SLC26A4-AS1 (lncRNA, log2FC=0.85, FDR=1.40e-03)
- TSIX (lncRNA, log2FC=0.82, FDR=7.17e-02)

#### Top 5 Downregulated ncRNAs

- STAG3L3 (transcribed_unprocessed_pseudogene, log2FC=-0.50, FDR=0.00e+00)
- LINC01354 (lncRNA, log2FC=-0.50, FDR=2.10e-03)
- SOX21-AS1 (lncRNA, log2FC=-0.51, FDR=1.26e-02)
- KLF3-AS1 (lncRNA, log2FC=-0.51, FDR=2.00e-04)
- NAPSB (transcribed_unprocessed_pseudogene, log2FC=-0.52, FDR=2.90e-03)
### GSE95587: Alzheimer's Disease (RNA-seq)
- **Samples:** 117 total (84 disease / 33 control)
- **ncRNA Biomarkers:** 0
- **Analysis Date:** Completed Feb 18, 2026

#### Top 5 Upregulated ncRNAs


#### Top 5 Downregulated ncRNAs

### GSE153960: ALS (RNA-seq)
- **Samples:** 1243 total (963 disease / 280 control)
- **ncRNA Biomarkers:** 40
- **Analysis Date:** Completed Feb 18, 2026

#### Top 5 Upregulated ncRNAs

- TGFB2-OT1 (lncRNA, log2FC=0.71, FDR=0.00e+00)
- nan (lncRNA, log2FC=0.69, FDR=0.00e+00)
- nan (lncRNA, log2FC=0.68, FDR=0.00e+00)
- LINC01094 (lncRNA, log2FC=0.65, FDR=0.00e+00)
- nan (transcribed_processed_pseudogene, log2FC=0.59, FDR=0.00e+00)

#### Top 5 Downregulated ncRNAs

- nan (lncRNA, log2FC=-0.50, FDR=0.00e+00)
- SLFNL1-AS1 (lncRNA, log2FC=-0.50, FDR=0.00e+00)
- PCDHA14 (transcribed_unprocessed_pseudogene, log2FC=-0.50, FDR=0.00e+00)
- nan (transcribed_processed_pseudogene, log2FC=-0.50, FDR=0.00e+00)
- nan (transcribed_unprocessed_pseudogene, log2FC=-0.50, FDR=0.00e+00)