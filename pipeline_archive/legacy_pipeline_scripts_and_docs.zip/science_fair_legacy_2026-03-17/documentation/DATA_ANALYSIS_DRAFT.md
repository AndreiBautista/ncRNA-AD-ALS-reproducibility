# Data and Analysis (Google Doc Ready)

## Data Tables

### Table A. Sample counts (unit: samples, n)
| Dataset | Disease group (n) | Control group (n) | Tissue/Source |
|---|---:|---:|---|
| AD (GSE203206) | Disease = 39 | Control = 8 | Human brain bulk RNA-seq |
| ALS (GSE124439) | ALS = 145 | Control = 17 | Human brain bulk RNA-seq |

### Table B. Top ncRNA biomarkers (unit: log2FC)
| Dataset | Gene | log2FC (disease - control) | p value | FDR (padj) | Direction |
|---|---|---:|---:|---:|---|
| AD | LINC01013 | -0.560 | 1.49e-10 | 1.07e-06 | Down |
| AD | ADGRB3-DT | -1.453 | 7.25e-10 | 2.59e-06 | Down |
| AD | AMMECR1LP1 | -0.981 | 3.84e-09 | 9.14e-06 | Down |
| ALS | TUSC7 | 0.247 | 2.02e-08 | 1.25e-04 | Up |
| ALS | MAPK8IP1P2 | 1.923 | 8.37e-08 | 2.41e-04 | Up |
| ALS | LINC02560 | 0.237 | 1.37e-07 | 2.41e-04 | Up |

### Table C. Descriptive statistics for top ncRNAs (unit: log2-CPM)
| Dataset | Gene | Disease mean ± SD | Control mean ± SD |
|---|---|---|---|
| AD | LINC01013 | 0.795 ± 0.359 | 1.355 ± 0.113 |
| AD | ADGRB3-DT | 3.607 ± 1.041 | 5.060 ± 0.267 |
| AD | AMMECR1LP1 | 1.066 ± 0.729 | 2.047 ± 0.211 |
| ALS | TUSC7 | 0.011 ± 0.024 | 0.000 ± 0.000 |
| ALS | MAPK8IP1P2 | 0.885 ± 1.216 | 0.109 ± 0.082 |
| ALS | LINC02560 | 0.010 ± 0.023 | 0.000 ± 0.000 |

### Table D. Cross-disease overlap
| Metric | Value |
|---|---:|
| Shared ncRNAs (AD vs ALS, FDR < 0.05) | 5 |

## Figures
Insert the following figures and place each under its own caption:
1. AD volcano plot (log2FC vs -log10(FDR))
2. AD PCA plot (samples clustered by condition)
3. AD top-3 bar plots (mean ± SD)
4. ALS volcano plot (log2FC vs -log10(FDR))
5. ALS PCA plot (samples clustered by condition)
6. ALS top-3 bar plots (mean ± SD)
7. AD vs ALS Venn diagram (shared ncRNAs)
8. AD ROC curve (top 10 ncRNAs)
9. ALS ROC curve (top 10 ncRNAs)

## Figure-by-Figure Analysis (Third Person, Passive Voice)
**Figure 1: AD volcano plot.** The x-axis shows log2FC (disease minus control) and the y-axis shows -log10(FDR). Genes farther to the left or right were changed more strongly, and genes higher on the plot were more statistically significant. The dense cluster near log2FC = 0 shows genes with little change, while the most important ncRNAs appear in the upper left or upper right. This supports the selection of top AD biomarkers used in Table B.

**Figure 2: AD PCA plot.** Each point represents one sample and the axes show the two strongest principal components. Separation between disease and control groups indicates that overall ncRNA expression differs between groups. This supports the claim that the AD disease state shifts the global ncRNA profile.

**Figure 3: AD top-3 bar plots.** Bars show mean log2-CPM with SD error bars for disease vs control. Lower disease means were observed for LINC01013, ADGRB3-DT, and AMMECR1LP1, matching the negative log2FC values in Table B. This directly links the statistical results to a visible expression shift.

**Figure 4: ALS volcano plot.** The distribution shows which ncRNAs have both large effect size and strong significance. The most significant ALS ncRNAs are positioned high on the plot, indicating low FDR values. This supports the ALS biomarker list in Table B.

**Figure 5: ALS PCA plot.** Disease and control samples show separation across the first two principal components, indicating a systematic expression difference in ALS. This provides a dataset-wide view that complements the gene-level statistics.

**Figure 6: ALS top-3 bar plots.** Higher mean expression in disease samples was observed for TUSC7, MAPK8IP1P2, and LINC02560, matching the positive log2FC values in Table B. The error bars show within-group variability, supporting reliability of the observed direction.

**Figure 7: AD vs ALS Venn diagram.** The overlap count shows ncRNAs that are significant in both diseases. This supports the cross-disease claim by highlighting shared biomarkers rather than disease-specific changes only.

**Figure 8: AD ROC curve.** The ROC curve shows sensitivity vs false positive rate using the top 10 AD ncRNAs as a combined score. A curve above the diagonal indicates better-than-random separation of disease and control, supporting diagnostic potential.

**Figure 9: ALS ROC curve.** The ROC curve demonstrates classification performance for ALS using the top 10 ncRNAs. Separation above the diagonal indicates that the ALS biomarkers discriminate between disease and control samples.

## Statistical Analysis (Descriptive and Inferential)
Descriptive statistics were computed as mean and standard deviation of log2-CPM for disease and control groups (Table C). Inferential statistics were computed using Welch two-sample t-tests, followed by Benjamini-Hochberg FDR correction (Table B). Significant ncRNAs were identified at FDR < 0.05. AD yielded 2,208 significant ncRNAs and ALS yielded 83 significant ncRNAs.

## Written Description (Third Person, Passive Voice)
Expression profiles were compared between disease and control groups for AD and ALS. Strong shifts were observed in multiple ncRNAs, and the most significant changes were summarized in Table B. In AD, LINC01013, ADGRB3-DT, and AMMECR1LP1 were reduced in disease compared with controls, as shown by negative log2FC values and lower means in Table C. In ALS, TUSC7, MAPK8IP1P2, and LINC02560 were elevated in disease compared with controls, as shown by positive log2FC values and higher means in Table C. A shared set of 5 ncRNAs was detected across AD and ALS, supporting cross-disease overlap (Table D and Venn diagram). ROC curves indicated separation of disease and control using the top 10 ncRNAs, supporting diagnostic potential.

