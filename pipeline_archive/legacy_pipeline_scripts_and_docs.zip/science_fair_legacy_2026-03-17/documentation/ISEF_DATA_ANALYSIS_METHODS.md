# ncRNA Biomarker Discovery - Data Analysis Methods

**Project:** ncRNA Biomarker Identification Study
**Date:** February 18, 2026

## 1. Data Source and Preparation

### Public Datasets
Four GEO datasets were selected based on:
1. Availability of raw counts/expression data
2. Sample annotations (disease status, tissue type)
3. Sufficient sample size (n ≥ 40)
4. Brain tissue origin (relevant to CNS diseases)

| Dataset ID | Disease | Platform | N Samples | N Disease | N Control | Reference |
|-----------|---------|----------|-----------|-----------|-----------|-----------|
| GSE203206 | Alzheimer's Disease | RNA-seq | 47 | 39 | 8 | Cognition/autopsy samples |
| GSE48350 | Alzheimer's Disease | Microarray (GPL570) | 173 | 33 | 140 | Temporal cortex |
| GSE95587 | Alzheimer's Disease | RNA-seq | 117 | 84 | 33 | Brain tissue |
| GSE153960 | ALS | RNA-seq | 1,243 | 963 | 280 | Motor cortex, spinal cord |

### Data Processing Pipeline

#### Step 1: Data Retrieval
- Downloaded raw counts from GEO (supplementary files for GSE95587)
- Microarray probes mapped to Ensembl gene IDs via GPL570
- Ensembl ID normalization (removal of version suffixes for consistent matching)

#### Step 2: Quality Control
- Removed genes with <1 CPM in <50% of samples
- Excluded non-human sequences (GSE153960: species filtering)
- Verified metadata: disease/control group classification

#### Step 3: Normalization
- **Method:** log2(CPM + 1) normalization
- **Formula:** log2((read_count / library_size) × 1,000,000 + 1)
- **Rationale:** Stabilizes variance, enables linear statistical tests

## 2. Differential Expression Analysis

### Statistical Test: Welch's t-test
- **Choice:** Accounts for unequal variances between disease/control groups
- **Null Hypothesis:** No difference in mean expression between groups
- **Formula:**
 - t = (mean_disease - mean_control) / sqrt(var_disease/n_disease + var_control/n_control)

### Multiple Testing Correction

#### Method: Benjamini-Hochberg FDR Control
- **Alpha:** 0.1 (10% false discovery rate)
- **Rationale:** Balances discovery power with false positive control in exploratory analysis
- **Formula:** Adjusted p-value = p-value × (total tests / rank)

### Significance Thresholds

Final biomarker set filtered by:
1. **FDR-corrected p-value:** < 0.1
2. **Absolute log2 fold-change:** > 0.5 (≈1.4× change in expression)

**Justification:**
- FDR < 0.1: More permissive than 0.05 (exploratory phase, rare ncRNA variants)
- |log2FC| > 0.5: Biologically meaningful expression difference

## 3. ncRNA Annotation and Classification

### Gene Annotation
- **Source:** Ensembl human genome annotation (v62)
- **Gene count:** 62,754 genes with biotype annotation

### ncRNA Biotypes Included
```
lncRNA (long non-coding RNA)
miRNA (microRNA)
snRNA (small nuclear RNA)
snoRNA (small nucleolar RNA)
scaRNA (small Cajal body-specific RNA)
misc_RNA (miscellaneous RNA)
pseudogene (all types) (transcribed and untranscribed)
rRNA (ribosomal RNA - mt_rRNA)
antisense (antisense transcripts)
```

### Filtering Logic
- All genes tested for differential expression
- Significant DE genes (FDR<0.1, |log2FC|>0.5) subset to ncRNA biotypes
- Result: High-quality, biologically-characterized ncRNA biomarkers

## 4. Visualization Methods

### Volcano Plots
- **X-axis:** log2 fold-change (disease/control)
- **Y-axis:** -log10(p-value)
- **Color:** Significance status (FDR < 0.1, red = significant)
- **Purpose:** Overview of DE landscape and effect sizes

### PCA (Principal Component Analysis)
- **Transformation:** log2-CPM normalized counts
- **Method:** Singular value decomposition
- **Interpretation:** PC1/PC2 capture major expression variance; cluster separation indicates distinct disease phenotypes

### Heatmaps
- **Data:** log2-CPM expression (top 30 ncRNAs)
- **Normalization:** z-score per gene (mean=0, SD=1)
- **Clustering:** Hierarchical clustering (Euclidean distance, Ward linkage)
- **Purpose:** Visualize biomarker co-expression patterns

### Bar Plots
- **Content:** Top 3 ncRNAs by absolute log2FC
- **Y-axis:** Mean expression by group ± SE
- **Statistical annotation:** p-value and FDR

## 5. Data Integration Across Datasets

### Cross-Dataset Overlap
For Alzheimer's disease datasets (GSE203206, GSE48350, GSE95587):
- Identified ncRNAs consistently dysregulated across 2+ independent cohorts
- Higher confidence biomarkers = replicated findings

For AD-ALS comparison:
- Identified ncRNAs significant in both disease types
- Potential "neurodegenerative signature" ncRNAs

## 6. Quality Metrics

### Reproducibility
- Open-source tools (Python, pandas, scipy)
- Version-controlled pipeline
- All intermediate files retained
- Full results tables provide transparency

### Power Analysis
- Largest dataset (GSE153960, n=1,243) provides power to detect small effects
- Multiple independent datasets enable validation
- Conservative FDR threshold reduces false positives

### Limitations
1. **GSE95587 yields 0 ncRNAs:** Pre-normalized RNA-seq data reduces variance resolution
2. **Batch effects:** Not explicitly corrected (different labs/platforms)
3. **Confounding:** Age, sex, comorbidities not adjusted in primary analysis
4. **Tissue heterogeneity:** Whole-tissue samples contain multiple cell types

## 7. Output Structure

```
results/isef_best/final_4datasets/
├── per_dataset/
│ ├── GSE203206/
│ │ ├── data/
│ │ │ ├── GSE203206_differential_results.csv (all genes)
│ │ │ ├── GSE203206_biomarker_candidates.csv (ncRNA only)
│ │ │ ├── GSE203206_DE_summary.csv (statistics)
│ │ │ └── GSE203206_dataset_summary.csv (metadata)
│ │ └── figures/
│ │ ├── GSE203206_volcano_*.png
│ │ ├── GSE203206_PCA.png
│ │ ├── GSE203206_top_ncRNA_heatmap.png
│ │ └── GSE203206_top3_ncRNA_barplot.png
│ ├── GSE48350/ (same structure)
│ ├── GSE95587/ (same structure)
│ └── GSE153960/ (same structure)
└── conserved_ncrnas/
 ├── cross_dataset_overlap.csv
 └── high_confidence_biomarkers.csv
```

## 8. Reproducibility

### Software Versions
- Python 3.9
- pandas 1.X
- scipy (ttest_ind, multiple testing)
- statsmodels (FDR-BH correction)
- matplotlib/seaborn (visualization)

### Raw Data Access
- GEO Series IDs: GSE203206, GSE48350, GSE95587, GSE153960
- Download via GEOquery (R) or GEOparse (Python)

### Code Repository
All pipeline scripts available in `pipeline/` and `scripts/` directories

---

**Contact:** austin.bautista@example.edu
**Citation:** [To be filled for publication]
