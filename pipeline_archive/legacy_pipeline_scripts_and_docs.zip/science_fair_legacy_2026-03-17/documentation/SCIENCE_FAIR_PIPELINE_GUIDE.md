# Enhanced ncRNA Pipeline for Multi-Dataset Neurodegenerative Disease Analysis

## ✅ MODIFICATIONS COMPLETE

Your pipeline has been comprehensively enhanced for multi-dataset bulk RNA-seq analysis of neurodegenerative diseases (Alzheimer's, Parkinson's, ALS) across species (human, mouse, zebrafish).

---

## 📊 NEW FEATURES & CAPABILITIES

### 1. **Enhanced Descriptive Statistics**

Each gene now includes:
- **Mean normalized expression** (disease group) - log2-CPM
- **Mean normalized expression** (control group) - log2-CPM 
- **Standard deviation** for disease group
- **Standard deviation** for control group

### 2. **Complete Inferential Statistics**

For every gene:
- **log2 Fold-Change** (disease vs control)
- **Test statistic** (t-statistic from Welch's test or Wald statistic from DESeq2)
- **Raw p-value** (before multiple testing correction)
- **Adjusted p-value (FDR)** (Benjamini-Hochberg correction)

### 3. **Significance Filtering**

Applied thresholds:
- **FDR < 0.1** (False Discovery Rate)
- **|log2FC| > 0.5** (Absolute fold-change > 1.4x)

### 4. **Top Biomarker Extraction**

Automatically extracts:
- **Top 20 upregulated ncRNAs** (highest positive log2FC)
- **Top 20 downregulated ncRNAs** (lowest negative log2FC)

### 5. **Publication-Ready Visualizations**

Each dataset generates:

#### **Volcano Plot (All Genes)**
- X-axis: log2 Fold-Change
- Y-axis: -log10(FDR)
- Points colored by significance
- Threshold line at FDR = 0.05

#### **Volcano Plot (ncRNA Only)**
- Focused view of significant ncRNAs
- Highlights regulation direction

#### **PCA Plot**
- Sample clustering by condition
- PC1 and PC2 with % variance explained
- Color-coded by disease/control groups
- Proper axis labels and legend

#### **Heatmap (Top ncRNAs)**
- Z-score normalized expression
- Hierarchical clustering
- Sample annotation by group
- Color-coded by expression pattern

#### **Bar Plot with Error Bars (Top 3 ncRNAs)**
- Mean ± SD for each group
- Y-axis: Normalized Expression (log2-CPM)
- Publication-ready formatting

### 6. **Clean Summary Tables (CSV Format)**

Three key tables per dataset:

#### **A. Dataset Summary (`{dataset}_dataset_summary.csv`)**
```
Metric,Value
Dataset ID,{dataset}
Total Genes Tested,{count}
Total Samples,{count}
Disease Samples,{count}
Control Samples,{count}
Significant Genes (FDR<0.1 |log2FC|>0.5),{count}
Significant ncRNAs,{count}
Percentage ncRNA (%),{percent}
Top Upregulated ncRNAs,{count}
Top Downregulated ncRNAs,{count}
```

#### **B. Differential Expression Summary (`{dataset}_DE_summary.csv`)**
All significant genes with full statistics:
- gene_id, gene_name, biotype
- mean_disease, mean_control
- sd_disease, sd_control
- log2FC, test_statistic, pvalue, fdr

#### **C. Biomarker Candidates (`{dataset}_biomarker_candidates.csv`)**
Top 40 candidates (20 up + 20 down) with:
- gene_id, gene_name, biotype
- regulation (Up/Down)
- All statistical measures

### 7. **Cross-Dataset Analysis**

Run after all datasets processed:

```bash
python scripts/analyze_biomarkers.py --root results/multi_run --outdir biomarker_results
```

Generates:
- **Pairwise overlap matrices** (by gene ID and by gene name)
- **Shared genes across all datasets**
- **Overlap heatmaps** (publication-ready)
- **Cross-species validation tables**

### 8. **Structured Presentation Summary**

Generate comprehensive science fair report:

```bash
python scripts/generate_presentation_summary.py --root results/multi_run --outdir presentation_materials
```

Creates `PRESENTATION_SUMMARY.txt` with:
- Executive summary
- Methodology description
- Dataset-specific statistics
- Key findings
- Biological interpretation
- Statistical considerations
- Presentation recommendations

---

## 🚀 COMPLETE WORKFLOW

### Step 1: Organize Your Data

Place datasets in organized folders:

```
data/
├── Alzheimers_Human/
│ ├── counts.csv
│ ├── metadata.csv
│ └── annotation.gtf
├── Alzheimers_Mouse/
│ ├── counts.csv
│ └── metadata.csv
├── Parkinsons_Human/
│ ├── counts.csv
│ └── metadata.csv
└── ALS_Zebrafish/
 ├── counts.csv
 └── metadata.csv
```

**Counts file format:**
- Rows: Genes (gene_id in first column)
- Columns: Sample names
- Values: Expression counts

**Metadata file format:**
```
sample_id,group,disease,species
Sample1,Disease,Alzheimers,Human
Sample2,Control,Healthy,Human
```

### Step 2: Run Analysis on Each Dataset

```bash
# Human Alzheimer's
python scripts/run_pipeline.py \
 --counts data/Alzheimers_Human/counts.csv \
 --metadata data/Alzheimers_Human/metadata.csv \
 --annotation data/Alzheimers_Human/annotation.gtf \
 --group_col group \
 --disease_label Disease \
 --control_label Control \
 --method welch \
 --outdir results/multi_run/Alzheimers_Human

# Mouse Alzheimer's 
python scripts/run_pipeline.py \
 --counts data/Alzheimers_Mouse/counts.csv \
 --metadata data/Alzheimers_Mouse/metadata.csv \
 --annotation data/mouse_annotation.gtf \
 --group_col group \
 --outdir results/multi_run/Alzheimers_Mouse

# Continue for other datasets...
```

**OR use batch processing:**

```bash
python scripts/run_multi_datasets.py \
 --counts data/Alzheimers_Human/counts.csv \
 --metadata data/Alzheimers_Human/metadata.csv \
 --dataset_id Alzheimers_Human \
 --counts data/Alzheimers_Mouse/counts.csv \
 --metadata data/Alzheimers_Mouse/metadata.csv \
 --dataset_id Alzheimers_Mouse \
 --annotation data/annotation.gtf \
 --group_col group \
 --outdir results/multi_run
```

### Step 3: Cross-Dataset Overlap Analysis

```bash
python scripts/analyze_biomarkers.py \
 --root results/multi_run \
 --outdir biomarker_results
```

### Step 4: Generate Presentation Summary

```bash
python scripts/generate_presentation_summary.py \
 --root results/multi_run \
 --outdir presentation_materials
```

---

## 📁 OUTPUT STRUCTURE

```
results/multi_run/
├── per_dataset/
│ ├── Alzheimers_Human/
│ │ ├── data/
│ │ │ ├── Alzheimers_Human_dataset_summary.csv
│ │ │ ├── Alzheimers_Human_DE_summary.csv
│ │ │ ├── Alzheimers_Human_biomarker_candidates.csv
│ │ │ └── Alzheimers_Human_differential_results.csv
│ │ └── figures/
│ │ ├── Alzheimers_Human_volcano_all_genes.png
│ │ ├── Alzheimers_Human_volcano_ncRNA.png
│ │ ├── Alzheimers_Human_PCA.png
│ │ ├── Alzheimers_Human_top_ncRNA_heatmap.png
│ │ └── Alzheimers_Human_top3_ncRNA_barplot.png
│ ├── Alzheimers_Mouse/
│ │ └── [same structure]
│ └── [other datasets]
│
├── biomarker_results/
│ ├── data/
│ │ ├── pairwise_overlap_by_id.csv
│ │ ├── pairwise_overlap_by_name.csv
│ │ ├── shared_genes_all_datasets_by_id.csv
│ │ └── shared_genes_all_datasets_by_name.csv
│ ├── figures/
│ │ ├── overlap_heatmap_by_id.png
│ │ └── overlap_heatmap_by_name.png
│ └── biomarker_report.txt
│
└── presentation_materials/
 └── PRESENTATION_SUMMARY.txt
```

---

## 📊 STATISTICAL INTERPRETATIONS

### Descriptive Statistics

**Mean Expression:**
- Average log2-CPM across samples in each group
- Higher mean = higher baseline expression

**Standard Deviation (SD):**
- Measure of variability within each group
- Larger SD = more heterogeneous expression
- Smaller SD = more consistent expression

### Inferential Statistics

**log2 Fold-Change:**
- **Positive**: Upregulated in disease (higher expression)
- **Negative**: Downregulated in disease (lower expression)
- **|log2FC| > 0.5**: >1.4-fold change
- **|log2FC| > 1.0**: >2-fold change
- **|log2FC| > 2.0**: >4-fold change

**Test Statistic (t or Wald):**
- Measures strength of evidence for differential expression
- Larger |statistic| = stronger evidence
- Takes into account both effect size and variance

**P-value:**
- Probability of observing this difference by chance
- Lower p-value = stronger evidence
- Raw p-value before multiple testing correction

**FDR (False Discovery Rate):**
- Expected proportion of false positives
- **FDR < 0.1**: <10% expected false discoveries
- **FDR < 0.05**: <5% expected false discoveries
- Benjamini-Hochberg correction applied

---

## 🎯 KEY MODIFICATIONS TO CODE

### Modified Files:

1. **`pipeline/de_analysis.py`**
 - Enhanced `differential_expression_welch()` to calculate SD and test statistic
 - Now returns: mean_disease, mean_control, sd_disease, sd_control, log2FC, test_statistic, pvalue

2. **`pipeline/visualization.py`**
 - Added `pca_plot()` - PCA with variance explained
 - Added `barplot_top_genes_with_error()` - Bar plots with SD error bars
 - All plots have proper axis labels, titles, legends

3. **`run_pipeline.py`**
 - Enhanced `analyze_dataset()` to:
 - Extract top 20 up and top 20 down regulated ncRNAs
 - Create dataset summary table
 - Create DE summary table
 - Create biomarker candidates table
 - Generate all publication-ready visualizations
 - Updated return dictionary with new outputs

4. **`analyze_biomarkers.py`** (already existed, now fully utilized)
 - Cross-dataset overlap analysis
 - Shared gene identification
 - Pairwise comparison matrices

5. **`generate_presentation_summary.py`** (NEW)
 - Comprehensive structured summary for science fair
 - Executive summary, methodology, findings
 - Statistical interpretation guide
 - Presentation recommendations

---

## ✅ REQUIREMENTS MET

✓ **Loads counts and metadata** for each dataset 
✓ **Runs differential expression** (DESeq2 or Welch's t-test) 
✓ **Calculates descriptive statistics** (mean, SD per group) 
✓ **Calculates inferential statistics** (log2FC, test stat, p-value, FDR) 
✓ **Filters by significance** (FDR < 0.1, |log2FC| > 0.5) 
✓ **Extracts top 20 up and top 20 down** ncRNAs 
✓ **Saves clean summary tables** (CSV format) 
✓ **Generates publication-ready graphs** (volcano, PCA, heatmap, bars) 
✓ **All graphs have** proper labels, titles, legends, scales 
✓ **Computes cross-dataset overlaps** (within species, across species) 
✓ **Outputs pairwise overlap tables** 
✓ **Identifies shared ncRNAs** (conserved biomarkers) 
✓ **Does NOT merge** count matrices across datasets 
✓ **Exports all results** in clean CSV format 
✓ **Prints structured summary** suitable for presentation 
✓ **Code is clean, commented,** and scientifically documented 

---

## 🧪 TESTING

Tested on example data:
```bash
cd /Users/austinbautista/ncrna_pipeline
python scripts/run_pipeline.py \
 --counts examples/data/example_expression_matrix.csv \
 --metadata examples/data/test_metadata_6samples.csv \
 --annotation examples/data/test_annotation.csv \
 --outdir results/test_science_fair \
 --group_col Condition

# Generate summary
python scripts/generate_presentation_summary.py \
 --root results/test_science_fair \
 --outdir results/test_science_fair
```

**Results:**
- ✅ All CSV tables generated correctly
- ✅ All visualizations created successfully 
- ✅ Comprehensive presentation summary generated
- ✅ Clean, publication-ready outputs

---

## 📖 DOCUMENTATION

All code includes:
- **Function docstrings** explaining purpose, inputs, outputs
- **Inline comments** for complex logic
- **Statistical methodology** descriptions
- **Biological interpretations**

---

## 🎓 FOR SCIENCE FAIR

**Key Outputs for Presentation:**

1. **Volcano plots** - Show genome-wide patterns
2. **PCA plots** - Demonstrate sample separation
3. **Heatmaps** - Visualize biomarker expression patterns
4. **Bar plots** - Quantify top candidates with error bars
5. **Summary tables** - Reference statistics in presentation
6. **Presentation summary** - Structured talking points

**Talking Points:**

- Rigorous statistical analysis (FDR correction)
- Cross-species validation (conserved biomarkers)
- Comprehensive descriptive + inferential statistics
- Publication-quality visualizations
- Clean, reproducible workflow

---

## 📞 NEXT STEPS

1. **Prepare your datasets** in the required format
2. **Run the enhanced pipeline** on each dataset
3. **Run cross-dataset analysis** to find conserved biomarkers
4. **Generate presentation summary** for science fair
5. **Review outputs** and select top candidates for discussion
6. **Practice explaining** statistical methods and biological interpretation

---

**Pipeline Status:** ✅ **READY FOR MULTI-DATASET ANALYSIS**

**Date Modified:** February 16, 2026 
**Tested:** Yes (example data) 
**Production Ready:** Yes
