# 🚀 START HERE: Quick Start Checklist

## YOUR PROJECT JUST UPGRADED! 🎯

**From:** Single-disease analysis (Alzheimer's only) 
**To:** Cross-disease meta-analysis (Alzheimer's + Parkinson's + ALS) 
**Impact:** SIGNIFICANTLY more impressive for 

---

## 📋 IMMEDIATE TODO (Next 2 Hours)

- [ ] Read `PROJECT_SUMMARY.md` (5 min) - Overview of what you're doing
- [ ] Read `CROSS_DISEASE_PROJECT_GUIDE.md` (15 min) - Detailed workflow
- [ ] Read `WORKFLOW_VISUALIZATION.md` (10 min) - Visual architecture
- [ ] Run `python scripts/search_geo_datasets.py` (2 min) - See GEO search terms
- [ ] Verify folder structure exists:
 ```bash
 ls data/neurodegenerative_diseases/
 ```
 Should show: `alzheimers/ parkinsons/ als/`

✅ **You're ready to start!**

---

## 🔍 THIS WEEK: FIND THE DATASETS

### Step 1: Search for Parkinson's Data (45 min)

1. Go to: **https://www.ncbi.nlm.nih.gov/geo/**
2. Click **"Advanced Search"**
3. Paste this search term:
 ```
 ("Parkinson disease" OR "Parkinson's disease") 
 AND ("RNA-seq" OR "RNA sequencing") 
 AND ("brain" OR "substantia nigra" OR "striatum")
 AND ("homo sapiens")
 NOT ("single cell")
 ```
4. Click **Search**
5. Filter by:
 - Organism: **Homo sapiens**
 - Study type: **Expression profiling by high throughput sequencing**
 - Date: **2015-2024** (recent, better quality)

6. Look for studies with:
 - ✅ Clearly titled with "Parkinson" or "PD"
 - ✅ Published in recent years (2015+)
 - ✅ Sample size looks good (30+ disease, 15+ control)
 - ✅ Brain tissue mentioned (substantia nigra, striatum, prefrontal cortex)
 - ✅ "RNA-seq" mentioned

7. **Bookmark promising results** (click to view):
 - Read the abstract
 - Check if raw counts available
 - Note the GEO accession (GSE######)

8. **Select 2-3 best studies** that together have 200+ samples

### Step 2: Search for ALS Data (45 min)

1. Go back to: **https://www.ncbi.nlm.nih.gov/geo/**
2. Click **"Advanced Search"**
3. Paste this search term:
 ```
 ("amyotrophic lateral sclerosis" OR "ALS" OR "Motor Neuron Disease")
 AND ("RNA-seq" OR "RNA sequencing")
 AND ("motor cortex" OR "spinal cord" OR "motor neuron" OR "brain")
 AND ("homo sapiens")
 NOT ("single cell")
 ```
4. Follow same process as Parkinson's
5. **Select 2-3 best studies** that together have 150-200 samples

### Step 3: Download the Files (1-2 hours)

For **each** promising study:

1. Click on the **GSE accession** (e.g., GSE111932)
2. Scroll down to **"Supplementary file"** section
3. Download:
 - `*counts.txt` or `*counts.csv` (the count matrix)
 - `series_matrix.txt` OR any metadata file
4. Save to a temporary folder on your computer

---

## 📁 NEXT: ORGANIZE YOUR DATA

### Create This Folder Structure:

```bash
# On your computer, create:
ncrna_pipeline/data/neurodegenerative_diseases/

parkinsons/
├── GSE111932/ ← First Parkinson's study
│ ├── counts.tsv
│ └── metadata.csv
├── GSE54282/ ← Second Parkinson's study (if found)
│ ├── counts.tsv
│ └── metadata.csv
└── GSE40967/ ← Third (if found)

als/
├── GSE153960/ ← First ALS study
│ ├── counts.tsv
│ └── metadata.csv
├── GSE112119/ ← Second ALS study
│ ├── counts.tsv
│ └── metadata.csv
└── GSE27894/ ← Third (if found)
```

### Convert Files to Standard Format:

For **each** study folder, create two files:

#### `counts.tsv`
✅ **Required format:**
- Tab-separated
- Header row: sample names
- First column: gene IDs (Ensembl format: ENSG00000...)
- Values: raw counts (integers)

```
Example:
gene_id sample1 sample2 sample3
ENSG00000223972 0 1 15
ENSG00000227232 2 8 23
```

**How to convert:**
- If you have a CSV: open in Excel, save as TSV (.txt with tabs)
- If you have series_matrix.txt: extract the data section (remove "!" headers)
- If you have multiple sheets: extract the counts sheet only

#### `metadata.csv`
✅ **Required format:**
- Comma-separated
- Headers: `sample_id,disease_status,tissue_type,study_id`
- disease_status: "Disease" or "Control"
- tissue_type: "brain", "substantia_nigra", "motor_cortex", etc.
- study_id: The GSE number

```
Example:
sample_id,disease_status,tissue_type,study_id
sample_1,Disease,substantia_nigra,GSE111932
sample_2,Control,substantia_nigra,GSE111932
sample_3,Disease,substantia_nigra,GSE111932
```

**How to create:**
1. Open Excel
2. Create 4 columns (as above)
3. Copy sample names from counts.tsv header
4. Look in dataset's series_matrix.txt or README to find disease/control labels
5. Save as CSV

---

## ✅ VALIDATION (When Ready)

Once all data is organized:

```bash
cd ~/ncrna_pipeline
python scripts/cross_disease_pipeline.py
```

This will check:
- ✅ All GSE folders exist
- ✅ Each GSE has counts.tsv + metadata.csv
- ✅ Fileformats are correct
- ✅ Sample counts make sense
- ✅ No obvious errors

**Expected output:**
```
✓ ALZHEIMERS 47 samples (1 study)
⏳ PARKINSONS 240 samples (3 studies) ← Your data
⏳ ALS 185 samples (2 studies) ← Your data
```

---

## 📊 THEN SEND ME:

Once validated, send me a message with:

**Parkinson's datasets found:**
- GSE numbers (e.g., "GSE111932, GSE54282, GSE40967")
- Total samples
- Tissue types
- Any issues you encountered

**ALS datasets found:**
- GSE numbers
- Total samples
- Tissue types
- Any issues you encountered

**Then I build:**
- Harmonization pipeline
- DESeq2 analysis script
- Visualization pipeline
- Cross-disease comparison

---

## ⏰ TIMELINE

```
This week:
 Mon-Wed → Search GEO for datasets (2-3 hrs)
 Wed-Thu → Download files (1-2 hrs)
 Thu-Fri → Format & organize (2-3 hrs)
 Fri → Run validation script (30 min)
 Send me results

Next week:
 I build & run analysis (2-3 days)
 You review results (1 day)

Week after:
 Generate visualizations (1 day)
 Build presentation (2 days)
 Practice presentation (1 day)
```

---

## 📚 HELPFUL RESOURCES

**If you get stuck:**

1. **Dataset format questions:**
 - Check: `CROSS_DISEASE_PROJECT_GUIDE.md` § "FILE FORMATS"
 - Example: Look at existing GSE203206 files for reference

2. **GEO search questions:**
 - Run: `python scripts/search_geo_datasets.py`
 - Check: "QUICK REFERENCE" section for study examples

3. **Data organization questions:**
 - Look at: `data/neurodegenerative_diseases/alzheimers/` (my example)
 - Copy that structure for your new disease folders

4. **Trouble downloading?**
 - Sometimes GEO has supplementary files linked in "Publication"
 - Check paper's journal website for data deposition
 - Contact authors (they usually respond!)

---

## 🎯 YOUR GOAL THIS WEEK

**Find & organize:**
- 2-3 Parkinson's studies (200+ samples)
- 2-3 ALS studies (150-200 samples)
- Properly formatted into folder structure
- Validated by the Python script

**Send me:**
- The GSE accession numbers
- Confirmation that validation passed

**Then I do:**
- All the heavy computational work
- Generate all the figures
- Prepare the presentation

---

## 💪 WHY THIS IS WINNING

This project is exceptionally strong because:

1. **Scale:** ~450 samples across 3 diseases (Most projects use <100)
2. **Novelty:** Cross-disease comparison is rare in science fairs
3. **Real Impact:** Could actually help patients with multiple diseases
4. **Rigor:** Using publication-standard methods (DESeq2)
5. **Clear Story:** "Found universal ncRNAs that appear in ALL 3 diseases"

Judges will be impressed. You're doing real research!

---

## 🚀 NEXT ACTION

**RIGHT NOW:**

1. Open a terminal
2. Type:
 ```bash
 cd ~/ncrna_pipeline
 python scripts/search_geo_datasets.py
 ```
3. Read the output
4. Open browser: https://www.ncbi.nlm.nih.gov/geo/
5. Start searching! 🔍

---

**Questions? Check the guides or let me know!**

*You've got this! 💪*
