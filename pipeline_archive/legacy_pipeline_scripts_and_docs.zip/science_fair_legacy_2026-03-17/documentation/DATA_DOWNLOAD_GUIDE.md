# Data Download Guide for Multi-Disease ncRNA Analysis

## What You Need for Each Disease/Species Combination

For EACH of the 9 datasets (3 diseases × 3 species), you need:

1. **counts.csv** - Expression matrix (genes × samples)
 - Rows: gene IDs (Ensembl IDs like ENSG00000123456)
 - Columns: sample names
 - Values: raw counts or normalized values

2. **metadata.csv** - Sample information
 - Rows: sample names (must match columns in counts)
 - Columns: condition/group, age, sex, brain region, etc.
 - Must have a column (group_col) that says "disease_label" vs "control_label"

3. **annotation_[species].csv** - Gene information
 - Already downloaded in setup_path_a.py ✓
 - Contains: gene_id, gene_name, biotype

---

## GEO Dataset Search Strategy

### For HUMAN datasets, search GEO (www.ncbi.nlm.nih.gov/geo) with:

**Alzheimer's:**
- "Alzheimer's disease brain RNA-seq" 
- "AD substantia nigra tissue RNA-seq"
- "dementia hippocampus transcriptome"
- Good datasets: GSE203206 ✓ (already have), GSE122063, GSE33000

**Parkinson's:**
- "Parkinson's disease substantia nigra RNA-seq"
- "PD dopaminergic neurons transcriptome"
- "neurodegeneration parkinsonism RNA-seq"
- Good datasets: GSE20164, GSE40958, GSE111031

**ALS:**
- "ALS spinal cord RNA-seq"
- "motor neuron degeneration transcriptome"
- "SOD1 ALS patient tissue RNA-seq"
- Good datasets: GSE112356, GSE124020, GSE137810

### For MOUSE model datasets, search with:

**Alzheimer's:**
- "APP/PS1 mouse brain RNA-seq"
- "5xFAD transgenic model transcriptome"
- Result format: Usually GSMxxxxx entries need to be combined
- Extraction: Use `geo_integration.py` in the pipeline

**Parkinson's:**
- "MPTP mouse brain RNA-seq"
- "dopamine neuron degeneration transcriptome"

**ALS:**
- "SOD1-G93A mouse spinal cord RNA-seq"
- "motor neuron transgenic disease model"

### For ZEBRAFISH datasets, search:

- "zebrafish disease model RNA-seq" + {disease}
- "danio rerio neurodegeneration transcriptome"
- May need BioProject (www.ncbi.nlm.nih.gov/bioproject)
- Filter by: RNA-seq, whole organism or neural tissue

---

## How to Download from GEO

### Method 1: Series Matrix File (EASIEST)
1. Go to GEO, find your GSE number (e.g., GSE203206)
2. Scroll to "Series Matrix File(s)"
3. Download: Series Matrix (compressed)
4. Use `geo_integration.py` in our pipeline to parse

### Method 2: GEO Query (Python)
```python
from GEOparse import get_gse

gse = get_gse("GSE203206", download=True)
# Extracts counts, metadata, sample info automatically
```

### Method 3: Supplementary Files
1. Some studies provide raw counts in supplementary files
2. Download directly and organize as counts.csv + metadata.csv

---

## File Organization Example

After downloading, organize like this:

```
data/
├── annotations/
│ ├── annotation_human.csv ← Downloaded by setup_path_a.py ✓
│ ├── annotation_mouse.csv ← Downloaded by setup_path_a.py ✓
│ └── annotation_zebrafish.csv ← Downloaded by setup_path_a.py ✓
│
├── alzheimers/
│ ├── human/
│ │ ├── counts.csv ← GSE203206 data ✓ (already have)
│ │ └── metadata.csv ← GSE203206 metadata ✓ (already have)
│ ├── mouse/
│ │ ├── counts.csv ← Search GEO, download, rename
│ │ └── metadata.csv ← Extract from GEO metadata
│ └── zebrafish/
│ ├── counts.csv
│ └── metadata.csv
│
├── parkinsons/
│ ├── human/
│ │ ├── counts.csv
│ │ └── metadata.csv
│ ├── mouse/
│ │ ├── counts.csv
│ │ └── metadata.csv
│ └── zebrafish/
│ ├── counts.csv
│ └── metadata.csv
│
└── als/
 ├── human/
 │ ├── counts.csv
 │ └── metadata.csv
 ├── mouse/
 │ ├── counts.csv
 │ └── metadata.csv
 └── zebrafish/
 ├── counts.csv
 └── metadata.csv
```

---

## Quick Dataset Recommendations (Starting Point)

**START WITH THESE (easiest to work with):**
1. ✓ Alzheimer's Human: GSE203206 (already downloaded)
2. Parkinson's Human: GSE40958 (well-curated, large)
3. ALS Human: GSE112356 (motor neurons, nice metadata)

**Then add ONE from each model organism:**
4. Alzheimer's Mouse: Search "APP/PS1 RNA-seq" on GEO
5. Parkinson's Mouse: Search "MPTP mouse RNA-seq" on GEO
6. ALS Mouse: Search "SOD1-G93A RNA-seq" on GEO

**Zebrafish can wait** (fewer datasets available, but add for maximum impact)

---

## Pro Tips for Data Wrangling

- Some GEO datasets have weird formats → Use `pipeline/io.py::safe_read_table()` 
- Check metadata column names vary → Use `group_col` parameter in config
- Different gene ID systems (ENSG vs. gene names) → Annotation must match!
- Test with 1-2 datasets first, then scale to 9

