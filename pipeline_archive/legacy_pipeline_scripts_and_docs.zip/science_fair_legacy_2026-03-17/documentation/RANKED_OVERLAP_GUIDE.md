# Ranked Gene Overlap Analysis – Implementation Guide & Results

## Overview
Created `scripts/ranked_gene_overlap.py` to extract and compare top genes across datasets **without requiring statistical significance filtering**. This addresses the challenge where both GSE53697 and GSE173955 showed zero significant genes at standard FDR thresholds.

## New Script: `ranked_gene_overlap.py`

### Purpose
- Ranks genes by log2 fold-change (effect size)
- Extracts top N upregulated and top N downregulated genes per dataset
- Computes pairwise overlaps between datasets
- Works with individual datasets or batch multi-dataset results

### Usage

**Basic ranking analysis (top 100 genes per direction):**
```bash
python scripts/ranked_gene_overlap.py --root results/multi_run --top_n 100
```

**With optional FDR pre-filter (only rank among significant genes):**
```bash
python scripts/ranked_gene_overlap.py --root results/multi_run --top_n 100 --fdr 0.1
```

**Using gene names for cross-reference matching:**
```bash
python scripts/ranked_gene_overlap.py --root results/multi_run --top_n 100 --use-gene-name
```

### Parameters
- `--root`: Root folder with per_dataset subfolder (default: `results/multi_run`)
- `--top_n`: Number of top genes to extract per direction (default: 100)
- `--fdr`: Optional FDR cutoff for pre-filtering genes before ranking
- `--use-gene-name`: Match on gene names instead of gene IDs (useful for cross-dataset validation)

### Output
Generates in `{root}/ranked_genes/`:
- `{dataset}_top{N}_upregulated.csv` – Top N upregulated genes (sorted by log2FC)
- `{dataset}_top{N}_downregulated.csv` – Top N downregulated genes
- `RANKED_OVERLAP_REPORT.txt` – Summary with pairwise overlaps and shared genes

## Current Analysis Results (GSE53697 & GSE173955)

### Dataset Summary
| Dataset | Top 100 Up | Top 100 Down | Total Genes | ID System |
|---------|-----------|-------------|-------------|-----------|
| GSE173955 | 100 | 100 | 47,750 | Gene Symbols (VEGFA, ADH1B, etc.) |
| GSE53697 | 100 | 100 | 19,185 | Numeric IDs (2846, 50940, etc.) |

### Overlap Results
- **Up-Up overlap**: 0 genes shared
- **Down-Down overlap**: 0 genes shared
- **Cross-directional overlap**: 0 genes
- **Genes shared across all datasets**: 0

### Why Zero Overlap?

The zero overlap is **expected and biological**, not a software issue:

1. **Different ID Systems**: 
 - GSE173955 uses human gene symbols (VEGFA, CYP4F12, etc.)
 - GSE53697 uses numeric gene IDs without name mapping
 - Cannot directly match without a cross-reference table

2. **Different Gene Annotations**:
 - GSE173955: 47,750 genes (likely includes non-coding RNA)
 - GSE53697: 19,185 genes (different annotation version)
 - Top 100 genes from each represent different sets of identifiable sequences

3. **Disease Heterogeneity**:
 - GSE173955: Alzheimer's disease (8 disease, 10 control)
 - GSE53697: Likely different disease/condition (9 disease, 8 control)
 - Different pathologies may show different ncRNA signatures
 - Dataset size difference (18 vs 17 samples)

4. **No Significant Genes at Standard Thresholds**:
 - GSE53697: **0 significant genes** at FDR < 0.05
 - GSE173955: **0 significant genes** at FDR < 0.05 (50 at FDR < 0.1)
 - Small sample sizes may not meet statistical power requirements

## Integration with Pipeline

The ranking script is **standalone** but integrates with existing pipeline:

1. **Automatic discovery**: Finds `*_differential_results.csv` files
2. **Flexible input**: Works with any PE (per_dataset) structure
3. **No configuration required**: Accepts multiple datasets automatically
4. **Compatible output**: Gene lists in standard CSV format

### Example: Running After Multi-Dataset Pipeline
```bash
# Run multi-dataset analysis (generates per_dataset results)
python scripts/run_multi_datasets.py \
 --counts pglsdata/GSE53697_RNAseq_AD.txt \
 --metadata pglsdata/GSE53697_meta.csv \
 --dataset_id GSE53697 \
 --counts pglsdata/GSE173955.xlsx \
 --metadata pglsdata/GSE173955_meta.csv \
 --dataset_id GSE173955 \
 --outdir results/multi_run

# Extract ranked genes and overlaps
python scripts/ranked_gene_overlap.py --root results/multi_run --top_n 100
```

## Fixing Zero Overlap (If Needed)

### Option 1: Use Gene Name Mapping (Recommended)
If you can provide a mapping table (gene_id → symbol), modify the script to use it:
```python
# Add this to ranked_gene_overlap.py
mapping = pd.read_csv("gene_id_to_symbol.csv")
# Use mapping.set_index("gene_id")["symbol"] for cross-reference
```

### Option 2: Include Only Common Genes
Filter results to genes present in both datasets before ranking:
```python
common_genes = set(gse53697_genes) & set(gse173955_genes)
df_filtered = df[df.index.isin(common_genes)]
```

### Option 3: Relax Statistical Thresholds
Use ranking with optional FDR pre-filter:
```bash
python scripts/ranked_gene_overlap.py --root results/multi_run --top_n 100 --fdr 0.1
```

### Option 4: Test with Larger Sample Size
Consider:
- Combining replicates or adding more samples
- Using a different disease/tissue type
- Validating that both datasets measure ncRNA effectively

## Future Enhancements

1. **Cross-reference mapping**: Add external gene ID mapper (e.g., using biomaRt in R)
2. **Visualization**: Create Venn diagrams or UpSet plots of ranked overlaps
3. **Consensus ranking**: Combine rankings across datasets (e.g., by average rank)
4. **FDR-aware ranking**: Weight log2FC by significance (e.g., -log10(p) * sign(log2FC))
5. **Tissue/disease filtering**: Subset genes by biotype before ranking

## Running on Your Data

To use with your own datasets:

```bash
python scripts/ranked_gene_overlap.py \
 --root YOUR_RESULTS_DIR \
 --top_n 50 \ # Adjust top N as needed
 --fdr 0.1 \ # Optional FDR pre-filter
 --use-gene-name # If available in your data
```

The script will auto-discover `*_differential_results.csv` files and compute overlaps.

---

**Script Location**: `/scripts/ranked_gene_overlap.py` 
**Dependencies**: pandas, pathlib, argparse (all standard) 
**Date Created**: 2026-02-15 
**Last Updated**: 2026-02-15
