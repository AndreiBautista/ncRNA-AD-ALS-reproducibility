# Project Report: ncRNA Biomarkers in AD and ALS

## Methods
- Datasets: AD (GSE203206) and ALS (GSE124439) bulk RNA-seq.
- Preprocessing: counts were normalized to log2-CPM; genes filtered to ncRNAs using annotation keywords.
- Differential expression: Welch two-sample t-test (disease vs control), with Benjamini-Hochberg FDR.
- Significance thresholds: primary FDR < 0.05; strict set uses FDR < 0.01 and |log2FC| > 1.

## Results
- AD samples: 39 disease, 8 control (group column: condition).
- ALS samples: 145 disease, 17 control (group column: disease_status).
- Significant ncRNAs (FDR < 0.05): AD = 2208, ALS = 83.
- Strict ncRNAs (FDR < 0.01 and |log2FC| > 1): AD = 66, ALS = 2.
- Shared ncRNAs between AD and ALS (FDR < 0.05 overlap): 5.
- Top AD ncRNAs: LINC01013, ADGRB3-DT, AMMECR1LP1, GAPDHP33, LINC01338.
- Top ALS ncRNAs: TUSC7, MAPK8IP1P2, LINC02560, CHRM3-AS1, AGBL1-AS1.

## Validation (ROC/AUC)
- AD ROC AUC (top 10 ncRNAs): 0.099.
- ALS ROC AUC (top 10 ncRNAs): 0.587.
- ROC plots: results/isef_figures/ad_roc_auc.png and results/isef_figures/als_roc_auc.png.

## Limitations and Future Work
- Results are based on public bulk RNA-seq datasets; cell-type effects are not directly resolved.
- Expression signatures may be dataset- or tissue-specific; replication on independent cohorts is needed.
- Future work: add pathway enrichment, compare with known ncRNA databases, and test a larger multi-disease panel.

## Reproducibility Steps
1. Generate figures and ROC validation:
 - /Users/austinbautista/ncrna_pipeline/.venv/bin/python scripts/generate_isef_figures.py
2. Generate this report:
 - /Users/austinbautista/ncrna_pipeline/.venv/bin/python scripts/generate_isef_report.py
3. Key outputs:
 - results/isef_figures/ (plots)
 - results/multi_dataset_analysis/isef_analysis/ (strict tables)
