# Path A Implementation Guide: Multi-Disease, Multi-Species ncRNA Biomarker Discovery

## Executive Summary
You're building a **3-disease × 3-species ncRNA biomarker discovery project**:
- **Diseases**: Alzheimer's (AD), Parkinson's (PD), Amyotrophic Lateral Sclerosis (ALS)
- **Species**: Humans, Mice, Zebrafish
- **Strategy**: Path A = Get proper gene annotation → identify true ncRNAs → apply strict filters → deliver 20-200 high-confidence biomarkers per disease

---

## Part 1: Understanding the Problem (Why Annotation Matters)

### The Current Bottleneck

Your pipeline correctly identifies differentially expressed genes across datasets, BUT all genes show `biotype="unknown"`:

```
gene_id biotype
ENSG00000230624 unknown ← Problem: can't tell if it's lncRNA, miRNA, etc.
ENSG00000228495 unknown
ENSG00000012345 unknown
```

**Without proper biotype information:**
- Can't filter to ncRNAs (lncRNA, miRNA, snoRNA, circRNA, etc.)
- Can't claim results are ncRNA biomarkers
- Would be 7,222 protein-coding + ncRNA genes mixed together (too broad for )

**With proper biotype information:**
- Identify true ncRNAs: ~2,000-3,000 in human genome
- Apply strict filters: FDR < 0.01, |log2FC| > 1.5
- End result: 20-100 focused, high-confidence ncRNA biomarkers per disease (-winning quality)

---

## Part 2: The Solution - Getting Proper Annotations

### Option A1: Use Ensembl BiomaRt (RECOMMENDED for this project)

BiomaRt allows you to query Ensembl database and download gene annotations with detailed biotype information.

**Installation:**
```bash
pip install biomaRt
```

**Python code to get annotations:**

```python
# get_annotation_biomart.py
import pandas as pd
from biomart import Server

def download_ensembl_annotation(species='hsapiens', save_path='annotation.csv'):
 """
 Download gene annotations with biotype from Ensembl BiomaRt.
 
 species: 'hsapiens' (humans), 'mmusculus' (mice), 'drerio' (zebrafish)
 """
 server = Server(host='https://www.ensembl.org')
 
 dataset_map = {
 'hsapiens': 'hsapiens_gene_ensembl',
 'mmusculus': 'mmusculus_gene_ensembl',
 'drerio': 'drerio_gene_ensembl'
 }
 
 dataset = server.marts['ENSEMBL_MART_ENSEMBL'].datasets[dataset_map[species]]
 
 annotation = dataset.query(
 attributes=['ensembl_gene_id', 'external_gene_name', 'gene_biotype'],
 use_cache=False
 )
 
 annotation.columns = ['gene_id', 'gene_name', 'biotype']
 annotation = annotation.set_index('gene_id')
 annotation.to_csv(save_path)
 print(f"Downloaded {len(annotation)} genes to {save_path}")
 return annotation

# Usage for each species:
# download_ensembl_annotation('hsapiens', 'annotation_human.csv')
# download_ensembl_annotation('mmusculus', 'annotation_mouse.csv')
# download_ensembl_annotation('drerio', 'annotation_zebrafish.csv')
```

**Result:** Annotation file with proper biotypes:
```
gene_id gene_name biotype
ENSG00000230624 LINC02020 lincRNA ← Now we know it's lncRNA!
ENSG00000228495 MIR6121 miRNA ← This is a microRNA
ENSG00000012345 SOX2OT lincRNA ← Another lncRNA
ENSG00000067225 RP4-791O19.7 lncRNA ← Long non-coding RNA
```

### Option A2: Alternative - Download directly from Ensembl FTP

If BiomaRt is slow, download pre-made GTF files from [Ensembl FTP](https://ftp.ensembl.org/pub/):

```bash
# Human (GRCh38)
wget https://ftp.ensembl.org/pub/release-104/gtf/homo_sapiens/Homo_sapiens.GRCh38.104.gtf.gz
gunzip Homo_sapiens.GRCh38.104.gtf.gz

# Mouse (GRCm39)
wget https://ftp.ensembl.org/pub/release-104/gtf/mus_musculus/Mus_musculus.GRCm39.104.gtf.gz
gunzip Mus_musculus.GRCm39.104.gtf.gz

# Zebrafish (GRCz11)
wget https://ftp.ensembl.org/pub/release-104/gtf/danio_rerio/Danio_rerio.GRCz11.104.gtf.gz
gunzip Danio_rerio.GRCz11.104.gtf.gz
```

Then parse with:

```python
import pandas as pd

def parse_ensembl_gtf(gtf_file, save_path='annotation.csv'):
 """Parse GTF file to extract gene_id, gene_name, and biotype."""
 genes = []
 
 with open(gtf_file) as f:
 for line in f:
 if line.startswith('#'):
 continue
 fields = line.split('\t')
 if fields[2] != 'gene': # Only look at gene lines
 continue
 
 # Parse attributes column
 attrs_str = fields[8]
 attrs = {}
 for attr in attrs_str.split(';'):
 if '=' in attr:
 key, val = attr.strip().split('=')
 attrs[key.strip()] = val.strip('"')
 
 genes.append({
 'gene_id': attrs.get('gene_id', ''),
 'gene_name': attrs.get('gene_name', ''),
 'biotype': attrs.get('gene_biotype', 'unknown')
 })
 
 df = pd.DataFrame(genes).drop_duplicates('gene_id').set_index('gene_id')
 df.to_csv(save_path)
 print(f"Parsed {len(df)} genes to {save_path}")
 return df
```

---

## Part 3: Understanding ncRNA Biotypes

When you download annotation, you'll see diverse biotypes. Here's what they mean:

### Non-Coding RNA Types (Your Pipeline Filters For These)

| Biotype | Full Name | Function |
|---------|-----------|----------|
| **lncRNA** / **lincRNA** | Long non-coding RNA | Gene regulation, chromatin remodeling, disease biomarkers |
| **miRNA** | microRNA | Post-transcriptional gene regulation, ~22bp |
| **snoRNA** | small nucleolar RNA | rRNA modification, ribosomes |
| **snRNA** | small nuclear RNA | mRNA splicing in snRNPs |
| **circRNA** | Circular RNA | Gene regulation, miRNA sponges |
| **piRNA** | PIWI-interacting RNA | Transposon silencing |
| **vault_RNA** | Vault RNA | Drug resistance, RNA transport |
| **scaRNA** | Small Cajal body RNA | snRNP biogenesis |
| **antisense** | Antisense RNA | Transcriptional/translational regulation |

### Your Pipeline's ncRNA Keywords

In `pipeline/processing.py`, the filter looks for:
```python
nc_keywords = set(['lncrna', 'lnc_rna', 'mirna', 'mir', 'snorna', 'snrna', 
 'antisense', 'misc_rna', 'rrna', 'ncrna', 'pseudogene', 
 'scarna', 'vault_rna', 'srna'])
```

**Science fact:** ncRNAs are excellent biomarkers because:
1. Highly tissue-specific expression patterns
2. Dysregulated in neurodegenerative diseases
3. Stable in blood (accessible for clinical testing)
4. Fewer genes (~2,000-3,000) = easier to validate experimentally
5. judges love ncRNA-focused projects (specialized, not generic)

---

## Part 4: The Complete Analysis Workflow

### Step-by-step flow:

```
┌─────────────────────────────────────────────────────────────┐
│ 1. GET ANNOTATIONS (Path A specific) │
│ Download human/mouse/zebrafish annotation from Ensembl │
│ Result: 3 CSV files with proper biotypes │
└────────────────────┬────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────┐
│ 2. ORGANIZE DATASETS (Multi-disease, multi-species) │
│ Prepare data structure: │
│ results/ │
│ ├── alzheimers/ │
│ │ ├── human/ │
│ │ ├── mouse/ │
│ │ └── zebrafish/ │
│ ├── parkinsons/ │
│ │ ├── human/ │
│ │ ├── mouse/ │
│ │ └── zebrafish/ │
│ └── als/ │
│ ├── human/ │
│ ├── mouse/ │
│ └── zebrafish/ │
└────────────────────┬────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────┐
│ 3. RUN PIPELINE PER DATASET │
│ For each dataset: │
│ a) Load counts + metadata + annotation │
│ b) Filter to ncRNAs only (using proper biotype) │
│ c) Normalize to log2-CPM │
│ d) Run Welch's t-test (disease vs. control) │
│ e) Apply strict filters: │
│ - FDR < 0.01 │
│ - |log2FC| > 1.5 │
│ Result: 20-200 high-confidence ncRNA biomarkers/dataset │
└────────────────────┬────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────┐
│ 4. CROSS-DATASET VALIDATION │
│ For each disease (across 3 species): │
│ Find ncRNAs that are: │
│ - Significant in ALL species (human + mouse + fish) │
│ - Same direction of regulation (all up or all down) │
│ Result: 5-50 evolutionary conserved biomarkers/disease │
└────────────────────┬────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────┐
│ 5. DISEASE-LEVEL INTEGRATION │
│ Cross 3 diseases (AD, PD, ALS): │
│ Find ncRNAs that are: │
│ - Dysregulated in 2+ diseases │
│ - Suggest common neurodegeneration mechanism │
│ Result: 10-30 universal neuropathy biomarkers │
└────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────┐
│ 6. BIOLOGICAL INTERPRETATION & DELIVERABLES │
│ - Literature mining: What do these ncRNAs do? │
│ - Pathway analysis: What biology do they regulate? │
│ - Clinical significance: Why matter for diagnosis? │
│ Result: presentation with 20-50 focus genes │
└────────────────────────────────────────────────────────────┘
```

---

## Part 5: Multi-Dataset Configuration

Create `config_multi_disease.yaml` to define all 9 datasets:

```yaml
# Configuration for multi-disease, multi-species ncRNA biomarker discovery

analysis:
 name: "Multi-Disease ncRNA Biomarker Discovery"
 description: "Cross-species, cross-disease analysis of ncRNA dysregulation"
 strict_filters:
 fdr_threshold: 0.01 # recommendation
 log2fc_threshold: 1.5 # recommendation
 min_datasets: 1 # Presence in N datasets

diseases:
 alzheimers:
 description: "Alzheimer's disease / neuroinflammation"
 datasets:
 human:
 counts_file: "data/alzheimers/human/counts.csv"
 metadata_file: "data/alzheimers/human/metadata.csv"
 annotation_file: "data/annotations/annotation_human.csv"
 group_column: "condition"
 disease_label: "Alzheimer"
 control_label: "Control"
 species: "human"
 source: "GEO / Synapse"
 
 mouse:
 counts_file: "data/alzheimers/mouse/counts.csv"
 metadata_file: "data/alzheimers/mouse/metadata.csv"
 annotation_file: "data/annotations/annotation_mouse.csv"
 group_column: "genotype"
 disease_label: "APP/PS1"
 control_label: "WT"
 species: "mouse"
 source: "GEO / published dataset"
 
 zebrafish:
 counts_file: "data/alzheimers/zebrafish/counts.csv"
 metadata_file: "data/alzheimers/zebrafish/metadata.csv"
 annotation_file: "data/annotations/annotation_zebrafish.csv"
 group_column: "treatment"
 disease_label: "tau_overexpression"
 control_label: "control"
 species: "zebrafish"
 source: "GEO / BioProject"

 parkinsons:
 description: "Parkinson's disease / dopaminergic neurodegeneration"
 datasets:
 human:
 counts_file: "data/parkinsons/human/counts.csv"
 metadata_file: "data/parkinsons/human/metadata.csv"
 annotation_file: "data/annotations/annotation_human.csv"
 group_column: "condition"
 disease_label: "Parkinson"
 control_label: "Control"
 species: "human"
 source: "GEO"
 
 mouse:
 counts_file: "data/parkinsons/mouse/counts.csv"
 metadata_file: "data/parkinsons/mouse/metadata.csv"
 annotation_file: "data/annotations/annotation_mouse.csv"
 group_column: "treatment"
 disease_label: "MPTP"
 control_label: "saline"
 species: "mouse"
 source: "GEO"
 
 zebrafish:
 counts_file: "data/parkinsons/zebrafish/counts.csv"
 metadata_file: "data/parkinsons/zebrafish/metadata.csv"
 annotation_file: "data/annotations/annotation_zebrafish.csv"
 group_column: "treatment"
 disease_label: "rotenone"
 control_label: "control"
 species: "zebrafish"
 source: "GEO"

 als:
 description: "Amyotrophic Lateral Sclerosis / motor neuron degeneration"
 datasets:
 human:
 counts_file: "data/als/human/counts.csv"
 metadata_file: "data/als/human/metadata.csv"
 annotation_file: "data/annotations/annotation_human.csv"
 group_column: "condition"
 disease_label: "ALS"
 control_label: "Control"
 species: "human"
 source: "GEO / Synapse"
 
 mouse:
 counts_file: "data/als/mouse/counts.csv"
 metadata_file: "data/als/mouse/metadata.csv"
 annotation_file: "data/annotations/annotation_mouse.csv"
 group_column: "genotype"
 disease_label: "SOD1_mutant"
 control_label: "WT"
 species: "mouse"
 source: "Published dataset"
 
 zebrafish:
 counts_file: "data/als/zebrafish/counts.csv"
 metadata_file: "data/als/zebrafish/metadata.csv"
 annotation_file: "data/annotations/annotation_zebrafish.csv"
 group_column: "morpholino"
 disease_label: "smn_knockdown"
 control_label: "control"
 species: "zebrafish"
 source: "GEO"

# Analysis output structure
output:
 base_dir: "results"
 per_disease_dir: "per_disease_ncrnabiomarkers"
 cross_disease_dir: "cross_disease_comparison"
 figures_dir: "figures"
```

---

## Part 6: Modified Pipeline for ncRNA-Only Analysis

Your pipeline already has ncRNA filtering! But here's how to make it stricter for Path A:

### Update `run_pipeline.py` to enforce strict metrics:

```python
# In run_pipeline.py, modify the filter applied to results:

def filter_to_significant_ncrnas(results_df, fdr_threshold=0.01, log2fc_threshold=1.5):
 """
 Filter results to high-confidence ncRNA biomarkers ( standards).
 """
 # Step 1: Filter to ncRNAs only (from biotype)
 nc_keywords = {'lncrna', 'lnc_rna', 'mirna', 'mir', 'snorna', 'snrna', 
 'antisense', 'misc_rna', 'rrna', 'ncrna', 'pseudogene', 
 'scarna', 'vault_rna', 'srna'}
 
 if 'biotype' in results_df.columns:
 biotype = results_df['biotype'].astype(str).fillna('').str.lower()
 is_ncrna = biotype.apply(lambda x: any(k in x for k in nc_keywords))
 results_df = results_df[is_ncrna].copy()
 
 # Step 2: Apply strict filters
 results_df = results_df[
 (results_df['fdr'] < fdr_threshold) & # FDR < 0.01
 (results_df['log2FC'].abs() > log2fc_threshold) # |log2FC| > 1.5
 ].copy()
 
 return results_df.sort_values('pvalue')
```

---

## Part 7: Cross-Species Validation Logic

The power of your project is validating biomarkers across species!\

```python
# Multi-species biomarker discovery

def find_conserved_ncrnas(results_dict, min_species=2, same_direction=True):
 """
 Find ncRNAs dysregulated across multiple species.
 
 results_dict: {'human': df, 'mouse': df, 'zebrafish': df}
 min_species: Require presence in N species
 same_direction: All must be up-regulated or all down-regulated
 
 Returns: DataFrame of conserved biomarkers with species counts
 """
 
 # Get set of significant ncRNAs in each species
 species_genes = {}
 species_fc = {} # Track direction (sign of log2FC)
 
 for species, results_df in results_dict.items():
 genes = set(results_df.index)
 fc_dict = results_df['log2FC'].to_dict()
 species_genes[species] = genes
 species_fc[species] = fc_dict
 
 # Find genes in multiple species
 all_genes = set()
 for genes in species_genes.values():
 all_genes.update(genes)
 
 conserved = []
 for gene in all_genes:
 species_with_gene = [sp for sp in species_genes.keys() 
 if gene in species_genes[sp]]
 
 if len(species_with_gene) < min_species:
 continue
 
 # Check direction conservation
 if same_direction:
 fcs = [species_fc[sp][gene] for sp in species_with_gene]
 if not (all(fc > 0 for fc in fcs) or all(fc < 0 for fc in fcs)):
 continue # Skip if mixed up/down regulation
 
 # Build record
 conserved.append({
 'gene_id': gene,
 'num_species': len(species_with_gene),
 'species': ', '.join(species_with_gene),
 'human_log2fc': species_fc['human'].get(gene, np.nan) if 'human' in species_fc else np.nan,
 'mouse_log2fc': species_fc['mouse'].get(gene, np.nan) if 'mouse' in species_fc else np.nan,
 'zebrafish_log2fc': species_fc['zebrafish'].get(gene, np.nan) if 'zebrafish' in species_fc else np.nan,
 })
 
 return pd.DataFrame(conserved).sort_values('num_species', ascending=False)
```

**Why this matters for :**
- If a biomarker is dysregulated in human + mouse + zebrafish → **evolutionarily conserved** → **likely functionally important** → **strong evidence of real biology**
- Much more convincing than single-species results!

---

## Part 8: Expected Results Structure

After running Path A on all 9 datasets:

```
results/
├── per_disease_ncrnabiomarkers/
│ ├── alzheimers/
│ │ ├── human_top_ncrnas.csv (20-50 genes, FDR<0.01, |log2FC|>1.5)
│ │ ├── mouse_top_ncrnas.csv
│ │ ├── zebrafish_top_ncrnas.csv
│ │ ├── conserved_across_species.csv (5-20 genes in all 3 species)
│ │ └── figures/
│ │ ├── alzheimers_ncrna_volcano.png
│ │ └── alzheimers_ncrna_heatmap.png
│ ├── parkinsons/
│ │ ├── human_top_ncrnas.csv
│ │ ├── mouse_top_ncrnas.csv
│ │ ├── zebrafish_top_ncrnas.csv
│ │ ├── conserved_across_species.csv
│ │ └── figures/
│ └── als/
│ ├── human_top_ncrnas.csv
│ ├── mouse_top_ncrnas.csv
│ ├── zebrafish_top_ncrnas.csv
│ ├── conserved_across_species.csv
│ └── figures/
│
└── cross_disease_comparison/
 ├── universal_neuropathy_biomarkers.csv (Dysregulated in 2+ diseases)
 ├── ncrna_heatmap_all_diseases.png
 └── biomarker_overlap_3diseases.png
```

---

## Part 9: Judge Questions You'll Crush

**Q: "Why just ncRNAs?"**
A: *"ncRNAs are underexplored biomarkers in neurodegenerative diseases. They represent ~10% of genes but are highly tissue-specific and dysregulated in disease. This focus makes our study rigorous—not chasing thousands of genes, but hundreds of biologically plausible candidates."*

**Q: "Why test in three species?"**
A: *"Cross-species validation is the gold standard in biomarker discovery. If a biomarker is dysregulated in human, mouse, and zebrafish models, it's evolutionarily conserved and likely functionally important. This dramatically increases confidence in biological relevance."*

**Q: "Why these specific filter thresholds?"**
A: *"FDR < 0.01 means only 1 false discovery per 100 results (very conservative). |log2FC| > 1.5 means at least 3-fold expression change, indicating a large biological effect. Together, these ensure we report high-confidence biomarkers suitable for experimental validation."*

**Q: "How do you plan to validate these?"**
A: *"Our top tier would validate using qPCR on independent patient samples (or model organism tissues). The best-hitting biomarkers would be tested as blood-based biomarkers, which could enable non-invasive disease monitoring or early detection."*

---

## Part 10: Next Steps (Action Plan)

### Immediate (This week):
1. **Download annotations** for all 3 species using BiomaRt or Ensembl FTP
2. **Reorganize data** into multi-disease, multi-species structure
3. **Update pipeline** to use proper annotations
4. **Run ncRNA-only analysis** on existing GSE203206 with strict filters

### Short-term (Next 1-2 weeks):
5. **Acquire new public datasets**:
 - Alzheimer's: Already have GSE203206; add 1-2 more human AD studies
 - Parkinson's: Download 1-2 human PD datasets from GEO
 - ALS: Download 1-2 human ALS datasets from GEO
6. **Download/prepare model organism datasets**:
 - Mouse models: Search GEO for APP/PS1, SOD1-ALS, MPTP-PD models
 - Zebrafish: Search GEO/BioProject for tau, SOD1, or dopamine models

### Medium-term (Weeks 3-4):
7. **Run full analysis** across all 9 datasets
8. **Validate conserved biomarkers** across species
9. **Identify disease-specific vs. universal neuropathy biomarkers**
10. **Generate final presentation**

---

## Code Architecture Summary

```
Your pipeline's structure (already built):

io.py
├── safe_read_table() → Load any CSV format
├── load_counts() → Returns counts matrix (genes × samples)
├── load_metadata() → Returns metadata (samples × attributes)
└── load_annotation() → Returns annotation (genes × biotype, etc.)

processing.py
├── log2_cpm() → Normalize to log2-CPM
└── filter_noncoding_genes() → Filter to ncRNAs (uses biotype column)

de_analysis.py
├── differential_expression() → Welch's t-test, FDR correction
└── Returns DataFrame with:
 └── gene_id, mean_disease, mean_control, log2FC, pvalue, fdr, significant

visualization.py
├── volcano_plot() → Feature significance vs. effect size
├── bar_plot() → Top up/down genes (both ncRNA only!)
├── heatmap() → Expression patterns across samples
└── (All saved with biotype annotation)

run_pipeline.py
└── Main orchestrator:
 ├── Load data
 ├── Filter to ncRNAs (NOW with proper biotype!)
 ├── Normalize
 ├── DE analysis
 ├── Generate figures
 └── Create summary CSVs
```

**The fix for Path A:**
- Just replace the annotation file with one that has true biotype data
- Everything else already works correctly!

---

## Why This is a Winning Project

✅ **Clear hypothesis**: ncRNAs are evolutionarily conserved biomarkers of neurodegeneration 
✅ **Rigorous methodology**: Proper statistical filters, cross-species validation 
✅ **Ambitious scope**: 3 diseases × 3 species = demonstrates mastery 
✅ **Biological insight**: Understanding which ncRNAs are conserved vs. disease-specific 
✅ **Clinical relevance**: Biomarkers could enable disease monitoring/diagnosis 
✅ **Reproducible**: Full code, clear data organization, version-controlled 
✅ **Honest about limitations**: ncRNA validation expensive, but have clear path forward 

---

**You've got this. Path A is the way.** 🧬
