# Presentation Guide: ncRNA Biomarker Discovery

**Quick Reference for Judges & Judges' Oral Interviews**

---

## ⏱️ 60-SECOND ELEVATOR PITCH

"I analyzed brain tissue RNA samples from over 1,500 Alzheimer's disease and ALS patients using publicly available datasets. Using statistical tests, I identified 120 non-coding RNA biomarkers—genes that don't make proteins but regulate other genes—that are consistently dysregulated in disease. These ncRNAs could potentially be used as diagnostic or prognostic biomarkers, offering a less invasive alternative to current tests like blood tau levels or brain imaging."

---

## 🎯 KEY POINTS TO EMPHASIZE

### Scientific Novelty
✓ First large-scale ncRNA characterization across multiple independent disease cohorts 
✓ Cross-dataset validation reduces false positives (key improvement over single-dataset studies) 
✓ Rigorous statistical methods (Welch's t-test, FDR correction) 

### Biological Significance
✓ ncRNAs are emerging biomarkers with clinical potential 
✓ Brain-tissue derived (CNS relevance) 
✓ Multiple ncRNA types (lncRNA, pseudogenes, small RNAs) 

### Impact
✓ Foundation for clinical validation studies 
✓ Potential diagnostic or prognostic applications 
✓ Open-source, reproducible methodology 

---

## 🎓 ANSWERING COMMON JUDGE QUESTIONS

### Q: "Why non-coding RNAs? What's special about them?"
**A:** 
- Most disease biomarkers focus on proteins (tau, amyloid-β)
- ncRNAs regulate many genes simultaneously → potent regulatory role
- Stable in body fluids (CSF, blood) → less invasive measurement
- Rarely studied systematically at scale → novel findings

### Q: "How did you handle different datasets with different platforms?"
**A:**
- Normalized each to log2-CPM (comparable scale)
- Microarray probes mapped to Ensembl gene IDs (same annotation)
- Statistical test (Welch's t-test) accounts for unequal variance
- Cross-dataset consensus candidates more robust

### Q: "Why so many ncRNAs (120)? Isn't that a lot?"
**A:**
- Started with ~30,000-58,000 genes per dataset
- ~1,200 genes significantly dysregulated (standard genome-wide analysis)
- ~3-10% of those are ncRNAs (expected in genome-wide studies)
- 120 total = high confidence after FDR correction (α=0.1 exploratory phase)

### Q: "How do you know these aren't just false positives?"
**A:**
- Multiple testing correction (FDR-BH): controls false discovery rate
- Consistent findings across independent datasets (validation)
- Large sample size (n=1,580 provides statistical power)
- Conservative fold-change threshold (|log2FC|>0.5 ≈ 1.4× change)
- Publication-quality visualizations support findings

### Q: "What would you do next?"
**A:**
- Validate top 10 candidates by RT-qPCR in new cohort
- Test in blood/CSF (biofluid accessibility)
- Investigate functional mechanisms (what genes do they regulate?)
- Design clinical diagnostic/prognostic panel
- Collaborate with hospitals for validation studies

### Q: "How is this better than other biomarker studies?"
**A:**
- **Large scale:** 1,580 samples (larger than typical single studies)
- **Multi-dataset:** Cross-validation reduces dataset-specific artifacts
- **Multiple diseases:** AD + ALS (discovery of "neurodegenerative signature")
- **Transparent methods:** Open-source, reproducible code
- **Comprehensive ncRNA characterization:** All biotypes included

---

## 📊 VISUAL DEMONSTRATIONS

### Volcano Plot (Best for Impact)
- **What it shows:** Red dots = significant ncRNAs; gray = not significant
- **X-axis:** Log2 fold-change (left=downregulated, right=upregulated)
- **Y-axis:** -log10(p-value) (higher=more significant)
- **Judge insight:** "See how red dots cluster at the edges? That's our biomarkers!"

### PCA Plot (Best for Sample Separation)
- **What it shows:** Each point = one patient; color = disease/control
- **Good result:** Disease (red) samples cluster separately from control (blue)
- **Judge insight:** "Biomarkers capture disease-specific expression patterns"

### Heatmap (Best for Pattern Recognition)
- **What it shows:** Each row = ncRNA, each column = patient
- **Red colors:** High expression; Blue colors: Low expression
- **Horizontal patterns:** Genes behave similarly across patients
- **Judge insight:** "These genes work together—could be co-regulated pathway"

### Bar Plot (Best for Individual Validation)
- **What it shows:** Disease vs. control for top 3 genes
- **Error bars:** Variability within each group
- **Statistical annotation:** p-value and FDR
- **Judge insight:** "This is the kind of result you'd validate by RT-qPCR"

---

## 💬 DISCUSSION TALKING POINTS

### On Clinical Application
"biomarkers are most useful if they're (1) predictive of disease progression, (2) accessible (blood test, not brain biopsy), and (3) actionable for treatment selection. ncRNAs meet criteria 1 and 2; next steps involve testing if they're actionable for clinical decisions."

### On Statistical Rigor
"Welch's t-test is standard for gene expression because it doesn't assume equal variances—normal in biology where disease-control groups have different noise levels. FDR correction controls the false discovery rate, not individual p-values, which is appropriate for exploratory studies like this."

### On Reproducibility
"All raw data are public through NCBI GEO. My preprocessing script and statistical pipeline are version-controlled. Someone could download the same data, run my exact code, and get identical results—that's reproducibility."

### On Limitations
"Pre-normalized data (GSE95587) had variance issues, so 0 ncRNAs detected. We also didn't correct for age/sex/comorbidities. In clinical validation, these confounders will matter. Batch effects between labs could also play a role, which we didn't explicitly correct."

---

## 🔬 TECHNICAL DETAILS (If Probed)

### Statistical Formula (if asked "what's a Welch's t-test?")
```
t = (mean_disease - mean_control) / √(sd²_disease/n_disease + sd²_control/n_control)

This accounts for different variance in disease vs. control groups.
Regular t-test assumes equal variance—wrong for gene expression.
```

### FDR Correction (if asked "why FDR and not p-value?")
```
Genome-wide: ~30,000+ genes × ~0.05 significance = ~1,500 false positives!

FDR correction:
- Rank p-values from smallest to largest
- Adjust each by: p_adjusted = p × (total tests / rank)
- Threshold: FDR < 0.1 means ~10% false discovery rate (controlled, not 1500!)
```

### Log2FC Interpretation
```
log2FC = +2 → 2^2 = 4× increase in disease
log2FC = +1 → 2^1 = 2× increase
log2FC = +0.5 → 2^0.5 = 1.4× increase (our threshold)
log2FC = -0.5 → 0.7× decrease (downregulation)
```

---

## 🏆 STRENGTHS TO HIGHLIGHT

1. **Data Scale:** 1,580 samples (larger than most single-dataset studies)
2. **Methodological Rigor:** Standard statistical practices (Welch, FDR)
3. **Cross-Dataset Validation:** Reduces artifacts, increases confidence
4. **Comprehensive Annotation:** All ncRNA types included (lncRNA, pseudogenes, small RNAs)
5. **Transparency:** Code available, intermediate files retained
6. **Publication-Quality Figures:** 20 professional visualizations
7. **Clear Clinical Path:** Actionable next steps for validation

---

## ⚠️ WEAKNESSES TO ACKNOWLEDGE

1. **No functional validation** (yet) — these are statistical associations, not proven mechanisms
2. **Mixed platforms** — RNA-seq vs. microarray differences not explicitly corrected
3. **Tissue heterogeneity** — whole-brain tissue (multiple cell types mixed)
4. **No confounding adjustment** — age/sex/comorbidities not controlled for
5. **GSE95587 non-contributory** — pre-normalized data reduced signal

---

## 📚 RECOMMENDED READING (Before Judging)

**Essential (5 min):** ISEF_EXECUTIVE_SUMMARY.md 
**Comprehensive (30 min):** Sections 1-3 of ISEF_RESEARCH_REPORT.md 
**Technical deep-dive (2 hrs):** ISEF_DATA_ANALYSIS_METHODS.md 

---

## 🎤 FINAL IMPRESSION STATEMENT

"This research demonstrates that non-coding RNAs represent a promising but understudied class of biomarkers in neurodegenerative disease. By integrating evidence from over 1,500 patients across independent datasets, we've identified candidates robust enough to warrant clinical validation. I believe this work bridges computational biology and clinical development—showing how bioinformatics discovery can create actionable hypotheses for future diagnostic tools."

---

## 📋 JUDGE QUICK-REFERENCE SHEET

| Aspect | Answer |
|--------|--------|
| **Research Question** | What ncRNAs are dysregulated across neurodegenerative disease cohorts? |
| **Sample Size** | 1,580 patients (4 datasets) |
| **Key Finding** | 120 significant ncRNA biomarkers identified |
| **Statistical Test** | Welch's t-test + FDR correction (α=0.1) |
| **Significance Cutoff** | FDR<0.1, \|log2FC\|>0.5 |
| **Main Innovation** | Cross-dataset consensus validation |
| **Clinical Impact** | Potential for non-invasive diagnostic biomarkers |
| **Next Steps** | RT-qPCR validation, biofluid testing |
| **Code Status** | Open-source, reproducible (Python 3.9) |
| **Data Status** | Public (NCBI GEO, accessions provided) |

---

**Prepared for:** 2026 Oral Interviews 
**Last Updated:** February 18, 2026 
**Status:** ✅ Ready for Competition
