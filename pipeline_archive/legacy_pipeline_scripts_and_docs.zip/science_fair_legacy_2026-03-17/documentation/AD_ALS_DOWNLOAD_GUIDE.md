# 📥 Download Guide: Alzheimer's + ALS Datasets

## Current Status

✅ **Alzheimer's:**
- GSE203206 (48 samples) - ✓ Already locally available

⏳ **Need to download:**
- Alzheimer's: GSE173955 (18), GSE95587 (117)
- ALS: GSE124439 (176), GSE116622 (77), GSE76220 (22)

**Total: 458 samples across 6 studies (AD: 183 samples, ALS: 275 samples)**

---

## Quick Download Links

Click these links to go directly to each dataset:

### Alzheimer's Disease

1. **GSE173955** (18 samples - Hippocampus)
 - Go to: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE173955
 - Look for supplementary file (usually .xlsx or .txt.gz)
 - Save to: `data/neurodegenerative_diseases/alzheimers/GSE173955/`

2. **GSE95587** (117 samples - Fusiform Gyrus, large Genentech dataset)
 - Go to: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE95587
 - Look for supplementary file (counts or expression matrix)
 - Save to: `data/neurodegenerative_diseases/alzheimers/GSE95587/`

### ALS

3. **GSE124439** (176 samples - Motor Cortex, NYGC ALS Consortium)
 - Go to: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE124439
 - Look for supplementary file (counts)
 - Save to: `data/neurodegenerative_diseases/als/GSE124439/`

4. **GSE116622** (77 samples - Brain, NYGC ALS Consortium)
 - Go to: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE116622
 - Look for supplementary file
 - Save to: `data/neurodegenerative_diseases/als/GSE116622/`

5. **GSE76220** (22 samples - Laser Capture Motor Neurons)
 - Go to: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE76220
 - Look for supplementary file
 - Save to: `data/neurodegenerative_diseases/als/GSE76220/`

---

## 📋 Step-by-Step Download Instructions

### For Each GEO Dataset:

#### Step 1: Go to the GEO Page
```
https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE123456
```

#### Step 2: Find the Data Files

Scroll down to the **"Supplementary file"** section. You'll see files listed.

**Look for files with these keywords:**
- `counts` ← BEST
- `gene_expression`
- `matrix`
- Often compressed as `.gz` or `.zip`

**Example filenames you might see:**
```
GSE173955_gene_expression.txt.gz
GSE95587_processed_counts.csv.gz
GSE124439_raw_counts.txt
GSE116622_expression_matrix.tsv.gz
GSE76220_ALS_LCM_Expression.xlsx
```

#### Step 3: Download the File

1. Click the download link
2. File will download to your `Downloads` folder
3. If compressed (`.gz`, `.zip`), extract it first

#### Step 4: Format the Data

**For each GSE folder you create:**

**a) Rename the counts file to `counts.txt`:**
```bash
# If you downloaded GSE173955_gene_expression.txt.gz:
cd data/neurodegenerative_diseases/alzheimers/GSE173955/
gunzip GSE173955_gene_expression.txt.gz
mv GSE173955_gene_expression.txt counts.txt
```

**b) Verify the format:**

Open `counts.txt` in a text editor or Excel:
- First row: sample names (headers)
- First column: gene IDs or gene names
- All other cells: numeric count values (integers)

Example:
```
gene_id sample_1 sample_2 sample_3
ENSG00000223972 0 1 15
ENSG00000227232 2 8 23
...
```

**c) Create `metadata.csv`:**

Using Excel or a text editor, create a CSV file:
```
sample_id,disease_status,tissue_type,study_id
sample_1,Control,hippocampus,GSE173955
sample_2,Disease,hippocampus,GSE173955
sample_3,Disease,hippocampus,GSE173955
...
```

**Important:**
- `disease_status` must be exactly "Control" or "Disease"
- `tissue_type` should match the dataset description
- Look at the GEO paper to figure out which samples are control vs disease

---

## 🔍 Finding Disease/Control Labels

When you download a dataset, you need to figure out which samples are "Disease" vs "Control".

### Where to find this info:

1. **GEO Page Phenotypes**: On the GEO dataset page, click the **"Phenotypes"** tab
 - Shows sample characteristics
 - Look for "disease state", "condition", "status", "phenotype"

2. **GEO Paper/Supplementary Table**: 
 - Find the publication linked from GEO
 - Usually has a Table S1 with sample information

3. **Series Matrix**: 
 - Go to GEO page, bottom section
 - Download `GSE######_series_matrix.txt`
 - Contains metadata for all samples
 - Open in text editor and search for relevant columns

4. **Contact Authors**: 
 - If uncertain, email the corresponding author
 - Usually respond within 24-48 hrs

---

## 📁 Folder Structure Reference

After downloading, your folder structure should look like:

```
data/neurodegenerative_diseases/

alzheimers/
├── GSE203206/ ✓ Already have
│ ├── counts.tsv
│ └── metadata.csv
├── GSE173955/ ⏳ Download
│ ├── counts.txt
│ └── metadata.csv
└── GSE95587/ ⏳ Download
 ├── counts.txt
 └── metadata.csv

als/
├── GSE124439/ ⏳ Download
│ ├── counts.txt
│ └── metadata.csv
├── GSE116622/ ⏳ Download
│ ├── counts.txt
│ └── metadata.csv
└── GSE76220/ ⏳ Download
 ├── counts.txt
 └── metadata.csv
```

---

## ✅ Quality Checks

Before we proceed with analysis, verify each dataset:

For each `counts.txt` file:
```bash
# Check first few lines
head data/neurodegenerative_diseases/[disease]/[GSE]/counts.txt

# Count genes and samples
wc -l data/neurodegenerative_diseases/[disease]/[GSE]/counts.txt
```

For each `metadata.csv` file:
```bash
# Check format
head data/neurodegenerative_diseases/[disease]/[GSE]/metadata.csv

# Should show: sample_id, disease_status, tissue_type, study_id
```

---

## 🚀 Validation

Once all files are downloaded and organized, run:

```bash
cd ~/ncrna_pipeline
python scripts/cross_disease_pipeline.py
```

This will:
- ✓ Check all folders exist
- ✓ Verify file formats
- ✓ Validate metadata structure
- ✓ Count samples per dataset
- ✓ Report readiness status

**Expected output:**
```
✓ ALZHEIMERS 183 samples (3 studies) - READY
✓ ALS 275 samples (3 studies) - READY
→ Total: 458 samples from 6 studies
```

---

## ❓ Troubleshooting

### "I can't find the counts file"

If the supplementary section doesn't have counts:

1. **Check the "Raw data"** section instead
 - May have SRA accessions
 - These require more complex download (SRA Toolkit needed)
 - Contact me if you hit this

2. **Contact the authors**
 - Email from GEO page
 - Ask for raw counts / expression matrix

### "The file is in a different format"

If you download an Excel file (.xlsx):
```bash
# Use Python to convert:
pip install openpyxl
python3 << 'EOF'
import pandas as pd
# Load Excel
df = pd.read_excel('GSE176220_gene_expression.xlsx', sheet_name=0)
# Save as tab-separated
df.to_csv('counts.txt', sep='\t', index=False)
EOF
```

### "Sample names don't match metadata"

If the column headers in counts.txt don't match sample_id in metadata.csv:

1. Extract the exact sample names from counts.txt header
2. Update metadata.csv sample_id column to match exactly
3. Must be character-for-character identical (case-sensitive)

---

## 📞 Need Help?

If you get stuck on any step, let me know:

1. Which dataset you're stuck on
2. What you see in the GEO supplementary files section
3. Any error messages

I can help you troubleshoot or try alternative download methods.

---

## ⏱️ Time Estimate

```
Searching & browsing: ~30 min (5 min per dataset)
Downloading files: ~15 min (files usually <100MB)
Extracting & renaming: ~10 min
Creating metadata: ~20 min (might need to look up papers)
Quality checks: ~10 min
Total: ~85 minutes (1.5 hours)
```

**You've got this! 💪**

Once you have the files downloaded and organized, just send me a message and I'll build the entire analysis pipeline.
