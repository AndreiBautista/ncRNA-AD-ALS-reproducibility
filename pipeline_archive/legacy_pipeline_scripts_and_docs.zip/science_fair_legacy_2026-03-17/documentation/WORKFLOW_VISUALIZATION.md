# Cross-Disease ncRNA Biomarker Discovery - Visual Workflow

## PROJECT ARCHITECTURE

```
┌──────────────────────────────────────────────────────────────────────────┐
│ CROSS-DISEASE ncRNA BIOMARKER DISCOVERY │
│ (Alzheimer's vs Parkinson's vs ALS) │
└──────────────────────────────────────────────────────────────────────────┘

 ┌─────────────────┐
 │ YOU: Find Data │
 └────────┬────────┘
 ↓
 ┌──────────────────────────────────────────────────────────┐
 │ PHASE 1: DATASET COLLECTION │
 │ (1-2 days) │
 └──────────────────────────────────────────────────────────┘
 ↙ ↓ ↖
 ┌────────────┐ ┌───────────────┐ ┌────────────┐
 │ ALZHEIMER'S│ │ PARKINSON'S │ │ ALS │
 │ GSE203206 │ │ GSE???? │ │ GSE???? │
 │ 47 samples │ │ 200+ samples │ │ 150+ samples
 │ ✓ READY │ │ ⏳FIND THESE │ │ ⏳ FIND THESE
 └────────────┘ └───────────────┘ └────────────┘
 │ │ │
 └────────┬───────────┴───────────┬───────────┘
 ↓
 ┌──────────────────────────────────────────────────────────┐
 │ PHASE 2: HARMONIZATION & ANALYSIS │
 │ (I BUILD THIS: 3-4 days) │
 │ │
 │ ✓ Merge datasets within each disease │
 │ ✓ Convert gene IDs → Ensembl format │
 │ ✓ Run DESeq2 per disease │
 │ ✓ Filter: FDR<0.01, |log2FC|>1 │
 │ ✓ Extract ncRNA genes only │
 └──────────────────────────────────────────────────────────┘
 ↙ ↓ ↖
 ┌─────────────┐ ┌──────────────┐ ┌──────────────┐
 │ AD Results │ │ PD Results │ │ ALS Results │
 │ ~69 genes │ │ ~80-150 genes│ │ ~60-120 genes
 │ (from Phase …│ │ │ │ │
 └─────────────┘ └──────────────┘ └──────────────┘
 │ │ │
 └────────┬────┴────┬────────┘
 ↓
 ┌──────────────────────────────────────────────────────────┐
 │ PHASE 3: CROSS-DISEASE ANALYSIS │
 │ (Find Shared Biomarkers) │
 └──────────────────────────────────────────────────────────┘
 ┌──────────────────────────┐
 │ Compare gene lists: │
 │ AD ∩ PD ∩ ALS = ? │
 └──────────┬───────────────┘
 ↓
 ┌──────────────────────────────────────────────────────────┐
 │ RESULTS │
 └──────────────────────────────────────────────────────────┘
 ↙ ↓ ↖
 ┌──────────────┐ ┌──────────────┐ ┌──────────────┐
 │ Shared in │ │ Shared in │ │ Shared in │
 │ 2 diseases │ │ ALL 3 │ │ Each disease │
 │ ~20-40 genes │ │ (GOLD STD) │ │ only │
 │ │ │ ~5-20 genes │ │ ~50-100 genes
 └──────────────┘ │🏆 HEADLINE │ └──────────────┘
 │ DISCOVERY │
 └──────────────┘
 ↓
 ┌──────────────────────────────────────────────────────────┐
 │ VISUALIZATIONS & PRESENTATION │
 │ • Per-disease: volcano plots, heatmaps, PCA │
 │ • Cross-disease: Venn diagram, forest plot, summary │
 │ • Publication-ready figures (dpi=300) │
 └──────────────────────────────────────────────────────────┘
```

---

## DATA FLOW SCHEMATIC

```
┌─────────────────────────────────────────────────────────────────┐
│ GEO DATABASE (Public RNA-seq datasets) │
├─────────────────────────────────────────────────────────────────┤
│ │
│ Alzheimer's Parkinson's ALS │
│ GSE203206 GSE111932 ← Find GSE153960 ← Find │
│ ✓ Ready GSE54282 ← Find GSE112119 ← Find │
│ 47 samples GSE40967 ← Find GSE27894 ← Find │
│ 200+ samples total 150+ samples total │
│ │
└─────────────────────────────┬───────────────────────────────────┘
 ↓
 ┌─────────────────────────────────┐
 │ DOWNLOAD & ORGANIZE FILES │
 │ (counts.tsv + metadata.csv) │
 └────────────────┬────────────────┘
 ↓
 ┌────────────────────────────────────────┐
 │ data/neurodegenerative_diseases/ │
 │ ├── alzheimers/GSE203206/ │
 │ ├── parkinsons/GSE111932/ │
 │ ├── parkinsons/GSE54282/ │
 │ ├── als/GSE153960/ │
 │ └── als/GSE112119/ │
 └────────────────┬───────────────────────┘
 ↓
 ┌────────────────────────────────────┐
 │ VALIDATION & HARMONIZATION │
 │ (python scripts/cross_disease_pipeline.py)
 └────────────────┬───────────────────┘
 ↓
 ┌────────────────────────────────────────┐
 │ GENE ID CONVERSION → ENSEMBL IDs │
 │ • All datasets use same gene IDs │
 │ • Remove duplicate genes │
 │ • Filter low-expression genes │
 └────────────────┬───────────────────────┘
 ↓
 ┌────────────────────────────────────────┐
 │ WITHIN-DISEASE ANALYSIS │
 │ For each disease separately: │
 │ • DESeq2 analysis (Disease vs Ctrl) │
 │ • Extract: log2FC, p-value, FDR │
 │ • Filter: FDR<0.01, |log2FC|>1 │
 │ • Keep ncRNAs only │
 └────────────────┬───────────────────────┘
 ↓
 ┌────────────────────────────────────────┐
 │ CROSS-DISEASE IDENTIFICATION │
 │ Find genes present in: │
 │ • All 3 diseases ← PRIMARY TARGET │
 │ • Exactly 2 diseases │
 │ • Check direction consistency │
 │ • Rank by effect size + significance │
 └────────────────┬───────────────────────┘
 ↓
 ┌────────────────────────────────────────┐
 │ VISUALIZATION & REPORTING │
 │ • Volcano plots (per disease) │
 │ • Heatmaps (top ncRNAs) │
 │ • PCA plots (sample clustering) │
 │ • Venn diagram (cross-disease) │
 │ • Forest plot (effect sizes) │
 │ • Summary tables & CSV exports │
 └────────────────┬───────────────────────┘
 ↓
 ┌────────────────────────────────────────┐
 │ PRESENTATION READY │
 │ • Science fair slides │
 │ • One-page abstract │
 │ • Poster backing board │
 │ • Judge Q&A talking points │
 └────────────────────────────────────────┘
```

---

## ANALYSIS PIPELINE LOGIC

```
FOR EACH DISEASE (AD, PD, ALS):
├─ Load all datasets for that disease
├─ Merge counts matrices (row-bind genes, align samples)
├─ Create combined metadata (track which study each sample came from)
│
├─ NORMALIZATION:
│ ├─ DESeq2 applied to raw counts
│ └─ Accounts for sequencing depth differences
│
├─ DIFFERENTIAL EXPRESSION:
│ ├─ Model: Gene expression ~ Disease Status
│ ├─ Statistical test: Negative binomial GLM (Wald test)
│ ├─ Output: log2FC (disease vs control)
│ ├─ Output: p-value
│ └─ Multiple testing correction: FDR-BH
│
├─ FILTERING:
│ ├─ FDR < 0.01 (very strict: 1% false discovery rate)
│ ├─ |log2FC| > 1.0 (>2-fold change threshold)
│ └─ Biotype = ncRNA (exclude protein-coding)
│
└─ OUTPUT: [Disease]_ncrna_biomarkers.csv

CROSS-DISEASE COMPARISON:
├─ Load biomarker lists from all 3 diseases
├─ Find overlapping genes: AD ∩ PD ∩ ALS
├─ Validate direction consistency:
│ ├─ If gene DOWN in all 3 → CONSISTENT (keep)
│ └─ If gene UP in AD but DOWN in PD → CONFLICTING (remove)
├─ Rank by:
│ ├─ # diseases (3 > 2)
│ ├─ Average |log2FC| (larger effect = stronger)
│ └─ Average FDR (more significant = better)
│
└─ OUTPUT: shared_3_diseases.csv (THE HEADLINE)
```

---

## EXPECTED DISCOVERY TIMELINE

```
Timeline relative to dataset completion:

Week 1-2: You collect datasets
 ↓
Week 3: I run harmonization
 ├─ Status: "Loading AD datasets... ✓ 47 samples"
 ├─ Status: "Loading PD datasets... ✓ 240 samples (3 studies)"
 ├─ Status: "Loading ALS datasets... ✓ 185 samples (2 studies)"
 ├─ Status: "Merging genes to Ensembl IDs... ✓ 19,234 genes common"
 └─ Status: "Filtering low-expression genes... ✓ 14,521 genes retained"
 ↓
Week 4: DESeq2 analysis per disease
 ├─ Status: "AD: Testing 3,485 ncRNAs... ✓ Done (89 significant)"
 ├─ Status: "PD: Testing 4,127 ncRNAs... ✓ Done (124 significant)"
 ├─ Status: "ALS: Testing 3,891 ncRNAs... ✓ Done (97 significant)"
 └─ Status: "Direction validation... ✓ Done"
 ↓
Week 4.5: Cross-disease analysis
 ├─ Status: "AD ∩ PD: 34 genes"
 ├─ Status: "AD ∩ ALS: 28 genes"
 ├─ Status: "PD ∩ ALS: 41 genes"
 ├─ Status: "AD ∩ PD ∩ ALS: 12 genes ← HEADLINE!"
 └─ Status: "Generating visualizations..."
 ↓
Week 5: Final report + presentation
 ├─ Summary table of 12 pan-disease biomarkers
 ├─ Venn diagram showing overlaps
 ├─ Per-disease volcano plots (3 figures)
 ├─ Cross-disease forest plot
 └─ Publication-ready report
```

---

## KEY STATISTICS & EXPECTED NUMBERS

```
SAMPLE SIZES:
 Alzheimer's: 47 samples (39 AD + 8 control) = READY
 Parkinson's: 240 samples (goal)
 ALS: 185 samples (goal)
 TOTAL: ~470 samples across 3 diseases

GENE COUNTS:
 Initial genes: ~60,000 (all human protein-coding + ncRNA)
 After merging: ~19,000 (genes common across datasets)
 ncRNAs only: ~3,500-4,500 per disease
 Significant: ~80-120 per disease (FDR<0.01, |log2FC|>1)

CROSS-DISEASE ESTIMATES:
 Shared in 2 diseases: ~25-50 genes
 Shared in ALL 3: ~5-20 genes ← MOST INTERESTING
 Disease-specific only: ~50-100 genes per disease

STATISTICAL POWER:
 With 240 PD samples: >90% power to detect |log2FC|>1 at FDR<0.01
 With 185 ALS samples: >85% power for same effect size
 This is WELL-POWERED analysis (publishable standard)
```

---

## INTERPRETATION GUIDE

```
IF you find 15 shared ncRNAs in all 3 diseases:

→ These represent UNIVERSAL NEURODEGENERATION MECHANISMS
 Why? Because:
 • Different diseases (different causes)
 • Different patients (different genetic backgrounds)
 • Different tissues analyzed (if applicable)
 • Yet SAME genes are dysregulated
 = These ncRNAs are fundamental to neuronal death

→ Such ncRNAs are:
 ✓ Diagnostic candidates (are ALL 3 diseases detectable by the same test?)
 ✓ Therapeutic targets (could ONE drug help all 3 diseases?)
 ✓ Research insights (what pathways do they regulate?)

→ For judges:
 "We identified 15 non-coding RNAs that are dysregulated
 in Alzheimer's, Parkinson's, and ALS. These universal
 biomarkers suggest shared molecular mechanisms across
 neurodegenerative diseases, with implications for
 diagnostic tests and unified therapeutic approaches."
 = VERY IMPRESSIVE STATEMENT
```

---

## FILE OUTPUTS YOU'LL HAVE

```
results/cross_disease_analysis/
│
├── alzheimers/
│ ├── ncrna_biomarkers.csv
│ ├── de_results_all.csv
│ ├── volcano_plot.png
│ ├── heatmap_top30.png
│ ├── pca_plot.png
│ └── top5_boxplots.png
│
├── parkinsons/
│ ├── ncrna_biomarkers.csv
│ ├── de_results_all.csv
│ ├── volcano_plot.png
│ ├── heatmap_top30.png
│ ├── pca_plot.png
│ └── top5_boxplots.png
│
├── als/
│ ├── ncrna_biomarkers.csv
│ ├── de_results_all.csv
│ ├── volcano_plot.png
│ ├── heatmap_top30.png
│ ├── pca_plot.png
│ └── top5_boxplots.png
│
├── CROSS_DISEASE_RESULTS/
│ ├── shared_2_diseases.csv
│ ├── shared_3_diseases.csv ← MAIN RESULT
│ ├── venn_diagram.png
│ ├── forest_plot_effect_sizes.png
│ ├── comparison_heatmap.png
│ └── SUMMARY_REPORT.txt
│
└── ISEF_PRESENTATION/
 ├── slides.pptx (8-10 slides)
 ├── one_page_abstract.pdf
 ├── judge_talking_points.txt
 └── all_figures_hires/ (300 dpi versions)
```

**Everything you need for !**
