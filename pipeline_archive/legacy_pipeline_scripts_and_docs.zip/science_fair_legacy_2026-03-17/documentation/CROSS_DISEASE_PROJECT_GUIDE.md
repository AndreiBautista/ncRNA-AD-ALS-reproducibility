# Cross-Disease ncRNA Biomarker Discovery Project

## 🎯 PROJECT GOAL
Identify **shared ncRNA biomarkers** across three neurodegenerative diseases (Alzheimer's, Parkinson's, ALS) that could represent universal mechanisms of neurodegeneration and prime therapeutic targets.

## 📊 PROJECT SCOPE

### Current Status:
- ✅ **Alzheimer's Disease (AD)**: GSE203206 ready (47 samples)
- ⏳ **Parkinson's Disease (PD)**: NEED TO FIND (target: 200+ samples)
- ⏳ **ALS**: NEED TO FIND (target: 150-200 samples)

### Timeline Estimate:
- **Dataset search & download:** 1-2 days
- **Data preprocessing:** 1-2 days 
- **Cross-disease analysis:** 2-3 days
- **Visualization & report:** 1-2 days
- **Total:** ~1 week of focused work

---

## 🔍 PHASE 1: DATASET COLLECTION

### Step 1: Search for Parkinson's Disease Datasets

Go to **https://www.ncbi.nlm.nih.gov/geo/** and search:

```
("Parkinson disease" OR "Parkinson's disease") 
AND ("RNA-seq" OR "RNA sequencing") 
AND ("brain" OR "substantia nigra" OR "striatum")
AND ("homo sapiens")
NOT ("single cell")
```

**What to look for:**
- Raw count matrices (not normalized TPM)
- 30+ PD patients + 15+ controls minimum
- Post-mortem brain preferred (or cell culture if necessary)
- Clear disease/control labels in metadata

**Promising starting points** (verify these still exist):
- GSE111932 (if available)
- GSE54282 (if includes raw counts)
- GSE40967 (postmortem brain)

### Step 2: Search for ALS Datasets

Go to **https://www.ncbi.nlm.nih.gov/geo/** and search:

```
("amyotrophic lateral sclerosis" OR "ALS" OR "Motor Neuron Disease")
AND ("RNA-seq" OR "RNA sequencing")
AND ("motor cortex" OR "spinal cord" OR "motor neuron" OR "brain")
AND ("homo sapiens")
NOT ("single cell")
```

**What to look for:**
- Raw count matrices
- 20+ ALS patients + 10+ controls minimum
- Nervous system tissue (motor cortex, spinal cord preferred)
- Clear disease/control metadata

**Promising starting points** (verify these still exist):
- GSE153960 (motor cortex)
- GSE112119 (spinal cord)
- GSE27894 (postmortem)

### Step 3: Download Files

For each promising study:

1. Click on the **GSE accession number** (e.g., GSE111932)
2. Download supplementary files:
 - `*counts.txt` or `*counts.csv` (raw expression counts)
 - `series_matrix.txt` OR metadata file
3. Save to your computer

---

## 📁 PHASE 2: ORGANIZE DATA LOCALLY

### Folder Structure

Create directories following this pattern:

```
ncrna_pipeline/
└── data/
 └── neurodegenerative_diseases/
 ├── alzheimers/
 │ └── GSE203206/
 │ ├── counts.tsv
 │ └── metadata.csv
 ├── parkinsons/
 │ ├── GSE111932/
 │ │ ├── counts.tsv
 │ │ └── metadata.csv
 │ ├── GSE54282/
 │ │ ├── counts.tsv
 │ │ └── metadata.csv
 │ └── ...
 └── als/
 ├── GSE153960/
 │ ├── counts.tsv
 │ └── metadata.csv
 ├── GSE112119/
 │ ├── counts.tsv
 │ └── metadata.csv
 └── ...
```

### File Formats

#### `counts.tsv`
- Tab-separated file
- Header: sample names (columns)
- First column: gene IDs (Ensembl format preferred: ENSG00000...)
- Values: raw expression counts (integers)

**Example:**
```
gene_id sample_1 sample_2 sample_3 sample_4
ENSG00000223972 0 1 15 4
ENSG00000227232 2 8 23 12
ENSG00000278817 4 7 31 19
```

#### `metadata.csv`
- Headers: `sample_id, disease_status, tissue_type, study_id`
- `disease_status`: "Disease" or "Control"
- `tissue_type`: "brain", "substantia_nigra", "motor_cortex", etc.
- `study_id`: GSE accession (e.g., "GSE111932")

**Example:**
```
sample_id,disease_status,tissue_type,study_id
sample_1,Disease,substantia_nigra,GSE111932
sample_2,Control,substantia_nigra,GSE111932
sample_3,Disease,substantia_nigra,GSE111932
sample_4,Control,substantia_nigra,GSE111932
```

---

## 🚀 PHASE 3: RUN PIPELINE

Once you've downloaded and organized datasets:

### Step 1: Validate data organization
```bash
cd ncrna_pipeline
python scripts/cross_disease_pipeline.py
```

This will check:
- All disease folders exist
- All GSE subfolders have counts.tsv + metadata.csv
- Sample counts and gene counts
- Any formatting issues

### Step 2: Report back with accessions
Send me:
- Alzheimer's datasets you're using (beyond GSE203206)
- Parkinson's accessions & sample counts
- ALS accessions & sample counts

Then I'll build the harmonization & DESeq2 analysis scripts.

---

## 📈 PHASE 4: ANALYSIS OUTPUT

### Expected Results

#### Per-disease outputs:
- `alzheimers_ncrna_biomarkers.csv` (e.g., 69 genes)
- `parkinsons_ncrna_biomarkers.csv` (e.g., ~80-150 genes)
- `als_ncrna_biomarkers.csv` (e.g., ~60-120 genes)

Each with columns: gene_id, gene_name, biotype, log2FC, FDR, mean_expression_disease, mean_expression_control

#### Cross-disease outputs:
- `shared_2_diseases.csv` (genes in AD+PD, AD+ALS, or PD+ALS)
- `shared_3_diseases.csv` (genes in ALL THREE - THE GOLD STANDARD)
- Cross-disease visualizations (Venn diagram, forest plot)

#### Expected biomarkers in shared_3_diseases:
- **Realistic estimate:** 5-20 shared ncRNAs
- **Why so few?** Each disease has unique + shared dysregulation; true pan-neurodegenerative markers are rare
- **Why powerful?** Those 5-20 represent universal neurodegeneration mechanisms

### Visualizations

**Per-disease:**
- Volcano plots (log2FC vs statistical significance)
- Heatmaps (top 30 ncRNAs across samples)
- PCA plots (disease vs control clustering)
- Bar plots (top 5 biomarkers: mean ± SD)

**Cross-disease:**
- Venn diagram (overlaps across diseases)
- Forest plot (effect sizes in each disease)
- Summary heatmap (shared biomarkers across diseases)

---

## 💡 PRESENTATION STRATEGY

### Slide Deck Structure:

1. **Introduction** (1 slide)
 - Problem: 3 major neurodegenerative diseases, 60+ million patients worldwide
 - Question: Are there shared molecular mechanisms?

2. **Hypothesis** (1 slide)
 - If diseases share ncRNA dysregulation, these are universal biomarkers
 - Such markers could enable early detection + unified therapeutics

3. **Methods** (2-3 slides)
 - Dataset overview (sample sizes, tissues)
 - Statistical approach (DESeq2, FDR thresholds)
 - Cross-disease comparison logic

4. **Per-Disease Results** (3 slides)
 - Volcano plot + top 20 biomarkers for each disease
 - Counts: "AD: 69 biomarkers", "PD: X biomarkers", "ALS: Y biomarkers"

5. **Cross-Disease Discovery** (2 slides)
 - Venn diagram showing overlaps
 - Table of shared biomarkers (if 3-disease shared, ~5-20 genes)

6. **Top Shared Biomarkers** (1 slide)
 - Ranked list of pan-disease ncRNAs
 - Effect sizes (log2FC) in each disease
 - Biological interpretation

7. **Implications** (1-2 slides)
 - Diagnostic potential: blood test for neurodegeneration?
 - Therapeutic targets: could single drug help multiple diseases?
 - Research directions: functional validation needed

8. **Conclusion** (1 slide)
 - Summary of findings
 - Why this matters for patients

### Judge Impact

**Strong talking points:**
- "Multi-disease analysis is rare in —most projects focus on one disease"
- "Finding shared biomarkers proves universal mechanisms exist"
- "These ncRNAs could become diagnostic tests or drug targets for millions of patients"
- "Used DESeq2 (publication-standard method) + strict FDR correction"
- "Analysis of ~400-500 patient samples from public databases"

---

## 📋 QUICK CHECKLIST

- [ ] Search GEO for Parkinson's datasets
- [ ] Search GEO for ALS datasets 
- [ ] Download files for each study
- [ ] Create folder structure: `data/neurodegenerative_diseases/[disease]/GSE####/`
- [ ] Format counts.tsv + metadata.csv for each dataset
- [ ] Run `python scripts/cross_disease_pipeline.py` validation
- [ ] Send me accession numbers
- [ ] I build & run analysis pipeline
- [ ] Review results
- [ ] Generate visualizations & report
- [ ] Prepare presentation

---

## ❓ FAQ

**Q: Can I use smaller sample sizes?**
A: Minimum 20 per group. Smaller = less statistical power, higher false discovery rate.

**Q: What if I find conflicting biomarkers (up in AD, down in PD)?**
A: Exclude from "shared biomarkers." These are disease-specific, not universal.

**Q: How do I know if the datasets are good quality?**
A: Check:
- Raw counts available (not just TPM)
- Clear sample metadata
- Reasonable sample sizes
- Published paper behind the data
- Recent (2015-2024 preferred)

**Q: What if I can't find enough ALS or PD data?**
A: Use what's available. Even 2-disease comparison (AD + strongest PD or ALS) is valuable.

**Q: Timeline too long?**
A: Start with AD + PD only. ALS can be added later.

---

## 🔗 RESOURCES

- **GEO Database:** https://www.ncbi.nlm.nih.gov/geo/
- **DESeq2 Paper:** Love et al. (2014) Genome Biology
- **ncRNA biotypes:** Ensembl Genome Browser > Non-coding RNA genes
- ** Science communication tips:** Google " judging criteria"

---

**Next step:** Start searching GEO for Parkinson's and ALS datasets. Send me the accessions when ready!
