# AI Coding Guidelines for ncRNA Differential Expression Pipeline

## Project Overview
This repository is a modular Python pipeline for identifying differentially expressed non-coding RNAs (lncRNA, miRNA, snoRNA, etc.) from bulk RNA-seq data with support for public dataset downloads (GEO, Synapse) and publication-quality visualizations.

**Key Workflow:**
1. Load counts matrix, metadata, and gene annotation
2. Filter to non-coding genes (biotype-based keyword matching)
3. Normalize to log2-CPM
4. Compute Welch t-test between disease and control groups
5. Adjust p-values (FDR-BH) and generate figures
6. Aggregate across datasets for conserved gene detection

## Architecture & Module Organization

### Core Modules (in `pipeline/`)
- **`io.py`**: I/O utilities for loading counts/metadata/annotation files and downloading from GEO/Synapse. Returns DataFrames indexed by gene/sample ID. Critical: Uses loose table parsing (`safe_read_table`) to handle diverse file formats.
- **`processing.py`**: Normalization (CPM → log2-CPM) and non-coding gene filtering. Filtering relies on biotype column in annotation matching keywords like `lncrna`, `mirna`, `snoRNA`, etc. If biotype is missing and `allow_missing=False`, raises error.
- **`de_analysis.py`**: Core statistical analysis. Uses Welch t-test (unequal variances) between disease/control groups, applies FDR-BH correction. Returns results DataFrame with columns: `gene_id`, `mean_disease`, `mean_control`, `log2FC`, `pvalue`, `fdr`, `significant`.
- **`visualization.py`**: Figure generation (volcano, heatmap, UpSet overlap, bar plots). All outputs saved with `dpi=300`. Heatmap uses z-score normalization. UpSet requires optional `upsetplot` dependency.

### Entry Points
- **`run_pipeline.py`**: CLI orchestrator. Handles per-dataset analysis, merges results, generates cross-dataset figures. Structure: `results/data/`, `results/per_dataset/`, `results/conserved_ncrnas/`, `results/figures/`.
- **`geo_integration.py`**: Standalone GEO fetcher. Best-effort parsing: tries series_matrix first, then per-GSM tables, then supplementary files. Infers group/disease/control columns from metadata if not provided. Produces: counts.csv, metadata.csv, differential_results.csv, heatmap.png, violin_top_genes.png.

## Critical Developer Workflows

### Running the Pipeline Locally
```bash
# With local files
python3 run_pipeline.py --counts data/counts.csv --metadata data/meta.csv \
 --annotation data/annotation.gtf --outdir results \
 --group_col condition --disease_label Disease --control_label Control

# With GEO dataset (requires annotation file)
python3 run_pipeline.py --datasets GSEXXXXX --annotation data/annotation.gtf --outdir results
```

### Testing with Example Data
```bash
# Example CSVs are in rnaseq_analysis_pipeline/data_examples/
# See QUICKSTART.md and test_pipeline.py for minimal reproducible examples
```

## Key Conventions & Patterns

### Data Indexing
- **Counts DataFrame**: Index = gene_id (rows), Columns = sample names
- **Metadata DataFrame**: Index = sample names, Columns = metadata fields (must include `group_col` for condition/group)
- **Annotation DataFrame**: Index = gene_id, Columns = `gene_name`, `biotype`, etc.
- **Results DataFrame**: Index = gene_id, Columns = log2FC, pvalue, fdr, significant, gene_name, biotype

### Non-Coding Gene Filtering
Biotype keywords are case-insensitive; search in `processing.py`:
```python
nc_keywords = set(['lncrna', 'lnc_rna', 'mirna', 'mir', 'snorna', 'snrna', 'antisense', 'misc_rna', 'rrna', 'ncrna', 'pseudogene', 'scarna', 'vault_rna', 'srna'])
```
If annotation lacks biotype column and upstream function set `allow_missing=False`, pipeline raises error—check annotation file validity.

### GEO Integration Quirks
- **Sample Name Alignment**: GEO sample names (GSM IDs) from `gse.gsms.keys()` must match counts DataFrame columns. If no direct match, `geo_integration.py` applies heuristic: strip whitespace/non-alphanumeric characters and re-match.
- **Group Column Detection**: Searches metadata column names for keywords: `group`, `condition`, `status`, `phenotype`, `disease`, `case` (case-insensitive). If multiple matches, picks first. Use `group_col_hint` parameter to override.
- **Disease/Control Labels**: Inferred from group column value frequencies if not explicitly provided. Highest count assumed disease, lowest assumed control.

### Error Handling Strategy
Functions raise descriptive `ValueError` or `FileNotFoundError` with context (e.g., "Grouping column 'xyz' not found"). CLI script catches exceptions per dataset and continues processing others.

## Integration Points & Dependencies
- **pandas** (data manipulation) and **numpy** (numeric ops): Core throughout all modules
- **scipy.stats.ttest_ind**: Two-sample t-test for DE analysis
- **statsmodels.stats.multitest**: FDR-BH p-value correction
- **matplotlib/seaborn**: All figure generation
- **GEOparse**: Optional, for GEO dataset downloads (auto-detect; raise helpful ImportError if missing)
- **synapseclient**: Optional, for Synapse downloads (placeholder in `io.py`, not fully implemented)
- **upsetplot**: Optional, for UpSet overlap plots (lazy import in `visualization.py`)

## Testing & Validation
- `rnaseq_analysis_pipeline/test_pipeline.py` contains integration tests with example data
- Example data in `rnaseq_analysis_pipeline/data_examples/`: `example_expression_matrix.csv`, `example_metadata.csv`
- When modifying statistical logic (de_analysis.py), ensure results match biological expectations (positive log2FC = upregulated in disease)

## Common Task Patterns
1. **Adding a new figure type**: Create function in `visualization.py` following heatmap/volcano signature (takes logcpm_df, metadata, group_col, out_path, etc.). Call in `run_pipeline.py`.
2. **Supporting new annotation format**: Extend `io.load_annotation()` with new suffix/parser logic.
3. **Changing DE statistic**: Modify `differential_expression()` in `de_analysis.py` (preserve result column names for downstream code).
4. **Troubleshooting GEO downloads**: Check `results/<GSE_ID>/` for downloaded files; inspect `supplementary_files/` if series_matrix parsing failed.
