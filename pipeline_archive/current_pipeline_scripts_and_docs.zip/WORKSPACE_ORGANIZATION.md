# Workspace Organization Guide

All files have been organized into clean folders for easy access.

## 📁 Folder Structure

### **submissions/**
Your teacher submission documents (CURRENT ASSIGNMENT - DATA & ANALYSIS)
- `DATA_AND_ANALYSIS_REPORT.docx` ⭐ **USE THIS FOR TEACHER SUBMISSION**
- `DATA_AND_ANALYSIS_REPORT.html` (HTML version)
- `DATA_AND_ANALYSIS_TEACHER_SUBMISSION.md` (Markdown version)
- submission drafts (DOCX, HTML)

### **all_figures_consolidated/**
All 23 final analysis figures organized and ready
- Numbered 01-23 with descriptive names
- Includes poster figures, summary figures, and per-dataset analyses
- See README.md inside for figure descriptions

### **documentation/**
All markdown guides and PDFs
- Project guides (, PATH_A, etc.)
- Start guides (START_HERE.md, START_HERE_ISEF.md)
- Analysis documentation
- Strategy and roadmap documents

### **raw_data/**
Downloaded GEO datasets and data files
- GSE203206, GSE48350, GSE153960 series matrix files
- Count matrices (.tsv, .txt)
- Metadata files (.csv)

### **presentations/**
PowerPoint poster templates
- ISEF_Grand_Award_Poster_Professional_2026.pptx
- Trifold templates
- Nature Neuroscience style poster

### **latex/**
LaTeX poster source
- ISEF_Poster_2026.tex

### **config/**
Configuration files
- config_datasets.yaml
- config_multi_disease.yaml

### **utility_scripts/**
Python helper scripts
- generate_docx_report.py (creates Word documents)
- Convert, embed, and creation scripts
- grand_award_analysis.py

### **pipeline/**
Main analysis code (Python modules)
- de_analysis.py (differential expression)
- visualization.py (figure generation)
- processing.py (data normalization)
- io.py (data loading)

### **results/**
Analysis output directories
- isef_best/ (final 3-dataset analysis)
- demo/, test_science_fair/, etc. (older runs)

### **data/**
Input data for pipeline
- Annotation files (GTF)
- Example datasets

### **figures/**
Older figure outputs (superseded by all_figures_consolidated/)

---

## 🎥 Video Documentation

**Script location:** `VIDEO_SCRIPT_DATA_COLLECTION.md` (root directory)

This is your complete guide for making the authentic data collection video. Includes:
- Full script (what to say verbatim)
- Screen recording instructions
- Technical setup checklist
- File paths to show
- Recovery tips

**Rubric breakdown:**
- Introduction (5 pts): Brief intro of yourself and project
- Methodology (5 pts): Explain your process
- Authentic Collection (20 pts): SHOW yourself accessing GEO, downloading data, running code

---

## 📊 Teacher Submission Checklist

**Main Submission:**
✅ `submissions/DATA_AND_ANALYSIS_REPORT.docx` (4.1 MB)
- 13 embedded figures (PCA, volcano plots, heatmaps, Venn, pathways, ROC curves)
- 3 data tables
- Complete statistical analysis
- Times New Roman 12pt, double-spaced, 1" margins

**Video Documentation:**
📹 Record using `VIDEO_SCRIPT_DATA_COLLECTION.md` as guide
- Screen share showing GEO access
- Terminal showing pipeline execution
- Walk through figures and results
- 3-5 minutes total

---

## 🔧 Quick Access Commands

```bash
# Open teacher submission document
open submissions/DATA_AND_ANALYSIS_REPORT.docx

# View video script
cat VIDEO_SCRIPT_DATA_COLLECTION.md

# See all figures
open all_figures_consolidated/

# Run pipeline example
python3 run_pipeline.py --counts data/example.csv --metadata data/meta.csv

# View results from final analysis
open results/isef_best/
```

---

## 📌 Important Files Quick Reference

| Purpose | Location |
|---------|----------|
| **Teacher submission (docx)** | `submissions/DATA_AND_ANALYSIS_REPORT.docx` |
| **Video script** | `VIDEO_SCRIPT_DATA_COLLECTION.md` |
| **All figures** | `all_figures_consolidated/` (23 files) |
| **Main analysis results** | `results/isef_best/` |
| **Pipeline code** | `pipeline/` |
| **Raw downloaded data** | `raw_data/` |
| ** poster (PowerPoint)** | `presentations/ISEF_Grand_Award_Poster_Professional_2026.pptx` |
| **Project overview** | `documentation/START_HERE_ISEF.md` |

---

## 🎯 Current Status

✅ Data analysis complete (1,463 samples, 3 datasets)
✅ Figures consolidated (23 final figures)
✅ Teacher Data & Analysis document created (DOCX with embedded images)
✅ Video script prepared
✅ Workspace organized

**Next steps:**
1. Record video using VIDEO_SCRIPT_DATA_COLLECTION.md
2. Upload DATA_AND_ANALYSIS_REPORT.docx to teacher
3. Submit video with document

---

**Last organized:** February 19, 2026
