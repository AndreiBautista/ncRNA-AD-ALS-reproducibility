from pathlib import Path
import pandas as pd
from docx import Document
from docx.shared import Pt


def add_heading(doc: Document, text: str, level: int = 1) -> None:
    h = doc.add_heading(text, level=level)
    if h.runs:
        h.runs[0].font.size = Pt(14 if level == 1 else 12)


def add_markdown_block(doc: Document, title: str, text: str) -> None:
    add_heading(doc, title, level=1)
    for line in text.splitlines():
        line = line.rstrip()
        if not line:
            continue
        if line.startswith("## "):
            add_heading(doc, line.replace("## ", "", 1), level=2)
        elif line.startswith("# "):
            add_heading(doc, line.replace("# ", "", 1), level=1)
        else:
            doc.add_paragraph(line)


def add_csv_table(doc: Document, title: str, csv_path: Path, max_rows: int = 200) -> None:
    add_heading(doc, title, level=1)
    doc.add_paragraph(f"Source: {csv_path.as_posix()}")
    df = pd.read_csv(csv_path)

    if df.empty:
        doc.add_paragraph("(No rows)")
        return

    if len(df) > max_rows:
        df = df.head(max_rows)
        doc.add_paragraph(f"Showing first {max_rows} rows.")

    table = doc.add_table(rows=1, cols=len(df.columns))
    table.style = "Table Grid"

    for i, col in enumerate(df.columns):
        table.rows[0].cells[i].text = str(col)

    for _, row in df.iterrows():
        cells = table.add_row().cells
        for i, val in enumerate(row.tolist()):
            cells[i].text = "" if pd.isna(val) else str(val)


def main() -> None:
    root = Path("phase2_validation_framework/outputs")
    report_md = root / "framework/reports/final_summary.md"
    out_docx = root / "model_comparison/ml/phase2_combined_summaries.docx"

    csv_sections = [
        ("Framework Master Summary Table", root / "model_comparison/ml/framework_master_summary_table.csv"),
        ("Validation Overview", root / "validation/external_validation/validation_overview.csv"),
        ("Panel Presence After Harmonization", root / "validation/external_validation/panel_presence_after_harmonization.csv"),
        ("Model Comparison Summary", root / "model_comparison/ml/model_comparison_summary.csv"),
        ("Single Gene vs Panel Summary", root / "model_comparison/ml/single_gene_auc.csv"),
        ("Transportability Results", root / "model_comparison/ml/transportability_results.csv"),
        ("Permutation Test Results", root / "model_comparison/ml/permutation_test_results.csv"),
        ("Coefficient Direction Summary", root / "model_comparison/ml/coefficient_direction_summary.csv"),
        ("Cross-Disease Effect Direction Table", root / "model_comparison/ml/cross_disease_effect_direction_table.csv"),
    ]

    doc = Document()
    add_heading(doc, "ncRNA Phase 2 Consolidated Summaries", level=0)
    doc.add_paragraph("Automatically generated from Phase 2 summary artifacts.")

    if report_md.exists():
        add_markdown_block(doc, "Final Summary Report", report_md.read_text(encoding="utf-8"))

    for title, path in csv_sections:
        if path.exists():
            add_csv_table(doc, title, path)
        else:
            add_heading(doc, title, level=1)
            doc.add_paragraph(f"Missing file: {path.as_posix()}")

    out_docx.parent.mkdir(parents=True, exist_ok=True)
    doc.save(out_docx)
    print(out_docx.as_posix())


if __name__ == "__main__":
    main()
