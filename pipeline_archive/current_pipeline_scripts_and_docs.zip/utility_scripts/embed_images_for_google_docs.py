#!/usr/bin/env python3
"""
Create Google Doc-ready HTML with embedded images
This script embeds PNG images as base64 into the HTML for proper Google Docs display
"""

import os
import base64
from pathlib import Path

def embed_images_in_html():
 """Embed PNG images into HTML as base64 for Google Docs"""
 
 base_dir = Path("/Users/austinbautista/ncrna_pipeline")
 results_dir = base_dir / "results/isef_best/final_4datasets/per_dataset"
 
 # Map of figure references to actual file locations
 figure_map = {
 "GSE203206_volcano_ncRNA": results_dir / "GSE203206/figures/GSE203206_volcano_ncRNA.png",
 "GSE203206_top_ncRNA_heatmap": results_dir / "GSE203206/figures/GSE203206_top_ncRNA_heatmap.png",
 "GSE203206_top3_ncRNA_barplot": results_dir / "GSE203206/figures/GSE203206_top3_ncRNA_barplot.png",
 "GSE203206_PCA": results_dir / "GSE203206/figures/GSE203206_PCA.png",
 "GSE48350_volcano_ncRNA": results_dir / "GSE48350/figures/GSE48350_volcano_ncRNA.png",
 "GSE48350_top_ncRNA_heatmap": results_dir / "GSE48350/figures/GSE48350_top_ncRNA_heatmap.png",
 "GSE48350_top3_ncRNA_barplot": results_dir / "GSE48350/figures/GSE48350_top3_ncRNA_barplot.png",
 "GSE48350_PCA": results_dir / "GSE48350/figures/GSE48350_PCA.png",
 "GSE95587_PCA": results_dir / "GSE95587/figures/GSE95587_PCA.png",
 "GSE153960_volcano_ncRNA": results_dir / "GSE153960/figures/GSE153960_volcano_ncRNA.png",
 "GSE153960_top_ncRNA_heatmap": results_dir / "GSE153960/figures/GSE153960_top_ncRNA_heatmap.png",
 "GSE153960_top3_ncRNA_barplot": results_dir / "GSE153960/figures/GSE153960_top3_ncRNA_barplot.png",
 "GSE153960_PCA": results_dir / "GSE153960/figures/GSE153960_PCA.png",
 }
 
 # Convert images to base64
 embedded_images = {}
 for name, path in figure_map.items():
 if path.exists():
 with open(path, "rb") as img_file:
 img_data = base64.b64encode(img_file.read()).decode('utf-8')
 embedded_images[name] = img_data
 print(f"✓ Embedded: {name}")
 else:
 print(f"✗ Not found: {path}")
 
 # Read the original HTML
 html_path = base_dir / "ISEF_DATA_ANALYSIS_REPORT_GOOGLE_DOC.html"
 with open(html_path, 'r') as f:
 html_content = f.read()
 
 # Replace placeholder references with embedded images
 for name, img_data in embedded_images.items():
 # Create embedded image HTML
 img_html = f'<img src="data:image/png;base64,{img_data}" style="max-width: 100%; height: auto; border: 1px solid #ccc; margin: 12pt 0;" alt="Figure: {name}">'
 
 # This is a more sophisticated replacement - we need to add the image after the figure descriptions
 placeholders = [
 f"*{name}.png",
 f"• {name}.png",
 f"{name}.png"
 ]
 
 for placeholder in placeholders:
 if placeholder in html_content:
 html_content = html_content.replace(placeholder, img_html)
 print(f"✓ Embedded image for: {name}")
 
 # Save the new HTML
 output_path = base_dir / "ISEF_DATA_ANALYSIS_REPORT_GOOGLE_DOC_WITH_IMAGES.html"
 with open(output_path, 'w') as f:
 f.write(html_content)
 
 print(f"\n✅ Created: {output_path}")
 print(" This HTML file has all images embedded as base64")
 print(" Upload to Google Docs: File → Open → Upload → Select this file")
 return output_path

if __name__ == "__main__":
 embed_images_in_html()
