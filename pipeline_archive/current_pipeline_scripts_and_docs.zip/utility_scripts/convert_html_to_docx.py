#!/usr/bin/env python3
"""Convert HTML report with embedded base64 images to DOCX format for Google Docs."""

import re
import base64
import io
from pathlib import Path
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH

def convert_html_to_docx(html_file, docx_file):
 """Convert HTML file to DOCX, extracting and embedding base64 images."""
 print(f"🔄 Converting {html_file} to DOCX format...")
 
 # Read HTML file
 with open(html_file, 'r', encoding='utf-8') as f:
 html_content = f.read()
 
 # Create document
 doc = Document()
 
 # Set default font
 style = doc.styles['Normal']
 style.font.name = 'Times New Roman'
 style.font.size = Pt(12)
 
 # Extract title
 title_match = re.search(r'<title>([^<]+)</title>', html_content)
 if title_match:
 title = title_match.group(1)
 heading = doc.add_heading(title, level=0)
 heading_style = heading.style
 heading_style.font.name = 'Times New Roman'
 
 # Extract body content
 body_match = re.search(r'<body>(.*?)</body>', html_content, re.DOTALL)
 if body_match:
 body_content = body_match.group(1)
 else:
 body_content = html_content
 
 # Process content line by line
 sections = re.split(r'(<h[1-4]>.*?</h[1-4]>|<table>.*?</table>|<p>.*?</p>|<img[^>]*>)', body_content, flags=re.DOTALL)
 
 for section in sections:
 section = section.strip()
 if not section:
 continue
 
 # Handle headings
 if re.match(r'<h[1-4]>', section):
 level_match = re.search(r'<h([1-4])>(.*?)</h\1>', section, re.DOTALL)
 if level_match:
 level = int(level_match.group(1))
 text = re.sub(r'<[^>]+>', '', level_match.group(2))
 heading = doc.add_heading(text, level=level)
 heading_style = heading.style
 heading_style.font.name = 'Times New Roman'
 
 # Handle images (base64)
 elif section.startswith('<img'):
 src_match = re.search(r'src="([^"]+)"', section)
 if src_match:
 src = src_match.group(1)
 if src.startswith('data:image'):
 match = re.match(r'data:image/(\w+);base64,(.+)', src)
 if match:
 image_format, base64_data = match.groups()
 try:
 image_bytes = base64.b64decode(base64_data)
 para = doc.add_paragraph()
 para.alignment = WD_ALIGN_PARAGRAPH.CENTER
 run = para.add_run()
 run.add_picture(io.BytesIO(image_bytes), width=Inches(5.5))
 print(f"✓ Embedded image")
 except Exception as e:
 print(f"⚠ Error decoding image: {e}")
 
 # Handle tables
 elif section.startswith('<table'):
 rows = re.findall(r'<tr>(.*?)</tr>', section, re.DOTALL)
 if rows:
 num_cols = len(re.findall(r'<th>|<td>', rows[0]))
 table = doc.add_table(rows=len(rows), cols=max(num_cols, 1))
 table.style = 'Light Grid Accent 1'
 
 for row_idx, row_content in enumerate(rows):
 cells_content = re.findall(r'<t[dh]>(.*?)</t[dh]>', row_content, re.DOTALL)
 for col_idx, cell_content in enumerate(cells_content):
 # Clean cell content
 cell_text = re.sub(r'<[^>]+>', '', cell_content).strip()
 if row_idx < len(table.rows) and col_idx < len(table.rows[row_idx].cells):
 table.rows[row_idx].cells[col_idx].text = cell_text
 
 # Handle paragraphs
 elif section.startswith('<p'):
 # Clean HTML tags
 text = re.sub(r'</?p[^>]*>', '', section)
 text = re.sub(r'<strong>(.*?)</strong>', r'\1', text)
 text = re.sub(r'</?[^>]+>', '', text)
 
 if text.strip():
 para = doc.add_paragraph(text.strip())
 para_style = para.style
 para_style.font.name = 'Times New Roman'
 
 # Save document
 doc.save(docx_file)
 print(f"✅ Saved: {docx_file}")
 print(f" Ready to upload to Google Docs: File → Open → Upload")

if __name__ == '__main__':
 html_file = Path('/Users/austinbautista/ncrna_pipeline/ISEF_DATA_ANALYSIS_REPORT_GOOGLE_DOC_WITH_IMAGES.html')
 docx_file = Path('/Users/austinbautista/ncrna_pipeline/ISEF_DATA_ANALYSIS_REPORT_GOOGLE_DOC.docx')
 
 if html_file.exists():
 convert_html_to_docx(str(html_file), str(docx_file))
 else:
 print(f"❌ HTML file not found: {html_file}")
