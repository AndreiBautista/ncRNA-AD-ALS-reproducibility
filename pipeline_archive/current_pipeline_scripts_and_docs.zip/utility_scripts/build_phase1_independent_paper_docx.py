#!/usr/bin/env python3
from pathlib import Path
import re
from docx import Document
from docx.shared import Pt
from docx.shared import Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH


def build_docx(md_path: Path, out_path: Path) -> None:
    lines = md_path.read_text(encoding="utf-8").splitlines()
    img_re = re.compile(r"^!\[(.*?)\]\((.*?)\)$")

    def is_table_line(text: str) -> bool:
        t = text.strip()
        return t.startswith("|") and t.endswith("|") and t.count("|") >= 2

    def is_separator_line(text: str) -> bool:
        t = text.strip().strip("|")
        parts = [p.strip() for p in t.split("|")]
        if not parts:
            return False
        for p in parts:
            raw = p.replace(":", "").replace("-", "")
            if raw != "":
                return False
            if "-" not in p:
                return False
        return True

    def parse_table_row(text: str) -> list[str]:
        return [c.strip() for c in text.strip().strip("|").split("|")]

    doc = Document()
    normal = doc.styles["Normal"]
    normal.font.name = "Times New Roman"
    normal.font.size = Pt(12)
    normal.paragraph_format.line_spacing = 2.0

    # Explicit title page
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("Convergent Non Coding RNA Biomarkers Across Alzheimer Disease and Amyotrophic Lateral Sclerosis")
    r.bold = True
    r.font.size = Pt(16)

    for t in [
        "Independent Research Paper for Science Fair Submission and Potential Student Research Publication",
        "",
        "Austin Bautista",
        "Independent Student Researcher",
        "March 2026",
    ]:
        q = doc.add_paragraph(t)
        q.alignment = WD_ALIGN_PARAGRAPH.CENTER

    doc.add_page_break()

    in_title_block = False
    i = 0
    while i < len(lines):
        raw = lines[i]
        s = raw.rstrip()

        if s.startswith("## Title Page"):
            in_title_block = True
            i += 1
            continue
        if in_title_block:
            if s.startswith("---"):
                in_title_block = False
            i += 1
            continue

        if not s:
            doc.add_paragraph("")
            i += 1
            continue

        if is_table_line(s):
            table_lines = []
            j = i
            while j < len(lines) and is_table_line(lines[j].rstrip()):
                table_lines.append(lines[j].rstrip())
                j += 1

            rows = []
            for idx, tl in enumerate(table_lines):
                if idx == 1 and is_separator_line(tl):
                    continue
                rows.append(parse_table_row(tl))

            if rows:
                n_cols = max(len(r) for r in rows)
                table = doc.add_table(rows=len(rows), cols=n_cols)
                table.style = "Table Grid"
                for r_idx, row in enumerate(rows):
                    for c_idx in range(n_cols):
                        txt = row[c_idx] if c_idx < len(row) else ""
                        table.cell(r_idx, c_idx).text = txt
                doc.add_paragraph("")

            i = j
            continue

        img_match = img_re.match(s)
        if img_match:
            alt_text = img_match.group(1).strip()
            img_path_raw = img_match.group(2).strip()
            img_path = Path(img_path_raw)
            if not img_path.exists():
                img_path = md_path.parent.parent / img_path_raw

            if img_path.exists():
                pic_par = doc.add_paragraph()
                pic_par.alignment = WD_ALIGN_PARAGRAPH.CENTER
                pic_run = pic_par.add_run()
                pic_run.add_picture(str(img_path), width=Inches(6.0))

                if alt_text:
                    cap = doc.add_paragraph(alt_text)
                    cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
            else:
                doc.add_paragraph(f"[Image missing: {img_path_raw}]")
            i += 1
            continue

        if s.startswith("# "):
            doc.add_heading(s[2:].strip(), level=1)
        elif s.startswith("## "):
            heading = s[3:].strip()
            if heading.lower().startswith("references"):
                doc.add_page_break()
            doc.add_heading(heading, level=2)
        elif s.startswith("### "):
            doc.add_heading(s[4:].strip(), level=3)
        elif s.startswith("---"):
            doc.add_paragraph("")
        elif s.startswith("- "):
            doc.add_paragraph(s[2:].strip(), style="List Bullet")
        elif len(s) > 2 and s[0].isdigit() and s[1] == ".":
            doc.add_paragraph(s, style="List Number")
        else:
            doc.add_paragraph(s)

        i += 1

    out_path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(out_path)


if __name__ == "__main__":
    md = Path("docs/PHASE1_INDEPENDENT_RESEARCH_PAPER.md")
    out = Path("docs/PHASE1_INDEPENDENT_RESEARCH_PAPER.docx")
    build_docx(md, out)
    print(out.as_posix())
