#!/usr/bin/env python3
from docx import Document
from pathlib import Path
import re

html_file = Path('/Users/austinbautista/ncrna_pipeline/ISEF_DATA_ANALYSIS_REPORT_COMPREHENSIVE_UPDATED.html')
docx_file = Path('/Users/austinbautista/ncrna_pipeline/ISEF_DATA_ANALYSIS_REPORT_COMPREHENSIVE_UPDATED.docx')

print('🔄 Converting comprehensive report to DOCX...')

with open(html_file, 'r') as f:
 html = f.read()

doc = Document()
style = doc.styles['Normal']
style.font.name = 'Times New Roman'

# Extract title
title_match = re.search(r'<title>([^<]+)</title>', html)
if title_match:
 doc.add_heading(title_match.group(1), level=0)

# Extract body
body_match = re.search(r'<body>(.*?)</body>', html, re.DOTALL)
body = body_match.group(1) if body_match else html

# Process content
for line in body.split('\n'):
 line = line.strip()
 if not line or len(line) < 3:
 continue
 
 if line.startswith('<h2>'):
 text = re.sub(r'<[^>]+>', '', line)
 if text:
 doc.add_heading(text, level=1)
 elif line.startswith('<h3>'):
 text = re.sub(r'<[^>]+>', '', line)
 if text:
 doc.add_heading(text, level=2)
 elif '<p' in line and '>' in line:
 text = re.sub(r'<[^>]+>', '', line)
 if text and len(text) > 5:
 doc.add_paragraph(text)
 elif '<li>' in line:
 text = re.sub(r'<[^>]+>', '', line)
 if text:
 doc.add_paragraph(text, style='List Bullet')
 elif '<hr' in line or '<HR' in line:
 doc.add_paragraph('_' * 70)

doc.save(str(docx_file))
size_mb = docx_file.stat().st_size / (1024*1024)
print(f'✅ Saved: {docx_file.name} ({size_mb:.1f} MB)')
print(' Ready for Google Docs: File → Open → Upload')
