# ncRNA Pipeline - Quick Start Guide

## 30 Second Setup

```bash
cd /Users/austinbautista/ncrna_pipeline

# Activate the environment (already created during setup)
source .venv/bin/activate

# Test the pipeline
python tests/test_pipeline.py

# Run on example data
python scripts/run_pipeline.py \
 --counts examples/data/example_expression_matrix.csv \
 --metadata examples/data/example_metadata.csv \
 --group_col Condition \
 --disease_label Disease \
 --control_label Control \
 --outdir results/test_run
```

## Using Your Own Data

### 1. Prepare your CSV files

**Counts file** (`counts.csv`):
- First column: gene IDs (e.g., ENSG00000210195)
- Other columns: counts for each sample
- No header names needed, just make sure columns match sample names in metadata

```csv
gene_id,Sample_A,Sample_B,Sample_C
ENSG00000001,45,32,78
ENSG00000002,120,98,145
```

**Metadata file** (`metadata.csv`):
- First column: sample name (matches column names in counts)
- Second column or later: "condition", "group", or similar for disease status
- Other columns: optional metadata (age, batch, etc.)

```csv
sample,condition,batch
Sample_A,Control,1
Sample_B,Control,1
Sample_C,Disease,2
```

**Annotation file** (OPTIONAL but recommended):
- Can be GTF or CSV
- Must have columns: gene_id, biotype
- The biotype column is how genes are filtered for lncRNA, miRNA, etc.

### 2. Run the pipeline

```bash
python scripts/run_pipeline.py \
 --counts YOUR_COUNTS.csv \
 --metadata YOUR_METADATA.csv \
 --annotation YOUR_ANNOTATION.gtf \
 --group_col condition \
 --disease_label Disease \
 --control_label Control \
 --outdir results/my_study
```

### 3. Check outputs

Results will be in `results/my_study/`:
- `per_dataset/` - Differential expression results and plots
- `figures/` - Summary visualizations

Key files:
- `*_differential_results.csv` - Full DE results (log2FC, p-values, FDR)
- `*_volcano.png` - Volcano plot (log2FC vs -log10(FDR))
- `*_top_genes_heatmap.png` - Heatmap of top genes

## Comparing Multiple Datasets (Correct Order)

Yes, comparing multiple datasets is valid, but only after analyzing them individually.

Correct order:

Analyze Dataset A -> get significant genes

Analyze Dataset B -> get significant genes

Compare overlap

Look for shared biological themes

You do NOT mash them together first.

You extract -> then compare.

### What You Want the AI to Do

You want code that:

- Filters significant genes
- Extracts top up/down genes
- Saves results
- Compares multiple datasets
- Shows overlapping genes
- Maybe makes a Venn diagram

That is completely reasonable.

### Prompt You Can Paste Into AI

This assumes your dataframe is called res (like DESeq2 output).

SINGLE DATASET EXTRACTION PROMPT
I have a DESeq2 results dataframe called "res" with the following columns:
- log2FoldChange
- padj
- gene (row names or a gene column)

Please write clean R code that:

1. Removes NA values
2. Filters genes with padj < 0.05 and abs(log2FoldChange) > 1
3. Separates upregulated and downregulated genes
4. Extracts the top 20 upregulated and top 20 downregulated genes (sorted by padj)
5. Saves them to CSV files
6. Prints how many total significant genes were found

Make the code clean and commented.

MULTIPLE DATASET COMPARISON PROMPT

If you have multiple result objects like:

res_AD

res_PD

res_FTD

Use this prompt:

I have multiple DESeq2 result dataframes:
res_AD
res_PD
res_FTD

Each contains:
- log2FoldChange
- padj
- gene column

Please write R code that:

1. Filters each dataset for padj < 0.05 and abs(log2FoldChange) > 1
2. Extracts the significant gene names from each dataset
3. Finds overlapping genes between:
 - AD vs PD
 - AD vs FTD
 - PD vs FTD
4. Finds genes shared across all three datasets
5. Prints the number of overlapping genes for each comparison
6. Creates a Venn diagram showing overlaps

Make the code clear and well commented.

### Important Reality Check

Comparing datasets only makes sense if:

- Same species
- Same gene naming format
- Similar preprocessing
- Similar tissue type

If one dataset is mouse and one is human, overlap may not work directly.

### What This Accomplishes

Now your project becomes:

"These diseases share X inflammatory genes"

"These datasets show overlapping mitochondrial dysfunction"

"Dataset A and B cluster similarly but C is distinct"

That's a story.

That's analysis.

## Common Parameters

| Flag | Default | Description |
|------|---------|-------------|
| `--counts` | Required | Path to counts CSV |
| `--metadata` | Required | Path to metadata CSV |
| `--annotation` | Optional | Path to annotation GTF/CSV |
| `--group_col` | condition | Column name in metadata for disease/control grouping |
| `--disease_label` | Disease | Value in group_col for disease samples |
| `--control_label` | Control | Value in group_col for healthy samples |
| `--pseudocount` | 1.0 | Added before log2 transform (prevents log(0)) |
| `--top_n` | 50 | Number of genes to show in plots |
| `--outdir` | results | Output directory |

## Troubleshooting

**"Module not found" errors?**
```bash
# Reinstall dependencies
source .venv/bin/activate
pip install -r requirements.txt
python tests/test_pipeline.py
```

**Sample names don't match?**
Check that:
1. Column names in counts CSV exactly match sample names in metadata
2. First row of counts CSV is the header (sample names)
3. Metadata sample column values match

**No genes detected after annotation filtering?**
The pipeline filters for non-coding RNAs by biotype. If you have no non-coding genes:
- Run without annotation (`--annotation` omitted) to include all genes
- Or create a simple annotation CSV with all biotypes set to "lncRNA"

## GEO Dataset Integration

To analyze a GEO Series directly:

```bash
python scripts/run_pipeline.py \
 --datasets GSE123456 \
 --annotation data/genes.gtf \
 --outdir results
```

Requirements:
- GEOparse must be installed (done by default)
- You must provide an annotation file

## Next Steps

See the main [`README.md`](../README.md) for:
- Full API documentation
- Architecture overview
- Contributing guidelines
