# Module Architecture

## High-Level Data Flow

```
Input Files
 ↓
[ io.py ] ← Load counts, metadata, annotation
 ↓
[ processing.py ] ← Normalize to log2-CPM, filter non-coding genes
 ↓
[ de_analysis.py ] ← Welch t-test, FDR correction
 ↓
[ visualization.py ] ← Generate plots
 ↓
Output Results
```

## Module Details

### `io.py` - Data Loading & Downloading

**Purpose**: Handle all file I/O and data source integration

**Key Functions:**
- `load_counts(path)` - Load expression matrix (genes × samples)
- `load_metadata(path, group_col)` - Load sample metadata with grouping column
- `load_annotation(path)` - Load gene annotation (GTF or CSV)
- `download_geo(gse_id, outdir)` - Fetch GEO dataset using GEOparse
- `download_synapse(syn_id, outdir)` - Synapse integration (placeholder)
- `safe_read_table(path)` - Flexible CSV/TSV parser

**Data Conventions:**
- **Counts**: Pandas DataFrame, index=gene_id, columns=sample_names
- **Metadata**: Pandas DataFrame, index=sample_names, columns=metadata fields
- **Annotation**: Pandas DataFrame, index=gene_id, columns=[gene_name, biotype, ...]

**Error Handling:**
- Files not found → `FileNotFoundError`
- Missing required columns → `ValueError`
- Invalid data types → `ValueError` with context

### `processing.py` - Normalization & Filtering

**Purpose**: Prepare data for statistical analysis

**Key Functions:**
- `cpm(counts)` - Convert raw counts to counts-per-million
- `log2_cpm(counts, pseudocount=1.0)` - Normalize to log2-transformed CPM
- `filter_noncoding_genes(counts, annot, allow_missing=False)` - Keep only non-coding RNAs

**Non-Coding RNA Definition:**
Case-insensitive biotype matching for keywords:
```
['lncrna', 'lnc_rna', 'mirna', 'mir', 'snorna', 'snrna', 
 'antisense', 'misc_rna', 'rrna', 'ncrna', 'pseudogene', 
 'scarna', 'vault_rna', 'srna']
```

If a gene's biotype matches any keyword (partial match), it's retained.

**Example**:
- Biotype: `"long non-coding RNA"` → matches `lncrna` ✓
- Biotype: `"miRNA"` → matches `mir` ✓
- Biotype: `"protein_coding"` → no match ✗

### `de_analysis.py` - Statistical Testing

**Purpose**: Identify differentially expressed genes

**Key Functions:**
- `differential_expression(logcpm, metadata, group_col, disease_label, control_label)` 
 - Two-sample Welch t-test (unequal variances)
 - Returns: DataFrame with log2FC, mean_disease, mean_control, pvalue
 
- `adjust_pvalues(res, method='fdr_bh')`
 - Benjamini-Hochberg FDR correction
 - Adds columns: fdr, significant (boolean, FDR < 0.05)
 
- `save_results(res, annot, out_prefix)`
 - Merge results with annotation
 - Sort by FDR then p-value
 - Save CSV and return merged DataFrame

**Results Columns:**
| Column | Type | Description |
|--------|------|-------------|
| gene_id | str | Gene identifier |
| mean_disease | float | Mean log2-CPM in disease samples |
| mean_control | float | Mean log2-CPM in control samples |
| log2FC | float | Mean difference (disease - control) |
| pvalue | float | Raw p-value from t-test |
| fdr | float | FDR-corrected p-value |
| significant | bool | FDR < 0.05 |
| gene_name | str | Human-readable name (from annotation) |
| biotype | str | RNA type (from annotation) |

### `visualization.py` - Figure Generation

**Purpose**: Generate publication-quality plots

**Key Functions:**
- `volcano_plot(res_df, out_path, title)` 
 - X-axis: log2FC | Y-axis: -log10(FDR)
 - Red points: significant (FDR < 0.05)
 - Grey: non-significant
 - Dashed line at FDR = 0.05
 - Output: 300 DPI PNG

- `heatmap_top_genes(logcpm, top_genes, metadata, group_col, out_path)`
 - Z-score normalized expression
 - Clustered rows (genes), ordered columns (by sample group)
 - Color bar indicating disease/control grouping
 - Output: 300 DPI PNG

- `upset_overlap(list_of_gene_sets, out_path, title)`
 - Shows intersection of significant gene lists across datasets
 - Requires `upsetplot` package
 - Output: 300 DPI PNG

- `barplot_significant_counts(signif_counts, out_path, title)`
 - Summary: number of significant genes per dataset
 - Output: 300 DPI PNG

## Entry Points & Orchestration

### `run_pipeline.py` - CLI Interface

**Purpose**: Orchestrate per-dataset analysis and cross-dataset results

**Key Functions:**
- `analyze_dataset()` - Run full pipeline on single dataset
- `ensure_dirs()` - Create output directory structure
- `main()` - Parse arguments, loop over datasets, generate cross-dataset plots

**Usage**:
```bash
# Local files
python scripts/run_pipeline.py \
 --counts data.csv --metadata meta.csv --annotation genes.gtf \
 --group_col condition --disease_label Disease --control_label Control

# GEO dataset
python scripts/run_pipeline.py --datasets GSE123456 --annotation genes.gtf
```

**Output Structure**:
```
results/
├── data/ # Downloaded files
├── per_dataset/ # Individual study analysis
│ ├── <name>_differential_results.csv
│ ├── <name>_volcano.png
│ └── <name>_top_genes_heatmap.png
├── conserved_ncrnas/ # Cross-study overlap
└── figures/ # Summary plots
 ├── conserved_upset.png
 └── ncRNA_significant_counts.png
```

### `geo_integration.py` - GEO Fetching

**Purpose**: Best-effort download and parsing of GEO datasets

**Key Functions:**
- `fetch_geo(gse_id, out_dir, annotate_gpl)` - Download & parse GSE
- `run_pipeline_on_gse()` - End-to-end wrapper for GEO analysis

**Strategy** (tries in order):
1. Series matrix (if available) - preferred, fast
2. Per-GSM tables - if series matrix not found
3. Supplementary files - fallback, may require manual inspection

**Known Limitations**:
- GEO metadata format varies widely
- Sample alignment may fail without hints
- Platform annotation may be incomplete

## Common Modifications

### Add a new visualization function

1. Add function to `visualization.py`:
```python
def my_plot(results_df, out_path, **kwargs):
 plt.figure(figsize=(8, 6))
 # ... plotting code ...
 Path(out_path).parent.mkdir(parents=True, exist_ok=True)
 plt.savefig(out_path, dpi=300, bbox_inches='tight')
 plt.close()
```

2. Call it from `run_pipeline.py`:
```python
my_plot_path = f"{out_prefix}_my_plot.png"
visualization.my_plot(results, my_plot_path)
```

### Support new annotation format

1. Extend `io.load_annotation()`:
```python
elif path.suffix.lower() == '.xlsx':
 df = pd.read_excel(path, sheet_name='genes')
 # ... parsing logic ...
```

### Customize RNA type filtering

1. Edit `pipeline/processing.py`:
```python
nc_keywords = set(['lncrna', 'my_custom_type', ...])
```

## Testing

Run `python tests/test_pipeline.py` to verify:
- All dependencies installed
- Pipeline runs on example data
- Output files generated correctly

## Performance Notes

- **Typical runtime**: 10-30 seconds per dataset (6-10 samples)
- **Memory usage**: ~200-500 MB for 20K genes × 10 samples
- **GEO downloads**: 5-30 minutes depending on dataset size

## Debugging Tips

1. **Enable logging**:
```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

2. **Check intermediate outputs**:
```python
# After loading
print(counts.shape, metadata.shape, annot.shape)

# After normalization
print(logcpm.describe())

# After DE analysis
print(results.describe())
print(results['significant'].sum(), "genes significant")
```

3. **Validate input data**:
```python
# Sample alignment
print("Overlapping samples:", 
 counts.columns.intersection(metadata.index).tolist())
```

---

For user-facing documentation, see [QUICKSTART.md](QUICKSTART.md) and [../README.md](../README.md)
