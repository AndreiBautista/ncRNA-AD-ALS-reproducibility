# Phase 2 Output Interpretation Layer

This guide gives a plain-language interpretation for the new Phase 2 result files and how to explain them in presentations.

## 1) biomarker_generalization_scores.csv
File path: phase2_validation_framework/outputs/framework/cross_disease_framework/biomarker_generalization_scores.csv

What this file means:
- This table ranks each fixed biomarker by how consistently it appears, keeps direction, and shows statistical support across external datasets.
- Higher scores mean a biomarker is more stable across datasets and diseases.

Result pattern that supports the hypothesis:
- Most or all panel biomarkers have high generalization scores.
- Direction consistency is high and does not flip between AD and ALS.

Result pattern that weakens the hypothesis:
- Scores are low or highly uneven (for example one biomarker carries everything while others fail).
- Frequent direction flips or weak significance support across datasets.

Recommended figure:
- Ranked horizontal bar chart of generalization_score by biomarker, with side annotations for presence_rate and direction_consistency.

Judge sentence:
- This score shows whether each biomarker is truly reproducible across independent cohorts, not just strong in one dataset.

## 2) cross_disease_transportability.csv
File path: phase2_validation_framework/outputs/framework/cross_disease_framework/cross_disease_transportability.csv

What this file means:
- This table tests strict transfer learning scenarios: train on AD and test on ALS, then train on ALS and test on AD.
- It reports out-of-disease performance for the panel and baselines.

Result pattern that supports the hypothesis:
- The fixed panel keeps useful AUC and balanced sensitivity/specificity in both AD->ALS and ALS->AD directions.
- Panel performance is consistently better than random baseline in both directions.

Result pattern that weakens the hypothesis:
- Strong collapse in one or both directions (AUC near chance).
- Large asymmetry where one direction works but the reverse fails badly.

Recommended figure:
- Two-group point or bar plot with scenarios AD->ALS and ALS->AD on x-axis and AUC on y-axis, colored by feature_set.

Judge sentence:
- Transportability is the strongest stress test here because it asks if a model learned in one disease still works in a different disease context.

## 3) pooled_panel_vs_baselines.csv
File path: phase2_validation_framework/outputs/model_comparison/ml/pooled_panel_vs_baselines.csv

What this file means:
- This table contains fold-level pooled CV comparisons between:
  - fixed_panel
  - top_de_baseline
  - random_genes_baseline
- It is a direct fairness check against common alternatives.

Result pattern that supports the hypothesis:
- fixed_panel has better mean AUC/F1 than both baselines across folds.
- fixed_panel performance is not dependent on a single lucky fold.

Result pattern that weakens the hypothesis:
- top_de_baseline or random baseline matches or exceeds fixed_panel consistently.
- fixed_panel is unstable with high fold-to-fold volatility.

Recommended figure:
- Boxplots of AUC by feature_set using fold-level results.

Judge sentence:
- Baseline comparison tells us whether our selected panel is genuinely informative or just equivalent to generic gene subsets.

## 4) panel_vs_baselines_summary.csv
File path: phase2_validation_framework/outputs/framework/cross_disease_framework/panel_vs_baselines_summary.csv

What this file means:
- This is the concise roll-up table combining pooled CV and cross-disease transportability into scenario-level averages by feature_set.
- It is the final head-to-head performance summary across all evaluated settings.

Result pattern that supports the hypothesis:
- fixed_panel ranks first or near-first across scenarios, especially in cross-disease transportability.
- random baseline remains clearly lower than fixed_panel.

Result pattern that weakens the hypothesis:
- fixed_panel advantage disappears in the summary table.
- Baselines repeatedly outperform fixed_panel in both pooled and transport settings.

Recommended figure:
- Faceted bar chart (one facet per scenario) showing AUC for each feature_set.

Judge sentence:
- This summary is the decision table that shows whether the biomarker panel remains competitive across internal and cross-disease tests.

## Verification Checks

Top DE baseline selected strictly in training folds only:
- Verified in [pipeline/modules/framework.py](pipeline/modules/framework.py#L181) and [pipeline/modules/framework.py](pipeline/modules/framework.py#L290), where _top_de_features_train_only is called with X_train and y_train only.
- Helper definition is in [pipeline/modules/framework.py](pipeline/modules/framework.py#L60).

Random gene baselines reproducible with fixed seeds:
- Verified in [pipeline/modules/framework.py](pipeline/modules/framework.py#L155) and [pipeline/modules/framework.py](pipeline/modules/framework.py#L235), where np.random.default_rng(seed) is used.
- CV randomization also uses fixed random_state in [pipeline/modules/framework.py](pipeline/modules/framework.py#L156).

Transportability keeps diseases separated correctly:
- Verified in [pipeline/modules/framework.py](pipeline/modules/framework.py#L241), [pipeline/modules/framework.py](pipeline/modules/framework.py#L243), and [pipeline/modules/framework.py](pipeline/modules/framework.py#L244).
- The code explicitly defines AD->ALS and ALS->AD pairs and builds separate train/test sets by disease label.
