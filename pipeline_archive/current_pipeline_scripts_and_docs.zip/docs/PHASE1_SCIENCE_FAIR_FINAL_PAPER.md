# Phase 1 Final Science Fair Paper
## Transcriptome-Scale Discovery of Candidate ncRNA Biomarkers in Neurodegeneration

**Author:** Austin Bautista  
**Project:** ncRNA Neurodegeneration Pipeline  
**Stage:** Phase 1 (Discovery and Candidate Selection)  
**Date:** March 2026

---

## Abstract
Neurodegenerative diseases such as Alzheimer's disease (AD) and amyotrophic lateral sclerosis (ALS) remain difficult to diagnose early with high confidence. Non-coding RNAs (ncRNAs) are promising biomarker candidates because they participate in transcriptional regulation, inflammatory signaling, synaptic maintenance, and stress-response pathways. The goal of Phase 1 of this project was to perform transcriptome-wide discovery and rank ncRNA biomarker candidates using reproducible statistical analysis.

Phase 1 implemented a differential expression workflow with normalization, Welch two-sample testing, and Benjamini-Hochberg false discovery rate (FDR) correction, then aggregated candidate consistency across datasets. Based on the archived Phase 1 biomarker outputs (`biomarker_results/`), 3 datasets were analyzed in the run documented on 2026-02-16, yielding 21,666 total biomarker entries and 7,222 unique biomarker identifiers after aggregation. In that run, 7,222 biomarkers appeared in at least 2 datasets and 7,222 appeared in at least 3 datasets. The top-ranked candidates included ENSG00000204389, ENSG00000206585, ENSG00000175426, ENSG00000117600, and ENSG00000285505, each with cross-dataset consistency in the analyzed cohort set.

Phase 1 successfully delivered a ranked candidate space for downstream fixed-panel validation (Phase 2), demonstrating a complete discovery pipeline from transcriptome-level screening to prioritized biomarker shortlist generation.

---

## 1. Introduction
Neurodegenerative diseases present major biological and clinical challenges due to progressive neuronal loss, overlapping phenotypes, and limited molecular markers for early detection. While protein-coding biomarkers are widely studied, ncRNAs (including lncRNAs, miRNAs, snoRNAs, and related classes) provide additional mechanistic information and may better capture regulatory disruption in disease states.

This project was structured as a two-stage pipeline:
- **Phase 1:** Discovery and candidate selection (transcriptome-wide)
- **Phase 2:** Fixed-panel validation and robustness testing (downstream of discovery)

This paper documents **Phase 1 only**, which focuses on broad candidate discovery and ranking, not final clinical claims.

---

## 2. Research Question and Objectives
### 2.1 Research Question
Can transcriptome-scale ncRNA differential expression analysis identify a reproducible set of candidate biomarkers for neurodegenerative disease phenotypes?

### 2.2 Objectives
1. Perform transcriptome-wide differential expression analysis on disease vs control RNA-seq datasets.
2. Correct for multiple hypothesis testing to control false discoveries.
3. Aggregate significant ncRNAs across datasets and rank candidates by cross-dataset consistency and effect characteristics.
4. Produce reproducible outputs suitable for science fair presentation and downstream validation.

---

## 3. Methods
### 3.1 Pipeline Overview
Phase 1 discovery included:
1. Data loading (counts matrix + metadata)
2. Group harmonization (disease/control labeling)
3. Expression normalization
4. Differential expression testing
5. FDR correction
6. Cross-dataset biomarker aggregation and ranking
7. Report and figure generation

### 3.2 Statistical Testing
Welch's t-test (unequal variance) was used at the gene/transcript level for disease vs control contrasts:

\[
 t = \frac{\bar{x}_{disease} - \bar{x}_{control}}{\sqrt{s_{disease}^2/n_{disease} + s_{control}^2/n_{control}}}
\]

This choice is robust for heterogeneous variance structures often seen in ncRNA expression.

### 3.3 Multiple Testing Correction
Because transcriptome-scale testing evaluates thousands of features, Benjamini-Hochberg FDR correction was used to control expected false discovery proportion.

### 3.4 Candidate Ranking
Candidate ranking (from project reporting outputs) incorporated:
- number of dataset appearances
- average log2 fold-change magnitude
- minimum FDR
- direction consistency
- disease/species breadth in the configured analysis

### 3.5 Reproducibility
All primary Phase 1 outputs referenced in this paper were taken from:
- `biomarker_results/biomarker_report.txt`
- `biomarker_results/PRESENTATION_SUMMARY.txt`
- `biomarker_results/top_candidates.csv`

---

## 4. Results
### 4.1 Run-Level Summary (Archived Phase 1 Output)
From `PRESENTATION_SUMMARY.txt` (analysis date: 2026-02-16):
- Datasets analyzed: **3**
- Total biomarker entries found: **21,666**
- Biomarkers in 2+ datasets: **7,222**
- Biomarkers in 3+ datasets: **7,222**

From `biomarker_report.txt`:
- Total unique biomarkers identified: **7,222**
- Biomarkers in 4+ datasets: **0**
- Biomarkers targeting 2+ diseases: **0** (in the documented run)
- Biomarkers targeting 2+ species: **0** (in the documented run)

### 4.2 Top Candidate Biomarkers
Top ranked candidates in the archived report included:
1. ENSG00000204389 (Biomarker score: 50.50; avg log2FC: 2.756; best FDR: 1.45e-03)
2. ENSG00000206585 (49.47; -2.256; 4.52e-03)
3. ENSG00000175426 (48.93; -1.977; 1.98e-03)
4. ENSG00000117600 (48.83; -1.920; 6.58e-04)
5. ENSG00000285505 (48.49; 1.997; 5.00e-02)

All five appeared in 3 datasets in the archived run and had 100% direction consistency in the provided summary.

### 4.3 Disease and Species Breadth in This Run
The archived Phase 1 biomarker summary for this run primarily reflected a human AD dataset configuration. Cross-disease and cross-species generalization was therefore not established at discovery stage in this specific result set.

---

## 5. Discussion
Phase 1 achieved its intended objective: generating a ranked candidate space from transcriptome-scale ncRNA discovery. The statistical workflow (Welch testing + FDR correction) was appropriate for high-dimensional expression screening and produced a sizable, ordered list of candidate ncRNAs.

A key strength of the workflow is reproducible automation: discovery is structured, re-runnable, and transparent in both code and output artifacts. This is important in science fair contexts because it demonstrates not only biological insight but also computational rigor.

At the same time, discovery-stage significance is not equivalent to clinical utility. Candidate lists from transcriptome-wide scans require strict external validation, transportability testing, and robustness stress tests before interpretation as practical biomarkers. That downstream function is handled in Phase 2.

---

## 6. Limitations
1. The documented archived run reflects a narrow cohort composition (primarily AD/human context), limiting immediate cross-disease claims at Phase 1.
2. Differential expression ranking can be influenced by cohort-specific preprocessing and metadata heterogeneity.
3. Discovery-stage outputs are sensitive to sample composition and should not be treated as final diagnostic signatures without external validation.
4. Candidate identifiers are reported as ENSG IDs in these artifacts; biological naming/annotation harmonization for final interpretation requires additional mapping steps.

---

## 7. Conclusion
Phase 1 of this project successfully produced a full ncRNA biomarker discovery workflow from raw expression comparison to ranked candidate outputs. The analysis identified thousands of candidate ncRNAs and prioritized top biomarkers with strong within-run consistency metrics. These results establish a credible discovery foundation and justify progression to fixed-panel, leakage-safe validation in Phase 2.

In summary, Phase 1 answered the discovery question: it generated a reproducible and statistically filtered candidate biomarker landscape suitable for rigorous downstream validation.

---

## 8. Future Work
1. Expand discovery-stage dataset diversity (additional species and neurodegenerative phenotypes).
2. Improve annotation harmonization from ENSG IDs to stable ncRNA names and biotypes.
3. Integrate batch-aware sensitivity analyses during discovery.
4. Couple Phase 1 ranking outputs with Phase 2 transportability metrics for end-to-end prioritization.

---

## 9. References
1. Benjamini Y, Hochberg Y. Controlling the False Discovery Rate: A Practical and Powerful Approach to Multiple Testing. *Journal of the Royal Statistical Society B*. 1995.
2. Love MI, Huber W, Anders S. Moderated estimation of fold change and dispersion for RNA-seq data with DESeq2. *Genome Biology*. 2014.
3. Ritchie ME, et al. limma powers differential expression analyses for RNA-sequencing and microarray studies. *Nucleic Acids Research*. 2015.
4. Project repository documentation:
 - `README.md`
 - `docs/legacy_root/DE_ANALYSIS_GUIDE.md`
 - `docs/legacy_root/FOR_JUDGES.md`
 - `biomarker_results/biomarker_report.txt`
 - `biomarker_results/PRESENTATION_SUMMARY.txt`
 - `biomarker_results/top_candidates.csv`

---

## Appendix A: Dataset Role Note
Repository phase-separation documentation lists discovery-only datasets for Phase 1 and external-validation-only datasets for Phase 2. The archived biomarker report summarized here corresponds to the configured discovery run captured in `biomarker_results/` and is reported exactly as recorded in those artifacts.
