# Phase 2 AD External Validation Dataset Selection (2026-03-18)

## Selection Gate
Replacement AD external validation datasets must satisfy:
1. RNA-seq with gene-level counts or TPM.
2. Contains non-coding RNAs (lncRNA-compatible panel check).
3. Uses Ensembl IDs or gene symbols compatible with harmonization.
4. Includes both disease and control samples.
5. Sample size >= 50 when possible.
6. Fixed-panel inclusion gate: at least 3/5 panel genes present.

Fixed panel: MEG9, ZMIZ1-AS1, SLC12A5-AS1, GUSBP1, STRCP1.

## Pre-Inclusion Gate Check
- GSE48350
  - Counts: data/neurodegenerative_diseases/alzheimers/GSE48350/counts_ensembl.tsv
  - Metadata: data/neurodegenerative_diseases/alzheimers/GSE48350/metadata_disease.csv
  - Sample sizes: 33 disease, 140 control (n=173)
  - Panel present: 3/5 (MEG9, ZMIZ1-AS1, GUSBP1)
  - Decision: INCLUDE

- GSE33000
  - Counts: data/neurodegenerative_diseases/alzheimers/GSE33000/counts_ensembl.tsv
  - Metadata: data/neurodegenerative_diseases/alzheimers/GSE33000/metadata_disease.csv
  - Sample sizes: 301 disease, 301 control (n=602)
  - Panel present: 0/5
  - Decision: EXCLUDE

## Phase 2 Config Update
Both configs were updated to use GSE48350 as AD external validation and keep GSE33000 excluded:
- config/examples/phase2_validation_config.yaml
- config/examples/phase2_validation_config_fast.yaml
