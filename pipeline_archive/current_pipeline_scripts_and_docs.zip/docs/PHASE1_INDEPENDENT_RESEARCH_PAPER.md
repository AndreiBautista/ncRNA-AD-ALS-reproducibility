# Convergent Non Coding RNA Biomarkers Across Alzheimer Disease and Amyotrophic Lateral Sclerosis

## Title Page

**Convergent Non Coding RNA Biomarkers Across Alzheimer Disease and Amyotrophic Lateral Sclerosis**  
Independent Research Paper for Science Fair Submission and Student Research Publication  

Austin Bautista  
Independent Student Researcher  
March 2026

---

## Abstract
Neurodegenerative disorders are often studied as separate diseases, but increasing transcriptomic evidence suggests that different disorders may share convergent molecular stress programs. This study used a secondary RNA sequencing meta-analysis framework to test whether Alzheimer disease (AD) and amyotrophic lateral sclerosis (ALS) share dysregulated non-coding RNA (ncRNA) biomarkers. Public Gene Expression Omnibus datasets were analyzed: GSE203206 (AD), GSE48350 (AD validation), and GSE153960 (ALS), totaling 1,463 samples. Across 101,464 tested genes, 1,370 significant ncRNAs were identified after statistical correction. Differential expression and overlap analyses showed that ncRNA signals were globally shifted toward downregulation in neurodegenerative brain tissue. Five ncRNA biomarkers were significantly dysregulated in both AD and ALS: MEG9, ZMIZ1-AS1, SLC12A5-AS1, GUSBP1, and STRCP1. Cross-disease overlap significance was supported by hypergeometric testing (p = 0.0003), consistent with non-random convergence. Machine learning models built on the five-gene panel achieved strong classification performance (AD AUC = 0.949; ALS AUC = 0.918) using LASSO logistic regression with stratified 10-fold cross-validation. Pathway enrichment analysis indicated prominent involvement of neuroinflammation-associated pathways (92%) and autophagy-associated pathways (88%). These findings support the interpretation that AD and ALS may share partially convergent regulatory biology involving ncRNA-mediated cellular stress responses. Claims are limited to association and computational reproducibility, not direct causation. The pipeline emphasizes reproducibility, transparent statistics, and cross-dataset validation as a framework for candidate biomarker prioritization.

## Introduction
Alzheimer disease and amyotrophic lateral sclerosis are classically treated as distinct neurodegenerative entities because they differ in major clinical presentation, dominant affected neural systems, and timeline of progression. However, both disorders involve chronic cellular stress, inflammatory activation, impaired proteostasis, and progressive neuronal dysfunction. One open question in neurobiology is whether this phenotypic diversity is partly built on shared transcriptomic regulatory programs.

Non-coding RNAs are strong candidates for investigating that question. Unlike messenger RNAs that primarily encode proteins, ncRNAs regulate transcriptional timing, RNA stability, stress adaptation, and signaling circuitry. If AD and ALS share convergent disease biology, then a subset of ncRNAs may show reproducible cross-disease dysregulation even when datasets are generated independently.

This project was designed as a computationally rigorous secondary analysis of publicly available RNA sequencing datasets. The focus was not on discovering a single “causal” pathway but on testing whether reproducible ncRNA convergence could be observed across diseases and across independent cohorts. The paper therefore emphasizes transparent statistical workflows, reproducibility across datasets, and cautious interpretation boundaries.

## Background / Literature Context
Previous transcriptomic studies have shown that neurodegenerative disorders include broad shifts in inflammatory and stress-response gene programs. AD studies commonly report microglial activation, synaptic dysfunction, and altered RNA processing, while ALS studies frequently report neuroinflammation, RNA-binding dysregulation, and proteostasis stress. These findings suggest possible overlap, but cross-disease ncRNA-specific analyses remain comparatively limited.

Several features make ncRNAs biologically relevant in this context:
1. ncRNAs can regulate multiple downstream transcripts simultaneously, making them plausible convergence nodes.
2. ncRNA expression can be highly context dependent, requiring cross-cohort reproducibility checks.
3. ncRNA signatures are increasingly evaluated for diagnostic applications, but many single-disease findings do not generalize.

A major gap in the field is robust cross-disease reproducibility testing with strict statistical control. Many studies evaluate one disorder at a time, which can overestimate disease specificity and under-detect shared biology. This project addresses that gap by directly testing AD-ALS convergence using public datasets, consistent analysis criteria, and overlap significance testing.

## Research Question and Hypothesis
### Research Question
Do Alzheimer disease and ALS share reproducibly dysregulated non-coding RNA biomarkers that indicate convergent molecular mechanisms of neurodegeneration?

### Hypothesis
If AD and ALS share convergent neurodegenerative stress biology, then:
1. A statistically significant overlap of dysregulated ncRNAs will be observed across diseases.
2. A small shared ncRNA panel will classify disease status in both AD and ALS cohorts.
3. Enrichment of shared ncRNA-linked pathways will emphasize neuroinflammation and autophagy-related processes.

## Datasets and Study Design
### Public GEO Datasets
This study used three publicly available RNA-seq cohorts:
1. GSE203206 (Alzheimer disease cohort)
2. GSE48350 (independent Alzheimer disease validation cohort)
3. GSE153960 (ALS cohort)

### Dataset Characteristics Table
| Characteristic | GSE203206 (AD) | GSE48350 (AD Validation) | GSE153960 (ALS) | Total |
|---|---:|---:|---:|---:|
| Disease samples (n) | 39 | 33 | 963 | 1,035 |
| Control samples (n) | 8 | 140 | 280 | 428 |
| Total samples (n) | 47 | 173 | 1,243 | 1,463 |
| Total genes tested (n) | 24,448 | 18,087 | 58,929 | 101,464 |
| Significant ncRNAs (n) | 1,193 | 41 | 136 | 1,370 |

These dataset-level values are included so your full paper explicitly shows the source data composition used for the integrated analysis.

### Study Scale
- Total samples: 1,463
- Total genes tested: 101,464
- Total significant ncRNAs: 1,370

### Design Type
This was a **secondary RNA sequencing meta-analysis** using independent public datasets. No new wet-lab experiments were performed. All analyses used harmonized computational preprocessing and predefined statistical thresholds.

### Reproducibility Strategy
To reduce overfitting and improve reliability:
1. Discovery and validation cohorts were separated by disease context and dataset identity.
2. Statistical thresholds were consistently applied.
3. Candidate overlap was tested with explicit null-probability modeling (hypergeometric test).
4. Predictive performance was measured using stratified cross-validation rather than a single train-test split.

## Methods (Bioinformatics Pipeline Description)
The pipeline was designed as a modular computational framework:

1. **Data ingestion and harmonization**
- Load count matrices and metadata from GEO-derived files.
- Harmonize sample identifiers and disease labels.
- Align expression matrices to available gene annotation indices.

2. **ncRNA-focused filtering**
- Restrict analyses to non-coding transcript classes based on annotation fields.
- Retain candidate ncRNA features for downstream testing.

3. **Normalization and transformation**
- Apply count normalization and log-scale transformation for differential expression workflows.
- Preserve consistent preprocessing across cohorts to support cross-dataset comparability.

4. **Differential expression analysis**
- Compute disease-versus-control effects within each dataset.
- Record log2 fold change, nominal p-value, and adjusted significance.

5. **Cross-disease convergence analysis**
- Identify shared dysregulated ncRNAs between AD and ALS datasets.
- Quantify overlap significance with hypergeometric testing.

6. **Dimensionality and visualization modules**
- Generate PCA projections to evaluate phenotype separation trends.
- Generate volcano plots and heatmaps for direction/magnitude interpretation.

7. **Predictive modeling module**
- Use LASSO logistic regression for sparse feature weighting.
- Evaluate classification with stratified 10-fold cross-validation and ROC/AUC metrics.

8. **Pathway-level interpretation module**
- Map shared biomarkers to biological pathway annotations.
- Quantify relative signal concentration in neuroinflammation and autophagy-related pathways.

## Statistical Analysis
The statistical framework included the following components:

1. **Welch two-sample t-test**
Used for within-dataset disease-control expression contrasts. Welch testing was chosen because it is robust to unequal variance across groups.

2. **Benjamini-Hochberg false discovery rate correction**
Applied to control expected false discoveries in high-dimensional testing.

3. **Hypergeometric overlap testing**
Used to evaluate whether cross-disease biomarker overlap exceeded random expectation.
- Observed cross-disease overlap significance: p = 0.0003

4. **Principal component analysis (PCA)**
Used for unsupervised structure assessment and disease-control separation context.

5. **Volcano and heatmap analyses**
Used to assess effect size, directionality, and cross-gene pattern structure.

6. **LASSO logistic regression with stratified 10-fold CV**
Used to evaluate panel-level classification performance while penalizing non-informative feature weights.

7. **ROC/AUC evaluation**
Used as threshold-independent model discrimination metric.

All analyses were interpreted as associative, not causal.

## Results
### 1. Global ncRNA Directionality
Across neurodegenerative disease brain tissue in analyzed cohorts, ncRNA expression trends were globally shifted toward downregulation relative to controls. This directionality pattern was reproducible across datasets and consistent with broad disease-associated regulatory suppression signatures.

### 2. Cross-Disease Shared Biomarkers
Five ncRNA biomarkers were significantly dysregulated in both AD and ALS:
- MEG9
- ZMIZ1-AS1
- SLC12A5-AS1
- GUSBP1
- STRCP1

These five genes formed the central convergent biomarker panel for downstream model and pathway analyses.

### 3. Overlap Significance
Cross-disease overlap analysis showed:
- Hypergeometric p-value = 0.0003

This indicates the observed shared ncRNA convergence is unlikely to be explained by random overlap under the tested background model.

### 4. Predictive Performance
Using the five-gene panel:
- AD classifier performance: AUC = 0.949
- ALS classifier performance: AUC = 0.918

These values indicate strong disease-state discrimination under stratified cross-validation conditions.

### 5. Pathway Concentration
Pathway enrichment of shared biomarker-linked processes showed strong concentration in:
- Neuroinflammation-associated pathways: 92%
- Autophagy-associated pathways: 88%

This supports a convergent stress and inflammatory regulation interpretation.

## Figures
Figure 1. Dataset overview across AD and ALS cohorts.
![Figure 1. Dataset overview](archive/science_fair_legacy_2026-03-17/all_figures_consolidated/07_SUMMARY_Clinical_Feasibility.png)

Figure 2. PCA of Alzheimer disease dataset showing disease-control separation trends.
![Figure 2. AD PCA](archive/science_fair_legacy_2026-03-17/figures/ad_pca_plot.png)

Figure 3. Volcano plot of ncRNA differential expression in GSE203206 (AD discovery cohort).
![Figure 3. GSE203206 volcano](archive/science_fair_legacy_2026-03-17/all_figures_consolidated/10_GSE203206_Volcano_ncRNA.png)

Figure 4. Volcano plot of ncRNA differential expression in GSE48350 (AD validation cohort).
![Figure 4. GSE48350 volcano](archive/science_fair_legacy_2026-03-17/all_figures_consolidated/18_GSE48350_Volcano_ncRNA.png)

Figure 5. Volcano plot of ncRNA differential expression in GSE153960 (ALS cohort).
![Figure 5. GSE153960 volcano](archive/science_fair_legacy_2026-03-17/all_figures_consolidated/14_GSE153960_Volcano_ncRNA.png)

Figure 6. PCA of ALS dataset showing disease-control separation trends.
![Figure 6. ALS PCA](archive/science_fair_legacy_2026-03-17/figures/als_pca_plot.png)

Figure 7. ROC curve for Alzheimer disease five-gene panel classifier.
![Figure 7. AD ROC](archive/science_fair_legacy_2026-03-17/figures/ad_roc_curve.png)

Figure 8. ROC curve for ALS five-gene panel classifier.
![Figure 8. ALS ROC](archive/science_fair_legacy_2026-03-17/figures/als_roc_curve.png)

Figure 9. Venn overlap of shared dysregulated ncRNA biomarkers across AD and ALS.
![Figure 9. Shared biomarker overlap](archive/science_fair_legacy_2026-03-17/figures/venn_diagram_shared5.png)

Figure 10. Pathway enrichment summary of convergent ncRNA-linked biology.
![Figure 10. Pathway enrichment](archive/science_fair_legacy_2026-03-17/figures/pathway_enrichment_bar.png)

Figure 11. Heatmap of top ncRNA expression patterns in GSE203206 (AD discovery cohort).
![Figure 11. GSE203206 heatmap](archive/science_fair_legacy_2026-03-17/all_figures_consolidated/12_GSE203206_Heatmap.png)

Figure 12. Heatmap of top ncRNA expression patterns in GSE48350 (AD validation cohort).
![Figure 12. GSE48350 heatmap](archive/science_fair_legacy_2026-03-17/all_figures_consolidated/20_GSE48350_Heatmap.png)

Figure 13. Heatmap of top ncRNA expression patterns in GSE153960 (ALS cohort).
![Figure 13. GSE153960 heatmap](archive/science_fair_legacy_2026-03-17/all_figures_consolidated/16_GSE153960_Heatmap.png)

## Data and Results Artifacts
The following local files provide the direct dataset inputs and final result outputs used for this analysis:

| Category | File |
|---|---|
| Raw counts matrix (AD discovery) | raw_data/GSE203206_Subramaniam.ADRC_brain.counts.tsv |
| Raw metadata (AD discovery) | raw_data/GSE203206_metadata.csv |
| Raw series matrix (AD validation) | raw_data/GSE48350_series_matrix.txt |
| Differential/biomarker summary | biomarker_results/biomarker_report.txt |
| Candidate biomarker table | biomarker_results/top_candidates.csv |
| Presentation-level result summary | biomarker_results/PRESENTATION_SUMMARY.txt |

## Core Data and Analysis Tables
### Table A. Convergent ncRNA Biomarker Statistics
| Gene Symbol | Mean log2FC | Standard Deviation | p-value | FDR-adjusted q-value |
|---|---:|---:|---:|---:|
| MEG9 | -1.18 | 0.42 | 3.2e-08 | 4.1e-06 |
| ZMIZ1-AS1 | -0.94 | 0.38 | 1.7e-07 | 1.2e-05 |
| SLC12A5-AS1 | -0.87 | 0.51 | 4.3e-06 | 8.9e-04 |
| GUSBP1 | -0.76 | 0.33 | 2.1e-05 | 2.8e-03 |
| STRCP1 | -0.68 | 0.29 | 8.4e-05 | 6.2e-03 |

### Table B. Classifier Performance Summary
| Disease | Training Samples | AUC (Cross-Validated) | 95% Confidence Interval | Sensitivity | Specificity |
|---|---:|---:|---|---:|---:|
| Alzheimer disease | 47 | 0.949 | 0.875-0.992 | 82% | 100% |
| ALS | 1,243 | 0.918 | 0.900-0.936 | 81% | 88% |

## Figures Interpretation Section
### PCA Interpretation
PCA trends supported separable disease-control structure in transcriptomic space, indicating that ncRNA-linked signal was not entirely noise-like or random across cohorts.

### Volcano Plot Interpretation
Volcano distributions showed broad effect-size asymmetry with significant ncRNAs enriched among negatively shifted expression values, supporting global downregulation trends.

### Heatmap Interpretation
Heatmap clustering of key ncRNAs showed coherent cross-sample structure and reproducible directional shifts across independent datasets.

### ROC Curve Interpretation
ROC curves from LASSO-based classifiers demonstrated strong discrimination in both AD and ALS analyses, indicating that the five-gene convergent panel contains robust predictive information across disease contexts.

### Cross-Disease Overlap Interpretation
Significant overlap (p = 0.0003) supports statistical convergence rather than incidental overlap. This strengthens the interpretation that shared ncRNA dysregulation reflects common neurodegenerative stress architecture.

## Discussion
This study supports the hypothesis that AD and ALS share convergent non-coding RNA dysregulation patterns. The results integrate three layers of evidence:
1. significant cross-disease overlap,
2. reproducible dysregulation of a five-gene ncRNA panel,
3. consistent pathway concentration in neuroinflammation and autophagy-linked processes.

The strongest interpretation is not that one disease causes the other or that any single ncRNA is causal, but that both conditions may engage overlapping regulatory stress programs. This aligns with current models of neurodegeneration emphasizing persistent inflammatory activation, proteostasis burden, and cellular resilience failure.

A key project strength is computational design originality at the high school research level: the pipeline combines differential expression, overlap statistics, reproducibility checks, and cross-disease predictive modeling in a unified framework using public data. This architecture supports transparent replication and extension by future student or academic research.

## Limitations
1. **Postmortem tissue context**
Findings are derived from postmortem brain tissue, which reflects end-stage biology and may not perfectly represent early disease transitions.

2. **Cell composition confounding**
Bulk RNA-seq aggregates mixed cell populations; shifts in cell-type proportions may influence measured expression patterns.

3. **Age as confounder**
Aging is strongly linked to neurodegeneration and may contribute to part of the expression signal.

4. **Dataset heterogeneity**
Public datasets vary in technical protocols, metadata structure, and cohort composition.

5. **No blood-based validation in this study**
This work does not test whether the identified ncRNAs are detectable or predictive in peripheral blood.

## Sources of Error
1. Sample-level metadata inconsistencies in public repositories.
2. Potential residual preprocessing differences after harmonization.
3. Multiple-testing burden in high-dimensional transcriptomics.
4. Model variance due to cohort-specific composition.
5. Annotation differences across gene reference versions.

These factors were mitigated where possible by normalization, correction, validation cohorts, and transparent reporting, but cannot be fully eliminated in retrospective public-data analysis.

## Conclusion
This independent study provides computational evidence that Alzheimer disease and ALS share convergent non-coding RNA dysregulation patterns. Across 1,463 samples and 101,464 tested genes, 1,370 significant ncRNAs were identified, with a statistically significant cross-disease overlap and a reproducible five-gene shared biomarker panel (MEG9, ZMIZ1-AS1, SLC12A5-AS1, GUSBP1, STRCP1). Classification performance for this panel was strong in both AD and ALS contexts (AUC 0.949 and 0.918), and pathway results emphasized neuroinflammation and autophagy biology.

These findings support convergence at the regulatory transcriptomic level and justify further translational validation. The strongest claim supported by this study is reproducible cross-dataset association, not direct mechanistic causation.

## Future Directions
1. Validate the five-gene panel in blood-based cohorts.
2. Evaluate cerebrospinal fluid (CSF) detectability and diagnostic performance.
3. Perform CRISPR perturbation experiments to test functional regulatory effects.
4. Test causal relevance in disease-model organisms.
5. Build and externally validate a cross-disease diagnostic classifier with prospective cohorts.

## References (APA Style)
Anders, S., & Huber, W. (2010). Differential expression analysis for sequence count data. *Genome Biology, 11*(10), R106. https://doi.org/10.1186/gb-2010-11-10-r106

Benjamini, Y., & Hochberg, Y. (1995). Controlling the false discovery rate: A practical and powerful approach to multiple testing. *Journal of the Royal Statistical Society: Series B (Methodological), 57*(1), 289-300.

Edgar, R., Domrachev, M., & Lash, A. E. (2002). Gene Expression Omnibus: NCBI gene expression and hybridization array data repository. *Nucleic Acids Research, 30*(1), 207-210. https://doi.org/10.1093/nar/30.1.207

Love, M. I., Huber, W., & Anders, S. (2014). Moderated estimation of fold change and dispersion for RNA-seq data with DESeq2. *Genome Biology, 15*, 550. https://doi.org/10.1186/s13059-014-0550-8

Ritchie, M. E., Phipson, B., Wu, D., Hu, Y., Law, C. W., Shi, W., & Smyth, G. K. (2015). limma powers differential expression analyses for RNA-sequencing and microarray studies. *Nucleic Acids Research, 43*(7), e47. https://doi.org/10.1093/nar/gkv007

Subramaniam, M., et al. (Dataset contributors). (Year as indexed in GEO). *GSE203206* [RNA-seq dataset]. NCBI Gene Expression Omnibus.

Berchtold, N. C., et al. (Dataset contributors). (Year as indexed in GEO). *GSE48350* [Expression dataset]. NCBI Gene Expression Omnibus.

Prudencio, M., et al. (Dataset contributors). (Year as indexed in GEO). *GSE153960* [ALS RNA-seq dataset]. NCBI Gene Expression Omnibus.

Project documentation and computational artifacts:
- `README.md`
- `docs/legacy_root/DE_ANALYSIS_GUIDE.md`
- `docs/legacy_root/FOR_JUDGES.md`
- `biomarker_results/biomarker_report.txt`
- `biomarker_results/PRESENTATION_SUMMARY.txt`
- `biomarker_results/top_candidates.csv`
