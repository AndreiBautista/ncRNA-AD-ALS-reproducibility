# GSE33000 - Visualization Fix Guide

## Problem

When running the pipeline on GSE33000 (a very large dataset with ~50K genes), the visualizations (volcano plot and heatmap) **may not generate** because:

1. **Heatmap clustering** on 50K genes × 19 samples is computationally intensive
2. **Memory usage** spikes during dendrogram calculation
3. **Process hangs** or becomes unresponsive

## Solution

Your **differential expression results ARE generated** and saved as:

```
results/GSE33000_analysis/per_dataset/local_differential_results.csv
```

This CSV file contains everything you need:
- **gene_id**: Gene identifier 
- **log2FC**: Log2 fold-change (disease vs control)
- **pvalue**: Raw p-value from t-test
- **fdr**: FDR-corrected p-value
- **significant**: Boolean (TRUE if FDR < 0.05)
- **gene_name**: Gene name
- **biotype**: Gene type

## How to Use the Results

### 1. View Top Genes

```bash
cd /Users/austinbautista/ncrna_pipeline

# Show top 20 significant genes (sorted by FDR)
head -21 results/GSE33000_analysis/per_dataset/local_differential_results.csv | cut -d, -f1-5

# Count total significant genes
awk -F',' '$7=="True"' results/GSE33000_analysis/per_dataset/local_differential_results.csv | wc -l
```

### 2. Create Your Own Plots

#### Option A: Subset Genes and Regenerate Plots

```bash
# Extract top 200 most significant genes
/Users/austinbautista/ncrna_pipeline/.venv/bin/python << 'PYTHON'
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

# Load results
df = pd.read_csv('results/GSE33000_analysis/per_dataset/local_differential_results.csv', index_col=0)

# Filter to top 200 genes by FDR
top200 = df.nsmallest(200, 'fdr')

# Create volcano plot
fig, ax = plt.subplots(figsize=(8, 6))
top200['negLog10FDR'] = -np.log10(top200['fdr'].replace(0, 1e-300))
colors = ['red' if x else 'lightgrey' for x in top200['significant']]
ax.scatter(top200['log2FC'], top200['negLog10FDR'], c=colors, alpha=0.6, s=20)
ax.axhline(-np.log10(0.05), color='black', linestyle='--', linewidth=0.7)
ax.set_xlabel('log2 fold-change')
ax.set_ylabel('-log10(FDR)')
ax.set_title('Volcano Plot - Top 200 Genes')
plt.tight_layout()
plt.savefig('volcano_plot_top200.png', dpi=300)
print('✓ Saved: volcano_plot_top200.png')

PYTHON
```

#### Option B: Excel/Spreadsheet Analysis

```bash
# The CSV is ready-to-use in Excel/Numbers/Google Sheets
open results/GSE33000_analysis/per_dataset/local_differential_results.csv
```

Then in your spreadsheet:
- Sort by **fdr** column (ascending) to see most significant
- Filter by **significant == TRUE** to see only significant genes
- Sort by **log2FC** (descending) to see most upregulated
- Create your own plots

#### Option C: Use R or Python for Custom Plots

```r
# R example
library(ggplot2)
df <- read.csv('results/GSE33000_analysis/per_dataset/local_differential_results.csv')
ggplot(df, aes(x=log2FC, y=-log10(fdr), color=significant)) +
 geom_point() +
 theme_minimal()
ggsave('volcano.pdf', width=8, height=6)
```

## If You Really Need the Heatmap

For smaller subsets only:

```bash
/Users/austinbautista/ncrna_pipeline/.venv/bin/python << 'PYTHON'
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import seaborn as sns
import matplotlib.pyplot as plt

# Load gene expression data
from pipeline import io
logcpm = io.load_counts('GSE33000_counts.txt') # Takes ~1 min to load
logcpm = pd.DataFrame(
 np.log2(logcpm.divide(logcpm.sum(axis=0), axis=1) * 1e6 + 1),
 index=logcpm.index, columns=logcpm.columns
)

# Load top genes
results_df = pd.read_csv('results/GSE33000_analysis/per_dataset/local_differential_results.csv', index_col=0)
top_genes = results_df.nsmallest(30, 'fdr').index.tolist() # Top 30 only

# Subset data
subset = logcpm.loc[logcpm.index.intersection(top_genes)]

# Create heatmap
g = sns.clustermap(subset, figsize=(10, 8), cmap='RdBu_r', center=0)
plt.savefig('heatmap_top30.png', dpi=300, bbox_inches='tight')
print('✓ Saved: heatmap_top30.png (this may take 2-5 minutes)')

PYTHON
```

##Summary

**Your analysis IS complete.** The CSV file contains all the statistical results. The visualizations are optional - you can:
- View the CSV directly
- Create custom plots in Excel
- Use R/Python to generate publication-quality figures
- Subset to smaller gene lists for faster heatmap generation

**Next steps:**
1. Open `local_differential_results.csv` in Excel
2. Sort/filter to find genes of interest
3. Validate biology with external databases (NCBI, Ensembl)

---

**Questions?** This is a known limitation with very large genomics datasets. Contact your bioinformatics team if you need help interpreting results.
