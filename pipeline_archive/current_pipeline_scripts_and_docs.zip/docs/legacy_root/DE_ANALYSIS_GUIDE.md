# Differential Expression Analysis: ncRNA Pipeline Documentation

## Overview

This pipeline implements state-of-the-art differential expression (DE) analysis for non-coding RNAs from bulk RNA-seq data. Two complementary statistical methods are available:

1. **Welch t-test (Default)** – Fast, robust for various distributions
2. **DESeq2 (Optional)** – Negative binomial GLM, gold-standard for count data

Both methods include:
- Automatic group detection from metadata
- Benjamini-Hochberg FDR correction (controls false discovery rate)
- Publication-quality visualizations (volcano plots, heatmaps)
- Cross-dataset conserved gene analysis

---

## Statistical Methods Explained

### Method 1: Welch t-Test (Default)

**When to use**: Fast screening, small-to-medium sample sizes, exploratory analysis

**Mathematical Foundation**:
- Two-sample t-test with **unequal variances** (Welch's correction)
- Formula: $t = \frac{\bar{x}_1 - \bar{x}_2}{\sqrt{\frac{s_1^2}{n_1} + \frac{s_2^2}{n_2}}}$
- Degrees of freedom adjusted using Welch–Satterthwaite equation
- Test assumes independence between groups; **does not require normality**

**Implementation**:
```python
from scipy.stats import ttest_ind
tstat, pvalue = ttest_ind(disease_samples, control_samples, equal_var=False)
```

**Rationale for ncRNA Study**:
- ncRNAs often have **zero-inflated, non-normal distributions**
- Welch's t-test is robust to non-normality and heteroscedasticity
- Faster than DESeq2: ~1 second for 20,000 genes
- Suitable for exploratory screens and validation

**Assumptions**:
- ✅ Independence between samples ✅ Independence between groups ✅ Continuous data (log2-CPM) ❌ Normally distributed (not required)

---

### Method 2: DESeq2 (Rigorous Analysis)

**When to use**: Publication-ready results, small sample counts, rigorous peer review

**Mathematical Foundation**:

DESeq2 uses a **Negative Binomial Generalized Linear Model**:

$Y_{ij} \sim \text{NB}(\mu_{ij}, \alpha_i)$

Where:
- $Y_{ij}$ = raw count for gene $i$ in sample $j$
- $\mu_{ij}$ = expected count (mean)
- $\alpha_i$ = gene-specific dispersion parameter

**Three-Stage Analysis**:

1. **Normalization (Size Factors)**
 - Accounts for sequencing depth differences
 - Uses median-of-ratios method: $s_j = \text{median}_i \frac{Y_{ij}}{\widetilde{Y_i}}$

2. **Dispersion Estimation**
 - Per-gene dispersion: $\hat{\alpha}_i$ (mean-variance relationship)
 - Shrinkage estimation pools information across genes
 - Handles sparse counts and low N per group

3. **Hypothesis Testing**
 - Wald test: $Z = \frac{\beta}{\text{SE}(\beta)}$ (follows standard normal)
 - Tests $H_0: \beta_\text{disease} = \beta_\text{control}$ (no effect)
 - More sensitive than t-test for multi-group comparisons

**Implementation** (requires rpy2 + R):
```r
# In R:
dds <- DESeqDataSetFromMatrix(countData, colData, design=~group)
dds <- DESeq(dds) # Estimates size factors, dispersions, tests
results <- results(dds, contrast=c("group", "disease", "control"))
```

**Advantages**:
- ✅ Purpose-built for **count data** (not log-normalized)
- ✅ Accounts for mean-variance relationship (fundamental to RNA-seq)
- ✅ Better statistical power with **small sample counts**
- ✅ Shrinkage estimation improves reproducibility
- ✅ Publication-standard method (widely cited)

**Disadvantages**:
- ❌ Requires R ≥ 3.6 + DESeq2 package (complex installation)
- ❌ Slower: ~5-30 seconds for 20,000 genes
- ❌ Less intuitive for exploratory use

---

## Computational Normalization

Both methods use **log₂-CPM normalization** as preprocessing:

$$\text{log₂-CPM} = \log_2\left(\frac{\text{counts} \times 10^6}{\text{library size}} + \text{pseudocount}\right)$$

**Components**:
- **CPM (Counts Per Million)**: Normalizes for sequencing depth
- **log₂**: Stabilizes variance, makes data approximately normal
- **Pseudocount** (default=1): Avoids log(0) for zero-count genes

**Why normalize for Welch, but not DESeq2?**
- Welch t-test assumes continuous, homoscedastic data
- DESeq2 works with **raw counts** (models discrete distribution)
- DESeq2 includes its own depth normalization internally

---

## Multiple Testing Correction

Any genome-wide analysis tests **~20,000 hypotheses simultaneously**. Naive p-values are inflated.

### Benjamini-Hochberg FDR Correction (Default)

**Definition**: False Discovery Rate (FDR) = E[# false positives / # total discoveries]

**Algorithm**:
1. Rank p-values: $p_{(1)} \leq p_{(2)} \leq \cdots \leq p_{(m)}$
2. Find largest $i$ where $p_{(i)} \leq \frac{i}{m} \alpha$
3. Reject all hypotheses 1 through $i$

**Example** (α = 0.05):
- 10,000 genes tested
- 500 genes with raw p < 0.05 (naive count)
- After FDR correction at 0.05: ~200 genes significant
- **Interpretation**: Among 200 discoveries, ≤10 expected to be false

**Comparison**:
- Bonferroni (p < 0.05/20,000 = 2.5e-6): Very conservative, few discoveries
- FDR-BH (adjusted p < 0.05): Balanced sensitivity/specificity
- Uncorrected: ~1,000 false positives expected by chance

---

## Pipeline Usage

### Quick Start: Default (Welch t-test)

```bash
# Minimal parameters (auto-detects groups)
python scripts/run_pipeline.py \
 --counts data/GSE33000_counts.txt \
 --metadata data/GSE33000_metadata.txt \
 --outdir results
```

**What happens**:
1. Loads counts/metadata
2. Auto-detects 'condition' or 'group' column
3. Auto-infers Disease vs Control from sample counts
4. Runs Welch t-test (~1 sec for 20K genes)
5. Saves CSV + publication-ready plots

### Advanced: Explicit Parameters

```bash
python scripts/run_pipeline.py \
 --counts data/counts.txt \
 --metadata data/metadata.txt \
 --group_col treatment_status \
 --disease_label Alzheimer \
 --control_label Healthy \
 --method welch \
 --top_n 100 \
 --outdir results
```

### Rigorous: DESeq2 Analysis

```bash
# First ensure R + DESeq2 installed:
# In R: install.packages("DESeq2")
# In Python: pip install rpy2

python scripts/run_pipeline.py \
 --counts data/counts.txt \
 --metadata data/metadata.txt \
 --raw_counts data/raw_counts.txt \ # Required!
 --method deseq2 \
 --outdir results/deseq2_results
```

---

## Output Interpretation

### Differential Results CSV

**File**: `*_differential_results.csv`

```
gene_id,log2FC,pvalue,fdr,significant,gene_name,biotype
ENSG00000101347,-3.45,1.2e-5,0.0012,True,LINC00174,lncRNA
ENSG00000227232,2.91,4.5e-4,0.0031,True,MIR1234,miRNA
ENSG00000243485,0.45,0.32,0.78,False,snoRNA_XYZ,snoRNA
...
```

**Column Meanings**:
- **log2FC**: Log₂-fold change. Positive = upregulated in disease; negative = downregulated
- **pvalue**: Raw p-value from t-test (or Wald test for DESeq2)
- **fdr**: Adjusted p-value after FDR-BH correction
- **significant**: TRUE if FDR < 0.05
- **gene_name**: Human-readable identifier
- **biotype**: RNA class (lncRNA, miRNA, snoRNA, etc.)

**Sorting**: Results pre-sorted by [fdr, pvalue, |log2FC|] for easy review

### Volcano Plot

- **X-axis**: log₂ fold-change (effect size)
- **Y-axis**: -log₁₀(adjusted p-value) (statistical power)
- **Red points**: Significant (FDR < 0.05)
- **Interpretation**: 
 - Upper-left: Downregulated, significant (strong evidence)
 - Upper-right: Upregulated, significant (strong evidence)
 - Lower regions: Not significant (likely noise)

### Heatmap of Top Genes

- **Each row**: One gene (top 50 by FDR)
- **Each column**: One sample
- **Color**: Z-score normalized expression
- **Hierarchical clustering**: Groups similar genes and samples
- **Interpretation**:
 - If heatmap shows clear disease/control blocks: High biological signal
 - If heatmap is noisy: Check for batch effects or heterogeneity

---

## Troubleshooting

### "Could not infer two groups from sample names"

**Problem**: Pipeline couldn't automatically detect disease vs control groups

**Solutions**:

1. **Add condition/group column to metadata**:
 ```
 sample,condition,treatment
 GSM1,Disease,Drug_A
 GSM2,Disease,Drug_A
 GSM3,Control,Vehicle
 ```

2. **Specify group column explicitly**:
 ```bash
 python scripts/run_pipeline.py \
 --counts data/counts.txt \
 --metadata data/metadata.txt \
 --group_col treatment \
 --disease_label Drug_A \
 --control_label Vehicle
 ```

### "Need at least 2 samples per group"

**Problem**: Fewer than 2 samples in disease or control group

**Solution**: Ensure at least n=2 per group (n=3+ recommended for statistical power)

### DESeq2 ImportError

**Problem**: `ImportError: No module named 'rpy2'`

**Solution**:
```bash
# Install rpy2
pip install rpy2

# In R (Rscript):
Rscript -e "install.packages('DESeq2')"
```

### Heatmap too slow / memory error

**Problem**: >50K samples causes matplotlib to hang

**Workarounds**:
1. Reduce `--top_n` (e.g., 10 instead of 50)
2. Use CSV results; don't generate plots
3. Switch to DESeq2 which uses raw counts (smaller file size)

---

## For Academic Presentations

### Key Talking Points

1. **Why two methods?**
 - Welch: Fast screening, exploratory analysis
 - DESeq2: Rigorous publication-ready validation
 - Trade-off: Speed vs. statistical rigor

2. **Statistical Validity**
 - FDR correction controls error rate genome-wide
 - Multiple testing: ~1,000 false positives expected if uncorrected
 - Typical result: 10-20% of tested genes significant after FDR

3. **ncRNA-Specific Advantages**
 - Handles sparse, zero-inflated data well
 - Automatic biotype filtering (lncRNA, miRNA, snoRNA, etc.)
 - Cross-dataset conserved gene analysis

4. **Validation Strategy**
 - Generate results with **both** methods
 - Compare: True discoveries should appear in both
 - Report genes consistent across methods → high confidence

### Example Manuscript Excerpt

> "We identified differentially expressed non-coding RNAs using Welch t-test (α = 0.05) with Benjamini-Hochberg FDR correction on log₂-CPM normalized counts. We validated findings using DESeq2 (LFC ≠ 0, Wald test, α = 0.05, FDR-corrected) on raw count data to account for the discrete nature of RNA-seq data. Genes appearing significant in both analyses were prioritized."

---

## References

1. **Welch t-test**: Welch, B. L. (1947). "The generalization of 'Student's' problem when several different population variances are involved." Biometrika, 34(1-2), 28-35.

2. **DESeq2**: Love, M. I., Huber, W., & Anders, S. (2014). "Moderated estimation of fold change and dispersion for RNA-seq data with DESeq2." Genome biology, 15(12), 550.

3. **Benjamini-Hochberg FDR**: Benjamini, Y., & Hochberg, Y. (1995). "Controlling the false discovery rate: a practical and powerful approach to multiple testing." Journal of the Royal Statistical Society, 57(1), 289-300.

4. **RNA-seq Normalization**: Evans, C., Hardin, J., & Stoebel, D. M. (2018). "Selecting between-sample RNA-seq normalization methods from the perspective of their assumptions." Briefings in bioinformatics, 19(5), 776-792.

---

## File Organization

```
pipeline/
├── de_analysis.py ← Welch + DESeq2 implementations
├── io.py ← Auto-detects group columns
├── processing.py ← Log2-CPM normalization
└── visualization.py ← Volcano plots, heatmaps

run_pipeline.py ← CLI with --method parameter

results/
├── per_dataset/
│ ├── local_differential_results.csv
│ ├── local_volcano.png
│ └── local_top_genes_heatmap.png
└── figures/ ← Cross-dataset plots
```

---

**Last Updated**: February 2026 
**Pipeline Version**: 2.0 (Dual DE Methods)
