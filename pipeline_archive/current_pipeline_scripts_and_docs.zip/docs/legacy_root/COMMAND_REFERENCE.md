# Quick Command Reference for ncRNA Biomarker Pipeline

## Activate Virtual Environment

```bash
cd /Users/austinbautista/ncrna_pipeline
source .venv/bin/activate
```

---

## Configure Your Datasets

Edit `config_datasets.yaml` to add your RNA-seq datasets:

```bash
nano config_datasets.yaml
```

Each entry needs:
- `species`: human, mouse, or zebrafish
- `disease`: alzheimers, parkinsons, or als
- `counts_path`: path to counts.txt file
- `metadata_path`: path to metadata.txt file
- `group_col`: column name for disease/control groups
- `disease_label`: value in group_col for disease samples
- `control_label`: value in group_col for control samples

---

## Run Analysis

### Full Analysis (All Datasets)

```bash
python scripts/analyze_biomarkers.py --config config_datasets.yaml --outdir biomarker_results
```

### Filter by Species

```bash
# Only human datasets
python scripts/analyze_biomarkers.py --config config_datasets.yaml --species human --outdir human_results

# Only mouse datasets
python scripts/analyze_biomarkers.py --config config_datasets.yaml --species mouse --outdir mouse_results

# Only zebrafish datasets
python scripts/analyze_biomarkers.py --config config_datasets.yaml --species zebrafish --outdir zebrafish_results
```

### Filter by Disease

```bash
# Only Alzheimer's datasets
python scripts/analyze_biomarkers.py --config config_datasets.yaml --disease alzheimers --outdir ad_results

# Only Parkinson's datasets
python scripts/analyze_biomarkers.py --config config_datasets.yaml --disease parkinsons --outdir pd_results

# Only ALS datasets
python scripts/analyze_biomarkers.py --config config_datasets.yaml --disease als --outdir als_results
```

### Adjust Significance Threshold

```bash
# Stricter (FDR < 0.01 instead of 0.05)
python scripts/analyze_biomarkers.py --config config_datasets.yaml --fdr-threshold 0.01 --outdir strict_results

# More lenient (FDR < 0.10)
python scripts/analyze_biomarkers.py --config config_datasets.yaml --fdr-threshold 0.10 --outdir lenient_results
```

### Get More/Fewer Biomarkers in Report

```bash
# Show top 50 biomarkers (default is 20)
python scripts/analyze_biomarkers.py --config config_datasets.yaml --top-n 50 --outdir top50_results

# Show top 100
python scripts/analyze_biomarkers.py --config config_datasets.yaml --top-n 100 --outdir top100_results
```

### Combined Filter

```bash
# Human Alzheimer's, stricter threshold, top 50
python scripts/analyze_biomarkers.py --config config_datasets.yaml \
 --species human \
 --disease alzheimers \
 --fdr-threshold 0.01 \
 --top-n 50 \
 --outdir human_ad_strict
```

---

## View Results

### Check Top Biomarkers

```bash
# View top 20 in terminal
head -20 biomarker_results/top_candidates.csv

# Open in Excel (on macOS)
open -a "Microsoft Excel" biomarker_results/top_candidates.csv

# Or view raw
cat biomarker_results/top_candidates.csv
```

### View Summary Report

```bash
# For judges/presentation
cat biomarker_results/PRESENTATION_SUMMARY.txt

# Full detailed report
cat biomarker_results/biomarker_report.txt
```

### View Figures

```bash
# Main heatmap (for your poster)
open biomarker_results/figures/biomarker_heatmap.png

# Dataset overlap visualization
open biomarker_results/figures/biomarker_overlap.png

# Individual dataset analysis folders
open biomarker_results/per_dataset/
```

### Organize Results

```bash
# Organize a messy results folder
python scripts/organize_results.py --root results
```

---

## Download Datasets from GEO

### Method 1: Automatic Download (if GSE ID known)

```bash
python scripts/auto_run_pipeline.py --input GSE33000

# Creates results/GSE33000_series_matrix/ with counts and metadata automatically
```

### Method 2: Manual Download

1. Go to https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSEXXX
2. Download "Series Matrix File" (or supplementary files if needed)
3. Extract and place in data/ folder
4. Create counts.txt and metadata.txt with proper format

---

## Format Requirements

### counts.txt (Tab-delimited)

```
gene_id sample1 sample2 sample3 sample4
ENSG0001 100 50 200 150
ENSG0002 500 450 600 550
ENSG0003 0 10 5 0
```

First column = gene_id, remaining columns = sample names with expression values

### metadata.txt (Tab-delimited)

```
sample condition
sample1 Disease
sample2 Control
sample3 Disease
sample4 Control
```

Must have `sample` column and a condition column (e.g., `group_col: condition`)

---

## Individual Dataset Analysis

Analyze single datasets without cross-comparison:

```bash
python scripts/run_pipeline.py \
 --counts data/mycounts.txt \
 --metadata data/mymetadata.txt \
 --outdir my_results \
 --group_col condition \
 --disease_label Disease \
 --control_label Control
```

---

## Statistical Methods

### Default: Welch's t-test

- Fast, robust for unequal variances
- Good for most cases
- FDR correction: Benjamini-Hochberg

```bash
# Explicitly specify (if needed)
python scripts/analyze_biomarkers.py --config config_datasets.yaml --fdr-threshold 0.05
```

### Alternative: DESeq2 (More Rigorous)

```bash
python scripts/run_pipeline.py \
 --counts data/mycounts.txt \
 --metadata data/mymetadata.txt \
 --method deseq2 \
 --outdir deseq2_results
```

(Requires R/rpy2 setup - ask if needed)

---

## Troubleshooting

### Error: "File not found"

Check that paths in config_datasets.yaml are correct:

```bash
# Test if file exists
ls -la /absolute/path/to/counts.txt
ls -la /absolute/path/to/metadata.txt
```

### Error: "Group column not found"

Verify metadata has the column specified in `group_col`:

```bash
# Check column names in metadata
head -1 data/metadata.txt
```

### Error: "No biomarkers found"

May mean:
- FDR threshold too strict (try `--fdr-threshold 0.10`)
- Too few samples in dataset
- Check individual dataset results first:

```bash
ls biomarker_results/per_dataset/*/local_differential_results.csv
head biomarker_results/per_dataset/[dataset_name]/local_differential_results.csv
```

### Speed Issues

- More datasets = slower analysis (normal)
- Strict FDR = fewer biomarkers (faster)
- Reduce --top-n to make report faster

---

## Output Files Explained

```
biomarker_results/
├── top_candidates.csv
│ └── Ranked list of biomarkers with scores and appearances
│ Columns: gene_id, biomarker_score, appearances, avg_log2fc, 
│ min_fdr, n_diseases, n_species, species, diseases
│
├── biomarker_report.txt
│ └── Detailed text report (for reference)
│
├── PRESENTATION_SUMMARY.txt
│ └── Key findings ready to paste in your poster
│
├── figures/
│ ├── biomarker_heatmap.png
│ │ └── Top biomarkers × datasets (GREEN = significant)
│ │ Perfect for science fair poster
│ └── biomarker_overlap.png
│ └── Pairwise dataset similarity bar chart
│ Shows which datasets have most in common
│
└── per_dataset/
 ├── [dataset1_name]/
 │ ├── [name]_counts.txt
 │ ├── [name]_metadata.txt
 │ ├── [name]_differential_results.csv
 │ ├── [name]_volcano.png
 │ └── [name]_heatmap.png
 │
 ├── [dataset2_name]/
 │ └── (same structure)
 │
 └── [dataset3_name]/
 └── (same structure)
```

---

## Key Metrics Explained

**In top_candidates.csv**:

| Metric | Meaning | Good Value |
|--------|---------|-----------|
| `biomarker_score` | Overall quality score (0-100+) | > 50 is good |
| `appearances` | # of datasets showing significant | > 2 is strong |
| `avg_log2fc` | Average fold-change magnitude | > 1.5 meaningful |
| `min_fdr` | Best (lowest) p-value adjusted | < 0.05 significant |
| `n_diseases` | # of diseases affected | > 2 shows pan-disease |
| `n_species` | # of species conserved | > 2 shows conservation |

**Biomarker Ranking**:
- High appearances + strict FDR = strong candidate
- High n_species + high n_diseases = universal biomarker
- High avg_log2fc = strong effect

---

## Science Fair Presentation Checklist

- [ ] Edit `config_datasets.yaml` with your datasets
- [ ] Run `python scripts/analyze_biomarkers.py --config config_datasets.yaml --outdir biomarker_results`
- [ ] Download `figures/biomarker_heatmap.png` for poster
- [ ] Download `figures/biomarker_overlap.png` for supporting figure
- [ ] Create table of top 10 from `top_candidates.csv`
- [ ] Copy key findings from `PRESENTATION_SUMMARY.txt`
- [ ] Write methods section (include statistical test, FDR correction, species/diseases)
- [ ] Practice explanation for judges
- [ ] Have `biomarker_results/top_candidates.csv` on laptop to show judges

---

## Need Help?

**For detailed workflow**: See `SCIENCE_FAIR_SETUP.md` 
**For DE analysis details**: See `DE_ANALYSIS_GUIDE.md` 
**For biomarker system**: See `BIOMARKER_DISCOVERY_GUIDE.md` 
**For installation**: See `docs/INSTALLATION.md`

---

Good luck with your science fair project! 🧬🏆
