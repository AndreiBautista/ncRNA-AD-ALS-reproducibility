# 🏆 Science Fair: Multi-Species ncRNA Biomarker Discovery
## Complete Setup & Workflow Guide

---

## What You Can Now Do

Your pipeline now supports **comprehensive multi-species, multi-disease analysis**:

✅ **3 Species**: Human, Mouse, Zebrafish 
✅ **3 Diseases**: Alzheimer's, Parkinson's, ALS 
✅ **Cross-Dataset Analysis**: Identify conserved biomarkers 
✅ **Science Fair Ready**: Visualizations, reports, talking points 

**Example Science Fair Project**:
> "Identifying Universal ncRNA Biomarkers for Neurodegenerative Diseases Across Species"
> 
> By analyzing RNA-seq from human, mouse, and zebrafish models of Alzheimer's disease, Parkinson's disease, and ALS, we identified ncRNA biomarkers that appear consistently across multiple organisms and disease conditions, suggesting evolutionary conservation and strong candidates for clinical translation.

---

## Step 1: Collect Your Datasets (Or Use Public Data)

### Option A: Download from GEO (Gene Expression Omnibus)

```bash
# Example: Download a GEO dataset (replace with any GSE ID)
python scripts/auto_run_pipeline.py --input GSE33000_series_matrix.txt.gz

# This creates:
# results/GSE33000_series_matrix/data/
# ├── GSE33000_series_matrix_counts.txt
# └── GSE33000_series_matrix_metadata.txt
```

### Option B: Use Your Own RNA-seq Data

Prepare files in this format:

**counts.txt** (tab-delimited):
```
gene_id sample1 sample2 sample3 sample4
ENSG0001 100 50 200 150
ENSG0002 500 450 600 550
ENSG0003 0 10 5 0
```

**metadata.txt** (tab-delimited):
```
sample condition
sample1 Disease
sample2 Control
sample3 Disease
sample4 Control
```

### Recommended Public Datasets (Examples)

| Study | Organism | Disease | Link |
|-------|----------|---------|------|
| GSE33000 | Human | Alzheimer's | https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE33000 |
| GSE76220 | Mouse | Alzheimer's | (search GEO for mouse Alzheimer's) |
| GSE103811 | Zebrafish | Development/Disease | (search GEO) |

---

## Step 2: Configure Your Datasets

Edit **config_datasets.yaml** to include any datasets you want (GSE or non-GSE):

```yaml
# HUMAN DATASETS (examples)
GSE33000_human_alzheimers:
 species: human
 disease: alzheimers
 counts_path: results/GSE33000_series_matrix/data/GSE33000_series_matrix_counts.txt
 metadata_path: results/GSE33000_series_matrix/data/GSE33000_series_matrix_metadata.txt
 group_col: condition
 disease_label: Disease
 control_label: Control
 notes: GEO GSE33000 - Human Alzheimer's brain tissue

# MOUSE DATASETS (examples)
GSE_mouse_alzheimers:
 species: mouse
 disease: alzheimers
 counts_path: data/mouse_alzheimers/counts.txt
 metadata_path: data/mouse_alzheimers/metadata.txt
 group_col: condition
 disease_label: Disease
 control_label: Control
 notes: Mouse model of Alzheimer's disease

GSE_mouse_parkinsons:
 species: mouse
 disease: parkinsons
 counts_path: data/mouse_parkinsons/counts.txt
 metadata_path: data/mouse_parkinsons/metadata.txt
 group_col: condition
 disease_label: Disease
 control_label: Control
 notes: Mouse model of Parkinson's disease

# ZEBRAFISH DATASETS (examples)
GSE_zebrafish_alzheimers:
 species: zebrafish
 disease: alzheimers
 counts_path: data/zebrafish_alzheimers/counts.txt
 metadata_path: data/zebrafish_alzheimers/metadata.txt
 group_col: condition
 disease_label: Disease
 control_label: Control
 notes: Zebrafish Alzheimer's model

GSE_zebrafish_als:
 species: zebrafish
 disease: als
 counts_path: data/zebrafish_als/counts.txt
 metadata_path: data/zebrafish_als/metadata.txt
 group_col: condition
 disease_label: Disease
 control_label: Control
 notes: Zebrafish ALS model
```

**Template for Each Entry (works for any dataset)**:
```yaml
YOUR_DATASET_ID:
 species: [human|mouse|zebrafish]
 disease: [alzheimers|parkinsons|als]
 counts_path: /absolute/or/relative/path/counts.txt
 metadata_path: /absolute/or/relative/path/metadata.txt
 group_col: condition # Column name in metadata for group assignment
 disease_label: Disease # Value in group_col for disease samples
 control_label: Control # Value in group_col for control samples
 notes: Brief description # Optional: where is this data from?
```

---

## Step 3: Run the Analysis

### Run All Datasets

```bash
cd /Users/austinbautista/ncrna_pipeline
source .venv/bin/activate

python scripts/analyze_biomarkers.py --config config_datasets.yaml --outdir biomarker_results
```

**Output**:
```
biomarker_results/
├── top_candidates.csv ← Main results
├── biomarker_report.txt ← Detailed findings
├── PRESENTATION_SUMMARY.txt ← Ready for your poster!
├── figures/
│ ├── biomarker_heatmap.png ← Cross-dataset visualization
│ └── biomarker_overlap.png ← Dataset similarity
└── per_dataset/ ← Individual dataset folders
 └── GSE33000_human_alzheimers/
 ├── data/
 │ └── GSE33000_human_alzheimers_differential_results.csv
 └── figures/
 ├── GSE33000_human_alzheimers_volcano.png
 └── GSE33000_human_alzheimers_top_genes_heatmap.png
```

### Analyze Subsets

```bash
# Only human datasets
python scripts/analyze_biomarkers.py --config config_datasets.yaml --species human --outdir human_analysis

# Only Alzheimer's
python scripts/analyze_biomarkers.py --config config_datasets.yaml --disease alzheimers --outdir alzheimers_analysis

# Stricter significance (FDR < 0.01 instead of 0.05)
python scripts/analyze_biomarkers.py --config config_datasets.yaml --fdr-threshold 0.01 --outdir strict_results

# Report more biomarkers (default 20, show top 50)
python scripts/analyze_biomarkers.py --config config_datasets.yaml --top-n 50 --outdir detailed_results
```

---

## Step 4: Interpret Results for Science Fair

### Key Files to Review

#### 1. **top_candidates.csv** - Sort by Impact

Open in Excel and sort by `biomarker_score` (highest first):

```
gene_id,biomarker_score,appearances,avg_log2fc,min_fdr,n_diseases,n_species,species,diseases
LINC00174,85.3,4,2.45,0.0001,2,2,human,mouse,alzheimers,parkinsons
MIR9876,79.1,3,1.98,0.0005,1,3,human,mouse,zebrafish,alzheimers
SNOXA,72.5,2,3.12,0.0012,3,1,human,alzheimers,parkinsons,als
```

**Talking Points**:
- **LINC00174**: "Found in 4 datasets (human & mouse, Alzheimer's & Parkinson's)"
- **MIR9876**: "Conserved across 3 species (human, mouse, zebrafish)"
- **SNOXA**: "Dysregulated in all 3 neurological diseases"

#### 2. **PRESENTATION_SUMMARY.txt** - Copy-Paste Ready

Example output:
```
KEY FINDINGS FOR SCIENCE FAIR:

🏆 TOP 5 BIOMARKER CANDIDATES:
 1. LINC00174: Found in 4 datasets, affects 2 diseases, 2 species
 2. MIR9876: Found in 3 datasets, affects 1 disease, 3 species
 3. SNOXA: Found in 2 datasets, affects 3 diseases, 1 species
 4. ...

🧠 DISEASE-SPECIFIC FINDINGS:
 • alzheimers: 85 unique biomarkers identified
 • parkinsons: 62 unique biomarkers identified
 • als: 45 unique biomarkers identified

🔬 CROSS-SPECIES CONSERVATION:
 • 18 biomarkers conserved across 2+ species
 • Suggests evolutionary conservation & clinical relevance
```

#### 3. **figures/biomarker_heatmap.png** - Your "Results" Figure

Shows which biomarkers are significant in which conditions:
- **Green cells** = significant in that species-disease combination
- **Red cells** = not significant
- Perfect for your science fair poster!

#### 4. **figures/biomarker_overlap.png** - Reproducibility Evidence

Shows which datasets have most in common:
- High overlap = consistent biomarkers
- Great for explaining "why this is reproducible"

---

## Step 5: Create Your Science Fair Poster

### Poster Layout

```
┌─────────────────────────────────────────────────────────────┐
│ TITLE: Identifying Universal ncRNA Biomarkers for │
│ Neurodegenerative Diseases Across Species │
│ │
├─────────────────────────────────────────────────────────────┤
│ BACKGROUND │ METHODS │ RESULTS │ CONCLUSION │
│ │ │ │ │
│ • ncRNAs as │ • Analyzed │ [HEATMAP] │ • 12 conserved │
│ biomarkers│ X datasets│ [OVERLAP] │ biomarkers │
│ • Cross- │ • Species: │ [TABLE] │ • Promising │
│ species │ H, M, Z │ [GRAPHS] │ for clinical │
│ models │ • Diseases: │ │ trial │
│ • Clinical │ AD, PD, ALS │ • Next: lab │
│ relevance │ • FDR <0.05 │ │ validation │
│ │ │ │ │
└─────────────────────────────────────────────────────────────┘
```

### Poster Content Checklist

- [ ] Title (clear, specific, compelling)
- [ ] Background (why ncRNAs matter, why cross-species)
- [ ] Methods (datasets, species, diseases, stats used)
- [ ] Results section with:
 - [ ] figures/biomarker_heatmap.png (top 30-50 biomarkers)
 - [ ] figures/biomarker_overlap.png (dataset similarity)
 - [ ] Table of top 10 biomarkers
 - [ ] Key statistics (total found, conserved, strongest)
- [ ] Conclusion
 - [ ] What you learned
 - [ ] Clinical implications
 - [ ] Next steps / validation experiments
- [ ] References (cite GEO datasets, statistical methods)

### Presentation Script (Judges will Ask)

**"Walk us through your analysis"**:
> "We downloaded RNA-seq data from public databases for three organisms—human, mouse, and zebrafish—each with three neurological diseases: Alzheimer's, Parkinson's, and ALS. We ran differential expression analysis on each dataset using Welch's t-test with FDR correction. Then we ranked ncRNA biomarkers by how many datasets showed them as significant. The most promising candidates are the ones that appear in multiple conditions, suggesting they're not just noise but real biological signals."

**"Why is this better than single-dataset analysis?"**
> "A single dataset might have batch effects or organism-specific artifacts. But if the same ncRNA is dysregulated in human Alzheimer's, mouse Alzheimer's, AND zebrafish Alzheimer's, that's strong evidence it's a real, conserved biomarker. We ranked them by cross-dataset consistency, which is a better indication of clinical potential than any single study."

**"What would you do next?"**
> "We would experimentally validate the top 5 biomarkers using qPCR in our own animal models. Then we'd do functional studies to understand what these ncRNAs actually do in disease. Finally, test them as biomarkers in patient blood samples."

---

## Example: What Your Results Will Look Like

### Scenario: You have 5 datasets

**Datasets analyzed**:
- GSE33000: Human + Alzheimer's
- GSE76220: Mouse + Alzheimer's 
- GSE_XXX: Zebrafish + Alzheimer's
- GSE_YYY: Human + Parkinson's
- GSE_ZZZ: Mouse + Parkinson's

**Expected findings**:
- 150+ total biomarkers discovered
- ~35 biomarkers in 2+ datasets (cross-validated)
- ~18 biomarkers in 3+ datasets (strong candidates)
- ~5 biomarkers across all 5 datasets (excellent candidates!)
- ~8 pan-disease biomarkers (work for AD and PD)
- ~12 pan-species biomarkers (conserved across H, M, Z)

**Science Fair Talking Points**:
- "We identified 5 universal biomarkers appearing in ALL datasets"
- "LINC00174 is conserved across human, mouse, and zebrafish—suggests fundamental mechanism"
- "Parkinsons-specific biomarkers: X1, X2, X3 (unique target set)"
- "Alzheimer's has more biomarkers than Parkinson's (more severe?)

---

## Troubleshooting Your Science Fair Analysis

### Problem: "Not enough datasets"

**Solution**: 
- Search GEO for more datasets (you can find 50+ for major diseases)
- Download from other public sources (TCGA, GTEx, etc.)
- Use your own data if available

### Problem: "Very few conserved biomarkers"

**Reason**: This is actually OK! Shows:
- Species differences (might be interesting finding)
- Disease-specific mechanisms (different biomarkers)

**Solution**: Reframe as "species-specific biomarkers" or "disease-specific mechanisms"

### Problem: "Results don't match my hypothesis"

**This is STILL good science!**
- Report what you found, not what you expected
- Explain why results differ from hypothesis
- This shows scientific thinking

---

## Files Checklist for Science Fair

✅ **Code/Data**:
- [ ] config_datasets.yaml (your dataset list)
- [ ] biomarker_results/ directory (all outputs)
- [ ] top_candidates.csv (for analysis)
- [ ] biomarker_report.txt (for reference)

✅ **Poster Elements**:
- [ ] figures/biomarker_heatmap.png (main figure)
- [ ] figures/biomarker_overlap.png (validation figure)
- [ ] Table of top 10 biomarkers
- [ ] Screenshots if needed

✅ **Documentation**:
- [ ] Notes on datasets (where from, n=?, species, disease)
- [ ] Methods (statistical tests, FDR correction)
- [ ] Your talking points (from PRESENTATION_SUMMARY.txt)

---

## Next Steps

### Immediate (This Week)
1. ✅ Collect 3-5 datasets (can get free from GEO)
2. ✅ Configure config_datasets.yaml
3. ✅ Run `python scripts/analyze_biomarkers.py`
4. ✅ Review results

### For Your Poster (Next Week)
1. ✅ Download figures/biomarker_heatmap.png and figures/biomarker_overlap.png
2. ✅ Create top 10 biomarker table
3. ✅ Write methods section
4. ✅ Draft poster layout

### For Judges (Before Fair)
1. ✅ Practice 2-minute explanation
2. ✅ Prepare answers to common questions
3. ✅ Test your code one more time
4. ✅ Bring top_candidates.csv on laptop for demos

---

## Commands Quick Reference

```bash
# Navigate to pipeline
cd /Users/austinbautista/ncrna_pipeline
source .venv/bin/activate

# Edit your config
nano config_datasets.yaml

# Run full analysis
python scripts/analyze_biomarkers.py --config config_datasets.yaml --outdir biomarker_results

# Check results
cat biomarker_results/PRESENTATION_SUMMARY.txt
open biomarker_results/figures/biomarker_heatmap.png

# Analyze just one disease
python scripts/analyze_biomarkers.py --config config_datasets.yaml --disease alzheimers --outdir ad_only

# Analyze just one species
python scripts/analyze_biomarkers.py --config config_datasets.yaml --species human --outdir human_only
```

---

## You're Ready! 🚀

- ✅ System set up
- ✅ Configuration ready
- ✅ Analysis pipeline functional
- ✅ Science fair ready outputs
- ✅ Documentation complete

Now:
1. **Add your datasets** to config_datasets.yaml
2. **Run the analysis**: `python scripts/analyze_biomarkers.py --config config_datasets.yaml`
3. **Create your poster** using the generated figures
4. **Win the science fair!** 🏆

Good luck! The judges will be impressed by your scientific rigor and comprehensive cross-dataset analysis!

---

**Need Help?**
- Questions about datasets? → See BIOMARKER_DISCOVERY_GUIDE.md
- Questions about stats? → See DE_ANALYSIS_GUIDE.md
- Can't get data to work? → Check ENHANCED_PIPELINE_README.md
