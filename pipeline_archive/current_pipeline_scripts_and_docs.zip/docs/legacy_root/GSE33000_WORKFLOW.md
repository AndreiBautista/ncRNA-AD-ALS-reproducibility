# GSE33000 Analysis Workflow

This guide documents the complete process for analyzing the GSE33000 dataset using the ncRNA pipeline.

## Overview

**What you're doing:**
1. Decompress the raw data file (`.txt.gz`)
2. Extract counts and metadata
3. Run the differential expression pipeline
4. Analyze results

**Time required:** ~10-15 minutes (mostly waiting for processing)

---

## Step 1: Decompress Raw Data

If your file is compressed (`.txt.gz`):

```bash
cd /Users/austinbautista/ncrna_pipeline
gunzip -c GSE33000_raw_data.txt.gz > GSE33000_raw_data.txt
```

**Verify it worked:**
```bash
ls -lh GSE33000_raw_data.txt
# Should show ~463 MB
```

---

## Step 2: Extract Counts and Metadata

The raw data file has gene information mixed with sample data. We need to separate it.

```bash
cd /Users/austinbautista/ncrna_pipeline
source .venv/bin/activate

python scripts/prepare_GSE33000.py
```

**What this does:**
- Reads `GSE33000_raw_data.txt`
- Creates `GSE33000_counts.txt` (gene expression values)
- Creates `GSE33000_metadata.txt` (sample information)

**Verify it worked:**
```bash
ls -lh GSE33000_*.txt
# Should create 3 files: raw_data.txt, counts.txt, metadata.txt
```

---

## Step 3: Check and Adjust Metadata

The pipeline needs to know which samples are "Disease" and which are "Control".

**Look at the metadata:**
```bash
head -20 GSE33000_metadata.txt
```

**Expected format:**
```
sample condition
HBTRC_PF_Pool_1 Disease
HBTRC_PF_Pool_2 Control
HBTRC_PF_Pool_3 Disease
...
```

**If the condition assignments are wrong:**

Open the file and edit manually:
```bash
# Edit with a text editor
open GSE33000_metadata.txt
# Or use nano
nano GSE33000_metadata.txt
```

Change `Disease` ↔ `Control` as needed based on your study design.

---

## Step 4: Run the Pipeline

Now analyze the data:

```bash
cd /Users/austinbautista/ncrna_pipeline
source .venv/bin/activate

python scripts/run_pipeline.py \
 --counts GSE33000_counts.txt \
 --metadata GSE33000_metadata.txt \
 --group_col condition \
 --disease_label Disease \
 --control_label Control \
 --outdir results/GSE33000_analysis \
 --top_n 50 \
 --pseudocount 1.0
```

**Parameter explanation:**
- `--counts` - The counts file we extracted
- `--metadata` - The metadata file we extracted
- `--group_col condition` - Column name in metadata that separates disease/control
- `--disease_label Disease` - Value in that column for disease samples
- `--control_label Control` - Value in that column for control samples
- `--outdir results/GSE33000_analysis` - Where to save results
- `--top_n 50` - Show top 50 genes in plots
- `--pseudocount 1.0` - Small number to prevent log(0)

**Expected output:**
```
Analysis complete. Results written to results/GSE33000_analysis
```

---

## Step 5: Check Results

**List all output files:**
```bash
ls -lR results/GSE33000_analysis/
```

**View the differential expression results:**
```bash
# First few lines
head -20 results/GSE33000_analysis/per_dataset/local_differential_results.csv

# Count how many significant genes (FDR < 0.05)
awk -F',' '$7=="True"' results/GSE33000_analysis/per_dataset/local_differential_results.csv | wc -l
```

**Open visualizations:**
```bash
# Volcano plot (log2FC vs -log10(FDR))
open results/GSE33000_analysis/per_dataset/local_volcano.png

# Heatmap of top genes
open results/GSE33000_analysis/per_dataset/local_top_genes_heatmap.png

# Summary bar chart
open results/GSE33000_analysis/figures/ncRNA_significant_counts.png
```

---

## Output Files Explained

```
results/GSE33000_analysis/
├── per_dataset/
│ ├── local_differential_results.csv ← MAIN RESULTS
│ │ Columns:
│ │ - gene_id: Gene identifier
│ │ - mean_disease: Avg log2-CPM in disease
│ │ - mean_control: Avg log2-CPM in control
│ │ - log2FC: log2(fold-change) disease/control
│ │ - pvalue: t-test p-value
│ │ - fdr: FDR-corrected p-value (Benjamini-Hochberg)
│ │ - significant: TRUE if FDR < 0.05
│ │
│ ├── local_volcano.png ← PLOT 1
│ │ X-axis: log2FC (fold change)
│ │ Y-axis: -log10(FDR) (significance)
│ │ Red dots: Significant genes (FDR < 0.05)
│ │ Grey dots: Non-significant
│ │
│ └── local_top_genes_heatmap.png ← PLOT 2
│ Shows expression patterns of top genes
│ Rows: Genes | Columns: Samples
│ Color: Expression level
│
├── figures/
│ └── ncRNA_significant_counts.png ← SUMMARY PLOT
│ Bar chart of significant gene counts
│
└── data/ ← Internal
 (Empty - no download data)
```

---

## Interpreting Results

### CSV File (local_differential_results.csv)

**Key columns:**
- **log2FC > 0** = Gene is upregulated in disease
- **log2FC < 0** = Gene is downregulated in disease
- **fdr < 0.05** = Statistically significant

**Example interpretation:**
```
TP53, log2FC = -2.5, fdr = 0.001, significant = True
→ TP53 is 2^2.5 = 5.7x LOWER in disease, highly significant
```

### Volcano Plot

- **Top left** = Strongly downregulated + significant (← look here)
- **Top right** = Strongly upregulated + significant (← look here)
- **Middle** = Not significant (ignore)

### Heatmap

- **Red = High expression** in that sample
- **Blue = Low expression** in that sample
- **Top genes with clear patterns** = Good candidates

---

## Troubleshooting

### ❌ Error: "File not found"

Make sure you're in the right directory:
```bash
cd /Users/austinbautista/ncrna_pipeline
ls GSE33000_* # Check files exist
```

### ❌ Error: "Grouping column 'condition' not found"

Check your metadata file has the column:
```bash
head -1 GSE33000_metadata.txt # Shows column names
# Should show: sample condition
```

### ❌ Error: "No samples match"

Sample names in counts might not match metadata exactly. Check:
```bash
head GSE33000_counts.txt | cut -f1-5 # First 5 columns of counts
head GSE33000_metadata.txt # First few rows of metadata
```

### ❌ Process is slow

- The pipeline is running on ~50K genes × 19 samples
- Normal to take 2-5 minutes
- Can't interrupt (let it finish)

---

## Full Command Reference

**One-liner (if everything is setup):**
```bash
cd /Users/austinbautista/ncrna_pipeline && \
source .venv/bin/activate && \
python scripts/prepare_GSE33000.py && \
python scripts/run_pipeline.py \
 --counts GSE33000_counts.txt \
 --metadata GSE33000_metadata.txt \
 --group_col condition \
 --disease_label Disease \
 --control_label Control \
 --outdir results/GSE33000_analysis \
 --top_n 50
```

---

## Next Steps

After running once:

1. **Save your results:**
 ```bash
 cp -r results/GSE33000_analysis ~/my_analyses/
 ```

2. **Edit metadata if needed:**
 - If disease/control assignments are wrong, edit `GSE33000_metadata.txt`
 - Re-run: `python scripts/run_pipeline.py ...` (same command as Step 4)

3. **Try different parameters:**
 ```bash
 # Look at top 100 genes instead
 python scripts/run_pipeline.py ... --top_n 100
 
 # Try different FDR threshold by editing pipeline code
 ```

4. **Use with other datasets:**
 - Same process: decompress → extract → run pipeline

---

## Environment Setup (One-time)

If you need to recreate the environment:

```bash
cd /Users/austinbautista/ncrna_pipeline
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Then run: `python scripts/prepare_GSE33000.py` (Step 2 above)

---

**Questions?** Check `docs/QUICKSTART.md` or `docs/ARCHITECTURE.md` for more details.
