# Multi-Species, Multi-Disease ncRNA Biomarker Discovery
## Science Fair Project Guide

---

## Executive Summary

This system allows you to **analyze ncRNA biomarkers across multiple species and diseases** simultaneously to identify the **most promising candidates for clinical translation**.

**Key Features**:
- ✅ Analyze any number of datasets (human, mouse, zebrafish; Alzheimer's, Parkinson's, ALS)
- ✅ Automatically identify conserved biomarkers (appear in multiple datasets)
- ✅ Rank biomarkers by cross-dataset consistency and impact
- ✅ Generate science fair-ready visualizations and reports
- ✅ Identify which species/disease combinations work best together

**Science Fair Value**:
- Shows comprehensive understanding of comparative genomics
- Demonstrates systems biology approach
- Identifies clinically relevant biomarkers
- Uses real GEO datasets and proper statistical methods

---

## How It Works: 3 Steps

### Step 1: Add Datasets to Config

Edit `config_datasets.yaml` to include your datasets:

```yaml
GSE33000_human_alzheimers:
 species: human
 disease: alzheimers
 counts_path: data/alzheimers_human/counts.txt
 metadata_path: data/alzheimers_human/metadata.txt
 group_col: condition
 disease_label: Disease
 control_label: Control

GSE_mouse_parkinsons:
 species: mouse
 disease: parkinsons
 counts_path: data/parkinsons_mouse/counts.txt
 metadata_path: data/parkinsons_mouse/metadata.txt
 group_col: condition
 disease_label: Disease
 control_label: Control
```

**Template for Each Dataset**:
```yaml
YOUR_DATASET_ID:
 species: [human|mouse|zebrafish]
 disease: [alzheimers|parkinsons|als]
 counts_path: path/to/counts.txt
 metadata_path: path/to/metadata.txt
 group_col: column_name_in_metadata
 disease_label: value_for_disease_group
 control_label: value_for_control_group
 notes: (optional) description
```

### Step 2: Run Multi-Dataset Analysis

```bash
python scripts/analyze_biomarkers.py --config config_datasets.yaml --outdir biomarker_results
```

**What it does**:
1. Analyzes each dataset individually (DE analysis, FDR correction)
2. Extracts significant biomarkers from each dataset
3. Identifies conserved biomarkers (appear in 2+, 3+, etc. datasets)
4. Ranks biomarkers by cross-dataset consistency
5. Generates science fair report and visualizations

**Output**: `biomarker_results/` directory with:
- `top_candidates.csv` - All biomarkers ranked by quality
- `biomarker_report.txt` - Detailed findings
- `PRESENTATION_SUMMARY.txt` - Ready for your poster
- `figures/biomarker_heatmap.png` - Cross-dataset visualization
- `figures/biomarker_overlap.png` - Which datasets are most similar

### Step 3: Interpret Results

The system identifies four types of biomarkers:

| Type | Meaning | Science Fair Value |
|------|---------|-------------------|
| **Universal** | Found in ALL datasets | Highest confidence candidates |
| **Pan-disease** | Multiple diseases, single species | Disease-independent biomarker |
| **Pan-species** | Same disease, multiple species | Evolutionarily conserved |
| **Conserved** | Found in 2-3 datasets | Reliable across conditions |

---

## Complete Workflow: From Raw Data to Science Fair

### Phase 1: Data Collection (Your Research)

**Where to get datasets**:
- **GEO (Gene Expression Omnibus)**: https://www.ncbi.nlm.nih.gov/geo/
- **Load public datasets** using your pipeline's auto_run_pipeline.py
- **Your own datasets**: RNA-seq counts + sample metadata

**Format needed**:
- Counts: gene_id × samples (tab-delimited)
- Metadata: sample_id with disease condition column

Example:
```
# counts.txt
gene_id sample1 sample2 sample3
ENSG001 100 50 200
ENSG002 500 450 600

# metadata.txt
sample condition
sample1 Disease
sample2 Control
sample3 Disease
```

### Phase 2: Dataset Configuration

1. **Get your data** (download from GEO or extract from files)
2. **Create directory structure**:
 ```
 data/
 ├── alzheimers_human/
 │ ├── counts.txt
 │ └── metadata.txt
 ├── parkinsons_human/
 │ ├── counts.txt
 │ └── metadata.txt
 ├── alzheimers_mouse/
 │ ├── counts.txt
 │ └── metadata.txt
 └── ... (more datasets)
 ```

3. **Edit config_datasets.yaml** with all your datasets

### Phase 3: Run Analysis

```bash
cd /Users/austinbautista/ncrna_pipeline
source .venv/bin/activate

# Analyze ALL datasets
python scripts/analyze_biomarkers.py --config config_datasets.yaml --outdir biomarker_results

# Or filter by species:
python scripts/analyze_biomarkers.py --config config_datasets.yaml --species human --outdir human_only

# Or filter by disease:
python scripts/analyze_biomarkers.py --config config_datasets.yaml --disease alzheimers --outdir ads_only
```

### Phase 4: Review Results for Science Fair

**Key Files to Review**:

1. **`top_candidates.csv`**
 - Open in Excel
 - Sort by `biomarker_score` (highest first)
 - Look at `appearances` column (how many datasets show this biomarker)
 - Check `n_diseases` and `n_species` (cross-applicability)

 Example output:
 ```
 gene_id,biomarker_score,appearances,avg_log2fc,n_diseases,n_species
 LINC00174,85.3,4,2.45,2,2
 MIR9876,79.1,3,1.98,1,3
 SNOXA,72.5,2,3.12,3,1
 ```

2. **`PRESENTATION_SUMMARY.txt`**
 - Copy-paste talking points directly into your presentation
 - Top 5 biomarkers with key statistics
 - Disease-specific findings
 - Cross-species conservation patterns

3. **`figures/biomarker_heatmap.png`**
 - Shows which biomarkers are significant in which conditions
 - Green = significant, Red = not significant
 - Perfect for your poster ("Results" section)

4. **`figures/biomarker_overlap.png`**
 - Shows similarity between datasets
 - High overlap = consistent biomarkers across conditions
 - Good for explaining reproducibility

---

## Interpreting Key Metrics

### Biomarker Score (0-100+)

Formula: `Appearances×10 + (1-avg_FDR)×10 + |avg_log2FC|×2 + Consistency×5`

**What it means**:
- **70-80**: Good candidate (reliable, moderate effect)
- **80-90**: Excellent candidate (appears 3+ datasets, consistent)
- **90+**: Outstanding candidate (universal across conditions)

### Appearances

Number of datasets where the biomarker is significant.

**Interpretation**:
- 1: Only in one condition (condition-specific)
- 2: Cross-validated (good evidence)
- 3: Highly reliable (strong candidate)
- 4+: Universal biomarker (best choice)

### n_diseases & n_species

How many different diseases/species show this biomarker.

**Science Fair Talking Point**:
- n_diseases = 2-3: "Works for multiple neurological diseases" ← **Great for translation**
- n_species = 2-3: "Conserved across evolution" ← **Suggests fundamental mechanism**

### Consistency (0-100%)

Whether the biomarker goes in same direction (all up or all down) across datasets.

- **100% consistent**: All datasets show upregulation (or all downregulation)
- **50% mixed**: Sometimes up, sometimes down (less reliable for biomarker)

---

## Science Fair Presentation Strategy

### Poster Organization

**Section 1: Background**
- ncRNAs as emerging biomarkers
- Current challenge: Finding reliable, cross-species biomarkers
- Why this matters: Better disease diagnosis and early treatment

**Section 2: Methods**
- Analyzed RNA-seq from X datasets
- Species: human, mouse, zebrafish
- Diseases: Alzheimer's, Parkinson's, ALS
- Statistical method: Welch t-test + FDR correction
- Biomarker ranking: Cross-dataset consistency

**Section 3: Results** (Use your generated figures!)
- `figures/biomarker_heatmap.png` (shows top biomarkers across conditions)
- `figures/biomarker_overlap.png` (shows dataset similarity)
- Table of top 10 biomarkers with metrics

**Section 4: Conclusion**
- X biomarkers are conserved across species and diseases
- Example: "LINC00174 appears in 4 datasets (human Alzheimer's, mouse Alzheimer's, etc.)"
- Suggests these are strong candidates for clinical validation

### Talking Points

**For judges**:

*"We analyzed ncRNA expression from different species and diseases to find biomarkers that work across conditions. We identified 85 significant ncRNAs, but ranking them by cross-dataset consistency revealed only 12 that appear reliably in multiple datasets—these are our top candidates for clinical development."*

*"LINC00174 is a particularly interesting candidate because it's dysregulated in Alzheimer's disease across human and mouse models, suggesting it might be a fundamental mechanism of neurodegeneration."*

*"Our approach is better than single-dataset analysis because it accounts for biological variability and shows that true biomarkers are reproducible across different organisms and experimental conditions."*

---

## Adding New Datasets

### Quick Guide

1. **Locate dataset** (GEO, or your own RNA-seq)
2. **Extract/download** counts and metadata files
3. **Format** as tab-delimited .txt files
4. **Add entry** to `config_datasets.yaml`:
 ```yaml
 NEW_DATASET_ID:
 species: [human|mouse|zebrafish]
 disease: [alzheimers|parkinsons|als]
 counts_path: path/to/your/counts.txt
 metadata_path: path/to/your/metadata.txt
 group_col: condition
 disease_label: Disease
 control_label: Control
 ```
5. **Run analysis** again - new dataset automatically included!

### Example: Adding a GEO Dataset

```bash
# Download:
python scripts/auto_run_pipeline.py --input GSE_your_dataset.txt.gz

# This creates data files in results/
# Note the paths, add to config_datasets.yaml:

GSE_new:
 species: human
 disease: alzheimers
 counts_path: results/GSE_new/data/GSE_new_counts.txt
 metadata_path: results/GSE_new/data/GSE_new_metadata.txt
 group_col: condition
 disease_label: Disease
 control_label: Control

# Re-run:
python scripts/analyze_biomarkers.py --config config_datasets.yaml
```

---

## Common Questions & Answers

### Q: How many datasets do I need?

**A**: Minimum 2 (shows reproducibility), ideal 3-4 (shows consistency), 5+ is excellent.

### Q: What if I only have one disease?

**A**: That's OK! The system will show:
- Pan-species patterns (conserved across organisms)
- Organism-specific mechanisms (unique to one species)
- Good for understanding how disease works across models

### Q: What if I only have one species?

**A**: That's OK! The system will show:
- Pan-disease patterns (same biomarkers for different diseases)
- Disease-specific mechanisms (unique to each disease)
- Useful for understanding disease relationships

### Q: How do I validate these biomarkers?

**A**: This is your next science fair project!
- Experimental validation (qPCR, Northern blot)
- Literature mining (are these known markers?)
- Functional studies (what do they do?)

---

## Troubleshooting

### Error: "No datasets analyzed successfully"

**Problem**: Config file points to non-existent data files

**Solution**:
1. Check file paths in config_datasets.yaml
2. Verify counts and metadata files exist
3. Use absolute paths if possible
4. Check for typos

### Error: "Only 1 dataset analyzed"

**Problem**: This is not an error! The system works with 1 dataset but can't find conserved biomarkers

**Solution**: Add more datasets to your config

### Heatmap not generated

**Problem**: Less than 2 datasets analyzed

**Solution**: Your analysis is still complete; visualizations require 2+ datasets

---

## Science Fair Judging Rubric

**What judges will assess**:

✅ **Scientific Rigor** (40%)
- Correct statistical methods (Welch t-test ✓, FDR correction ✓)
- Multiple datasets for validation
- Clear hypothesis (conserved biomarkers exist)

✅ **Comprehensiveness** (30%)
- Number of species (human, mouse, zebrafish = 3)
- Number of diseases (Alzheimer's, Parkinson's, ALS = 3)
- Cross-dataset comparison (showing your main insight)

✅ **Innovation** (20%)
- Multi-species approach (not just single study)
- Ranking by consistency (smart metric)
- Clear clinical relevance (real biomarkers)

✅ **Communication** (10%)
- Clear poster and presentation
- Can explain results to non-experts
- Shows you understand the science

---

## Files You'll Use

| File | Purpose |
|------|---------|
| **config_datasets.yaml** | Your dataset configurations |
| **analyze_biomarkers.py** | Main orchestrator (run this!) |
| **pipeline/biomarker_analysis.py** | Cross-dataset comparison logic |
| **biomarker_results/** | Output directory (your science fair data) |

---

## Command Cheat Sheet

```bash
# Full analysis (all datasets)
python scripts/analyze_biomarkers.py --config config_datasets.yaml --outdir biomarker_results

# Only human datasets
python scripts/analyze_biomarkers.py --config config_datasets.yaml --species human --outdir human_analysis

# Only Alzheimer's datasets
python scripts/analyze_biomarkers.py --config config_datasets.yaml --disease alzheimers --outdir ads_analysis

# Top 50 biomarkers (default is 20)
python scripts/analyze_biomarkers.py --config config_datasets.yaml --top-n 50

# Different FDR threshold (default 0.05)
python scripts/analyze_biomarkers.py --config config_datasets.yaml --fdr-threshold 0.01
```

---

## Next Steps

1. **Edit config_datasets.yaml** with your datasets
2. **Run** `python scripts/analyze_biomarkers.py --config config_datasets.yaml`
3. **Review output** in biomarker_results/
4. **Create poster** using generated figures and top_candidates.csv
5. **Practice presentation** explaining why top candidates are promising
6. **Win science fair!** 🏆

---

**Last Updated**: February 2026 
**Quality**: Production-ready for science fair submission
