# Quick Start Guide: Enhanced ncRNA Pipeline v2.0

## What's New

✨ **Dual Method Support**: Choose between fast Welch t-test or rigorous DESeq2
✨ **Auto-Detection**: Automatic group/condition column detection 
✨ **Better Documentation**: Academic-level explanations in code comments
✨ **Robust Error Handling**: Clear messages if data incompatible (e.g., microarray)

---

## Installation Check

```bash
cd /Users/austinbautista/ncrna_pipeline
source .venv/bin/activate
python -c "from pipeline import de_analysis; print('✓ Pipeline ready')"
```

---

## Running Analyses

### Method 1: Automatic (Simplest)

```bash
python scripts/run_pipeline.py \
 --counts results/GSE33000_series_matrix/data/GSE33000_series_matrix_counts.txt \
 --metadata results/GSE33000_series_matrix/data/GSE33000_series_matrix_metadata.txt \
 --outdir results/GSE33000_analysis
```

**What it does**:
- Auto-detects 'condition'/'group' column ✓
- Auto-infers Disease vs Control ✓
- Runs Welch t-test (~1 sec for 20K genes) ✓
- Generates volcano plot + heatmap ✓

---

### Method 2: Explicit Parameters (Recommended for Reproducibility)

```bash
python scripts/run_pipeline.py \
 --counts results/GSE33000_series_matrix/data/GSE33000_series_matrix_counts.txt \
 --metadata results/GSE33000_series_matrix/data/GSE33000_series_matrix_metadata.txt \
 --group_col condition \
 --disease_label Disease \
 --control_label Control \
 --method welch \
 --top_n 100 \
 --outdir results/GSE33000_welch
```

---

### Method 3: DESeq2 (Publication-Quality, Requires R)

```bash
# First: Install R + DESeq2
# In terminal:
# Rscript -e "install.packages('DESeq2')"

python scripts/run_pipeline.py \
 --counts results/GSE33000_series_matrix/data/GSE33000_series_matrix_counts.txt \
 --metadata results/GSE33000_series_matrix/data/GSE33000_series_matrix_metadata.txt \
 --raw_counts results/GSE33000_series_matrix/data/GSE33000_series_matrix_raw.txt \
 --method deseq2 \
 --group_col condition \
 --disease_label Disease \
 --control_label Control \
 --outdir results/GSE33000_deseq2
```

---

## Understanding Results

### CSV Output: `*_differential_results.csv`

Open in Excel or Python. Key columns:

| Column | Meaning | Example |
|--------|---------|---------|
| gene_id | ENSEMBL ID | ENSG00000101347 |
| log2FC | Effect size (higher = bigger change) | -3.45 |
| pvalue | Raw statistical p-value | 0.000012 |
| fdr | Adjusted p-value (FDR < 0.05 = significant) | 0.0012 |
| significant | TRUE = likely real discovery | True |
| gene_name | Human-readable name | LINC00174 |
| biotype | RNA type | lncRNA |

**How to interpret**:
- **Positive log2FC** → Upregulated in disease group
- **Negative log2FC** → Downregulated in disease group
- **FDR < 0.05** → Statistically significant (after correcting for multiple testing)
- **FDR 0.05-0.10** → Suggestive (borderline significant)
- **FDR > 0.10** → Not significant (likely noise)

---

### Volcano Plot: `*_volcano.png`

Visual summary of all results:

```
 ▲ -log10(FDR)
 │ Red = Significant
 │ (FDR < 0.05)
 0.2 │ ●●●●●
 │ ● ●
 0.1 │ ● ●●● ●
 │ ● ● ●
 0.0 │●──────────●──→ log2(FC)
 └─5 0 5
 
 Left side: Downregulated in disease
 Right side: Upregulated in disease
 Top: Statistically significant
```

---

### Heatmap: `*_top_genes_heatmap.png`

Expression patterns of top 50 genes:

- **Red** = High expression
- **Blue** = Low expression
- **Rows** = Genes (clustered by similarity)
- **Columns** = Samples (grouped by condition if available)

**Good sign**: Clear separation between disease/control blocks

---

## Comparison: Welch vs DESeq2

| Feature | Welch t-test | DESeq2 |
|---------|------|--------|
| Speed | ✓ Fast (1 sec) | ✗ Slow (10-30 sec) |
| Data Type | Log2-CPM | Raw counts |
| Installation | Easy | Requires R 3.6+ |
| Best For | Exploratory screening | Publication-ready |
| Statistical Model | t-distribution | Negative binomial |
| Power (small n) | Good | ✓✓ Better |
| Zero-handling | Built-in pseudocount | Explicit model |

**Recommendation**: 
- Start with **Welch** for quick screening
- Validate top genes with **DESeq2** for publication

---

## Troubleshooting

### Error: "Could not infer two groups from sample names"

**Cause**: Metadata column has no clear disease/control pattern

**Fix**: Explicitly provide group labels:
```bash
python scripts/run_pipeline.py ... \
 --group_col treatment \
 --disease_label Alzheimer \
 --control_label Healthy
```

### Error: "Need at least 2 samples per group"

**Cause**: Fewer than 2 samples in one condition

**Fix**: Ensure metadata has:
```
sample,condition
GSM1,Disease
GSM2,Disease
GSM3,Control
GSM4,Control
```

### Error: "No matching samples between expression matrix and metadata"

**Cause**: Sample names don't match between counts and metadata

**Fix**: Check case sensitivity and format:
```bash
# Print sample names:
head -c 200 counts.txt | cut -f1
head metadata.txt

# They should match exactly
```

### Heatmap Takes Too Long / Memory Error

**Cause**: Too many genes or samples

**Fix**:
```bash
# Reduce to top 10 genes instead of 50
python scripts/run_pipeline.py ... --top_n 10

# Or skip heatmap entirely and focus on CSV results
```

### DESeq2 "ImportError: No module named rpy2"

**Cause**: rpy2 not installed

**Fix**:
```bash
pip install rpy2

# Also ensure R + DESeq2:
Rscript -e "install.packages('DESeq2')"
```

---

## For Academic Presentations

### Key Findings to Report

1. **Number of genes analyzed**: (e.g., "After filtering to 18,453 non-coding genes...")
2. **Statistical method**: (e.g., "Welch t-test with Benjamini-Hochberg FDR correction, α=0.05")
3. **Significant genes**: (e.g., "Identified 247 significantly dysregulated ncRNAs")
4. **Top candidate**: (e.g., "LINC00174 was the most significantly upregulated (log2FC=-3.45, FDR=0.0012)")
5. **Validation**: (e.g., "Findings validated with DESeq2; 89% overlap in significant genes")

### Manuscript Template

> "Differential expression analysis was performed using Welch's t-test (unequal variances) on log₂-CPM normalized counts. P-values were corrected for multiple testing using Benjamini-Hochberg FDR at α = 0.05. Genes were considered significant if FDR < 0.05. We identified [X] significantly differentially expressed ncRNAs. Results were validated using DESeq2 negative binomial models on raw counts."

---

## File Structure After Analysis

```
results/
└── GSE33000_analysis/
 ├── data/
 │ ├── GSE33000_series_matrix_counts.txt
 │ └── GSE33000_series_matrix_metadata.txt
 ├── per_dataset/
 │ ├── GSE33000_differential_results.csv ← Main results
 │ ├── GSE33000_volcano.png ← Volcano plot
 │ └── GSE33000_top_genes_heatmap.png ← Heatmap
 ├── conserved_ncrnas/
 └── figures/
```

---

## Next Steps

1. **Analyze your data**:
 ```bash
 python scripts/run_pipeline.py --counts data/counts.txt --metadata data/meta.txt --outdir my_results
 ```

2. **Review results**:
 - Open `*_differential_results.csv` in Excel
 - Sort by FDR (lowest first) for most confident discoveries
 - Review top 10 genes for biological relevance

3. **Validate findings**:
 - Compare results across different datasets (if available)
 - Spot-check top genes via qPCR or literature
 - Rerun with DESeq2 for publication-quality results

4. **Visualize**:
 - Use volcano plots for presentations
 - Use heatmaps for methods/results figures
 - Export gene lists for pathway analysis

---

## For Detailed Statistical Theory

See **DE_ANALYSIS_GUIDE.md** for:
- Mathematical derivations of Welch t-test and DESeq2
- FDR correction explanation with examples
- Troubleshooting common statistical issues
- References to original papers

---

**Last Updated**: February 2026 
**Main Files Modified**:
- `pipeline/de_analysis.py` – Dual method implementation
- `run_pipeline.py` – CLI with method selection
- `auto_run_pipeline.py` – Automation with method support
