# Installation & Setup Guide

## Prerequisites

- **Python 3.8+** (3.9+ recommended)
- **macOS/Linux/Windows with Python environment manager**
- ~500 MB disk space for dependencies

## Option 1: Automatic Setup (Recommended)

If you have VS Code with an AI agent:

1. The agent will create a virtual environment automatically
2. Dependencies will be installed
3. Pipeline will be tested with example data

**Status**: ✅ Already done for you

Your environment is at: `/Users/austinbautista/ncrna_pipeline/.venv`

To use in any terminal:
```bash
source /Users/austinbautista/ncrna_pipeline/.venv/bin/activate
```

## Option 2: Manual Setup

If you need to recreate or extend the environment:

### Step 1: Create virtual environment
```bash
cd /Users/austinbautista/ncrna_pipeline
python3 -m venv .venv
source .venv/bin/activate
```

### Step 2: Install dependencies
```bash
pip install --upgrade pip
pip install -r requirements.txt
```

### Step 3: Verify installation
```bash
python tests/test_pipeline.py
```

Expected output:
```
✓ All dependencies installed!
✓ Tested 20 genes
✓ Found X significant genes (FDR < 0.05)
✓ TEST PASSED - Pipeline is working!
```

## Dependency Details

### Core Dependencies (Required)
- **pandas**: Data manipulation
- **numpy**: Numerical computing
- **scipy**: Scientific computing (t-tests)
- **statsmodels**: Statistical analysis (FDR correction)
- **matplotlib**: Plotting backend
- **seaborn**: Statistical visualization
- **scikit-learn**: Machine learning utilities

### Optional Dependencies
- **GEOparse**: Download datasets from Gene Expression Omnibus (GEO)
- **synapseclient**: Download datasets from Synapse (not fully implemented)
- **upsetplot**: Generate UpSet intersection plots

Install all with: `pip install -r requirements.txt`

## Updating Packages

To update all packages:
```bash
source .venv/bin/activate
pip install --upgrade pip
pip install --upgrade -r requirements.txt
```

To update a single package:
```bash
pip install --upgrade pandas
```

## Troubleshooting

### "Command not found: python"

**Problem**: `python` command doesn't exist on your system

**Solution**: Use `python3` explicitly or activate the virtual environment:
```bash
source .venv/bin/activate
python --version # Should show Python 3.9.6 or similar
```

### ImportError for missing packages

**Problem**: `ModuleNotFoundError: No module named 'pandas'`

**Solution**: 
```bash
source .venv/bin/activate
pip install pandas
# Or reinstall all:
pip install -r requirements.txt
```

### Permission denied errors

**Problem**: `Permission denied` when running scripts

**Solution**: 
```bash
chmod +x run_pipeline.py tests/test_pipeline.py
```

### Slow GEOparse downloads

**Problem**: `GEOparse` takes a very long time to download data

**Solution**: 
- This is normal for large datasets (can take 5-30 minutes)
- You can download manually and provide local files instead:
```bash
python scripts/run_pipeline.py \
 --counts local_counts.csv \
 --metadata local_metadata.csv \
 --outdir results
```

## Environment Variables (Advanced)

For per-dataset analysis with multiple GEO datasets:
```bash
export BIOTYPE_KEYWORDS="lncrna,mirna,snorna" # Customize RNA types
export LOG2_PSEUDOCOUNT=0.5 # Adjust CPM pseudocount
```

## Uninstalling / Cleanup

To remove the virtual environment:
```bash
rm -rf /Users/austinbautista/ncrna_pipeline/.venv
```

To remove all analysis results:
```bash
rm -rf /Users/austinbautista/ncrna_pipeline/results/
rm -rf /Users/austinbautista/ncrna_pipeline/test_results/
```

## System Specifications

Tested on:
- macOS 10.15+ (Catalina, Big Sur, Monterey, Ventura)
- Ubuntu 18.04+
- Python 3.8, 3.9, 3.10, 3.11

## Getting Help

1. Run the test suite: `python tests/test_pipeline.py`
2. Check [QUICKSTART.md](QUICKSTART.md) for usage examples
3. Review [../README.md](../README.md) for architecture
4. Check `.github/copilot-instructions.md` for development guidelines
