# Phase 2 ncRNA Validation Framework Summary

## Scientific Caution
Findings represent statistical association and predictive performance only.
No causal biological effect is inferred from this dry-lab analysis alone.

## External Validation Overview
dataset_id    disease                role  panel_genes_present  panel_genes_tested
 GSE203206 alzheimers external_validation                    5                   5
  GSE48350 alzheimers external_validation                    3                   5
 GSE124439        als external_validation                    5                   5

## External Replication (Fixed ncRNA Panel)
    gene_id  datasets_present  datasets_total  mean_log2FC  median_log2FC  min_fdr  presence_rate
     GUSBP1                 3               3    -0.224317      -0.170181 0.000034       1.000000
       MEG9                 3               3    -0.504540      -0.415888 0.000011       1.000000
SLC12A5-AS1                 2               3     0.059368       0.059368 0.004487       0.666667
     STRCP1                 2               3    -0.455771      -0.455771 0.004487       0.666667
  ZMIZ1-AS1                 3               3    -0.307785      -0.437272 0.000720       1.000000

## Model Comparison
                          model      auc  accuracy  precision   recall       f1  sensitivity  specificity  fold  n_features  auc_ci_low  auc_ci_high
         A_logistic_fixed_panel 0.879572  0.850701   0.897675 0.834094 0.864067     0.834094     0.872727   2.0         5.0    0.855943     0.897191
          B_svm_rbf_fixed_panel 0.866317  0.848138   0.880929 0.847983 0.863438     0.847983     0.848485   2.0         5.0    0.851907     0.875829
    C_random_forest_fixed_panel 0.879476  0.808850   0.829378 0.843354 0.833395     0.843354     0.763636   2.0         5.0    0.846078     0.902554
D_gradient_boosting_fixed_panel 0.863783  0.798372   0.831958 0.815703 0.820895     0.815703     0.775758   2.0         5.0    0.839045     0.880534

## Panel vs Baselines Across Datasets
                 scenario           feature_set      auc  accuracy       f1  sensitivity  specificity
                pooled_cv       top_de_baseline 0.905760  0.848138 0.862907     0.843354     0.854545
                pooled_cv           fixed_panel 0.879233  0.848138 0.863438     0.847983     0.848485
                pooled_cv random_genes_baseline 0.863036  0.830867 0.845779          NaN          NaN
train_als_test_alzheimers random_genes_baseline 0.542033  0.534545 0.236211          NaN          NaN
train_als_test_alzheimers           fixed_panel 0.525901  0.686364 0.258065     0.166667     0.939189
train_als_test_alzheimers       top_de_baseline 0.261449  0.295455 0.444444     0.861111     0.020270
train_alzheimers_test_als       top_de_baseline 0.625963  0.895062 0.944625     1.000000     0.000000
train_alzheimers_test_als random_genes_baseline 0.552921  0.804012 0.843828          NaN          NaN
train_alzheimers_test_als           fixed_panel 0.507911  0.888889 0.941176     0.993103     0.000000

## Robustness
### Seed stability
 seed  auc_mean  auc_std
    1  0.883189 0.058424
    7  0.888055 0.019946
   21  0.886450 0.027101
   42  0.879224 0.037817
   84  0.881556 0.052006
  123  0.885358 0.027576

### Class imbalance
class_weight  auc_mean  auc_std
        None  0.880476 0.036433
    balanced  0.879224 0.037817

### Permutation test
 observed_auc  mean_permuted_auc  permutation_pvalue  n_permutations
     0.879224           0.510417            0.019608              50

## Cross-Disease Framework Summary
   disease     gene_id  mean_log2FC  mean_fdr  n_datasets
       als      GUSBP1     0.205003  0.014456           1
       als        MEG9    -0.415888  0.004487           1
       als SLC12A5-AS1    -0.171534  0.004487           1
       als      STRCP1    -0.331162  0.004487           1
       als   ZMIZ1-AS1    -0.437272  0.000720           1
alzheimers      GUSBP1    -0.438977  0.028441           2
alzheimers        MEG9    -0.548866  0.245138           2
alzheimers SLC12A5-AS1     0.290271  0.022447           1
alzheimers      STRCP1    -0.580380  0.009801           1
alzheimers   ZMIZ1-AS1    -0.243042  0.085255           2

## Limitations
- Public cohorts can contain technical and clinical heterogeneity.
- Postmortem tissue may introduce RNA quality effects.
- Target/pathway interpretation depends on external mapping resources.
- External replication confirms consistency, not causality.