#!/usr/bin/env python3
"""
Test script for ncRNA pipeline.

Verifies that dependencies are installed and pipeline works with example data.

Usage:
 python tests/test_pipeline.py
"""
import sys
import os
from pathlib import Path

# Add parent directory to path so we can import pipeline module
sys.path.insert(0, str(Path(__file__).parent.parent))

def check_dependencies():
 """Check if all required packages are installed."""
 print("\n" + "=" * 60)
 print(" Checking Dependencies")
 print("=" * 60)

 required = {
 'pandas': 'pandas',
 'numpy': 'numpy',
 'scipy': 'scipy',
 'statsmodels': 'statsmodels',
 'sklearn': 'scikit-learn',
 'matplotlib': 'matplotlib',
 'seaborn': 'seaborn',
 }

 missing = []
 for import_name, package_name in required.items():
 try:
 __import__(import_name)
 print(f"✓ {package_name}")
 except ImportError:
 print(f"✗ {package_name}")
 missing.append(package_name)

 if missing:
 print(f"\n❌ Missing: {', '.join(missing)}")
 print("\nFix with: pip install -r requirements.txt")
 return False

 print("\n✓ All dependencies installed!")
 return True


def test_pipeline():
 """Run pipeline with example data."""
 print("\n" + "=" * 60)
 print(" Running Pipeline with Example Data")
 print("=" * 60 + "\n")

 try:
 from pipeline import io, processing, de_analysis, visualization
 from pathlib import Path

 # Load example data
 data_dir = Path("examples/data")
 counts_path = str(data_dir / "example_expression_matrix.csv")
 metadata_path = str(data_dir / "example_metadata.csv")

 print(f"Loading counts from {counts_path}...")
 counts = io.load_counts(counts_path)
 print(f" ✓ Loaded {counts.shape[0]} genes, {counts.shape[1]} samples")

 print(f"\nLoading metadata from {metadata_path}...")
 metadata = io.load_metadata(metadata_path, group_col='Condition')
 print(f" ✓ Loaded metadata for {metadata.shape[0]} samples")

 print("\nNormalizing to log2-CPM...")
 logcpm = processing.log2_cpm(counts)
 print(f" ✓ Normalized data shape: {logcpm.shape}")

 print("\nRunning differential expression analysis...")
 results = de_analysis.differential_expression(
 logcpm, metadata, 'Condition', 'Disease', 'Control'
 )
 results = de_analysis.adjust_pvalues(results)
 print(f" ✓ Tested {results.shape[0]} genes")
 sig_genes = (results['fdr'] < 0.05).sum()
 print(f" ✓ Found {sig_genes} significant genes (FDR < 0.05)")

 print("\nGenerating volcano plot...")
 outdir = Path("test_results")
 outdir.mkdir(exist_ok=True)
 volcano_out = str(outdir / "volcano_plot.png")
 visualization.volcano_plot(results, volcano_out, title="Example Analysis")
 print(f" ✓ Saved to {volcano_out}")

 print("\n" + "=" * 60)
 print(" ✓ TEST PASSED - Pipeline is working!")
 print("=" * 60 + "\n")
 return True

 except Exception as e:
 print(f"\n❌ TEST FAILED: {e}")
 import traceback
 traceback.print_exc()
 return False


if __name__ == "__main__":
 if not check_dependencies():
 sys.exit(1)

 if not test_pipeline():
 sys.exit(1)

 print("Ready to use! Try:")
 print(" python run_pipeline.py --counts examples/data/example_expression_matrix.csv \\")
 print(" --metadata examples/data/example_metadata.csv \\")
 print(" --outdir results")
