#!/bin/bash
# Quick setup script for ncRNA pipeline environment

set -e

PIPELINE_DIR="/Users/austinbautista/ncrna_pipeline"
VENV_PATH="$PIPELINE_DIR/.venv"

echo "═══════════════════════════════════════════════════════════"
echo " ncRNA Pipeline Environment Setup"
echo "═══════════════════════════════════════════════════════════"
echo ""

# Check if venv exists
if [ ! -d "$VENV_PATH" ]; then
 echo "📦 Creating virtual environment..."
 cd "$PIPELINE_DIR"
 python3 -m venv .venv
 echo "✓ Virtual environment created"
else
 echo "✓ Virtual environment already exists"
fi

echo ""
echo "🔧 Activating environment..."
source "$VENV_PATH/bin/activate"
echo "✓ Environment activated"

echo ""
echo "📚 Installed packages:"
pip list | grep -E "pandas|numpy|scipy|statsmodels|matplotlib|seaborn|GEOparse|upsetplot"

echo ""
echo "═══════════════════════════════════════════════════════════"
echo "✅ Ready to use! You can now run:"
echo ""
echo " python scripts/run_pipeline.py --help"
echo " python tests/test_pipeline.py"
echo ""
echo "Or try the example:"
echo " python scripts/run_pipeline.py \\\"
echo " --counts examples/data/example_expression_matrix.csv \\\"
echo " --metadata examples/data/example_metadata.csv \\\"
echo " --group_col Condition \\\"
echo " --disease_label Disease \\\"
echo " --control_label Control \\\"
echo " --outdir results/demo"
echo ""
echo "═══════════════════════════════════════════════════════════"
