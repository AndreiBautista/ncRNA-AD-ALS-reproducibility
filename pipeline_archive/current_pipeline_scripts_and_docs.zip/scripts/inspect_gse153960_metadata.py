#!/usr/bin/env python3
"""Inspect GSE153960 GEO metadata for sample group labels."""

from collections import Counter
from pathlib import Path
import logging

import GEOparse


def main():
 logging.getLogger("GEOparse").setLevel(logging.WARNING)

 out_dir = Path("data/neurodegenerative_diseases/als/GSE153960/geo")
 out_dir.mkdir(parents=True, exist_ok=True)

 gse = GEOparse.get_GEO("GSE153960", destdir=str(out_dir), annotate_gpl=False)

 records = []
 for gsm_name, gsm in gse.gsms.items():
 chars = gsm.metadata.get("characteristics_ch1", [])
 group = None
 sample_alt = None
 for c in chars:
 c_lower = c.lower()
 if c_lower.startswith("group:"):
 group = c.split(":", 1)[1].strip()
 if c_lower.startswith("sample id alt:"):
 sample_alt = c.split(":", 1)[1].strip()
 records.append((gsm_name, sample_alt, group))

 missing_alt = sum(1 for r in records if not r[1])
 missing_group = sum(1 for r in records if not r[2])
 print("Total GSMs:", len(records))
 print("Missing sample id alt:", missing_alt)
 print("Missing group:", missing_group)

 counter = Counter([r[2] for r in records if r[2]])
 print("Group value counts (top 15):")
 for val, cnt in counter.most_common(15):
 print(f"- {val}: {cnt}")

 print("\nExample mappings:")
 shown = 0
 for gsm, alt, group in records:
 if alt and group:
 print(gsm, "->", alt, "|", group)
 shown += 1
 if shown >= 5:
 break


if __name__ == "__main__":
 main()
