#!/bin/bash
# Complete Biomarker Discovery Workflow
# For Alzheimer's Disease ncRNA Biomarkers

echo "=========================================="
echo "ncRNA BIOMARKER DISCOVERY PIPELINE"
echo "=========================================="
echo ""

# Setup
cd /Users/austinbautista/ncrna_pipeline
source .venv/bin/activate

# Create output directory
mkdir -p results/alzheimers_biomarker_discovery

echo "Step 1: Downloading datasets from GEO..."
echo "------------------------------------------"

# Dataset 1: Brain tissue
echo "Analyzing GSE33000 (Brain tissue)..."
python scripts/geo_integration.py \
 --geo_id GSE33000 \
 --annotation data/annotations/human.gtf \
 --outdir results/alzheimers_biomarker_discovery/GSE33000_brain

# Dataset 2: Another brain cohort
echo "Analyzing GSE5281 (Independent cohort)..."
python scripts/geo_integration.py \
 --geo_id GSE5281 \
 --annotation data/annotations/human.gtf \
 --outdir results/alzheimers_biomarker_discovery/GSE5281_brain

# Dataset 3: Blood samples (if available)
echo "Analyzing GSE63060 (Blood samples)..."
python scripts/geo_integration.py \
 --geo_id GSE63060 \
 --annotation data/annotations/human.gtf \
 --outdir results/alzheimers_biomarker_discovery/GSE63060_blood

echo ""
echo "Step 2: Cross-dataset validation..."
echo "------------------------------------------"

# Find shared biomarkers
python scripts/analyze_biomarkers.py \
 --root results/alzheimers_biomarker_discovery \
 --outdir results/alzheimers_biomarker_discovery/validated_biomarkers

echo ""
echo "Step 3: Generate presentation summary..."
echo "------------------------------------------"

python scripts/generate_presentation_summary.py \
 --root results/alzheimers_biomarker_discovery \
 --outdir results/alzheimers_biomarker_discovery

echo ""
echo "=========================================="
echo "✓ BIOMARKER DISCOVERY COMPLETE!"
echo "=========================================="
echo ""
echo "Results saved to: results/alzheimers_biomarker_discovery/"
echo ""
echo "Key files to review:"
echo " 1. Validated biomarkers:"
echo " results/alzheimers_biomarker_discovery/validated_biomarkers/data/shared_genes_all_datasets_by_id.csv"
echo ""
echo " 2. Overlap heatmap:"
echo " results/alzheimers_biomarker_discovery/validated_biomarkers/figures/overlap_heatmap_by_id.png"
echo ""
echo " 3. Full report:"
echo " results/alzheimers_biomarker_discovery/validated_biomarkers/biomarker_report.txt"
echo ""
echo " 4. Presentation summary:"
echo " results/alzheimers_biomarker_discovery/PRESENTATION_SUMMARY.txt"
echo ""
echo "Open results folder:"
echo " open results/alzheimers_biomarker_discovery/"
echo ""
