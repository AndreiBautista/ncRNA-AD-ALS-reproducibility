#!/usr/bin/env python3
"""
Harmonization pipeline: Convert all gene IDs to Ensembl format and merge within-disease datasets.

This script:
1. Detects gene ID format in each dataset
2. Creates mappings to Ensembl IDs using available resources
3. Harmonizes all datasets to use Ensembl IDs
4. Merges datasets within each disease (keeping only common genes)
5. Saves merged count matrices for downstream analysis
"""

import pandas as pd
import numpy as np
from pathlib import Path
import gzip
import re
import json

# Configuration
ALZHEIMERS_DATASETS = {
 'GSE203206': ('data/neurodegenerative_diseases/alzheimers/GSE203206', 'counts.tsv'),
 'GSE173955': ('data/neurodegenerative_diseases/alzheimers/GSE173955', 'counts.txt'),
 'GSE48350': ('data/neurodegenerative_diseases/alzheimers/GSE48350', 'counts.txt'),
}

ALS_DATASETS = {
 'GSE76220': ('data/neurodegenerative_diseases/als/GSE76220', 'counts.txt'),
 'GSE153960': ('data/neurodegenerative_diseases/als/GSE153960', 'counts.txt'),
}

ANNOTATION_FILE = 'data/annotations/Homo_sapiens.GRCh38.110_annotation.csv'
OUTPUT_DIR = Path('data/harmonized_datasets')


class GeneIDMapper:
 """Maps various gene IDs to Ensembl gene IDs."""
 
 def __init__(self, annotation_file):
 """Load annotation file and build mapping tables."""
 self.annot = pd.read_csv(annotation_file)
 
 # Build Ensembl ID → gene info mappings
 self.ensembl_to_info = {}
 self.gene_symbol_to_ensembl = {}
 
 for _, row in self.annot.iterrows():
 if pd.notna(row['gene_id']) and row['gene_id'] != '':
 self.ensembl_to_info[row['gene_id']] = row.to_dict()
 
 # Map gene symbols to Ensembl IDs
 if pd.notna(row['gene_name']) and row['gene_name'] != '':
 self.gene_symbol_to_ensembl[row['gene_name']] = row['gene_id']
 
 # Load Affy probe mappings if available
 self.affy_to_ensembl = self._load_affy_mappings()
 
 # Load Entrez ID mappings if available
 self.entrez_to_ensembl = self._load_entrez_mappings()
 
 print(f"✓ Loaded {len(self.ensembl_to_info)} Ensembl IDs")
 print(f"✓ Loaded {len(self.gene_symbol_to_ensembl)} gene symbol mappings")
 print(f"✓ Loaded {len(self.affy_to_ensembl)} Affy probe mappings")
 print(f"✓ Loaded {len(self.entrez_to_ensembl)} Entrez ID mappings")
 
 def _load_affy_mappings(self):
 """Load Affy probe to Ensembl mappings from biomaRt file if available."""
 mapping = {}
 biomart_file = Path('data/annotations/affy_mappings.csv')
 
 if biomart_file.exists():
 try:
 df = pd.read_csv(biomart_file)
 if 'affy_id' in df.columns and 'ensembl_gene_id' in df.columns:
 mapping = dict(zip(df['affy_id'], df['ensembl_gene_id']))
 print(f" Loaded Affy mappings from {biomart_file.name}")
 except Exception as e:
 print(f" ⚠ Could not load Affy mappings: {e}")
 
 return mapping
 
 def _load_entrez_mappings(self):
 """Load Entrez ID to Ensembl mappings from file if available."""
 mapping = {}
 entrez_file = Path('data/annotations/entrez_to_ensembl.csv')
 
 if entrez_file.exists():
 try:
 df = pd.read_csv(entrez_file)
 if 'entrez_id' in df.columns and 'ensembl_gene_id' in df.columns:
 mapping = dict(zip(df['entrez_id'].astype(str), df['ensembl_gene_id']))
 print(f" Loaded Entrez mappings from {entrez_file.name}")
 except Exception as e:
 print(f" ⚠ Could not load Entrez mappings: {e}")
 
 return mapping
 
 def detect_id_format(self, genes):
 """Detect gene ID format in a list of gene IDs."""
 sample = [g for g in genes if pd.notna(g) and g != ''][:1000]
 if not sample:
 return 'unknown'
 
 # Check Ensembl format (ENSG000000...)
 ensembl_pattern = re.compile(r'^ENSG\d{11}')
 ensembl_count = sum(1 for g in sample if ensembl_pattern.match(str(g)))
 
 # Check Affy format (####_at/_s_at/etc)
 affy_pattern = re.compile(r'^\d+_(at|s_at|x_at)$')
 affy_count = sum(1 for g in sample if affy_pattern.match(str(g)))
 
 # Check Entrez format (numeric)
 entrez_count = sum(1 for g in sample if str(g).isdigit())
 
 # Check gene symbol format (common pattern: starts with letter, alphanumeric)
 symbol_count = sum(1 for g in sample if isinstance(g, str) and g[0].isalpha())
 
 scores = {
 'ensembl': ensembl_count / len(sample) if ensembl_count > 0 else 0,
 'affy': affy_count / len(sample) if affy_count > 0 else 0,
 'entrez': entrez_count / len(sample) if entrez_count > 0 else 0,
 'symbol': symbol_count / len(sample) if symbol_count > 0 else 0
 }
 
 best_format = max(scores, key=scores.get)
 confidence = scores[best_format]
 
 return best_format, confidence
 
 def map_genes(self, genes, format_type):
 """Map gene IDs to Ensembl IDs based on detected format."""
 ensembl_ids = []
 unmapped = 0
 
 for gene in genes:
 gene = str(gene).strip() if pd.notna(gene) else ''
 ensembl_id = None
 
 if format_type == 'ensembl':
 # Check if already Ensembl (with or without version)
 base_id = gene.split('.')[0] if '.' in gene else gene
 if base_id in self.ensembl_to_info:
 ensembl_id = base_id
 
 elif format_type == 'affy':
 # Use Affy mapping
 if gene in self.affy_to_ensembl:
 ensembl_id = self.affy_to_ensembl[gene]
 
 elif format_type == 'entrez':
 # Use Entrez mapping
 if gene in self.entrez_to_ensembl:
 ensembl_id = self.entrez_to_ensembl[gene]
 
 elif format_type == 'symbol':
 # Use gene symbol mapping
 if gene in self.gene_symbol_to_ensembl:
 ensembl_id = self.gene_symbol_to_ensembl[gene]
 
 if ensembl_id:
 ensembl_ids.append(ensembl_id)
 else:
 unmapped += 1
 ensembl_ids.append(None)
 
 mapping_rate = (len(ensembl_ids) - unmapped) / len(ensembl_ids) if ensembl_ids else 0
 print(f" Mapped {len(ensembl_ids) - unmapped}/{len(ensembl_ids)} genes ({mapping_rate*100:.1f}%)")
 
 return ensembl_ids


def load_harmonize_dataset(gse_id, dataset_dir, counts_file, mapper):
 """Load a dataset and harmonize gene IDs to Ensembl."""
 counts_path = Path(dataset_dir) / counts_file
 
 print(f"\n Loading {gse_id}...")
 
 # Load counts
 try:
 # Try TSV first, then CSV
 if counts_file.endswith('.tsv'):
 counts_df = pd.read_csv(counts_path, sep='\t', index_col=0)
 else:
 # Try different separators
 for sep in ['\t', ',', ' ']:
 try:
 counts_df = pd.read_csv(counts_path, sep=sep, index_col=0, engine='python')
 if counts_df.shape[1] > 1:
 break
 except:
 continue
 
 # Ensure counts are numeric
 counts_df = counts_df.apply(pd.to_numeric, errors='coerce')
 
 print(f" Shape: {counts_df.shape[0]} genes × {counts_df.shape[1]} samples")
 
 # Detect ID format
 id_format, confidence = mapper.detect_id_format(counts_df.index)
 print(f" Gene ID format: {id_format} (confidence: {confidence*100:.0f}%)")
 
 # Map to Ensembl
 ensembl_ids = mapper.map_genes(counts_df.index, id_format)
 
 # Create new dataframe with Ensembl IDs
 counts_df['ensembl_id'] = ensembl_ids
 counts_df = counts_df[counts_df['ensembl_id'].notna()].copy()
 
 # Handle duplicate Ensembl IDs (take mean)
 if counts_df.index.duplicated().any():
 print(f" ⚠ {counts_df.index.duplicated().sum()} duplicate entries, aggregating...")
 counts_df = counts_df.groupby('ensembl_id').mean()
 else:
 counts_df = counts_df.set_index('ensembl_id')
 
 counts_df.index.name = 'gene_id'
 
 print(f" Harmonized: {counts_df.shape[0]} genes × {counts_df.shape[1]} samples")
 return counts_df
 
 except Exception as e:
 print(f" ✗ Error loading {gse_id}: {e}")
 return None


def merge_within_disease(datasets_dict, disease_name, mapper):
 """Merge all datasets for a disease, keeping only common genes."""
 print(f"\n{'='*70}")
 print(f"MERGING {disease_name.upper()} DATASETS")
 print(f"{'='*70}")
 
 harmonized = {}
 total_samples_input = 0
 
 # Load and harmonize each dataset
 for gse_id, (dataset_dir, counts_file) in datasets_dict.items():
 counts = load_harmonize_dataset(gse_id, dataset_dir, counts_file, mapper)
 if counts is not None:
 harmonized[gse_id] = counts
 total_samples_input += counts.shape[1]
 
 if len(harmonized) == 0:
 print(f"✗ No datasets loaded for {disease_name}")
 return None
 
 # Find common genes across all datasets
 common_genes = set(harmonized[list(harmonized.keys())[0]].index)
 for counts_df in list(harmonized.values())[1:]:
 common_genes = common_genes.intersection(set(counts_df.index))
 
 print(f"\n Common genes across {len(harmonized)} datasets: {len(common_genes)}")
 
 if len(common_genes) == 0:
 print(f" ⚠ No common genes found!")
 return None
 
 # Filter to common genes and merge
 merged_list = []
 for gse_id, counts_df in harmonized.items():
 merged_list.append(counts_df.loc[list(common_genes)])
 
 # Concatenate along samples axis
 merged_counts = pd.concat(merged_list, axis=1)
 
 print(f" Merged shape: {merged_counts.shape[0]} genes × {merged_counts.shape[1]} samples")
 print(f" (Merged from {len(harmonized)} datasets, {total_samples_input} → {merged_counts.shape[1]} samples)")
 
 return merged_counts


def main():
 """Main harmonization pipeline."""
 print(f"{'='*70}")
 print("GENE ID HARMONIZATION & DATASET MERGING")
 print(f"{'='*70}")
 
 # Create mapper
 print(f"\nLoading annotation...")
 mapper = GeneIDMapper(ANNOTATION_FILE)
 
 # Create output directory
 OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
 
 # Merge Alzheimer's datasets
 ad_merged = merge_within_disease(ALZHEIMERS_DATASETS, "Alzheimer's Disease", mapper)
 if ad_merged is not None:
 ad_output = OUTPUT_DIR / 'alzheimers_merged.csv'
 ad_merged.to_csv(ad_output)
 print(f" ✓ Saved to {ad_output}")
 
 # Merge ALS datasets
 als_merged = merge_within_disease(ALS_DATASETS, "ALS", mapper)
 if als_merged is not None:
 als_output = OUTPUT_DIR / 'als_merged.csv'
 als_merged.to_csv(als_output)
 print(f" ✓ Saved to {als_output}")
 
 # Create metadata
 print(f"\n{'='*70}")
 print("CREATING MERGED METADATA")
 print(f"{'='*70}")
 
 for disease_name, datasets_dict in [("Alzheimer's Disease", ALZHEIMERS_DATASETS), ("ALS", ALS_DATASETS)]:
 merged_meta = []
 
 for gse_id, (dataset_dir, _) in datasets_dict.items():
 meta_path = Path(dataset_dir) / 'metadata.csv'
 if meta_path.exists():
 meta = pd.read_csv(meta_path, index_col=0)
 meta['gse_id'] = gse_id
 merged_meta.append(meta)
 
 if merged_meta:
 merged_meta = pd.concat(merged_meta, axis=0)
 
 output_file = OUTPUT_DIR / f"{disease_name.lower().replace(' ', '_')}_metadata.csv"
 merged_meta.to_csv(output_file)
 print(f" ✓ {disease_name}: {output_file.name} ({merged_meta.shape[0]} samples)")
 
 print(f"\n{'='*70}")
 print("HARMONIZATION COMPLETE")
 print(f"{'='*70}")
 print(f"Output directory: {OUTPUT_DIR}")


if __name__ == '__main__':
 main()
