#!/usr/bin/env python3
"""
Generate visualization plots for Path A Alzheimer's ncRNA biomarker analysis
Creates publication-quality figures for GSE203206 dataset
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.patches import Rectangle
import os

# Set style
sns.set_style("whitegrid")
plt.rcParams['figure.figsize'] = (12, 8)

OUTPUT_DIR = 'results/alzheimers/human/real_datasets_analysis/figures'
BIOMARKER_FILE = 'results/alzheimers/human/real_datasets_analysis/GSE203206_ncrna_biomarkers.csv'
COUNTS_FILE = 'data/alzheimers/human/raw_datasets/GSE203206/counts.tsv'
METADATA_FILE = 'data/alzheimers/human/raw_datasets/GSE203206/metadata.csv'

os.makedirs(OUTPUT_DIR, exist_ok=True)

print("Loading data...")
biomarkers = pd.read_csv(BIOMARKER_FILE, index_col='gene_id')
counts = pd.read_csv(COUNTS_FILE, sep='\t', index_col=0)
metadata = pd.read_csv(METADATA_FILE, index_col=0)

# Convert counts to log2 CPM for plotting
counts = counts.astype(float)
cpm = (counts / counts.sum(axis=0)) * 1e6
log2cpm = np.log2(cpm + 1)

print(f"✓ Loaded {len(biomarkers)} biomarkers")
print(f"✓ Loaded {counts.shape[0]} × {counts.shape[1]} expression matrix")
print(f"✓ Loaded {len(metadata)} samples")

# ============================================================================
# Figure 1: VOLCANO PLOT
# ============================================================================
print("\nCreating volcano plot...")

fig, ax = plt.subplots(figsize=(12, 8))

# All genes in background
all_log2fc = biomarkers['log2FC'].values
all_fdr = biomarkers['fdr'].values
all_neglog10_fdr = -np.log10(all_fdr)

# Color points by significance
colors = ['red' if fdr < 0.01 else 'gray' for fdr in all_fdr]

scatter = ax.scatter(all_log2fc, all_neglog10_fdr, c=colors, alpha=0.6, s=100, edgecolors='black', linewidth=0.5)

# Add threshold lines
ax.axhline(y=-np.log10(0.01), color='blue', linestyle='--', linewidth=2, label='FDR = 0.01')
ax.axvline(x=1.5, color='green', linestyle='--', linewidth=2, label='log2FC = 1.5')
ax.axvline(x=-1.5, color='green', linestyle='--', linewidth=2)

# Label top genes
for gene_id, row in biomarkers.head(10).iterrows():
 gene_name = row['gene_name'] if pd.notna(row['gene_name']) else 'Unknown'
 ax.annotate(gene_name[:15], 
 xy=(row['log2FC'], -np.log10(row['fdr'])),
 xytext=(5, 5), textcoords='offset points',
 fontsize=9, fontweight='bold',
 bbox=dict(boxstyle='round,pad=0.3', facecolor='yellow', alpha=0.7))

ax.set_xlabel('log2(Fold Change)', fontsize=14, fontweight='bold')
ax.set_ylabel('-log10(FDR q-value)', fontsize=14, fontweight='bold')
ax.set_title('Volcano Plot: Alzheimer\'s ncRNA Dysregulation (GSE203206)\n43 Significant Biomarkers (FDR<0.01, |log2FC|>1.5)', 
 fontsize=16, fontweight='bold', pad=20)
ax.legend(fontsize=12, loc='upper right')
ax.grid(True, alpha=0.3)

volcano_file = os.path.join(OUTPUT_DIR, 'GSE203206_volcano_plot.png')
plt.savefig(volcano_file, dpi=300, bbox_inches='tight')
print(f"✓ Saved: {volcano_file}")
plt.close()

# ============================================================================
# Figure 2: TOP 15 GENES - BOX PLOTS
# ============================================================================
print("Creating box plots for top 15 genes...")

top_genes = biomarkers.head(15).index.tolist()
fig, axes = plt.subplots(3, 5, figsize=(20, 12))
axes = axes.flatten()

for i, gene_id in enumerate(top_genes):
 ax = axes[i]
 gene_name = biomarkers.loc[gene_id, 'gene_name']
 gene_name = gene_name if pd.notna(gene_name) else 'Unknown'
 
 # Get expression data
 expr_data = log2cpm.loc[gene_id] if gene_id in log2cpm.index else None
 
 if expr_data is not None:
 disease_expr = expr_data[metadata['condition'] == 'Disease'].values
 control_expr = expr_data[metadata['condition'] == 'Control'].values
 
 # Box plot
 bp = ax.boxplot([disease_expr, control_expr], labels=['AD', 'Control'],
 patch_artist=True, widths=0.6)
 
 # Color boxes
 colors_bp = ['lightcoral', 'lightblue']
 for patch, color in zip(bp['boxes'], colors_bp):
 patch.set_facecolor(color)
 
 # Add points
 x_disease = np.random.normal(1, 0.04, size=len(disease_expr))
 x_control = np.random.normal(2, 0.04, size=len(control_expr))
 ax.scatter(x_disease, disease_expr, alpha=0.6, s=50, color='darkred')
 ax.scatter(x_control, control_expr, alpha=0.6, s=50, color='darkblue')
 
 # Formatting
 ax.set_ylabel('log2(CPM)', fontsize=10, fontweight='bold')
 ax.set_title(f'{gene_name[:20]}\nlog2FC={biomarkers.loc[gene_id, "log2FC"]:.2f}', 
 fontsize=11, fontweight='bold')
 ax.grid(True, alpha=0.3, axis='y')

plt.tight_layout()
boxplot_file = os.path.join(OUTPUT_DIR, 'GSE203206_top15_boxplots.png')
plt.savefig(boxplot_file, dpi=300, bbox_inches='tight')
print(f"✓ Saved: {boxplot_file}")
plt.close()

# ============================================================================
# Figure 3: HEATMAP OF TOP 20 BIOMARKERS
# ============================================================================
print("Creating heatmap...")

top_20 = biomarkers.head(20).index.tolist()
heatmap_data = log2cpm.loc[top_20].copy()

# Normalize by row (z-score)
heatmap_data_norm = heatmap_data.apply(lambda x: (x - x.mean()) / x.std(), axis=1)

# Sort columns by disease/control status for better visualization
disease_samples = metadata[metadata['condition'] == 'Disease'].index.tolist()
control_samples = metadata[metadata['condition'] == 'Control'].index.tolist()
heatmap_data_norm = heatmap_data_norm[disease_samples + control_samples]

# Create heatmap
fig, ax = plt.subplots(figsize=(16, 10))

# Create color map
sns.heatmap(heatmap_data_norm, cmap='RdBu_r', center=0, 
 xticklabels=False, yticklabels=True,
 cbar_kws={'label': 'Z-score normalized\nexpression'},
 ax=ax, linewidths=0.5, linecolor='gray')

# Add labels
gene_labels = []
for gene_id in top_20:
 gene_name = biomarkers.loc[gene_id, 'gene_name']
 if pd.notna(gene_name):
 gene_labels.append(f'{gene_name[:15]}')
 else:
 gene_labels.append(gene_id[:15])

ax.set_yticklabels(gene_labels, rotation=0, fontsize=10)
ax.set_xlabel(f'Samples (Disease n={len(disease_samples)}, Control n={len(control_samples)})', 
 fontsize=12, fontweight='bold')
ax.set_ylabel('Top 20 ncRNA Biomarkers', fontsize=12, fontweight='bold')
ax.set_title('Heatmap: Top 20 ncRNA Biomarkers in Alzheimer\'s\nZ-score Normalized Expression', 
 fontsize=14, fontweight='bold', pad=20)

# Add vertical line between disease and control
ax.axvline(x=len(disease_samples), color='black', linewidth=3)

heatmap_file = os.path.join(OUTPUT_DIR, 'GSE203206_heatmap_top20.png')
plt.savefig(heatmap_file, dpi=300, bbox_inches='tight')
print(f"✓ Saved: {heatmap_file}")
plt.close()

# ============================================================================
# Figure 4: SUMMARY STATISTICS BAR CHART
# ============================================================================
print("Creating summary statistics bar chart...")

fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(14, 10))

# Panel 1: Number of up/down regulated
directions = ['Upregulated\n(log2FC > 0)', 'Downregulated\n(log2FC < 0)']
counts_dir = [len(biomarkers[biomarkers['log2FC'] > 0]), len(biomarkers[biomarkers['log2FC'] < 0])]
colors_dir = ['lightcoral', 'lightblue']
bars1 = ax1.bar(directions, counts_dir, color=colors_dir, edgecolor='black', linewidth=2)
ax1.set_ylabel('Number of Genes', fontsize=12, fontweight='bold')
ax1.set_title('Directional Changes in Alzheimer\'s', fontsize=13, fontweight='bold')
ax1.set_ylim(0, max(counts_dir) * 1.2)
for bar, count in zip(bars1, counts_dir):
 height = bar.get_height()
 ax1.text(bar.get_x() + bar.get_width()/2., height,
 f'{int(count)}', ha='center', va='bottom', fontsize=12, fontweight='bold')
ax1.grid(True, alpha=0.3, axis='y')

# Panel 2: Biotype distribution
biotypes = biomarkers['biotype'].value_counts()
colors_bio = sns.color_palette('Set2', len(biotypes))
bars2 = ax2.barh(biotypes.index, biotypes.values, color=colors_bio, edgecolor='black', linewidth=2)
ax2.set_xlabel('Number of Genes', fontsize=12, fontweight='bold')
ax2.set_title('ncRNA Biotypes Distribution', fontsize=13, fontweight='bold')
for i, (bar, count) in enumerate(zip(bars2, biotypes.values)):
 ax2.text(count, i, f' {int(count)}', va='center', fontsize=11, fontweight='bold')
ax2.grid(True, alpha=0.3, axis='x')

# Panel 3: Fold change distribution
log2fc_range = [-3, -2, -1, 0, 1, 2, 3]
ax3.hist(biomarkers['log2FC'], bins=15, color='skyblue', edgecolor='black', linewidth=1.5)
ax3.axvline(x=1.5, color='green', linestyle='--', linewidth=2, label='Threshold (1.5)')
ax3.axvline(x=-1.5, color='green', linestyle='--', linewidth=2)
ax3.set_xlabel('log2(Fold Change)', fontsize=12, fontweight='bold')
ax3.set_ylabel('Frequency', fontsize=12, fontweight='bold')
ax3.set_title('Distribution of log2 Fold Changes', fontsize=13, fontweight='bold')
ax3.legend(fontsize=11)
ax3.grid(True, alpha=0.3, axis='y')

# Panel 4: P-value distribution
ax4.hist(-np.log10(biomarkers['fdr']), bins=15, color='lightcoral', edgecolor='black', linewidth=1.5)
ax4.axvline(x=-np.log10(0.01), color='blue', linestyle='--', linewidth=2, label='FDR threshold (0.01)')
ax4.set_xlabel('-log10(FDR)', fontsize=12, fontweight='bold')
ax4.set_ylabel('Frequency', fontsize=12, fontweight='bold')
ax4.set_title('Distribution of FDR-Adjusted P-Values', fontsize=13, fontweight='bold')
ax4.legend(fontsize=11)
ax4.grid(True, alpha=0.3, axis='y')

plt.tight_layout()
summary_file = os.path.join(OUTPUT_DIR, 'GSE203206_summary_statistics.png')
plt.savefig(summary_file, dpi=300, bbox_inches='tight')
print(f"✓ Saved: {summary_file}")
plt.close()

# ============================================================================
# Figure 5: TOP 10 GENES RANKED BY P-VALUE
# ============================================================================
print("Creating ranked biomarkers bar chart...")

top_10 = biomarkers.head(10).copy()
top_10['display_name'] = top_10['gene_name'].fillna('Unknown')[:15]

fig, ax = plt.subplots(figsize=(12, 8))

# Create bar chart
y_pos = np.arange(len(top_10))
colors_rank = ['red' if fc > 0 else 'blue' for fc in top_10['log2FC']]

bars = ax.barh(y_pos, -np.log10(top_10['fdr']), color=colors_rank, alpha=0.7, edgecolor='black', linewidth=1.5)

# Customize
ax.set_yticks(y_pos)
ax.set_yticklabels(top_10['display_name'], fontsize=11, fontweight='bold')
ax.set_xlabel('-log10(FDR-adjusted p-value)', fontsize=12, fontweight='bold')
ax.set_title('Top 10 Most Significant ncRNA Biomarkers for Alzheimer\'s', fontsize=14, fontweight='bold', pad=20)
ax.axvline(x=-np.log10(0.01), color='green', linestyle='--', linewidth=2, label='FDR=0.01 threshold')
ax.legend(fontsize=11)
ax.grid(True, alpha=0.3, axis='x')

# Add values on bars
for i, (bar, gene_id) in enumerate(zip(bars, top_10.index)):
 width = bar.get_width()
 log2fc = top_10.loc[gene_id, 'log2FC']
 ax.text(width, bar.get_y() + bar.get_height()/2.,
 f' log2FC={log2fc:.2f}',
 ha='left', va='center', fontsize=10, fontweight='bold')

plt.tight_layout()
ranked_file = os.path.join(OUTPUT_DIR, 'GSE203206_top10_ranked.png')
plt.savefig(ranked_file, dpi=300, bbox_inches='tight')
print(f"✓ Saved: {ranked_file}")
plt.close()

# ============================================================================
# Summary
# ============================================================================
print("\n" + "="*80)
print(" VISUALIZATION GENERATION COMPLETE")
print("="*80)
print(f"\nOutput directory: {OUTPUT_DIR}")
print(f"\nGenerated figures (DPI=300, publication-quality):")
print(f" 1. GSE203206_volcano_plot.png - Main statistical overview")
print(f" 2. GSE203206_top15_boxplots.png - Individual gene comparisons")
print(f" 3. GSE203206_heatmap_top20.png - Expression patterns across samples")
print(f" 4. GSE203206_summary_statistics.png - Statistical distributions")
print(f" 5. GSE203206_top10_ranked.png - Top candidates by significance")
print("\n✅ All visualizations ready for presentation!")
