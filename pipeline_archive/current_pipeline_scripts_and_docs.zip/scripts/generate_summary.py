#!/usr/bin/env python3
"""
Generate comprehensive summary of all analysis results.
"""

import pandas as pd
from pathlib import Path

print("="*80)
print("COMPREHENSIVE ANALYSIS SUMMARY")
print("="*80)

# 1. Dataset Statistics
print("\n" + "="*80)
print("1. DATASET STATISTICS")
print("="*80)

ad_counts = pd.read_csv('data/harmonized_datasets/alzheimers_disease_counts.csv', index_col=0)
als_counts = pd.read_csv('data/harmonized_datasets/als_counts_corrected.csv', index_col=0)
ad_meta = pd.read_csv('data/harmonized_datasets/alzheimers_metadata_corrected.csv', index_col=0)

print(f"\nAlzheimer's Disease (GSE203206):")
print(f" - Total samples: {ad_counts.shape[1]}")
print(f" - Disease samples: {(ad_meta['condition'] == 'Disease').sum()}")
print(f" - Control samples: {(ad_meta['condition'] == 'Control').sum()}")
print(f" - Genes profiled: {ad_counts.shape[0]:,}")
print(f" - Tissue: Occipital lobe")

print(f"\nALS (GSE153960 - NYGC Cohort):")
print(f" - Total samples: {als_counts.shape[1]:,}")
print(f" - Genes profiled: {als_counts.shape[0]:,}")
print(f" - Tissue: Brain (multiple regions)")
print(f" - Note: All ALS cases (no controls in this dataset)")

print(f"\nCombined:")
print(f" - Total samples analyzed: {ad_counts.shape[1] + als_counts.shape[1]:,}")
print(f" - Overlapping genes: 22,221")

# 2. Alzheimer's Disease vs Control Results
print("\n" + "="*80)
print("2. ALZHEIMER'S DISEASE BIOMARKERS")
print("="*80)

ad_biomarkers = pd.read_csv('results/deseq2/alzheimers/ncrna_biomarkers.csv')
print(f"\nSignificant ncRNA biomarkers (FDR < 0.05): {len(ad_biomarkers):,}")
print(f" - Upregulated in AD: {(ad_biomarkers['log2FoldChange'] > 0).sum()}")
print(f" - Downregulated in AD: {(ad_biomarkers['log2FoldChange'] < 0).sum()}")

print(f"\nBiotype distribution (top 5):")
biotype_counts = ad_biomarkers['biotype'].value_counts().head(5)
for biotype, count in biotype_counts.items():
 print(f" - {biotype}: {count}")

print(f"\nTop 5 upregulated ncRNAs:")
top_up = ad_biomarkers[ad_biomarkers['log2FoldChange'] > 0].head(5)
for idx, row in top_up.iterrows():
 gene_name = row['gene_name'] if pd.notna(row['gene_name']) else row['gene_id']
 print(f" • {gene_name:20s} ({row['biotype']:25s}): log2FC={row['log2FoldChange']:5.2f}, padj={row['padj']:.2e}")

print(f"\nTop 5 downregulated ncRNAs:")
top_down = ad_biomarkers[ad_biomarkers['log2FoldChange'] < 0].head(5)
for idx, row in top_down.iterrows():
 gene_name = row['gene_name'] if pd.notna(row['gene_name']) else row['gene_id']
 print(f" • {gene_name:20s} ({row['biotype']:25s}): log2FC={row['log2FoldChange']:5.2f}, padj={row['padj']:.2e}")

# 3. Cross-Disease Results
print("\n" + "="*80)
print("3. CROSS-DISEASE COMPARISON (AD vs ALS)")
print("="*80)

cross_disease = pd.read_csv('results/cross_disease/disease_specific_ncrnas.csv')
print(f"\nDisease-specific ncRNAs (FDR < 0.05): {len(cross_disease):,}")

ad_specific = cross_disease[cross_disease['log2FoldChange_AD_vs_ALS'] > 0]
als_specific = cross_disease[cross_disease['log2FoldChange_AD_vs_ALS'] < 0]

print(f" - Higher in Alzheimer's: {len(ad_specific):,}")
print(f" - Higher in ALS: {len(als_specific):,}")

print(f"\nTop 5 Alzheimer's-specific ncRNAs:")
for idx, row in ad_specific.head(5).iterrows():
 gene_name = row['gene_name'] if pd.notna(row['gene_name']) else row['gene_id']
 print(f" • {gene_name:20s} ({row['biotype']:25s}): log2FC={row['log2FoldChange_AD_vs_ALS']:5.2f}, padj={row['padj']:.2e}")

print(f"\nTop 5 ALS-specific ncRNAs:")
for idx, row in als_specific.head(5).iterrows():
 gene_name = row['gene_name'] if pd.notna(row['gene_name']) else row['gene_id']
 print(f" • {gene_name:20s} ({row['biotype']:25s}): log2FC={row['log2FoldChange_AD_vs_ALS']:5.2f}, padj={row['padj']:.2e}")

# 4. Key Findings
print("\n" + "="*80)
print("4. KEY FINDINGS")
print("="*80)

print("\n✓ Successfully analyzed 2,003 samples across two neurodegenerative diseases")
print("✓ Identified 1,733 ncRNA biomarkers for Alzheimer's Disease")
print("✓ Discovered 5,955 disease-specific ncRNA signatures distinguishing AD from ALS")
print("✓ Found novel lncRNA candidates including TGFB2-OT1, ADGRB3-DT, and LINC01013")
print("✓ Identified snoRNA and miRNA dysregulation patterns unique to each disease")

# 5. Output Files
print("\n" + "="*80)
print("5. OUTPUT FILES")
print("="*80)

output_files = [
 ('results/deseq2/alzheimers/ncrna_biomarkers.csv', 'AD biomarkers (Disease vs Control)'),
 ('results/cross_disease/disease_specific_ncrnas.csv', 'Disease-specific ncRNAs (AD vs ALS)'),
 ('data/harmonized_datasets/alzheimers_disease_counts.csv', 'Harmonized AD counts'),
 ('data/harmonized_datasets/als_counts_corrected.csv', 'Harmonized ALS counts'),
]

for filepath, description in output_files:
 if Path(filepath).exists():
 size = Path(filepath).stat().st_size / 1024 / 1024
 print(f" ✓ {description}")
 print(f" {filepath} ({size:.1f} MB)")

print("\n" + "="*80)
print("ANALYSIS COMPLETE - Ready for publication and presentation!")
print("="*80)
