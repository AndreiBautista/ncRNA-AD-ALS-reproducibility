#!/usr/bin/env python3
"""Generate an -ready report with methods, results, validation, and reproducibility steps."""

from pathlib import Path
import pandas as pd

from pipeline import de_analysis as pipeline_de

BASE_DIR = Path(__file__).resolve().parent.parent
REPORT_PATH = BASE_DIR / "ISEF_REPORT.md"

AD_META_PATH = BASE_DIR / "data" / "alzheimers" / "human" / "raw_datasets" / "GSE203206" / "metadata.csv"
ALS_META_PATH = BASE_DIR / "data" / "neurodegenerative_diseases" / "als" / "GSE124439" / "metadata.csv"

AD_BIO_PATH = BASE_DIR / "results" / "multi_dataset_analysis" / "GSE203206_biomarkers.csv"
ALS_BIO_PATH = BASE_DIR / "results" / "multi_dataset_analysis" / "GSE124439_biomarkers.csv"

AD_STRICT_PATH = BASE_DIR / "results" / "multi_dataset_analysis" / "isef_analysis" / "AD_biomarkers_strict_FDR01_FC1.csv"
ALS_STRICT_PATH = BASE_DIR / "results" / "multi_dataset_analysis" / "isef_analysis" / "ALS_biomarkers_strict_FDR01_FC1.csv"
SHARED_PATH = BASE_DIR / "results" / "multi_dataset_analysis" / "isef_analysis" / "Shared_ncRNAs_AD_ALS.csv"

ROC_PATH = BASE_DIR / "results" / "isef_figures" / "roc_auc_summary.csv"


def get_group_col(metadata: pd.DataFrame, preferred: str = None) -> str:
 if preferred and preferred in metadata.columns:
 return preferred
 try:
 return pipeline_de.detect_group_column(metadata)
 except ValueError:
 for candidate in ['disease_status', 'diagnosis', 'group', 'condition']:
 if candidate in metadata.columns:
 return candidate
 raise


def infer_labels(metadata: pd.DataFrame, group_col: str):
 values = list(metadata[group_col].value_counts().index)
 value_lower = {v: str(v).lower() for v in values}

 disease_keywords = ['disease', 'case', 'treatment', 'affected', 'als', 'ad', 'alzheimer']
 control_keywords = ['control', 'healthy', 'normal']

 disease_label = next((v for v in values if any(k in value_lower[v] for k in disease_keywords)), None)
 control_label = next((v for v in values if any(k in value_lower[v] for k in control_keywords)), None)

 if disease_label is None and control_label is None and len(values) == 2:
 control_label = metadata[group_col].value_counts().idxmin()
 disease_label = [v for v in values if v != control_label][0]
 elif disease_label is None and control_label is not None and len(values) == 2:
 disease_label = [v for v in values if v != control_label][0]
 elif control_label is None and disease_label is not None and len(values) == 2:
 control_label = [v for v in values if v != disease_label][0]

 if disease_label is None or control_label is None:
 disease_label, control_label, _, _ = pipeline_de.validate_groups(metadata, group_col)

 return disease_label, control_label


def fdr_col(df: pd.DataFrame) -> str:
 return 'padj' if 'padj' in df.columns else 'fdr'


def top_genes(df: pd.DataFrame, n: int = 5) -> list:
 col = fdr_col(df)
 sorted_df = df.sort_values(col)
 if 'gene_name' in sorted_df.columns:
 return sorted_df['gene_name'].dropna().head(n).tolist()
 if 'gene_id' in sorted_df.columns:
 return sorted_df['gene_id'].dropna().head(n).tolist()
 return sorted_df.index[:n].tolist()


ad_meta = pd.read_csv(AD_META_PATH, index_col=0)
als_meta = pd.read_csv(ALS_META_PATH, index_col=0)

ad_group_col = get_group_col(ad_meta)
als_group_col = get_group_col(als_meta, preferred='disease_status')

ad_disease, ad_control = infer_labels(ad_meta, ad_group_col)
als_disease, als_control = infer_labels(als_meta, als_group_col)

ad_counts = ad_meta[ad_group_col].value_counts()
als_counts = als_meta[als_group_col].value_counts()

ad_bio = pd.read_csv(AD_BIO_PATH)
als_bio = pd.read_csv(ALS_BIO_PATH)

ad_sig = (ad_bio[fdr_col(ad_bio)] < 0.05).sum()
als_sig = (als_bio[fdr_col(als_bio)] < 0.05).sum()

ad_strict = pd.read_csv(AD_STRICT_PATH) if AD_STRICT_PATH.exists() else pd.DataFrame()
als_strict = pd.read_csv(ALS_STRICT_PATH) if ALS_STRICT_PATH.exists() else pd.DataFrame()

shared = pd.read_csv(SHARED_PATH) if SHARED_PATH.exists() else pd.DataFrame()
shared_count = len(shared)

ad_top = top_genes(ad_bio, n=5)
als_top = top_genes(als_bio, n=5)

roc_summary = pd.read_csv(ROC_PATH) if ROC_PATH.exists() else pd.DataFrame()
roc_ad = roc_summary[roc_summary['dataset'] == 'AD'] if not roc_summary.empty else pd.DataFrame()
roc_als = roc_summary[roc_summary['dataset'] == 'ALS'] if not roc_summary.empty else pd.DataFrame()

ad_auc = f"{roc_ad['auc'].iloc[0]:.3f}" if not roc_ad.empty else "NA"
als_auc = f"{roc_als['auc'].iloc[0]:.3f}" if not roc_als.empty else "NA"

report = f"""# Project Report: ncRNA Biomarkers in AD and ALS

## Methods
- Datasets: AD (GSE203206) and ALS (GSE124439) bulk RNA-seq.
- Preprocessing: counts were normalized to log2-CPM; genes filtered to ncRNAs using annotation keywords.
- Differential expression: Welch two-sample t-test (disease vs control), with Benjamini-Hochberg FDR.
- Significance thresholds: primary FDR < 0.05; strict set uses FDR < 0.01 and |log2FC| > 1.

## Results
- AD samples: {ad_counts.get(ad_disease, 0)} disease, {ad_counts.get(ad_control, 0)} control (group column: {ad_group_col}).
- ALS samples: {als_counts.get(als_disease, 0)} disease, {als_counts.get(als_control, 0)} control (group column: {als_group_col}).
- Significant ncRNAs (FDR < 0.05): AD = {ad_sig}, ALS = {als_sig}.
- Strict ncRNAs (FDR < 0.01 and |log2FC| > 1): AD = {len(ad_strict)}, ALS = {len(als_strict)}.
- Shared ncRNAs between AD and ALS (FDR < 0.05 overlap): {shared_count}.
- Top AD ncRNAs: {', '.join(ad_top)}.
- Top ALS ncRNAs: {', '.join(als_top)}.

## Validation (ROC/AUC)
- AD ROC AUC (top 10 ncRNAs): {ad_auc}.
- ALS ROC AUC (top 10 ncRNAs): {als_auc}.
- ROC plots: results/isef_figures/ad_roc_auc.png and results/isef_figures/als_roc_auc.png.

## Limitations and Future Work
- Results are based on public bulk RNA-seq datasets; cell-type effects are not directly resolved.
- Expression signatures may be dataset- or tissue-specific; replication on independent cohorts is needed.
- Future work: add pathway enrichment, compare with known ncRNA databases, and test a larger multi-disease panel.

## Reproducibility Steps
1. Generate figures and ROC validation:
 - /Users/austinbautista/ncrna_pipeline/.venv/bin/python generate_isef_figures.py
2. Generate this report:
 - /Users/austinbautista/ncrna_pipeline/.venv/bin/python generate_isef_report.py
3. Key outputs:
 - results/isef_figures/ (plots)
 - results/multi_dataset_analysis/isef_analysis/ (strict tables)
"""

REPORT_PATH.write_text(report)
print(f"Report written to {REPORT_PATH}")
