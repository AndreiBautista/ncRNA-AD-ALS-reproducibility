#!/bin/bash
# Simple Biomarker Discovery - Pick Your Datasets
# Edit the GSE IDs below to analyze different datasets

cd /Users/austinbautista/ncrna_pipeline
source .venv/bin/activate

# EDIT THESE 3 LINES - Put your dataset IDs here:
DATASET1="GSE33000" # Replace with your dataset
DATASET2="GSE5281" # Replace with your dataset 
DATASET3="GSE48350" # Replace with your dataset

echo "Analyzing datasets: $DATASET1, $DATASET2, $DATASET3"
echo ""

# Download annotation if needed
if [ ! -f "data/annotations/human.gtf" ]; then
 echo "Downloading annotation..."
 mkdir -p data/annotations
 curl -L -o data/annotations/human.gtf.gz https://ftp.ebi.ac.uk/pub/databases/gencode/Gencode_human/release_44/gencode.v44.annotation.gtf.gz
 gunzip data/annotations/human.gtf.gz
fi

# Analyze each dataset
mkdir -p results/my_biomarkers

echo "Dataset 1: $DATASET1"
python scripts/geo_integration.py \
 --geo_id $DATASET1 \
 --annotation data/annotations/human.gtf \
 --outdir results/my_biomarkers/$DATASET1

echo "Dataset 2: $DATASET2"
python scripts/geo_integration.py \
 --geo_id $DATASET2 \
 --annotation data/annotations/human.gtf \
 --outdir results/my_biomarkers/$DATASET2

echo "Dataset 3: $DATASET3"
python scripts/geo_integration.py \
 --geo_id $DATASET3 \
 --annotation data/annotations/human.gtf \
 --outdir results/my_biomarkers/$DATASET3

# Find shared biomarkers
echo "Finding shared biomarkers..."
python scripts/analyze_biomarkers.py \
 --root results/my_biomarkers \
 --outdir results/my_biomarkers/validated

echo ""
echo "✓ Done! Results in: results/my_biomarkers/validated/data/"
echo ""
echo "View results:"
echo " open results/my_biomarkers/validated/data/"
