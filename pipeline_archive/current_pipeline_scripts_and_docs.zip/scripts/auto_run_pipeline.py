#!/usr/bin/env python3
"""
Auto-run the ncRNA pipeline from a single raw .txt/.txt.gz file.

This script:
1) Detects delimiter and loads the raw table (gz supported)
2) Extracts gene_id + sample columns
3) Creates counts + metadata files
4) Runs the pipeline

Usage example:
 python auto_run_pipeline.py --input GSE33000_raw_data.txt.gz

Optional:
 --annotation path/to/annotation.gtf
 --outdir results/GSE33000
 --group-map path/to/sample_groups.csv
"""
import argparse
import gzip
from pathlib import Path
import re
import sys
import csv
from io import StringIO

import pandas as pd

from run_pipeline import analyze_dataset, ensure_dirs


def _detect_delimiter(file_path: Path) -> str:
 # GEO series_matrix files are tab-delimited inside the table section
 if "series_matrix" in file_path.name.lower():
 return "\t"

 if file_path.suffix == ".gz":
 opener = gzip.open
 mode = "rt"
 else:
 opener = open
 mode = "r"

 with opener(file_path, mode) as handle:
 header = handle.readline().strip("\n")

 if "\t" in header:
 return "\t"

 candidates = ["\t", ",", ";", " "]
 counts = {sep: header.count(sep) for sep in candidates}
 return max(counts, key=counts.get)


def _extract_series_matrix_table(input_path: Path, out_path: Path) -> None:
 if input_path.suffix == ".gz":
 opener = gzip.open
 mode = "rt"
 else:
 opener = open
 mode = "r"

 in_table = False
 wrote = False
 with opener(input_path, mode) as handle, open(out_path, "w", encoding="utf-8") as out:
 for line in handle:
 if line.startswith("!series_matrix_table_begin"):
 in_table = True
 continue
 if line.startswith("!series_matrix_table_end"):
 break
 if in_table:
 out.write(line)
 wrote = True

 if not wrote:
 raise ValueError("Could not find series_matrix table section in file")


def _choose_gene_column(columns):
 lower_map = {c.lower(): c for c in columns}
 candidates = [
 "gene_id",
 "gene",
 "gene symbol",
 "gene_symbol",
 "symbol",
 "genename",
 "gene_name",
 ]
 for name in candidates:
 if name in lower_map:
 return lower_map[name]
 return columns[0]


def _infer_groups(sample_names):
 control_re = re.compile(r"control|ctrl|normal|healthy|wt", re.I)
 disease_re = re.compile(r"disease|case|tumor|affected|patient|ad|pd|als", re.I)
 groups = []
 for s in sample_names:
 if control_re.search(s):
 groups.append("Control")
 elif disease_re.search(s):
 groups.append("Disease")
 else:
 groups.append("Unknown")
 return groups


def _load_group_map(path: Path):
 df = pd.read_csv(path)
 cols = [c.lower() for c in df.columns]
 if "sample" not in cols or "condition" not in cols:
 raise ValueError("group map must have columns: sample, condition")
 df.columns = [c.lower() for c in df.columns]
 return dict(zip(df["sample"].astype(str), df["condition"].astype(str)))


def main():
 parser = argparse.ArgumentParser(
 description="Auto-run ncRNA pipeline from a raw .txt/.txt.gz file",
 epilog="""
EXAMPLES:
 # Default (Welch t-test, auto-detect groups)
 python auto_run_pipeline.py --input data.txt.gz

 # Using DESeq2 (requires raw counts path)
 python auto_run_pipeline.py --input data.txt.gz --method deseq2 --raw-counts data_raw.txt

 # With custom group mapping
 python auto_run_pipeline.py --input data.txt.gz --group-map samples.csv
 """
 )
 parser.add_argument("--input", help="Path to raw .txt or .txt.gz file")
 parser.add_argument("--outdir", help="Output directory (default: results/<dataset_name>)")
 parser.add_argument("--annotation", help="Optional annotation file (GTF/CSV/TXT)")
 parser.add_argument("--raw-counts", help="Raw counts file for DESeq2 analysis")
 parser.add_argument("--group-map", help="CSV with columns: sample, condition")
 parser.add_argument("--group-col", default=None, 
 help="Metadata column for groups (auto-detected if not provided)")
 parser.add_argument("--disease-label", default=None,
 help="Disease label (auto-inferred if not provided)")
 parser.add_argument("--control-label", default=None,
 help="Control label (auto-inferred if not provided)")
 parser.add_argument("--method", choices=['welch', 'deseq2'], default='welch',
 help="DE method: welch (default) or deseq2 (requires rpy2 + R)")
 parser.add_argument("--top-n", type=int, default=50)
 parser.add_argument("--pseudocount", type=float, default=1.0)
 args = parser.parse_args()

 if not args.input:
 args.input = input("Enter path to .txt or .txt.gz file: ").strip()
 if not args.input:
 raise ValueError("Input file path is required")

 input_path = Path(args.input).expanduser().resolve()
 if not input_path.exists():
 raise FileNotFoundError(f"Input file not found: {input_path}")

 dataset_name = input_path.name
 for ext in [".txt.gz", ".txt", ".gz"]:
 if dataset_name.endswith(ext):
 dataset_name = dataset_name[: -len(ext)]
 break

 outdir = Path(args.outdir) if args.outdir else Path("results") / dataset_name
 ensure_dirs(outdir)

 print(f"Loading raw file: {input_path}")
 sep = _detect_delimiter(input_path)
 print(f"Detected delimiter: {repr(sep)}")

 table_path = input_path
 if "series_matrix" in input_path.name.lower():
 print("Detected GEO series_matrix file. Extracting table section...")
 table_path = (outdir / "data" / f"{dataset_name}_series_matrix_table.txt")
 _extract_series_matrix_table(input_path, table_path)
 print(f"Extracted table -> {table_path}")

 print("Reading header...")
 header_df = pd.read_csv(
 table_path,
 sep=sep,
 compression="infer",
 engine="python",
 nrows=0,
 )
 if header_df.shape[1] < 2:
 raise ValueError("Input file has too few columns to parse counts")

 gene_col = _choose_gene_column(header_df.columns)

 drop_cols = {
 "reporterid",
 "reporter_id",
 "id_ref",
 "id",
 "probe_id",
 "transcript",
 "gene",
 "gene_id",
 "gene_name",
 "gene symbol",
 "gene_symbol",
 "symbol",
 }
 sample_cols = [c for c in header_df.columns if c.lower() not in drop_cols and c != gene_col]
 if not sample_cols:
 raise ValueError("No sample columns detected. Provide a group map or check the raw file format.")

 data_dir = outdir / "data"
 data_dir.mkdir(parents=True, exist_ok=True)
 counts_path = data_dir / f"{dataset_name}_counts.txt"

 print("\nExtracting counts (this can take a few minutes for large files)...")
 chunksize = 50000
 wrote_header = False
 for chunk_idx, chunk in enumerate(
 pd.read_csv(
 table_path,
 sep=sep,
 compression="infer",
 engine="python",
 chunksize=chunksize,
 )
 ):
 chunk = chunk[[gene_col] + sample_cols].copy()
 chunk = chunk.rename(columns={gene_col: "gene_id"})
 chunk["gene_id"] = chunk["gene_id"].astype(str)
 chunk = chunk.set_index("gene_id")
 chunk = chunk.apply(pd.to_numeric, errors="coerce")
 chunk = chunk.dropna(how="all")

 chunk.to_csv(
 counts_path,
 sep="\t",
 mode="w" if not wrote_header else "a",
 header=not wrote_header,
 )
 wrote_header = True

 if (chunk_idx + 1) % 2 == 0:
 print(f" ...processed {chunksize * (chunk_idx + 1):,} rows")

 print(f"Saved counts: {counts_path}")

 if args.group_map:
 group_map = _load_group_map(Path(args.group_map))
 groups = [group_map.get(s, "Unknown") for s in sample_cols]
 else:
 groups = _infer_groups(sample_cols)

 metadata = pd.DataFrame({
 "sample": sample_cols,
 args.group_col: groups,
 })

 metadata_path = data_dir / f"{dataset_name}_metadata.txt"
 metadata.to_csv(metadata_path, sep="\t", index=False)
 print(f"Saved metadata: {metadata_path}")

 unique_groups = set(metadata[args.group_col])
 if unique_groups == {"Unknown"} or len(unique_groups) < 2:
 print("\nWARNING: Could not infer two groups from sample names.")
 print("Edit the metadata file and re-run with --group-col/labels.")
 print(f"Metadata file: {metadata_path}")
 sys.exit(1)

 print("\nRunning pipeline...")
 out_prefix = str(outdir / "per_dataset" / dataset_name)
 try:
 analyze_dataset(
 counts_path=str(counts_path),
 metadata_path=str(metadata_path),
 annotation_path=args.annotation,
 group_col=args.group_col,
 disease_label=args.disease_label,
 control_label=args.control_label,
 out_prefix=out_prefix,
 pseudocount=args.pseudocount,
 top_n=args.top_n,
 method=args.method,
 raw_counts_path=args.raw_counts
 )
 print("\n✅ Done!")
 print(f"Results in: {outdir}")
 except Exception as e:
 print(f"\n❌ Pipeline failed: {e}")
 sys.exit(1)


if __name__ == "__main__":
 main()
