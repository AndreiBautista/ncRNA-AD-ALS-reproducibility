#!/usr/bin/env python3
"""
Python-based differential expression analysis using Welch's t-test.
Memory-efficient and stable - no R dependencies.
"""

import pandas as pd
import numpy as np
from scipy import stats
from statsmodels.stats.multitest import fdrcorrection
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

# Configuration
DATASETS = {
 'Alzheimers': {
 'counts': 'data/harmonized_datasets/alzheimers_disease_counts.csv',
 'metadata': 'data/harmonized_datasets/alzheimers_metadata_corrected.csv',
 'output_dir': 'results/deseq2/alzheimers',
 'has_controls': True
 },
 # ALS dataset (GSE153960) contains only ALS cases - no controls
 # Will be used for cross-disease comparison
}

ANNOTATION_FILE = 'data/annotations/annotation_human.csv'

# ncRNA keywords
NC_KEYWORDS = set(['lncrna', 'lnc_rna', 'mirna', 'mir', 'snorna', 'snrna', 
 'antisense', 'misc_rna', 'rrna', 'ncrna', 'pseudogene', 
 'scarna', 'vault_rna', 'srna'])


def load_data(disease_name, config):
 """Load counts and metadata for a disease."""
 print(f"\n{'='*70}")
 print(f"{disease_name.upper()} - Loading Data")
 print(f"{'='*70}")
 
 # Load counts
 print(f" Loading counts from {Path(config['counts']).name}...")
 counts_df = pd.read_csv(config['counts'], index_col=0)
 print(f" Shape: {counts_df.shape[0]} genes × {counts_df.shape[1]} samples")
 
 # Load metadata
 print(f" Loading metadata from {Path(config['metadata']).name}...")
 metadata = pd.read_csv(config['metadata'], index_col=0)
 print(f" Samples: {metadata.shape[0]}")
 
 # Find group column
 group_col = None
 for col in ['group', 'condition', 'disease', 'status', 'Group', 'Condition', 'disease_status']:
 if col in metadata.columns:
 group_col = col
 break
 
 if not group_col:
 raise ValueError(f"No group column found in metadata. Available: {list(metadata.columns)}")
 
 print(f" Group column: '{group_col}'")
 groups = metadata[group_col].value_counts()
 print(f" Groups: {dict(groups)}")
 
 return counts_df, metadata, group_col


def normalize_to_log2cpm(counts_df):
 """Normalize counts to log2(CPM + 1)."""
 print(f"\n Normalizing to log2(CPM + 1)...")
 
 # Calculate library sizes
 lib_sizes = counts_df.sum(axis=0)
 
 # CPM
 cpm = counts_df.divide(lib_sizes, axis=1) * 1e6
 
 # Log2 transform with pseudocount
 log2cpm = np.log2(cpm + 1)
 
 print(f" Done. Range: [{log2cpm.min().min():.2f}, {log2cpm.max().max():.2f}]")
 
 return log2cpm


def run_differential_expression(log2cpm, metadata, group_col):
 """Run Welch's t-test between disease and control groups."""
 print(f"\n Running differential expression analysis...")
 
 # Identify disease and control labels
 groups = metadata[group_col].value_counts()
 
 # Try to identify control group
 control_labels = ['Control', 'control', 'WT', 'Normal', 'normal', 'Ctrl']
 control_label = None
 for label in control_labels:
 if label in groups.index:
 control_label = label
 break
 
 if not control_label:
 # Use group with most samples as disease
 disease_label = groups.index[0]
 control_label = groups.index[1] if len(groups) > 1 else None
 else:
 disease_label = [g for g in groups.index if g != control_label][0]
 
 print(f" Disease: {disease_label} (n={groups[disease_label]})")
 print(f" Control: {control_label} (n={groups[control_label]})")
 
 # Get sample indices
 disease_samples = metadata[metadata[group_col] == disease_label].index
 control_samples = metadata[metadata[group_col] == control_label].index
 
 # Filter to samples in counts
 disease_samples = [s for s in disease_samples if s in log2cpm.columns]
 control_samples = [s for s in control_samples if s in log2cpm.columns]
 
 print(f" Running Welch's t-test on {log2cpm.shape[0]} genes...")
 
 results = []
 for gene_id in log2cpm.index:
 disease_vals = log2cpm.loc[gene_id, disease_samples].values
 control_vals = log2cpm.loc[gene_id, control_samples].values
 
 # Skip if not enough samples
 if len(disease_vals) < 2 or len(control_vals) < 2:
 continue
 
 # Calculate means
 mean_disease = disease_vals.mean()
 mean_control = control_vals.mean()
 log2fc = mean_disease - mean_control
 
 # Welch's t-test
 try:
 t_stat, pval = stats.ttest_ind(disease_vals, control_vals, equal_var=False)
 except:
 pval = 1.0
 t_stat = 0.0
 
 results.append({
 'gene_id': gene_id,
 'log2FoldChange': log2fc,
 'mean_disease': mean_disease,
 'mean_control': mean_control,
 'pvalue': pval,
 't_statistic': t_stat
 })
 
 results_df = pd.DataFrame(results)
 
 # FDR correction
 print(f" Applying FDR correction...")
 valid_pvals = results_df['pvalue'].notna()
 fdr_results = fdrcorrection(results_df.loc[valid_pvals, 'pvalue'].values)
 
 results_df['padj'] = np.nan
 results_df.loc[valid_pvals, 'padj'] = fdr_results[1]
 
 # Sort by adjusted p-value
 results_df = results_df.sort_values('padj')
 
 print(f" Tested {len(results_df)} genes")
 print(f" Significant (FDR < 0.05): {(results_df['padj'] < 0.05).sum()}")
 
 return results_df


def filter_to_ncrna(results_df, annotation):
 """Filter results to ncRNAs based on biotype."""
 print(f"\n Filtering to ncRNAs...")
 
 # Ensure gene_id in both dataframes are strings
 results_df['gene_id'] = results_df['gene_id'].astype(str)
 annotation['gene_id'] = annotation['gene_id'].astype(str)
 
 # Merge with annotation
 results_with_annot = results_df.merge(
 annotation[['gene_id', 'gene_name', 'biotype']], 
 on='gene_id', 
 how='left'
 )
 
 # Identify ncRNAs
 biotype_lower = results_with_annot['biotype'].fillna('').astype(str).str.lower()
 is_ncrna = biotype_lower.apply(lambda x: any(k in x for k in NC_KEYWORDS))
 
 ncrna_results = results_with_annot[is_ncrna].copy()
 
 print(f" Total ncRNAs: {len(ncrna_results)}")
 print(f" Significant ncRNAs (FDR < 0.05): {(ncrna_results['padj'] < 0.05).sum()}")
 
 return results_with_annot, ncrna_results


def analyze_disease(disease_name, config, annotation):
 """Run complete analysis pipeline for one disease."""
 print(f"\n{'='*70}")
 print(f"ANALYZING {disease_name.upper()}")
 print(f"{'='*70}")
 
 # Load data
 counts_df, metadata, group_col = load_data(disease_name, config)
 
 # Normalize
 log2cpm = normalize_to_log2cpm(counts_df)
 
 # Differential expression
 results_df = run_differential_expression(log2cpm, metadata, group_col)
 
 # Filter to ncRNAs
 all_results, ncrna_results = filter_to_ncrna(results_df, annotation)
 
 # Save results
 output_dir = Path(config['output_dir'])
 output_dir.mkdir(parents=True, exist_ok=True)
 
 print(f"\n Saving results to {output_dir}/")
 
 # All results
 all_file = output_dir / 'all_de_results.csv'
 all_results.to_csv(all_file, index=False)
 print(f" ✓ All results: {all_file.name} ({len(all_results)} genes)")
 
 # ncRNA results
 ncrna_file = output_dir / 'ncrna_de_results.csv'
 ncrna_results.to_csv(ncrna_file, index=False)
 print(f" ✓ ncRNA results: {ncrna_file.name} ({len(ncrna_results)} ncRNAs)")
 
 # Significant biomarkers
 biomarkers = ncrna_results[ncrna_results['padj'] < 0.05].copy()
 if len(biomarkers) > 0:
 biomarkers_file = output_dir / 'ncrna_biomarkers.csv'
 biomarkers.to_csv(biomarkers_file, index=False)
 print(f" ✓ Biomarkers (FDR<0.05): {biomarkers_file.name} ({len(biomarkers)} biomarkers)")
 
 return all_results, ncrna_results, biomarkers


def main():
 """Main analysis pipeline."""
 print(f"{'='*70}")
 print("PYTHON-BASED DIFFERENTIAL EXPRESSION ANALYSIS")
 print(f"{'='*70}")
 
 # Load annotation
 print(f"\nLoading annotation from {ANNOTATION_FILE}...")
 annotation = pd.read_csv(ANNOTATION_FILE)
 print(f" Loaded {len(annotation)} genes")
 
 # Run analysis for each disease
 all_biomarkers = {}
 
 for disease_name, config in DATASETS.items():
 try:
 all_res, ncrna_res, biomarkers = analyze_disease(disease_name, config, annotation)
 all_biomarkers[disease_name] = biomarkers
 except Exception as e:
 print(f"\n✗ Error analyzing {disease_name}: {e}")
 import traceback
 traceback.print_exc()
 continue
 
 # Summary
 print(f"\n{'='*70}")
 print("SUMMARY")
 print(f"{'='*70}")
 
 for disease_name, biomarkers in all_biomarkers.items():
 print(f"\n{disease_name}:")
 print(f" Total biomarkers (FDR < 0.05): {len(biomarkers)}")
 
 if len(biomarkers) > 0:
 upregulated = (biomarkers['log2FoldChange'] > 0).sum()
 downregulated = (biomarkers['log2FoldChange'] < 0).sum()
 print(f" Upregulated: {upregulated}")
 print(f" Downregulated: {downregulated}")
 
 print(f"\n Top 10 biomarkers:")
 for idx, row in biomarkers.head(10).iterrows():
 gene_name = row['gene_name'] if pd.notna(row['gene_name']) else row['gene_id']
 biotype = row['biotype'] if pd.notna(row['biotype']) else 'unknown'
 print(f" • {gene_name:20s} ({biotype:15s}): "
 f"log2FC={row['log2FoldChange']:6.2f}, padj={row['padj']:.2e}")
 
 print(f"\n{'='*70}")
 print("✓ ANALYSIS COMPLETE")
 print(f"{'='*70}")


if __name__ == '__main__':
 main()
