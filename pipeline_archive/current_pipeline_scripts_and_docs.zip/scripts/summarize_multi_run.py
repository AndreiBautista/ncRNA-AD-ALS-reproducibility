#!/usr/bin/env python3
"""Summarize multiple dataset results and compute overlaps."""
import argparse
from pathlib import Path
import pandas as pd


def _find_results_file(dataset_dir: Path):
 candidates = list(dataset_dir.glob("**/*_differential_results.csv"))
 return candidates[0] if candidates else None


def main() -> None:
 parser = argparse.ArgumentParser(
 description="Summarize multi-dataset DE results and overlaps"
 )
 parser.add_argument("--root", default="results/multi_run",
 help="Root folder containing per_dataset subfolder")
 parser.add_argument("--fdr", type=float, default=0.1,
 help="FDR cutoff for significance")
 parser.add_argument("--log2fc", type=float, default=0.5,
 help="Absolute log2FC cutoff for significance")
 parser.add_argument("--top_n", type=int, default=20,
 help="Top N up/down genes to save")
 args = parser.parse_args()

 root = Path(args.root)
 per_dataset = root / "per_dataset"
 if not per_dataset.exists():
 raise FileNotFoundError(f"Missing per_dataset folder in {root}")

 summary_dir = root / "summary"
 summary_dir.mkdir(parents=True, exist_ok=True)

 summary_rows = []
 gene_sets: dict[str, set[str]] = {}

 for dataset_dir in sorted(p for p in per_dataset.iterdir() if p.is_dir()):
 res_path = _find_results_file(dataset_dir)
 if res_path is None:
 continue

 df = pd.read_csv(res_path)
 if "gene_id" in df.columns:
 df = df.set_index("gene_id")

 required = {"log2FC", "fdr"}
 if not required.issubset(df.columns):
 continue

 sig = df[(df["fdr"] < args.fdr) & (df["log2FC"].abs() > args.log2fc)].copy()
 gene_sets[dataset_dir.name] = set(sig.index.astype(str))

 up = sig[sig["log2FC"] > 0].sort_values("fdr").head(args.top_n)
 down = sig[sig["log2FC"] < 0].sort_values("fdr").head(args.top_n)

 sig.to_csv(summary_dir / f"{dataset_dir.name}_significant.csv")
 up.to_csv(summary_dir / f"{dataset_dir.name}_top_up.csv")
 down.to_csv(summary_dir / f"{dataset_dir.name}_top_down.csv")

 summary_rows.append({
 "dataset": dataset_dir.name,
 "significant_genes": int(sig.shape[0]),
 "fdr_cutoff": args.fdr,
 "log2fc_cutoff": args.log2fc,
 "top_n": args.top_n,
 "results_file": str(res_path),
 })

 summary_df = pd.DataFrame(summary_rows)
 summary_df.to_csv(summary_dir / "summary_stats.csv", index=False)

 overlap_lines = []
 datasets = sorted(gene_sets.keys())
 for i in range(len(datasets)):
 for j in range(i + 1, len(datasets)):
 a, b = datasets[i], datasets[j]
 overlap = sorted(gene_sets[a].intersection(gene_sets[b]))
 pd.DataFrame({"gene_id": overlap}).to_csv(
 summary_dir / f"{a}_vs_{b}_overlap.csv", index=False
 )
 overlap_lines.append(f"{a} vs {b}: {len(overlap)}")

 shared_all = set.intersection(*gene_sets.values()) if gene_sets else set()
 pd.DataFrame({"gene_id": sorted(shared_all)}).to_csv(
 summary_dir / "shared_all_datasets.csv", index=False
 )

 summary_txt = [
 "MULTI-DATASET SUMMARY",
 "=" * 60,
 f"Datasets: {', '.join(datasets) if datasets else 'None'}",
 f"FDR cutoff: {args.fdr}",
 f"log2FC cutoff: {args.log2fc}",
 f"Top N: {args.top_n}",
 "",
 "Significant genes per dataset:",
 ]

 for row in summary_rows:
 summary_txt.append(f"- {row['dataset']}: {row['significant_genes']}")

 summary_txt.append("")
 summary_txt.append("Pairwise overlaps:")
 if overlap_lines:
 summary_txt.extend(overlap_lines)
 else:
 summary_txt.append("(none)")
 summary_txt.append("")
 summary_txt.append(f"Shared across all datasets: {len(shared_all)}")

 (summary_dir / "SUMMARY.txt").write_text("\n".join(summary_txt), encoding="utf-8")
 print(f"Summary saved: {summary_dir}")


if __name__ == "__main__":
 main()
