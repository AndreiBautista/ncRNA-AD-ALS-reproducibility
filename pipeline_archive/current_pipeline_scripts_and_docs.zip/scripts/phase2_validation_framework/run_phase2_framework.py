#!/usr/bin/env python3
"""CLI entry point for Phase 2 fixed-biomarker validation framework."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys

# Allow running from repository root without installation.
REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from pipeline.modules.configuration import load_config
from pipeline.modules.orchestrator import run_pipeline


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Run Phase 2 framework on fixed ncRNA biomarkers only "
            "(external validation, model comparison, robustness, optional network/pathway)."
        )
    )
    parser.add_argument("--config", required=True, help="Path to Phase 2 YAML/JSON config")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    config = load_config(args.config)
    outputs = run_pipeline(config)

    print("Phase 2 run completed.")
    print(f"Returned tables: {', '.join(sorted(outputs.keys()))}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
