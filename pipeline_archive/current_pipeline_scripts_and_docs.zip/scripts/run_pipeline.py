"""Command-line runner for the ncRNA pipeline.

Usage examples:
 python3 run_pipeline.py --datasets GSEXXXXX --outdir results
 python3 run_pipeline.py --counts counts.csv --metadata meta.csv --annotation genes.gtf --outdir results

This script orchestrates per-dataset analysis and conserved ncRNA identification.
"""
import argparse
from pathlib import Path
import os
import sys
import pandas as pd

ROOT_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT_DIR))

from pipeline import io, processing, de_analysis, visualization


def ensure_dirs(outdir: Path):
 (outdir / 'data').mkdir(parents=True, exist_ok=True)
 (outdir / 'per_dataset').mkdir(parents=True, exist_ok=True)
 (outdir / 'conserved_ncrnas').mkdir(parents=True, exist_ok=True)
 (outdir / 'figures').mkdir(parents=True, exist_ok=True)


def analyze_dataset(counts_path, metadata_path, annotation_path, group_col=None, 
 disease_label=None, control_label=None, out_prefix='results', 
 pseudocount=1.0, top_n=50, method='welch', raw_counts_path=None):
 """
 Analyze a single dataset for differentially expressed ncRNAs.
 
 MODIFIED PIPELINE STEPS (DE-THEN-FILTER):
 1. Load expression counts and sample metadata
 2. Load gene annotation (if provided)
 3. Normalize counts to log2-CPM (ALL genes)
 4. Detect/validate sample grouping (disease vs control)
 5. Run DE analysis on ALL genes (Welch t-test or DESeq2)
 6. Correct for multiple testing (Benjamini-Hochberg FDR)
 7. Apply significance thresholds (padj < 0.1, abs(log2FC) > 0.5)
 8. Filter significant genes to ncRNA biotypes
 9. Merge results with annotations
 10. Generate visualizations (volcano plot, heatmap)
 
 REPORTING:
 - Total genes tested
 - Total significant genes (after step 7)
 - Significant ncRNAs (after step 8)
 - Breakdown per dataset
 
 Args:
 counts_path: Path to expression count matrix (genes × samples)
 metadata_path: Path to sample metadata with group/condition column
 annotation_path: Path to gene annotation (GTF or CSV) [optional]
 group_col: Column name in metadata for group assignment (auto-detected if None)
 disease_label: Label for disease samples (auto-inferred if None)
 control_label: Label for control samples (auto-inferred if None)
 out_prefix: Dataset output directory (data/ and figures/ will be created inside)
 pseudocount: Small constant added before log2 (avoids log(0))
 top_n: Number of top genes to show in heatmap
 method: 'welch' (default, fast) or 'deseq2' (more robust, slower)
 raw_counts_path: Path to raw counts (required if method='deseq2')
 """
 dataset_dir = Path(out_prefix)
 dataset_id = dataset_dir.name
 data_dir = dataset_dir / 'data'
 figures_dir = dataset_dir / 'figures'
 data_dir.mkdir(parents=True, exist_ok=True)
 figures_dir.mkdir(parents=True, exist_ok=True)

 print(f"\n━━━ Analyzing {dataset_id} ━━━")
 
 # Load data
 print(" Loading data...")
 counts = io.load_counts(counts_path)
 total_genes = counts.shape[0]
 total_samples = counts.shape[1]
 print(f" Counts: {total_genes} genes × {total_samples} samples")
 
 meta = io.load_metadata(metadata_path, group_col)
 print(f" Metadata: {meta.shape[0]} samples")
 
 # Load annotation if provided
 if annotation_path:
 print(" Loading annotation...")
 annot = io.load_annotation(annotation_path)
 print(f" Annotation: {annot.shape[0]} genes")
 else:
 # No annotation: use all genes (mark as unknown)
 print(" No annotation provided; analyzing all genes without biotype filtering")
 annot = pd.DataFrame({'gene_name': counts.index, 'biotype': 'unknown'}, index=counts.index)
 
 # ================ KEY CHANGE: Normalize ALL genes, don't filter yet ================
 print(" Normalizing to log2-CPM (all genes)...")
 logcpm = processing.log2_cpm(counts, pseudocount=pseudocount)
 
 # Differential expression on ALL genes
 print(" Running differential expression analysis (all genes)...")
 
 # For DESeq2, need raw counts
 if method.lower() == 'deseq2' and raw_counts_path:
 raw_counts = io.load_counts(raw_counts_path)
 res = de_analysis.differential_expression(
 logcpm, meta, group_col, disease_label, control_label, 
 method=method, raw_counts_df=raw_counts
 )
 else:
 res = de_analysis.differential_expression(
 logcpm, meta, group_col, disease_label, control_label, method=method
 )
 
 # Adjust p-values
 res = de_analysis.adjust_pvalues(res)
 
 # Merge with annotation to get biotypes
 merged_all = res.merge(
 annot[['gene_name', 'biotype']],
 left_index=True,
 right_index=True,
 how='left'
 ).sort_values(['fdr', 'pvalue', 'log2FC'])
 
 # ================ APPLY SIGNIFICANCE THRESHOLDS ================
 print("\n Filtering by significance thresholds (FDR < 0.1, |log2FC| > 0.5)...")
 sig_threshold = (merged_all['fdr'] < 0.1) & (merged_all['log2FC'].abs() > 0.5)
 significant_genes = merged_all[sig_threshold].copy()
 total_sig = len(significant_genes)
 print(f" Significant genes (all types): {total_sig}")
 
 # Filter significant genes to ncRNA biotypes
 print(" Filtering significant genes to ncRNA biotypes...")
 significant_ncrna = processing.filter_results_to_ncrna(significant_genes)
 sig_ncrna_count = len(significant_ncrna)
 print(f" Significant ncRNAs: {sig_ncrna_count}")
 
 # Compute ncRNA biotype breakdown
 if len(significant_ncrna) > 0 and 'biotype' in significant_ncrna.columns:
 biotype_counts = significant_ncrna['biotype'].value_counts()
 print(f" ncRNA breakdown:")
 for biotype, count in biotype_counts.items():
 print(f" {biotype}: {count}")
 
 # ================ EXTRACT TOP 20 UP AND DOWN REGULATED ncRNAs ================
 print("\n Extracting top biomarker candidates...")

 if significant_ncrna.empty or 'log2FC' not in significant_ncrna.columns:
 print(" No significant ncRNAs available for ranking.")
 top_20_up = significant_ncrna.head(0).copy()
 top_20_down = significant_ncrna.head(0).copy()
 biomarker_candidates = significant_ncrna.copy()
 else:
 # Sort by log2FC (descending for upregulated, ascending for downregulated)
 ncrna_sorted = significant_ncrna.sort_values('log2FC', ascending=False)

 # Extract top 20 upregulated and top 20 downregulated
 top_20_up = ncrna_sorted.head(20).copy()
 top_20_down = ncrna_sorted.tail(20).copy()

 print(f" Top 20 upregulated ncRNAs: {len(top_20_up)}")
 print(f" Top 20 downregulated ncRNAs: {len(top_20_down)}")

 # Combine for biomarker candidates table
 biomarker_candidates = pd.concat([top_20_up, top_20_down])
 biomarker_candidates['regulation'] = ['Up']*len(top_20_up) + ['Down']*len(top_20_down)
 
 # ================ CREATE CLEAN SUMMARY TABLES ================
 print("\n Creating clean summary tables for presentation...")
 save_prefix = str(data_dir / dataset_id)
 
 # 1. Dataset Summary Table
 dataset_summary = pd.DataFrame({
 'Metric': [
 'Dataset ID',
 'Total Genes Tested',
 'Total Samples',
 'Disease Samples',
 'Control Samples',
 'Significant Genes (FDR<0.1, |log2FC|>0.5)',
 'Significant ncRNAs',
 'Percentage ncRNA (%)',
 'Top Upregulated ncRNAs',
 'Top Downregulated ncRNAs'
 ],
 'Value': [
 dataset_id,
 total_genes,
 total_samples,
 len(meta[meta[group_col] == disease_label]) if disease_label else 'N/A',
 len(meta[meta[group_col] == control_label]) if control_label else 'N/A',
 total_sig,
 sig_ncrna_count,
 f"{100*sig_ncrna_count/total_sig:.1f}" if total_sig > 0 else '0.0',
 len(top_20_up),
 len(top_20_down)
 ]
 })
 dataset_summary_path = f"{save_prefix}_dataset_summary.csv"
 dataset_summary.to_csv(dataset_summary_path, index=False)
 print(f" ✓ Dataset summary: {dataset_summary_path}")
 
 def _safe_select(df, columns):
 missing = [c for c in columns if c not in df.columns]
 if missing:
 return pd.DataFrame(columns=columns)
 return df[columns].copy()

 # 2. Differential Expression Summary Table (all significant genes with statistics)
 de_cols = ['gene_name', 'biotype', 'mean_disease', 'mean_control',
 'sd_disease', 'sd_control', 'log2FC', 'test_statistic',
 'pvalue', 'fdr']
 de_summary = _safe_select(significant_genes, de_cols).round(4)
 de_summary_path = f"{save_prefix}_DE_summary.csv"
 de_summary.to_csv(de_summary_path)
 print(f" ✓ DE summary: {de_summary_path}")
 
 # 3. Top Biomarker Candidates Table (top 20 up + top 20 down with full statistics)
 biomarker_cols = ['gene_name', 'biotype', 'regulation',
 'mean_disease', 'mean_control',
 'sd_disease', 'sd_control', 'log2FC',
 'test_statistic', 'pvalue', 'fdr']
 biomarker_table = _safe_select(biomarker_candidates, biomarker_cols).round(4)
 biomarker_path = f"{save_prefix}_biomarker_candidates.csv"
 biomarker_table.to_csv(biomarker_path)
 print(f" ✓ Biomarker candidates: {biomarker_path}")
 
 # Also save complete results (for reference)
 csv_path = f"{save_prefix}_differential_results.csv"
 merged_all.to_csv(csv_path)
 print(f" ✓ All DE results: {csv_path}")
 
 # ================ GENERATE PUBLICATION-READY VISUALIZATIONS ================
 print("\n Generating publication-ready visualizations...")
 
 plot_log = figures_dir / 'plot_errors.log'
 
 # 1. Volcano plot (all genes)
 volcano_path = str(figures_dir / f"{dataset_id}_volcano_all_genes.png")
 try:
 visualization.volcano_plot(merged_all, volcano_path, title=f"{dataset_id}: Differential Expression (All Genes)")
 print(f" ✓ Volcano plot (all genes): {volcano_path}")
 except Exception as e:
 message = f"{dataset_id} volcano plot failed: {e}"
 print(f" ✗ {message}")
 plot_log.parent.mkdir(parents=True, exist_ok=True)
 with open(plot_log, 'a', encoding='utf-8') as handle:
 handle.write(message + "\n")
 
 # 2. Volcano plot (ncRNAs only)
 volcano_ncrna_path = str(figures_dir / f"{dataset_id}_volcano_ncRNA.png")
 try:
 if len(significant_ncrna) > 0:
 visualization.volcano_plot(significant_ncrna, volcano_ncrna_path, 
 title=f"{dataset_id}: Significant ncRNAs")
 print(f" ✓ Volcano plot (ncRNA): {volcano_ncrna_path}")
 except Exception as e:
 message = f"{dataset_id} ncRNA volcano plot failed: {e}"
 print(f" ✗ {message}")
 
 # 3. PCA plot (colored by condition)
 pca_path = str(figures_dir / f"{dataset_id}_PCA.png")
 try:
 visualization.pca_plot(logcpm, meta, group_col, pca_path, 
 title=f"{dataset_id}: Principal Component Analysis")
 print(f" ✓ PCA plot: {pca_path}")
 except Exception as e:
 message = f"{dataset_id} PCA plot failed: {e}"
 print(f" ✗ {message}")
 plot_log.parent.mkdir(parents=True, exist_ok=True)
 with open(plot_log, 'a', encoding='utf-8') as handle:
 handle.write(message + "\n")
 
 # 4. Heatmap of top ncRNAs
 heatmap_path = str(figures_dir / f"{dataset_id}_top_ncRNA_heatmap.png")
 try:
 if len(biomarker_candidates) > 0:
 top_for_heatmap = biomarker_candidates.index[:min(50, len(biomarker_candidates))].tolist()
 visualization.heatmap_top_genes(logcpm, top_for_heatmap, meta, group_col, heatmap_path)
 print(f" ✓ Heatmap (top ncRNAs): {heatmap_path}")
 except Exception as e:
 message = f"{dataset_id} heatmap failed: {e}"
 print(f" ✗ {message}")
 plot_log.parent.mkdir(parents=True, exist_ok=True)
 with open(plot_log, 'a', encoding='utf-8') as handle:
 handle.write(message + "\n")
 
 # 5. Bar plots with error bars for top 3 ncRNAs
 barplot_path = str(figures_dir / f"{dataset_id}_top3_ncRNA_barplot.png")
 try:
 if len(biomarker_candidates) >= 3:
 top_3_genes = biomarker_candidates.index[:3].tolist()
 visualization.barplot_top_genes_with_error(
 logcpm, top_3_genes, meta, group_col, barplot_path,
 title=f"{dataset_id}: Top 3 ncRNA Biomarkers (Mean ± SD)", top_n=3
 )
 print(f" ✓ Bar plot (top 3 ncRNAs): {barplot_path}")
 except Exception as e:
 message = f"{dataset_id} bar plot failed: {e}"
 print(f" ✗ {message}")
 plot_log.parent.mkdir(parents=True, exist_ok=True)
 with open(plot_log, 'a', encoding='utf-8') as handle:
 handle.write(message + "\n")
 
 # ================ PRINT SUMMARY ================
 print(f"\n ✅ {dataset_id} analysis complete")
 print(f" Summary Statistics:")
 print(f" Total genes tested: {total_genes}")
 print(f" Total significant (FDR<0.1, |log2FC|>0.5): {total_sig}")
 print(f" Significant ncRNAs: {sig_ncrna_count}")
 if total_sig > 0:
 print(f" Percentage ncRNA: {100*sig_ncrna_count/total_sig:.1f}%")
 print(f" Top 20 upregulated ncRNAs: {len(top_20_up)}")
 print(f" Top 20 downregulated ncRNAs: {len(top_20_down)}\n")
 
 return {
 'csv': csv_path,
 'dataset_summary': dataset_summary_path,
 'de_summary': de_summary_path,
 'biomarker_candidates': biomarker_path,
 'volcano': volcano_path,
 'volcano_ncrna': volcano_ncrna_path,
 'pca': pca_path,
 'heatmap': heatmap_path,
 'barplot': barplot_path,
 'total_genes': total_genes,
 'significant_count': total_sig,
 'significant_ncrna_count': sig_ncrna_count,
 'top_20_up': top_20_up,
 'top_20_down': top_20_down,
 'biomarker_candidates_df': biomarker_candidates
 }


def main():
 parser = argparse.ArgumentParser(
 description='ncRNA pipeline runner',
 epilog='''
EXAMPLES:
 # Local analysis with auto-detected groups
 python run_pipeline.py --counts data/counts.txt --metadata data/meta.txt --outdir results
 
 # Specify groups explicitly
 python run_pipeline.py --counts data/counts.txt --metadata data/meta.txt \\
 --group_col condition --disease_label Disease --control_label Control \\
 --method welch --outdir results
 
 # Using DESeq2 (requires raw counts)
 python run_pipeline.py --counts data/counts.txt --metadata data/meta.txt \\
 --raw_counts data/raw_counts.txt --method deseq2 --outdir results
 '''
 )
 parser.add_argument('--datasets', nargs='*', help='List of GEO dataset IDs (GSExxxxx)')
 parser.add_argument('--counts', help='Path to expression counts (CSV/TXT/TSV)')
 parser.add_argument('--metadata', help='Path to sample metadata (CSV/TXT/TSV)')
 parser.add_argument('--annotation', help='Path to gene annotation (GTF/CSV) [optional]')
 parser.add_argument('--raw_counts', help='Path to raw counts for DESeq2 analysis [optional]')
 parser.add_argument('--group_col', default=None, 
 help='Metadata column for sample groups [auto-detected if not provided]')
 parser.add_argument('--disease_label', default=None,
 help='Label for disease/treatment samples [auto-inferred if not provided]')
 parser.add_argument('--control_label', default=None,
 help='Label for control samples [auto-inferred if not provided]')
 parser.add_argument('--method', choices=['welch', 'deseq2'], default='welch',
 help='DE method: welch (fast, default) or deseq2 (slower, more robust)')
 parser.add_argument('--outdir', default='results', help='Output directory')
 parser.add_argument('--pseudocount', type=float, default=1.0,
 help='Pseudocount added before log2 normalization')
 parser.add_argument('--top_n', type=int, default=50,
 help='Number of top genes to show in heatmap')
 
 args = parser.parse_args()

 outdir = Path(args.outdir)
 ensure_dirs(outdir)

 per_dataset_results = {}
 
 # Local analysis
 if args.counts and args.metadata:
 prefix = outdir / 'per_dataset' / Path('local')
 prefix = str(prefix)
 try:
 res = analyze_dataset(
 args.counts, args.metadata, args.annotation, 
 group_col=args.group_col,
 disease_label=args.disease_label,
 control_label=args.control_label,
 out_prefix=prefix,
 pseudocount=args.pseudocount,
 top_n=args.top_n,
 method=args.method,
 raw_counts_path=args.raw_counts
 )
 per_dataset_results['local'] = res
 except Exception as e:
 print(f"✗ Local analysis failed: {e}")
 
 # GEO dataset analysis
 if args.datasets:
 for ds in args.datasets:
 try:
 if ds.upper().startswith('GSE'):
 print(f"\n🔽 Downloading {ds} from GEO...")
 downloaded = io.download_geo(ds, outdir / 'data' / ds)
 counts = downloaded['counts']
 metadata = downloaded['metadata']
 
 if args.annotation is None:
 raise ValueError('Provide annotation file (--annotation) for GEO analysis')
 
 out_pref = str(outdir / 'per_dataset' / ds)
 res = analyze_dataset(
 counts, metadata, args.annotation,
 group_col=args.group_col,
 disease_label=args.disease_label,
 control_label=args.control_label,
 out_prefix=out_pref,
 pseudocount=args.pseudocount,
 top_n=args.top_n,
 method=args.method,
 raw_counts_path=args.raw_counts
 )
 per_dataset_results[ds] = res
 else:
 print(f"⚠️ Dataset {ds}: auto-download not supported (provide local files instead)")
 except Exception as e:
 print(f"✗ Dataset {ds} failed: {e}")

 # Cross-dataset analysis
 if per_dataset_results and len(per_dataset_results) > 1:
 print(f"\n━━━ Cross-Dataset Analysis ━━━")
 
 # Extract top gene sets for overlap analysis
 top_sets = {}
 for name, info in per_dataset_results.items():
 if 'biomarker_candidates_df' in info and len(info['biomarker_candidates_df']) > 0:
 top_sets[name] = set(info['biomarker_candidates_df'].index.tolist())
 
 if top_sets and len(top_sets) > 1:
 upset_path = outdir / 'figures' / 'conserved_upset.png'
 try:
 visualization.upset_overlap(top_sets, str(upset_path), title='Conserved ncRNAs')
 print(f"✓ UpSet plot: {upset_path}")
 except Exception as e:
 print(f"⚠ UpSet plot not generated: {e}")
 
 sig_counts = pd.Series({name: info['significant_ncrna_count'] for name, info in per_dataset_results.items()})
 bar_path = outdir / 'figures' / 'ncRNA_significant_counts.png'
 try:
 visualization.barplot_significant_counts(sig_counts, str(bar_path), 
 title='Significant ncRNAs per dataset')
 print(f"✓ Bar plot: {bar_path}")
 except Exception as e:
 print(f"✗ Bar plot error: {e}")

 print(f"\n✅ Analysis complete. Results: {outdir}")


if __name__ == '__main__':
 main()
