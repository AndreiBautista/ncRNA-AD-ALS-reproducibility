#!/usr/bin/env python3
"""Build metadata files for GSE125583 using GEO characteristics."""

from pathlib import Path
import logging

import pandas as pd
import GEOparse


def classify_diagnosis(diagnosis: str) -> str:
 if not diagnosis:
 return "Unknown"
 diag_lower = diagnosis.lower()
 if "control" in diag_lower:
 return "Control"
 if "alzheimer" in diag_lower:
 return "Disease"
 return "Other"


def main():
 logging.getLogger("GEOparse").setLevel(logging.WARNING)

 base_dir = Path("data/neurodegenerative_diseases/alzheimers/GSE125583")
 counts_path = base_dir / "counts.tsv"
 if not counts_path.exists():
 raise FileNotFoundError(counts_path)

 counts_df = pd.read_csv(counts_path, sep="\t", nrows=0)
 sample_ids = counts_df.columns.tolist()[1:]

 geo_dir = base_dir / "geo"
 geo_dir.mkdir(parents=True, exist_ok=True)
 gse = GEOparse.get_GEO("GSE125583", destdir=str(geo_dir), annotate_gpl=False)

 rows = []
 missing = 0
 for gsm_name in sample_ids:
 gsm = gse.gsms.get(gsm_name)
 diagnosis = None
 tissue = None
 sex = None
 age = None
 if gsm:
 chars = gsm.metadata.get("characteristics_ch1", [])
 for c in chars:
 c_lower = c.lower()
 if c_lower.startswith("diagnosis:"):
 diagnosis = c.split(":", 1)[1].strip()
 elif c_lower.startswith("tissue:"):
 tissue = c.split(":", 1)[1].strip()
 elif c_lower.startswith("sex:"):
 sex = c.split(":", 1)[1].strip()
 elif c_lower.startswith("age:"):
 age = c.split(":", 1)[1].strip()
 if not diagnosis:
 missing += 1
 disease_status = classify_diagnosis(diagnosis)
 rows.append({
 "sample_id": gsm_name,
 "disease_status": disease_status,
 "diagnosis": diagnosis if diagnosis else "Unknown",
 "tissue_type": tissue if tissue else "",
 "sex": sex if sex else "",
 "age": age if age else "",
 "study_id": "GSE125583",
 })

 meta_full = pd.DataFrame(rows)
 meta_full_path = base_dir / "metadata_full.csv"
 meta_full.to_csv(meta_full_path, index=False)

 meta_filtered = meta_full[meta_full["disease_status"].isin(["Disease", "Control"])].copy()
 meta_filtered_path = base_dir / "metadata_disease.csv"
 meta_filtered.to_csv(meta_filtered_path, index=False)

 print("Total samples in counts:", len(sample_ids))
 print("Missing metadata matches:", missing)
 print("Disease/Control counts:")
 print(meta_filtered["disease_status"].value_counts())
 print("Saved:", meta_full_path)
 print("Saved:", meta_filtered_path)


if __name__ == "__main__":
 main()
