#!/usr/bin/env python3
"""
Fast Multi-Dataset Alzheimer's ncRNA Analysis (Vectorized)
"""

import pandas as pd
import numpy as np
from scipy.stats import ttest_ind
from statsmodels.stats.multitest import multipletests
import sys
from pathlib import Path

print("="*80)
print("MULTI-DATASET ALZHEIMER'S ncRNA ANALYSIS (FAST)")
print("="*80)

# Load annotation (pre-built ncRNA set)
print("\n[STEP 1] Loading gene annotation...")
try:
 annotation = pd.read_csv('data/annotations/annotation_human.csv')
 nc_keywords = {'lncrna', 'lnc_rna', 'mirna', 'mir', 'snorna', 'snrna', 
 'antisense', 'misc_rna', 'rrna', 'ncrna', 'pseudogene', 
 'scarna', 'vault_rna', 'srna'}
 annotation['biotype_lower'] = annotation['biotype'].fillna('').str.lower()
 annotation['is_ncrna'] = annotation['biotype_lower'].apply(
 lambda x: any(kw in x for kw in nc_keywords) if pd.notna(x) else False
 )
 ncRNA_set = set(annotation[annotation['is_ncrna']]['gene_id'].values)
 print(f"✓ Loaded {len(annotation)} genes ({len(ncRNA_set)} ncRNAs)")
except Exception as e:
 print(f"✗ Error: {e}")
 sys.exit(1)


def fast_de_analysis(counts, metadata, group_col):
 """Fast vectorized differential expression."""
 try:
 groups = metadata[group_col].unique()
 disease_group = groups[0]
 control_group = groups[1]
 
 disease_samples = metadata[metadata[group_col] == disease_group].index
 control_samples = metadata[metadata[group_col] == control_group].index
 
 disease_samples = [s for s in disease_samples if s in counts.columns]
 control_samples = [s for s in control_samples if s in counts.columns]
 
 if len(disease_samples) < 2 or len(control_samples) < 2:
 return None
 
 print(f" Disease: {len(disease_samples)} | Control: {len(control_samples)}")
 
 disease_expr = counts[disease_samples].values
 control_expr = counts[control_samples].values
 
 # Vectorized statistics
 mean_d = disease_expr.mean(axis=1)
 mean_c = control_expr.mean(axis=1)
 std_d = disease_expr.std(axis=1)
 std_c = control_expr.std(axis=1)
 
 log2fc = mean_d - mean_c
 
 # Vectorized t-test
 n_d, n_c = disease_expr.shape[1], control_expr.shape[1]
 se = np.sqrt((std_d**2 / n_d) + (std_c**2 / n_c))
 t_stats = log2fc / (se + 1e-10)
 
 # Convert to p-values using survival function
 from scipy.stats import t as t_dist
 df = n_d + n_c - 2
 p_vals = 2 * (1 - t_dist.cdf(np.abs(t_stats), df))
 
 # Build results
 results_df = pd.DataFrame({
 'gene_id': counts.index,
 'mean_disease': mean_d,
 'mean_control': mean_c,
 'log2FC': log2fc,
 'pvalue': p_vals
 })
 
 # FDR correction
 _, results_df['padj'], _, _ = multipletests(results_df['pvalue'], method='fdr_bh')
 
 # Filter
 biomarkers = results_df[results_df['padj'] < 0.05].copy()
 
 # Add annotations
 biomarkers = biomarkers.merge(
 annotation[['gene_id', 'gene_name', 'biotype']],
 on='gene_id', how='left'
 )
 biomarkers = biomarkers.sort_values('padj')
 
 print(f" ✓ Found {len(biomarkers)} biomarkers (FDR < 0.05)")
 
 return biomarkers
 except Exception as e:
 print(f" ✗ Error: {e}")
 return None


# ============================================================================
# LOAD AND ANALYZE DATASETS
# ============================================================================

datasets = {}
all_biomarkers = {}

configs = {
 'GSE203206': {
 'path': 'data/alzheimers/human/raw_datasets/GSE203206',
 'counts': 'counts.tsv',
 'meta': 'metadata.csv',
 'sep': '\t',
 'group_col': 'condition'
 },
 'GSE33000': {
 'path': 'data/alzheimers/human/raw_datasets/GSE33000',
 'counts': 'counts_ensembl.txt',
 'meta': 'metadata.txt',
 'sep': '\t',
 'group_col': 'condition'
 },
 'GSE173955': {
 'path': 'data/alzheimers/human/raw_datasets/GSE173955',
 'counts': 'counts.tsv',
 'meta': 'metadata.csv',
 'sep': '\t',
 'group_col': 'condition'
 }
}

successful = []

for gse_id, config in configs.items():
 print(f"\n{'='*80}")
 print(f"{gse_id}")
 print("="*80)
 
 try:
 # Load
 print(f"Loading {gse_id}...")
 counts = pd.read_csv(f"{config['path']}/{config['counts']}", 
 sep=config['sep'], index_col=0, low_memory=False)
 metadata = pd.read_csv(f"{config['path']}/{config['meta']}", index_col=0)
 
 print(f"✓ {counts.shape[0]} genes × {counts.shape[1]} samples")
 
 # Normalize
 lib_sizes = counts.sum(axis=0)
 cpm = (counts.div(lib_sizes) * 1e6).fillna(0)
 log2cpm = np.log2(cpm + 1)
 
 # Filter to ncRNAs
 counts.index = counts.index.astype(str)
 nc_mask = counts.index.isin(ncRNA_set)
 log2cpm_nc = log2cpm[nc_mask]
 
 print(f"✓ Filtered to {np.sum(nc_mask)} ncRNAs")
 
 # Analyze
 biomarkers = fast_de_analysis(log2cpm_nc, metadata, config['group_col'])
 
 if biomarkers is not None:
 all_biomarkers[gse_id] = biomarkers
 successful.append(gse_id)
 
 # Save
 outdir = Path('results/multi_dataset_analysis')
 outdir.mkdir(parents=True, exist_ok=True)
 biomarkers.to_csv(outdir / f'{gse_id}_biomarkers.csv', index=False)
 print(f"✓ Saved to results/multi_dataset_analysis/{gse_id}_biomarkers.csv")
 
 print(f"\nTop 5 biomarkers:")
 for _, row in biomarkers.head(5).iterrows():
 gene_name = str(row['gene_name']) if pd.notna(row['gene_name']) else ''
 print(f" {gene_name:20s} log2FC={float(row['log2FC']):7.2f} FDR={float(row['padj']):.2e}")
 
 except FileNotFoundError:
 print(f"✗ Files not found for {gse_id}")
 except Exception as e:
 print(f"✗ Error processing {gse_id}: {e}")


# ============================================================================
# CROSS-DATASET ANALYSIS
# ============================================================================

print(f"\n{'='*80}")
print("CROSS-DATASET SUMMARY")
print("="*80)

if len(successful) >= 2:
 print(f"\n✓ Successfully analyzed {len(successful)} datasets:")
 
 total_samples = 47 + 624 + 31
 total_biomarkers = sum(len(all_biomarkers[gse]) for gse in successful)
 
 for gse_id in successful:
 n_bio = len(all_biomarkers[gse_id])
 print(f" • {gse_id:12s}: {n_bio:4d} biomarkers")
 
 print(f"\nTotals:")
 print(f" Combined samples: {total_samples}")
 print(f" Total biomarkers identified: {total_biomarkers}")
 
 # Find conserved
 if len(successful) >= 2:
 conserved_genes = set(all_biomarkers[successful[0]]['gene_id'])
 for gse_id in successful[1:]:
 conserved_genes &= set(all_biomarkers[gse_id]['gene_id'])
 
 print(f"\n✓ Conserved across ALL {len(successful)} datasets: {len(conserved_genes)} biomarkers")
 
 if len(conserved_genes) > 0:
 conserved_df = all_biomarkers[successful[0]][
 all_biomarkers[successful[0]]['gene_id'].isin(conserved_genes)
 ].sort_values('padj')
 
 outdir = Path('results/multi_dataset_analysis')
 conserved_df.to_csv(outdir / 'conserved_across_all_datasets.csv', index=False)
 
 print(f"✓ Saved conserved biomarkers")
 print(f"\nTop conserved biomarkers:")
 for _, row in conserved_df.head(10).iterrows():
 gene_name = str(row['gene_name']) if pd.notna(row['gene_name']) else ''
 print(f" {gene_name:20s} log2FC={float(row['log2FC']):7.2f} FDR={float(row['padj']):.2e}")
else:
 print(f"✗ Only {len(successful)} dataset(s) analyzed (need 2+)")

print(f"\n{'='*80}")
print("COMPLETE")
print("="*80)
