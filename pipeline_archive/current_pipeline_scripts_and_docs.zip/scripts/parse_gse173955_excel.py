#!/usr/bin/env python3
"""
Parse GSE173955 Excel file (processed gene-level expression) into standard format
Converts Excel table to counts.tsv and metadata.csv for pipeline analysis
"""

import pandas as pd
import numpy as np
import os

print("Parsing GSE173955 gene-level expression Excel file...")

# Read the Excel file
xlsx_file = 'GSE173955_gene_expression.xlsx'
df = pd.read_excel(xlsx_file, sheet_name=0, skiprows=2)

print(f"Raw shape: {df.shape}")
print(f"Columns: {list(df.columns)}")

# The structure is:
# Column 0: Gene names
# Columns 1-8: AD samples (8 AD patients)
# Columns 10-19: Non-AD samples (10 control patients)
# Column 'Mean' and 'SD' are summary stats

# Extract gene names
genes = df.iloc[:, 0].values

# AD samples: columns 1-8 (indices 1-8)
# The actual column headers are numeric: 1, 2, 3, 4, 5, 6, 7, 8
ad_data = df.iloc[:, 1:9].copy() # columns 1-8
ad_samples = [f"AD_{i+1}" for i in range(8)]
ad_data.columns = ad_samples

# Non-AD samples: After the "Mean" and "SD" columns, we have columns labeled 1-10
# These are in columns 13-22 (indices 13-22)
non_ad_data = df.iloc[:, 13:23].copy() # 10 control samples
non_ad_samples = [f"Control_{i+1}" for i in range(10)]
non_ad_data.columns = non_ad_samples

# Combine all expression data
counts_data = pd.concat([ad_data, non_ad_data], axis=1)
counts_data.index = genes
counts_data.index.name = 'gene_id'

# Set gene names as index (some genes may have non-unique names)
counts_data = counts_data.fillna(0).astype(np.float32)

print(f"\nProcessed expression matrix:")
print(f" Genes: {len(counts_data)}")
print(f" Samples: {counts_data.shape[1]}")
print(f" AD samples: {len(ad_samples)}")
print(f" Control samples: {len(non_ad_samples)}")
print(f" Value range: {counts_data.values.min():.2f} - {counts_data.values.max():.2f}")

# Create metadata
metadata = pd.DataFrame({
 'sample_id': counts_data.columns,
 'group': ['Disease'] * len(ad_samples) + ['Control'] * len(non_ad_samples),
 'condition': ['Alzheimer\'s Disease'] * len(ad_samples) + ['Non-affected'] * len(non_ad_samples),
})
metadata.set_index('sample_id', inplace=True)

print(f"\nMetadata:")
print(f" Samples: {metadata.shape[0]}")
print(f" Group distribution:")
print(metadata['group'].value_counts())

# Save files
output_dir = 'data/alzheimers/human/raw_datasets/GSE173955'
os.makedirs(output_dir, exist_ok=True)

counts_file = f'{output_dir}/counts.tsv'
metadata_file = f'{output_dir}/metadata.csv'

counts_data.to_csv(counts_file, sep='\t')
metadata.to_csv(metadata_file)

print(f"\n✓ Saved counts to {counts_file}")
print(f"✓ Saved metadata to {metadata_file}")

# Verify
print(f"\nVerification:")
print(f" Counts shape: {counts_data.shape}")
print(f" Metadata shape: {metadata.shape}")
print(f" Sample names match: {set(counts_data.columns) == set(metadata.index)}")
