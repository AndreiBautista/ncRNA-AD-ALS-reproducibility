#!/usr/bin/env python3
"""Extract counts matrix from a GEO series_matrix file."""

import argparse
from pathlib import Path
import pandas as pd


def main():
 parser = argparse.ArgumentParser(description="Extract counts from series_matrix.txt.gz")
 parser.add_argument("input_path", help="Path to series_matrix.txt or .gz")
 parser.add_argument("output_path", help="Output counts file (tsv)")
 args = parser.parse_args()

 input_path = Path(args.input_path)
 if not input_path.exists():
 raise FileNotFoundError(input_path)

 compression = "gzip" if input_path.suffix == ".gz" else None
 df = pd.read_csv(
 input_path,
 sep="\t",
 comment="!",
 compression=compression,
 engine="python",
 )
 if df.shape[1] < 2:
 raise ValueError("Parsed table has fewer than 2 columns.")

 output_path = Path(args.output_path)
 output_path.parent.mkdir(parents=True, exist_ok=True)
 df.to_csv(output_path, sep="\t", index=False)
 print("Saved:", output_path)
 print("Shape:", df.shape)


if __name__ == "__main__":
 main()
