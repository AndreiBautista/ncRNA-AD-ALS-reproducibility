#!/usr/bin/env python3
"""
Science Fair Presentation Summary Generator

Creates a comprehensive, structured summary report from multi-dataset ncRNA analysis
suitable for science fair presentations and scientific documentation.

Usage:
 python generate_presentation_summary.py --root results/multi_run --outdir presentation_materials
"""

import argparse
from pathlib import Path
import pandas as pd
from datetime import datetime


def generate_comprehensive_summary(results_root: Path, output_path: Path):
 """
 Generate a comprehensive presentation-ready summary.
 
 Args:
 results_root: Root directory with per_dataset results
 output_path: Path to output summary file
 """
 lines = []
 
 # Header
 lines.extend([
 "=" * 100,
 "MULTI-DATASET BULK RNA-SEQ ANALYSIS OF NEURODEGENERATIVE DISEASES",
 "Non-Coding RNA Biomarker Discovery Across Species",
 "=" * 100,
 f"Report Generated: {datetime.now().strftime('%B %d, %Y at %I:%M %p')}",
 "",
 ""
 ])
 
 # Section 1: Executive Summary
 lines.extend([
 "EXECUTIVE SUMMARY",
 "-" * 100,
 "",
 "BACKGROUND:",
 "Neurodegenerative diseases (Alzheimer's, Parkinson's, ALS) are devastating conditions with limited",
 "early diagnostic tools. Non-coding RNAs (ncRNAs) have emerged as promising biomarkers due to their",
 "stability in biological fluids and disease-specific expression patterns.",
 "",
 "OBJECTIVE:",
 "Identify conserved ncRNA biomarkers across multiple species (human, mouse, zebrafish) and diseases",
 "that could serve as universal early diagnostic markers for neurodegenerative conditions.",
 "",
 "APPROACH:",
 "We performed differential expression analysis on bulk RNA-seq datasets from multiple species and",
 "disease conditions, applying rigorous statistical thresholds (FDR < 0.1, |log2FC| > 0.5) to identify",
 "significantly dysregulated ncRNAs. Cross-dataset overlap analysis identified conserved biomarkers.",
 "",
 ""
 ])
 
 # Section 2: Methodology
 lines.extend([
 "METHODOLOGY",
 "-" * 100,
 "",
 "STATISTICAL ANALYSIS:",
 " • Differential Expression: DESeq2 or Welch's t-test",
 " • Multiple Testing Correction: Benjamini-Hochberg FDR",
 " • Significance Thresholds: FDR < 0.1 AND |log2 Fold-Change| > 0.5",
 " • Normalization: log2-CPM (counts per million)",
 "",
 "DESCRIPTIVE STATISTICS (Per Gene):",
 " • Mean normalized expression (disease group)",
 " • Mean normalized expression (control group)",
 " • Standard deviation for each group",
 "",
 "INFERENTIAL STATISTICS (Per Gene):",
 " • log2 Fold-Change (disease vs control)",
 " • Test statistic (t-statistic or Wald statistic)",
 " • Raw p-value",
 " • FDR-adjusted p-value",
 "",
 "BIOMARKER SELECTION:",
 " • Top 20 upregulated ncRNAs (highest positive log2FC)",
 " • Top 20 downregulated ncRNAs (lowest negative log2FC)",
 " • Cross-dataset validation (overlap analysis)",
 "",
 ""
 ])
 
 # Section 3: Load and summarize results
 per_dataset = results_root / "per_dataset"
 
 if per_dataset.exists():
 datasets = sorted([d for d in per_dataset.iterdir() if d.is_dir()])
 
 lines.extend([
 "DATASETS ANALYZED",
 "-" * 100,
 f"Total Datasets: {len(datasets)}",
 ""
 ])
 
 # Load and display each dataset summary
 dataset_summaries = {}
 for dataset_dir in datasets:
 dataset_id = dataset_dir.name
 
 # Try to load dataset summary
 summary_file = None
 for candidate in dataset_dir.glob("**/*_dataset_summary.csv"):
 summary_file = candidate
 break
 
 if summary_file and summary_file.exists():
 summary_df = pd.read_csv(summary_file)
 dataset_summaries[dataset_id] = summary_df
 
 lines.append(f"{dataset_id}:")
 for _, row in summary_df.iterrows():
 lines.append(f" {row['Metric']:.<50} {row['Value']}")
 lines.append("")
 
 # Section 4: Cross-Dataset Results
 lines.extend([
 "",
 "CROSS-DATASET ANALYSIS",
 "-" * 100,
 ""
 ])
 
 # Check for biomarker results
 biomarker_dir = results_root.parent / "biomarker_results"
 if biomarker_dir.exists():
 report_file = biomarker_dir / "biomarker_report.txt"
 if report_file.exists():
 lines.append("See biomarker_results/biomarker_report.txt for detailed cross-dataset analysis")
 lines.append("")
 
 # Section 5: Key Findings
 lines.extend([
 "",
 "KEY FINDINGS",
 "-" * 100,
 ""
 ])
 
 total_datasets = len(datasets)
 total_biomarkers = 0
 
 for dataset_id, summary_df in dataset_summaries.items():
 sig_ncrnas = summary_df[summary_df['Metric'] == 'Significant ncRNAs']['Value'].values
 if len(sig_ncrnas) > 0:
 try:
 total_biomarkers += int(sig_ncrnas[0])
 except:
 pass
 
 lines.extend([
 f"1. Analyzed {total_datasets} datasets across multiple species and disease conditions",
 f"2. Identified {total_biomarkers} total significant ncRNA biomarkers across all datasets",
 "3. Applied stringent statistical thresholds to ensure robust findings",
 "4. Generated publication-ready visualizations for each dataset:",
 " - Volcano plots (genome-wide differential expression)",
 " - PCA plots (sample clustering by condition)",
 " - Heatmaps (expression patterns of top biomarkers)",
 " - Bar plots (quantitative expression with error bars)",
 "",
 ""
 ])
 
 # Section 6: Biological Interpretation
 lines.extend([
 "BIOLOGICAL INTERPRETATION",
 "-" * 100,
 "",
 "UPREGULATED ncRNAs (Potential Diagnostic Markers):",
 " → Increased expression in disease state",
 " → Could indicate compensatory cellular mechanisms",
 " → May serve as positive diagnostic indicators",
 " → Potential therapeutic targets for downregulation",
 "",
 "DOWNREGULATED ncRNAs (Potential Diagnostic Markers):",
 " → Decreased expression in disease state",
 " → May indicate loss of normal regulatory function",
 " → Could serve as negative diagnostic indicators",
 " → Potential therapeutic targets for upregulation",
 "",
 "CROSS-SPECIES CONSERVATION:",
 " → Biomarkers present in multiple species suggest fundamental disease mechanisms",
 " → Species-specific biomarkers may reflect unique pathophysiology",
 " → Cross-validated findings increase clinical translation potential",
 "",
 ""
 ])
 
 # Section 7: Output Files
 lines.extend([
 "OUTPUT FILES & DATA",
 "-" * 100,
 "",
 "PER-DATASET RESULTS:",
 " Each dataset folder (results/multi_run/per_dataset/{dataset}/) contains:",
 "",
 " DATA TABLES:",
 " • {dataset}_dataset_summary.csv .......... Overview statistics",
 " • {dataset}_DE_summary.csv ............... Full differential expression results",
 " • {dataset}_biomarker_candidates.csv ..... Top 40 biomarkers (20 up + 20 down)",
 " • {dataset}_differential_results.csv ..... Complete results (all genes)",
 "",
 " FIGURES:",
 " • {dataset}_volcano_all_genes.png ........ Genome-wide DE visualization",
 " • {dataset}_volcano_ncRNA.png ............ ncRNA-specific DE",
 " • {dataset}_PCA.png ...................... Sample clustering",
 " • {dataset}_top_ncRNA_heatmap.png ........ Expression heatmap",
 " • {dataset}_top3_ncRNA_barplot.png ....... Quantitative expression (mean ± SD)",
 "",
 ""
 ])
 
 # Section 8: Statistical Considerations
 lines.extend([
 "STATISTICAL CONSIDERATIONS",
 "-" * 100,
 "",
 "DESCRIPTIVE STATISTICS:",
 " • Mean Expression: Average log2-CPM across all samples in each group",
 " • Standard Deviation: Measure of variability within each group",
 " • Larger SD indicates more heterogeneous expression",
 "",
 "INFERENTIAL STATISTICS:",
 " • log2 Fold-Change: Magnitude of expression change (disease vs control)",
 " - Positive: Upregulated in disease",
 " - Negative: Downregulated in disease",
 " - |log2FC| > 0.5 means >1.4-fold change",
 " - |log2FC| > 1.0 means >2-fold change",
 "",
 " • False Discovery Rate (FDR):",
 " - FDR < 0.1: <10% expected false positives",
 " - FDR < 0.05: <5% expected false positives",
 " - Benjamini-Hochberg correction for multiple testing",
 "",
 " • Test Statistic:",
 " - t-statistic (Welch's t-test): Measures strength of signal",
 " - Larger |t| indicates stronger evidence",
 "",
 ""
 ])
 
 # Section 9: Next Steps
 lines.extend([
 "RECOMMENDATIONS & NEXT STEPS",
 "-" * 100,
 "",
 "FOR SCIENCE FAIR PRESENTATION:",
 " 1. Highlight top biomarker candidates from each disease",
 " 2. Show cross-dataset validation (conserved biomarkers)",
 " 3. Present volcano plots and PCA to show robust separation",
 " 4. Use bar plots to quantify expression changes",
 " 5. Discuss biological relevance of top candidates",
 "",
 "FOR FURTHER RESEARCH:",
 " 1. Validate top candidates in independent cohorts",
 " 2. Perform functional studies (knockdown/overexpression)",
 " 3. Test biomarkers in patient samples (blood, CSF)",
 " 4. Investigate mechanism of dysregulation",
 " 5. Assess diagnostic performance (ROC curves, sensitivity/specificity)",
 "",
 ""
 ])
 
 # Section 10: Conclusion
 lines.extend([
 "CONCLUSION",
 "-" * 100,
 "",
 "This comprehensive analysis identified ncRNA biomarkers across multiple neurodegenerative",
 "disease models and species. The rigorous statistical approach, combining descriptive and",
 "inferential statistics with cross-dataset validation, provides high-confidence candidates",
 "for further study and potential clinical translation.",
 "",
 "The identified biomarkers represent promising targets for:",
 " • Early disease detection",
 " • Disease progression monitoring",
 " • Therapeutic intervention",
 " • Understanding disease mechanisms",
 "",
 "=" * 100,
 "",
 "END OF REPORT",
 "=" * 100
 ])
 
 else:
 lines.append("ERROR: No per_dataset results found. Please run pipeline first.")
 
 # Write report
 output_path.parent.mkdir(parents=True, exist_ok=True)
 output_path.write_text("\n".join(lines), encoding='utf-8')
 
 return str(output_path)


def main():
 parser = argparse.ArgumentParser(
 description="Generate comprehensive presentation summary for science fair"
 )
 parser.add_argument("--root", default="results/multi_run",
 help="Root directory with per_dataset results")
 parser.add_argument("--outdir", default="presentation_materials",
 help="Output directory for presentation materials")
 
 args = parser.parse_args()
 
 root = Path(args.root)
 output_dir = Path(args.outdir)
 output_dir.mkdir(parents=True, exist_ok=True)
 
 print("\n" + "=" * 80)
 print("GENERATING SCIENCE FAIR PRESENTATION SUMMARY")
 print("=" * 80 + "\n")
 
 summary_path = output_dir / "PRESENTATION_SUMMARY.txt"
 result_path = generate_comprehensive_summary(root, summary_path)
 
 print(f"✓ Presentation summary generated: {result_path}")
 print(f"\nThis comprehensive report includes:")
 print(" • Executive summary")
 print(" • Methodology description")
 print(" • Dataset statistics")
 print(" • Key findings")
 print(" • Biological interpretation")
 print(" • Statistical considerations")
 print(" • Recommendations for presentation")
 print("\n" + "=" * 80 + "\n")


if __name__ == "__main__":
 main()
