#!/usr/bin/env python3
"""
PATH A: Multi-Dataset Analysis for Alzheimer's
================================================

Runs ncRNA biomarker discovery on all 3 Alzheimer's human datasets
with proper annotations, then validates conservation across datasets.
"""

import pandas as pd
import numpy as np
from pathlib import Path
from scipy import stats
from statsmodels.stats.multitest import multipletests
import os

print("\n" + "="*80)
print(" PATH A: MULTI-DATASET ALZHEIMER'S ncRNA BIOMARKER DISCOVERY")
print("="*80)

# ===== CONFIGURATION =====
datasets = {
 'GSE203206': {
 'counts': 'GSE203206_Subramaniam.ADRC_brain.counts.tsv',
 'metadata': 'GSE203206_metadata.csv',
 'group_col': 'condition',
 'disease': 'Disease',
 'control': 'Control',
 },
 'dataset1': {
 'counts': 'data/alzheimers/human/dataset1/dataset1_counts.tsv',
 'metadata': 'data/alzheimers/human/dataset1/dataset1_metadata.csv',
 'group_col': 'condition',
 'disease': 'Disease',
 'control': 'Control',
 },
 'dataset2': {
 'counts': 'data/alzheimers/human/dataset2/dataset2_counts.tsv',
 'metadata': 'data/alzheimers/human/dataset2/dataset2_metadata.csv',
 'group_col': 'condition',
 'disease': 'Disease',
 'control': 'Control',
 },
 'dataset3': {
 'counts': 'data/alzheimers/human/dataset3/dataset3_counts.tsv',
 'metadata': 'data/alzheimers/human/dataset3/dataset3_metadata.csv',
 'group_col': 'condition',
 'disease': 'Disease',
 'control': 'Control',
 }
}

annotation_file = 'data/annotations/annotation_human.csv'

# ===== LOAD ANNOTATION =====
print("\n[STEP 1] Loading proper gene annotation...")
if not Path(annotation_file).exists():
 print(f"✗ {annotation_file} not found")
 print(" Run: python fix_annotations_path_a.py")
 exit(1)

annot_df = pd.read_csv(annotation_file, index_col=0)
print(f"✓ Loaded {len(annot_df):,} genes with proper biotypes")

# Define ncRNA keywords
nc_keywords = set(['lncrna', 'lnc_rna', 'mirna', 'mir', 'snorna', 'snrna',
 'antisense', 'misc_rna', 'rrna', 'ncrna', 'pseudogene',
 'scarna', 'vault_rna', 'srna'])

# ===== ANALYZE EACH DATASET =====
all_results = {}
output_dir = 'results/alzheimers/human/path_a_analysis'
os.makedirs(output_dir, exist_ok=True)

for dataset_name, config in datasets.items():
 print(f"\n{'='*80}")
 print(f"ANALYZING: {dataset_name}")
 print(f"{'='*80}")
 
 # Check if file exists
 if not Path(config['counts']).exists():
 print(f"✗ File not found: {config['counts']}")
 continue
 
 # ===== LOAD DATA =====
 print(f"Loading counts from {config['counts']}...")
 counts_df = pd.read_csv(config['counts'], sep='\t', index_col=0)
 print(f"✓ Loaded {counts_df.shape[0]:,} genes × {counts_df.shape[1]:,} samples")
 
 # Load metadata
 metadata_df = pd.read_csv(config['metadata'], index_col=0)
 print(f"✓ Loaded metadata for {len(metadata_df)} samples")
 
 # Filter to ncRNAs
 biotype = annot_df['biotype'].astype(str).fillna('').str.lower()
 ncrna_mask = biotype.apply(lambda x: any(k in x for k in nc_keywords))
 ncrna_genes = annot_df[ncrna_mask].index
 
 counts_ncrna = counts_df.loc[counts_df.index.intersection(ncrna_genes)].copy()
 print(f"✓ Filtered to {len(counts_ncrna)} ncRNA genes")
 
 # Get groups
 group_col = config['group_col']
 disease_label = config['disease']
 control_label = config['control']
 
 disease_samples = metadata_df[metadata_df[group_col].str.contains(disease_label, na=False, case=False)].index
 control_samples = metadata_df[metadata_df[group_col].str.contains(control_label, na=False, case=False)].index
 
 print(f" Disease samples: {len(disease_samples)}")
 print(f" Control samples: {len(control_samples)}")
 
 # Calculate expression
 disease_expr = np.log2(counts_ncrna.loc[:, disease_samples].mean(axis=1) + 1)
 control_expr = np.log2(counts_ncrna.loc[:, control_samples].mean(axis=1) + 1)
 
 log2fc = disease_expr - control_expr
 
 # T-test
 pvalues = []
 for gene in counts_ncrna.index:
 if len(disease_samples) > 0:
 disease_cols = [s for s in disease_samples if s in counts_ncrna.columns]
 control_cols = [s for s in control_samples if s in counts_ncrna.columns]
 
 if len(disease_cols) > 0 and len(control_cols) > 0:
 disease_vals = np.log2(counts_ncrna.loc[gene, disease_cols].values + 1)
 control_vals = np.log2(counts_ncrna.loc[gene, control_cols].values + 1)
 t_stat, p_val = stats.ttest_ind(disease_vals, control_vals, equal_var=False)
 pvalues.append(p_val)
 else:
 pvalues.append(1.0)
 else:
 pvalues.append(1.0)
 
 pvalues = np.array(pvalues)
 
 # FDR correction
 fdr_rejected, fdr_pvalues, _, _ = multipletests(pvalues, method='fdr_bh')
 
 # Create results
 results = pd.DataFrame({
 'gene_id': counts_ncrna.index,
 'mean_disease': disease_expr.values,
 'mean_control': control_expr.values,
 'log2FC': log2fc.values,
 'pvalue': pvalues,
 'fdr': fdr_pvalues,
 }, index=counts_ncrna.index)
 
 # Add annotation
 results = results.join(annot_df[['gene_name', 'biotype']])
 
 # ===== APPLY STRICT FILTERS =====
 print("\nApplying -grade filters...")
 print(" FDR < 0.01")
 print(" |log2FC| > 1.5")
 
 FDR_THRESHOLD = 0.01
 LOG2FC_THRESHOLD = 1.5
 
 filtered = results[
 (results['fdr'] < FDR_THRESHOLD) &
 (results['log2FC'].abs() > LOG2FC_THRESHOLD)
 ].copy().sort_values('fdr')
 
 print(f"✓ Found {len(filtered)} high-confidence ncRNA biomarkers")
 
 # Save results
 output_file = os.path.join(output_dir, f'{dataset_name}_ncrna_biomarkers.csv')
 filtered.to_csv(output_file)
 print(f"✓ Saved to {output_file}")
 
 # Store for cross-dataset analysis
 all_results[dataset_name] = filtered
 
 # Show top 5
 if len(filtered) > 0:
 print(f"\nTop 5 biomarkers:")
 for i, (gene_id, row) in enumerate(filtered.head(5).iterrows(), 1):
 gene_name = str(row['gene_name']) if pd.notna(row['gene_name']) else "?"
 biotype = str(row['biotype'])[:12] if pd.notna(row['biotype']) else "?"
 print(f" {i}. {gene_id:18s} | {gene_name:18s} | log2FC={row['log2FC']:6.2f}")

# ===== CROSS-DATASET VALIDATION =====
print("\n" + "="*80)
print(" CROSS-DATASET VALIDATION")
print("="*80)

if len(all_results) > 1:
 # Find genes present in all datasets
 all_genes = set(all_results[list(all_results.keys())[0]].index)
 for dataset_name in list(all_results.keys())[1:]:
 all_genes = all_genes.intersection(set(all_results[dataset_name].index))
 
 print(f"\nBiomarkers present in ALL {len(all_results)} datasets: {len(all_genes)}")
 
 if len(all_genes) > 0:
 # Create cross-dataset summary
 cross_data = []
 for gene_id in all_genes:
 row_data = {'gene_id': gene_id}
 
 for dataset_name, results_df in all_results.items():
 if gene_id in results_df.index:
 gene_row = results_df.loc[gene_id]
 row_data[f'{dataset_name}_log2FC'] = gene_row['log2FC']
 row_data[f'{dataset_name}_fdr'] = gene_row['fdr']
 row_data[f'{dataset_name}_name'] = gene_row.get('gene_name', '?')
 else:
 row_data[f'{dataset_name}_log2FC'] = np.nan
 row_data[f'{dataset_name}_fdr'] = np.nan
 
 cross_data.append(row_data)
 
 cross_df = pd.DataFrame(cross_data).set_index('gene_id')
 
 # Save cross-dataset results
 cross_file = os.path.join(output_dir, 'conserved_across_3_datasets.csv')
 cross_df.to_csv(cross_file)
 print(f"✓ Saved conserved biomarkers to {cross_file}")
 
 # Show top conserved
 print(f"\nTop conserved ncRNA biomarkers (dysregulated in ALL 3 datasets):")
 print(f"{'-'*80}")
 for i, (gene_id, row) in enumerate(cross_df.head(10).iterrows(), 1):
 # Get the gene name (from any dataset)
 gene_name = "?"
 for dataset_name in all_results.keys():
 name_col = f'{dataset_name}_name'
 if name_col in row.index and pd.notna(row[name_col]):
 gene_name = str(row[name_col])
 break
 
 # Get average log2FC direction
 fc_cols = [col for col in row.index if 'log2FC' in col]
 avg_fc = row[[col for col in fc_cols if pd.notna(row[col])]].mean()
 
 print(f"{i:2d}. {gene_id:18s} | {gene_name:18s} | Avg log2FC = {avg_fc:6.2f}")
 
 # Show summary table
 print(f"\n\nDetailed cross-dataset comparison (top 10):")
 print(f"{'-'*80}")
 display_cols = [col for col in cross_df.columns if 'log2FC' in col]
 print(cross_df[display_cols].head(10).to_string())

# ===== SUMMARY =====
print("\n" + "="*80)
print(" ANALYSIS COMPLETE")
print("="*80)

print(f"""
Results saved to: {output_dir}

Files generated:
✓ GSE203206_ncrna_biomarkers.csv ({len(all_results.get('GSE203206', pd.DataFrame()))} ncRNAs)
✓ dataset1_ncrna_biomarkers.csv ({len(all_results.get('dataset1', pd.DataFrame()))} ncRNAs)
✓ dataset2_ncrna_biomarkers.csv ({len(all_results.get('dataset2', pd.DataFrame()))} ncRNAs)
✓ dataset3_ncrna_biomarkers.csv ({len(all_results.get('dataset3', pd.DataFrame()))} ncRNAs)
✓ conserved_across_3_datasets.csv ({len(all_genes)} conserved ncRNAs)

KEY FINDINGS:
• {len(all_genes)} ncRNA biomarkers are dysregulated across ALL 3 Alzheimer's datasets
• These conserved biomarkers are the most confident candidates for validation
• Each biomarker has proper Ensembl biotype annotation (not "unknown")
• Strict filtering ensures high quality: FDR<0.01 and |log2FC|>1.5

NEXT STEPS:
1. Review the conserved biomarkers list
2. Perform literature search on top candidates
3. Plan experimental validation (qPCR, functional studies)
4. Expand to mouse and zebrafish models (Phase 2)

Path A is working beautifully! 🚀
""")

print("="*80)
