#!/usr/bin/env python3
"""Map GSE48350 probe IDs to gene symbols and Ensembl IDs."""

from pathlib import Path
import logging
import re

import pandas as pd
import GEOparse


def pick_gene_symbol_column(gpl_table: pd.DataFrame) -> str:
 preferred = ["Gene Symbol", "GENE_SYMBOL", "Gene symbol", "gene_symbol", "Symbol"]
 for col in preferred:
 if col in gpl_table.columns:
 return col
 for col in gpl_table.columns:
 if re.search(r"gene.*symbol|symbol", col, re.IGNORECASE):
 return col
 return ""


def normalize_symbol(value: str) -> str:
 if not isinstance(value, str):
 return ""
 value = value.strip()
 if not value:
 return ""
 # Common separators in GPL tables
 for sep in ["///", ";", ",", "|"]:
 if sep in value:
 value = value.split(sep)[0].strip()
 break
 return value


def main():
 logging.getLogger("GEOparse").setLevel(logging.WARNING)

 base_dir = Path("data/neurodegenerative_diseases/alzheimers/GSE48350")
 counts_path = base_dir / "counts.txt"
 if not counts_path.exists():
 raise FileNotFoundError(counts_path)

 geo_dir = base_dir / "geo"
 geo_dir.mkdir(parents=True, exist_ok=True)

 gse = GEOparse.get_GEO("GSE48350", destdir=str(geo_dir), annotate_gpl=True)
 if not gse.gpls:
 raise RuntimeError("No GPL table found for GSE48350.")

 gpl = next(iter(gse.gpls.values()))
 gpl_table = gpl.table

 gene_symbol_col = pick_gene_symbol_column(gpl_table)
 if not gene_symbol_col:
 raise RuntimeError("Could not find a gene symbol column in GPL table.")

 probe_col = gpl_table.columns[0]
 mapping = gpl_table[[probe_col, gene_symbol_col]].copy()
 mapping.columns = ["probe_id", "gene_symbol"]
 mapping["gene_symbol"] = mapping["gene_symbol"].astype(str).map(normalize_symbol)
 mapping = mapping[mapping["gene_symbol"] != ""]

 counts_df = pd.read_csv(counts_path, sep="\t", index_col=0)
 counts_df.index = counts_df.index.astype(str)

 counts_df = counts_df.join(mapping.set_index("probe_id"), how="left")
 counts_df = counts_df[counts_df["gene_symbol"].notna()]

 symbol_counts = counts_df.groupby("gene_symbol").mean(numeric_only=True)

 annot_path = Path("data/annotations/annotation_human.csv")
 annot_df = pd.read_csv(annot_path)
 annot_df = annot_df.dropna(subset=["gene_name", "gene_id"])\
 .drop_duplicates(subset=["gene_name"])
 symbol_to_ensembl = dict(zip(annot_df["gene_name"].astype(str), annot_df["gene_id"].astype(str)))

 symbol_counts["gene_id"] = symbol_counts.index.map(lambda s: symbol_to_ensembl.get(str(s)))
 mapped = symbol_counts[symbol_counts["gene_id"].notna()].copy()

 mapped = mapped.set_index("gene_id")
 mapped = mapped.drop(columns=[c for c in mapped.columns if c == "gene_id"], errors="ignore")

 out_path = base_dir / "counts_ensembl.tsv"
 mapped.to_csv(out_path, sep="\t")

 print("GPL platform:", gpl.name)
 print("Gene symbol column:", gene_symbol_col)
 print("Original probes:", counts_df.shape[0])
 print("Mapped symbols:", symbol_counts.shape[0])
 print("Mapped Ensembl IDs:", mapped.shape[0])
 print("Saved:", out_path)


if __name__ == "__main__":
 main()
