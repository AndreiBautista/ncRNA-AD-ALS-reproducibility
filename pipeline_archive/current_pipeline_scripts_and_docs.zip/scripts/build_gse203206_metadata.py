#!/usr/bin/env python3
"""Build metadata files for GSE203206 using provided metadata CSV."""

from pathlib import Path
import pandas as pd


def main():
 base_dir = Path("data/neurodegenerative_diseases/alzheimers/GSE203206")
 counts_path = base_dir / "counts.tsv"
 meta_source = Path("GSE203206_metadata.csv")

 if not counts_path.exists():
 raise FileNotFoundError(counts_path)
 if not meta_source.exists():
 raise FileNotFoundError(meta_source)

 counts_df = pd.read_csv(counts_path, sep="\t", nrows=0)
 sample_ids = counts_df.columns.tolist()[1:]

 meta_df = pd.read_csv(meta_source)
 meta_df = meta_df.rename(columns={"sample": "sample_id", "condition": "disease_status"})

 meta_df = meta_df[meta_df["sample_id"].isin(sample_ids)].copy()
 meta_df["tissue_type"] = "occipital_lobe"
 meta_df["study_id"] = "GSE203206"

 meta_full_path = base_dir / "metadata_full.csv"
 meta_df.to_csv(meta_full_path, index=False)

 meta_filtered = meta_df[meta_df["disease_status"].isin(["Disease", "Control"])].copy()
 meta_filtered_path = base_dir / "metadata_disease.csv"
 meta_filtered.to_csv(meta_filtered_path, index=False)

 print("Total samples in counts:", len(sample_ids))
 print("Metadata matched samples:", meta_df.shape[0])
 print("Disease/Control counts:")
 print(meta_filtered["disease_status"].value_counts())
 print("Saved:", meta_full_path)
 print("Saved:", meta_filtered_path)


if __name__ == "__main__":
 main()
