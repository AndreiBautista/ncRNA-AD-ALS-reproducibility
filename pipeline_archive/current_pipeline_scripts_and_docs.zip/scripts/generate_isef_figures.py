#!/usr/bin/env python3
"""
Generate -required figures for AD, ALS, and cross-disease analysis.
Figures:
- AD: volcano, heatmap (top 30), PCA, bar plots (top 3)
- ALS: volcano, heatmap (top 30), PCA, bar plots (top 3)
- Cross-disease: Venn diagram, shared ncRNA table, combined bar plots
"""

import math
import pandas as pd
import numpy as np
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle
from sklearn.metrics import roc_curve, auc

from pipeline import processing as pipeline_processing
from pipeline import de_analysis as pipeline_de
from pipeline import visualization as viz

BASE_DIR = Path(__file__).resolve().parent.parent
OUT_DIR = BASE_DIR / "results" / "isef_figures"
OUT_DIR.mkdir(parents=True, exist_ok=True)

AD_COUNTS_PATH = BASE_DIR / "data" / "alzheimers" / "human" / "raw_datasets" / "GSE203206" / "counts.tsv"
AD_COUNTS_FALLBACK = BASE_DIR / "data" / "alzheimers" / "human" / "raw_datasets" / "GSE203206" / "counts.csv"
AD_META_PATH = BASE_DIR / "data" / "alzheimers" / "human" / "raw_datasets" / "GSE203206" / "metadata.csv"
AD_BIO_PATH = BASE_DIR / "results" / "multi_dataset_analysis" / "GSE203206_biomarkers.csv"

ALS_COUNTS_PATH = BASE_DIR / "data" / "neurodegenerative_diseases" / "als" / "GSE124439" / "counts.csv"
ALS_META_PATH = BASE_DIR / "data" / "neurodegenerative_diseases" / "als" / "GSE124439" / "metadata.csv"
ALS_BIO_PATH = BASE_DIR / "results" / "multi_dataset_analysis" / "GSE124439_biomarkers.csv"

ANNOTATION_PATH = BASE_DIR / "data" / "annotations" / "annotation_human.csv"

SHARED_PATH = BASE_DIR / "results" / "multi_dataset_analysis" / "isef_analysis" / "Shared_ncRNAs_AD_ALS.csv"


def load_counts(path_primary: Path, path_fallback: Path = None) -> pd.DataFrame:
 if path_primary.exists():
 return pd.read_csv(path_primary, sep='\t', index_col=0, low_memory=False)
 if path_fallback and path_fallback.exists():
 return pd.read_csv(path_fallback, index_col=0, low_memory=False)
 raise FileNotFoundError(f"Counts file not found: {path_primary}")


def normalize_ensembl_index(df: pd.DataFrame) -> pd.DataFrame:
 df = df.copy()
 df.index = df.index.astype(str).str.split('.').str[0]
 return df


def ensure_fdr_columns(df: pd.DataFrame) -> pd.DataFrame:
 out = df.copy()
 if 'fdr' not in out.columns and 'padj' in out.columns:
 out['fdr'] = out['padj']
 if 'significant' not in out.columns and 'fdr' in out.columns:
 out['significant'] = out['fdr'] < 0.05
 return out


def load_metadata(path: Path) -> pd.DataFrame:
 return pd.read_csv(path, index_col=0)


def get_group_col(metadata: pd.DataFrame, preferred: str = None) -> str:
 if preferred and preferred in metadata.columns:
 return preferred

 try:
 return pipeline_de.detect_group_column(metadata)
 except ValueError:
 for candidate in ['disease_status', 'diagnosis', 'group', 'condition']:
 if candidate in metadata.columns:
 return candidate
 raise


def infer_labels(metadata: pd.DataFrame, group_col: str):
 values = list(metadata[group_col].value_counts().index)
 value_lower = {v: str(v).lower() for v in values}

 disease_keywords = ['disease', 'case', 'treatment', 'affected', 'als', 'ad', 'alzheimer']
 control_keywords = ['control', 'healthy', 'normal']

 disease_label = next((v for v in values if any(k in value_lower[v] for k in disease_keywords)), None)
 control_label = next((v for v in values if any(k in value_lower[v] for k in control_keywords)), None)

 if disease_label is None and control_label is None and len(values) == 2:
 control_label = metadata[group_col].value_counts().idxmin()
 disease_label = [v for v in values if v != control_label][0]
 elif disease_label is None and control_label is not None and len(values) == 2:
 disease_label = [v for v in values if v != control_label][0]
 elif control_label is None and disease_label is not None and len(values) == 2:
 control_label = [v for v in values if v != disease_label][0]

 if disease_label is None or control_label is None:
 disease_label, control_label, _, _ = pipeline_de.validate_groups(metadata, group_col)

 return disease_label, control_label


def get_gene_list(df: pd.DataFrame) -> list:
 if 'gene_id' in df.columns:
 return df['gene_id'].tolist()
 return df.index.tolist()


def map_logcpm_to_gene_name(logcpm_df: pd.DataFrame, annotation_path: Path) -> pd.DataFrame:
 if not annotation_path.exists():
 return logcpm_df

 annot = pd.read_csv(annotation_path)
 if 'gene_id' not in annot.columns or 'gene_name' not in annot.columns:
 return logcpm_df

 annot = annot[['gene_id', 'gene_name']].dropna()
 annot['gene_id'] = annot['gene_id'].astype(str).str.split('.').str[0]
 gene_map = annot.set_index('gene_id')['gene_name'].to_dict()

 mapped = logcpm_df.copy()
 mapped['gene_name'] = mapped.index.map(gene_map)
 mapped = mapped.dropna(subset=['gene_name'])
 mapped = mapped.groupby('gene_name').mean(numeric_only=True)
 return mapped


def plot_simple_venn(n_a: int, n_b: int, n_shared: int, out_path: Path, title: str):
 plt.figure(figsize=(6, 4))
 ax = plt.gca()
 ax.set_xlim(0, 10)
 ax.set_ylim(0, 6)
 ax.axis('off')

 left = Circle((4, 3), 2.5, alpha=0.3, color='#e74c3c')
 right = Circle((6, 3), 2.5, alpha=0.3, color='#3498db')
 ax.add_patch(left)
 ax.add_patch(right)

 ax.text(3, 3, str(n_a - n_shared), ha='center', va='center', fontsize=12)
 ax.text(7, 3, str(n_b - n_shared), ha='center', va='center', fontsize=12)
 ax.text(5, 3, str(n_shared), ha='center', va='center', fontsize=12, fontweight='bold')

 ax.text(3.5, 5.3, 'AD', ha='center', va='center', fontsize=12)
 ax.text(6.5, 5.3, 'ALS', ha='center', va='center', fontsize=12)
 ax.set_title(title, fontsize=12, fontweight='bold')

 out_path.parent.mkdir(parents=True, exist_ok=True)
 plt.tight_layout()
 plt.savefig(out_path, dpi=300)
 plt.close()


def combined_barplot_shared(logcpm_ad: pd.DataFrame, logcpm_als: pd.DataFrame,
 meta_ad: pd.DataFrame, meta_als: pd.DataFrame,
 group_col_ad: str, group_col_als: str,
 shared_genes: list, out_path: Path):
 if not shared_genes:
 return

 ad_disease_label, ad_control_label = infer_labels(meta_ad, group_col_ad)
 als_disease_label, als_control_label = infer_labels(meta_als, group_col_als)

 ad_disease_samples = meta_ad[meta_ad[group_col_ad] == ad_disease_label].index.tolist()
 ad_control_samples = meta_ad[meta_ad[group_col_ad] == ad_control_label].index.tolist()
 als_disease_samples = meta_als[meta_als[group_col_als] == als_disease_label].index.tolist()
 als_control_samples = meta_als[meta_als[group_col_als] == als_control_label].index.tolist()

 n = len(shared_genes)
 fig, axes = plt.subplots(1, n, figsize=(4 * n, 5), squeeze=False)
 axes = axes.flatten()

 for i, gene in enumerate(shared_genes):
 ax = axes[i]
 if gene not in logcpm_ad.index or gene not in logcpm_als.index:
 continue

 # AD stats
 ad_disease = logcpm_ad.loc[gene, ad_disease_samples]
 ad_control = logcpm_ad.loc[gene, ad_control_samples]

 # ALS stats
 als_disease = logcpm_als.loc[gene, als_disease_samples]
 als_control = logcpm_als.loc[gene, als_control_samples]

 means = [ad_control.mean(), ad_disease.mean(), als_control.mean(), als_disease.mean()]
 sds = [ad_control.std(), ad_disease.std(), als_control.std(), als_disease.std()]
 
 # Fix labels: if disease_label is already "ALS" or "AD", use "Disease"/"Control"
 ad_dis_txt = "Disease" if ad_disease_label in ["AD", "Alzheimer", "Disease"] else ad_disease_label
 ad_ctl_txt = "Control" if ad_control_label in ["Control", "Healthy"] else ad_control_label
 als_dis_txt = "Disease" if als_disease_label in ["ALS", "Disease"] else als_disease_label
 als_ctl_txt = "Control" if als_control_label in ["Control", "Healthy"] else als_control_label
 
 labels = [f"AD {ad_ctl_txt}", f"AD {ad_dis_txt}",
 f"ALS {als_ctl_txt}", f"ALS {als_dis_txt}"]
 colors = ['#3498db', '#e74c3c', '#3498db', '#e74c3c']

 x = np.arange(len(labels))
 ax.bar(x, means, yerr=sds, color=colors, alpha=0.75, capsize=4, edgecolor='black', linewidth=0.7)
 ax.set_xticks(x)
 ax.set_xticklabels(labels, rotation=45, ha='right')
 ax.set_title(gene)
 ax.set_ylabel('log2-CPM')

 out_path.parent.mkdir(parents=True, exist_ok=True)
 plt.tight_layout()
 plt.savefig(out_path, dpi=300, bbox_inches='tight')
 plt.close()


def roc_auc_plot(logcpm_df: pd.DataFrame, metadata: pd.DataFrame, group_col: str,
 top_genes: list, out_path: Path, title: str) -> dict:
 samples = logcpm_df.columns.intersection(metadata.index)
 if len(samples) == 0:
 return {}

 disease_label, control_label = infer_labels(metadata, group_col)
 group_series = metadata.loc[samples, group_col].astype(str)

 y_true = group_series.apply(lambda x: 1 if x == str(disease_label) else 0).values
 genes = [g for g in top_genes if g in logcpm_df.index]
 if len(genes) == 0:
 return {}

 scores = logcpm_df.loc[genes, samples].mean(axis=0).values
 fpr, tpr, _ = roc_curve(y_true, scores)
 auc_value = auc(fpr, tpr)

 plt.figure(figsize=(5, 5))
 plt.plot(fpr, tpr, color='#e74c3c', lw=2, label=f'AUC = {auc_value:.3f}')
 plt.plot([0, 1], [0, 1], color='grey', lw=1, linestyle='--')
 plt.xlabel('False Positive Rate (1 - Specificity)', fontsize=11)
 plt.ylabel('True Positive Rate (Sensitivity)', fontsize=11)
 plt.title(title)
 plt.legend(loc='lower right', bbox_to_anchor=(0.95, 0.15), framealpha=0.95)
 plt.tight_layout()
 out_path.parent.mkdir(parents=True, exist_ok=True)
 plt.savefig(out_path, dpi=300, bbox_inches='tight')
 plt.close()

 return {
 'auc': float(auc_value),
 'n_samples': int(len(samples)),
 'n_genes': int(len(genes)),
 'disease_label': str(disease_label),
 'control_label': str(control_label)
 }


print("Loading AD data...")
ad_counts = load_counts(AD_COUNTS_PATH, AD_COUNTS_FALLBACK)
ad_counts = normalize_ensembl_index(ad_counts)
ad_meta = load_metadata(AD_META_PATH)
ad_bio = pd.read_csv(AD_BIO_PATH)

print("Loading ALS data...")
als_counts = pd.read_csv(ALS_COUNTS_PATH, index_col=0)
als_meta = load_metadata(ALS_META_PATH)
als_bio = pd.read_csv(ALS_BIO_PATH)

# Determine group columns
ad_group_col = get_group_col(ad_meta)
als_group_col = get_group_col(als_meta, preferred='disease_status')

# Normalize counts
ad_logcpm = pipeline_processing.log2_cpm(ad_counts)
als_logcpm = pipeline_processing.log2_cpm(als_counts)

ad_logcpm = ad_logcpm.loc[:, ad_logcpm.columns.intersection(ad_meta.index)]
als_logcpm = als_logcpm.loc[:, als_logcpm.columns.intersection(als_meta.index)]

# Prepare biomarker tables
ad_bio = ensure_fdr_columns(ad_bio)
als_bio = ensure_fdr_columns(als_bio)

ad_sort_col = 'padj' if 'padj' in ad_bio.columns else 'fdr'
als_sort_col = 'padj' if 'padj' in als_bio.columns else 'fdr'

ad_top = ad_bio.sort_values(ad_sort_col).head(30)
als_top = als_bio.sort_values(als_sort_col).head(30)

# AD figures
print("Creating AD figures...")
viz.volcano_plot(ad_bio.rename(columns={'padj': 'fdr'}) if 'fdr' not in ad_bio else ad_bio,
 str(OUT_DIR / "ad_volcano.png"),
 title="AD ncRNA Volcano Plot")

viz.heatmap_top_genes(ad_logcpm, get_gene_list(ad_top), ad_meta, ad_group_col,
 str(OUT_DIR / "ad_heatmap_top30.png"))

viz.pca_plot(ad_logcpm, ad_meta, ad_group_col, str(OUT_DIR / "ad_pca.png"),
 title="AD PCA (ncRNA, log2-CPM)")

viz.barplot_top_genes_with_error(ad_logcpm, get_gene_list(ad_top), ad_meta, ad_group_col,
 str(OUT_DIR / "ad_top3_barplots.png"),
 title="AD Top 3 ncRNAs (Mean ± SD)", top_n=3)

ad_auc_stats = roc_auc_plot(
 ad_logcpm,
 ad_meta,
 ad_group_col,
 get_gene_list(ad_top)[:10],
 OUT_DIR / "ad_roc_auc.png",
 title="AD ROC (Top 10 ncRNAs)"
)

# ALS figures
print("Creating ALS figures...")
viz.volcano_plot(als_bio.rename(columns={'padj': 'fdr'}) if 'fdr' not in als_bio else als_bio,
 str(OUT_DIR / "als_volcano.png"),
 title="ALS ncRNA Volcano Plot")

viz.heatmap_top_genes(als_logcpm, get_gene_list(als_top), als_meta, als_group_col,
 str(OUT_DIR / "als_heatmap_top30.png"))

viz.pca_plot(als_logcpm, als_meta, als_group_col, str(OUT_DIR / "als_pca.png"),
 title="ALS PCA (ncRNA, log2-CPM)")

viz.barplot_top_genes_with_error(als_logcpm, get_gene_list(als_top), als_meta, als_group_col,
 str(OUT_DIR / "als_top3_barplots.png"),
 title="ALS Top 3 ncRNAs (Mean ± SD)", top_n=3)

als_auc_stats = roc_auc_plot(
 als_logcpm,
 als_meta,
 als_group_col,
 get_gene_list(als_top)[:10],
 OUT_DIR / "als_roc_auc.png",
 title="ALS ROC (Top 10 ncRNAs)"
)

# Cross-disease figures
print("Creating cross-disease figures...")

ad_sig = ad_bio[ad_bio[ad_sort_col] < 0.05].copy()
als_sig = als_bio[als_bio[als_sort_col] < 0.05].copy()

if 'gene_name' in ad_sig.columns and 'gene_name' in als_sig.columns:
 ad_set = set(ad_sig['gene_name'].dropna())
 als_set = set(als_sig['gene_name'].dropna())
else:
 ad_set = set(ad_sig['gene_id'].dropna())
 als_set = set(als_sig['gene_id'].dropna())

shared = sorted(ad_set.intersection(als_set))

plot_simple_venn(len(ad_set), len(als_set), len(shared), OUT_DIR / "ad_als_venn.png",
 title="Shared ncRNAs (FDR < 0.05)")

# Save shared table
shared_table_path = OUT_DIR / "shared_ncrna_table.csv"
pd.DataFrame({"gene_name": shared}).to_csv(shared_table_path, index=False)

# Combined bar plots for top shared candidates
shared_candidates = []
if SHARED_PATH.exists():
 shared_df = pd.read_csv(SHARED_PATH)
 if 'gene_name' in shared_df.columns:
 shared_candidates = shared_df['gene_name'].dropna().head(3).tolist()

ad_logcpm_by_name = map_logcpm_to_gene_name(ad_logcpm, ANNOTATION_PATH)

combined_barplot_shared(ad_logcpm_by_name, als_logcpm, ad_meta, als_meta,
 ad_group_col, als_group_col,
 shared_candidates, OUT_DIR / "shared_top3_barplots.png")

roc_summary = []
if ad_auc_stats:
 roc_summary.append({'dataset': 'AD', **ad_auc_stats})
if als_auc_stats:
 roc_summary.append({'dataset': 'ALS', **als_auc_stats})

if roc_summary:
 pd.DataFrame(roc_summary).to_csv(OUT_DIR / "roc_auc_summary.csv", index=False)

print(f"✓ figures saved to {OUT_DIR}")
