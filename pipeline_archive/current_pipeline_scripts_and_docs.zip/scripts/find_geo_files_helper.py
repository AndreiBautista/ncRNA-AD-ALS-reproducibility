#!/usr/bin/env python3
"""
Find exact location of count files on GEO pages
Check supplementary files, raw data, contact papers, etc.
"""

import sys

print("""
╔════════════════════════════════════════════════════════════════════════════╗
║ WHERE TO FIND COUNT FILES ON GEO ║
╚════════════════════════════════════════════════════════════════════════════╝

If you don't see supplementary files directly, try these locations:

STEP 1: Check the GEO Page
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

On each GEO page (https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSEXXXXX):

a) Look for "Supplementary file" section near the bottom
 - If it says "No supplements", go to step 2

b) Look for "Raw data" section 
 - May have SRA (Sequence Read Archive) links
 - Harder to use but contains raw data

c) Look for "Relations" section
 - May link to publication
 - Publication often has supplementary tables/data


STEP 2: Check the Published Paper
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

On each GEO page:
 a) Click "Publication" link (if available)
 b) Go to journal website
 c) Look for "Supplementary Materials" or "Supplementary Tables"
 d) Download Supplementary Table 1 (usually has counts/expression)


STEP 3: Alternative - Search for .xlsx or .txt files
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Try searching directly on GEO:
 Go to: https://www.ncbi.nlm.nih.gov/geo/browse/?view=overview&series=GSEXXXXX
 Scroll to "Full record" section
 Look for downloadable files link


STEP 4: Download Options For Each Dataset
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

GSE173955 (Hisayama - 18 samples, Hippocampus)
─────────────────────────────────────────────
 Location 1: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE173955
 → Scroll to bottom, look for "Supplementary file"
 
 Location 2: Published paper contains Supplementary Table
 → https://doi.org/[look on GEO page]
 
 Alternative: Contact authors from the paper
 → They usually respond within 24hrs


GSE95587 (Genentech/Roche - 117 samples, Fusiform Gyrus)
────────────────────────────────────────────────────────
 Location 1: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE95587
 → Check "Supplementary file" and "Raw data" sections
 
 This is a large published study, likely has supplementary files
 Check the publication for data availability


GSE124439 (NYGC ALS - 176 samples, Motor Cortex)
─────────────────────────────────────────────────
 Location 1: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE124439
 → NYGC (New York Genome Center) datasets usually have good data
 
 Location 2: May be linked from NYGC website directly
 → https://www.nygenome.org/


GSE116622 (NYGC C9ORF72 - 77 samples)
──────────────────────────────────────
 Location 1: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE116622
 → Check supplementary files

 Location 2: NYGC may host files directly


GSE76220 (Laser Capture Motor Neurons - 22 samples)
───────────────────────────────────────────────────
 Location 1: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE76220
 → Look for "ALS_LCM" or motor neuron specific files
 
 Location 2: Publication may have data files


═══════════════════════════════════════════════════════════════════════════════

IF YOU STILL CAN'T FIND THEM:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Option A: Contact the authors
 - Email corresponding author
 - Say: "I'm a high school student doing research on ncRNA biomarkers. 
 Can you share the raw expression counts for your study?"
 - Most researchers respond within 24-48 hours

Option B: Download from SRA (harder but possible)
 - Go to "Raw data" section on GEO
 - Click SRA link
 - Download with SRA Toolkit
 - Requires running alignment pipeline (more complex)

Option C: Use what you have
 - We already have GSE203206 with 48 samples
 - Can proceed with just Alzheimer's data alone
 - Still strong project!


═══════════════════════════════════════════════════════════════════════════════

WHAT TO TELL ME:

For each dataset, let me know:
 ✓ Whether you found the count file
 ✓ What filename you see
 ✓ What format it's in (.xlsx, .txt, .csv, etc.)
 ✓ How many rows/columns it has (if you can open it)

Then I'll help you download and organize it!

═══════════════════════════════════════════════════════════════════════════════
""")
