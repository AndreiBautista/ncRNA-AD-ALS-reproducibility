#!/usr/bin/env python3
"""Inspect GSE48350 GEO metadata for disease/control labels."""

from collections import Counter
from pathlib import Path
import logging

import GEOparse


def main():
 logging.getLogger("GEOparse").setLevel(logging.WARNING)

 out_dir = Path("data/neurodegenerative_diseases/alzheimers/GSE48350/geo")
 out_dir.mkdir(parents=True, exist_ok=True)

 gse = GEOparse.get_GEO("GSE48350", destdir=str(out_dir), annotate_gpl=False)

 records = []
 for gsm_name, gsm in gse.gsms.items():
 chars = gsm.metadata.get("characteristics_ch1", [])
 group = None
 diagnosis = None
 for c in chars:
 c_lower = c.lower()
 if c_lower.startswith("group:"):
 group = c.split(":", 1)[1].strip()
 if c_lower.startswith("diagnosis:"):
 diagnosis = c.split(":", 1)[1].strip()
 title = gsm.metadata.get("title", [""])[0]
 records.append((gsm_name, group, diagnosis, title))

 print("Total GSMs:", len(records))

 counter_group = Counter([r[1] for r in records if r[1]])
 counter_diag = Counter([r[2] for r in records if r[2]])

 if counter_group:
 print("Group value counts (top 10):")
 for val, cnt in counter_group.most_common(10):
 print(f"- {val}: {cnt}")
 if counter_diag:
 print("Diagnosis value counts (top 10):")
 for val, cnt in counter_diag.most_common(10):
 print(f"- {val}: {cnt}")

 print("\nExample entries:")
 for gsm, group, diagnosis, title in records[:5]:
 print(gsm, "|", group, "|", diagnosis, "|", title)


if __name__ == "__main__":
 main()
