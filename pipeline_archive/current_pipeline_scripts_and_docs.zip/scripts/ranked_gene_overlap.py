#!/usr/bin/env python3
"""Extract and compare ranked gene lists across datasets (without strict significance filtering)."""
import argparse
from pathlib import Path
import pandas as pd
from typing import Dict, Set


def load_de_results(csv_path: str) -> pd.DataFrame:
 """Load differential expression results."""
 df = pd.read_csv(csv_path)
 # Remove duplicates (can occur during pipeline runs)
 if "gene_id" in df.columns:
 df = df.drop_duplicates(subset=["gene_id"], keep="first")
 if "gene_id" in df.columns:
 df = df.set_index("gene_id")
 if "log2FC" not in df.columns and "log2FoldChange" in df.columns:
 df = df.rename(columns={"log2FoldChange": "log2FC"})
 return df


def extract_top_genes(df: pd.DataFrame, top_n: int = 100, fdr_cutoff: float = None, use_gene_name: bool = False) -> Dict[str, Set[str]]:
 """Extract top N up/down regulated genes from a dataset, optionally filtered by FDR.
 
 Args:
 df: DataFrame with log2FC and optional fdr columns
 top_n: Top N genes to extract per direction
 fdr_cutoff: Optional FDR cutoff for pre-filtering
 use_gene_name: If True and gene_name column exists, use it instead of gene_id
 """
 if fdr_cutoff is not None and "fdr" in df.columns:
 df = df[df["fdr"] < fdr_cutoff].copy()
 
 # Sort by log2FC and extract top N upregulated and downregulated
 df_sorted = df.sort_values("log2FC", ascending=False)
 
 # Get top n genes for each direction
 top_up_df = df_sorted.head(top_n)
 top_down_df = df_sorted.tail(top_n)
 
 # Use gene_name for matching if available and requested
 if use_gene_name and "gene_name" in df.columns:
 upregulated = set(top_up_df["gene_name"].fillna("").astype(str))
 downregulated = set(top_down_df["gene_name"].fillna("").astype(str))
 # Remove empty strings
 upregulated.discard("")
 downregulated.discard("")
 else:
 upregulated = set(top_up_df.index.astype(str))
 downregulated = set(top_down_df.index.astype(str))
 
 return {"upregulated": upregulated, "downregulated": downregulated}


def compute_overlap(gene_sets: Dict[str, Dict[str, Set[str]]]) -> Dict:
 """Compute pairwise overlaps between datasets."""
 datasets = sorted(gene_sets.keys())
 overlaps = {
 "up_up": {},
 "down_down": {},
 "up_down": {}, # Up in A vs Down in B
 }
 
 # Pairwise overlaps
 for i in range(len(datasets)):
 for j in range(i + 1, len(datasets)):
 a, b = datasets[i], datasets[j]
 
 # Up-up overlap
 up_overlap = gene_sets[a]["upregulated"].intersection(gene_sets[b]["upregulated"])
 overlaps["up_up"][f"{a}_vs_{b}"] = {
 "genes": sorted(up_overlap),
 "count": len(up_overlap),
 "pct_a": 100 * len(up_overlap) / len(gene_sets[a]["upregulated"]),
 "pct_b": 100 * len(up_overlap) / len(gene_sets[b]["upregulated"]),
 }
 
 # Down-down overlap
 down_overlap = gene_sets[a]["downregulated"].intersection(gene_sets[b]["downregulated"])
 overlaps["down_down"][f"{a}_vs_{b}"] = {
 "genes": sorted(down_overlap),
 "count": len(down_overlap),
 "pct_a": 100 * len(down_overlap) / len(gene_sets[a]["downregulated"]),
 "pct_b": 100 * len(down_overlap) / len(gene_sets[b]["downregulated"]),
 }
 
 # Up-down (cross-direction)
 cross = gene_sets[a]["upregulated"].intersection(gene_sets[b]["downregulated"])
 overlaps["up_down"][f"{a}_up_vs_{b}_down"] = {
 "genes": sorted(cross),
 "count": len(cross),
 "pct_a": 100 * len(cross) / len(gene_sets[a]["upregulated"]),
 "pct_b": 100 * len(cross) / len(gene_sets[b]["downregulated"]),
 }
 
 # All datasets shared
 if len(datasets) > 1:
 up_shared = set.intersection(*[gene_sets[d]["upregulated"] for d in datasets])
 down_shared = set.intersection(*[gene_sets[d]["downregulated"] for d in datasets])
 overlaps["shared_all"] = {
 "upregulated": sorted(up_shared),
 "downregulated": sorted(down_shared),
 "up_count": len(up_shared),
 "down_count": len(down_shared),
 }
 
 return overlaps


def main() -> None:
 parser = argparse.ArgumentParser(
 description="Extract ranked gene lists and compute overlaps (no strict significance required)"
 )
 parser.add_argument("--root", default="results/multi_run",
 help="Root folder containing per_dataset subfolder")
 parser.add_argument("--top_n", type=int, default=100,
 help="Top N genes to extract per direction (default 100)")
 parser.add_argument("--fdr", type=float, default=None,
 help="Optional FDR cutoff for pre-filtering (default: None = use all genes)")
 parser.add_argument("--use-gene-name", action="store_true",
 help="Use gene_name column for matching instead of gene_id (useful for cross-reference)")
 args = parser.parse_args()

 root = Path(args.root)
 per_dataset = root / "per_dataset"
 if not per_dataset.exists():
 raise FileNotFoundError(f"Missing per_dataset folder in {root}")

 output_dir = root / "ranked_genes"
 output_dir.mkdir(parents=True, exist_ok=True)

 gene_sets = {}
 dataset_summaries = []

 # Load and extract from each dataset
 for dataset_dir in sorted(p for p in per_dataset.iterdir() if p.is_dir()):
 res_path = None
 for candidate in dataset_dir.glob("**/*_differential_results.csv"):
 res_path = candidate
 break
 
 if res_path is None:
 print(f"⚠ Skipping {dataset_dir.name} (no results file found)")
 continue

 df = load_de_results(str(res_path))
 genes = extract_top_genes(df, top_n=args.top_n, fdr_cutoff=args.fdr, use_gene_name=args.use_gene_name)
 gene_sets[dataset_dir.name] = genes

 # Save top genes for each dataset
 up_genes = pd.DataFrame({"gene_id": sorted(genes["upregulated"])})
 down_genes = pd.DataFrame({"gene_id": sorted(genes["downregulated"])})
 
 up_genes.to_csv(output_dir / f"{dataset_dir.name}_top{args.top_n}_upregulated.csv", index=False)
 down_genes.to_csv(output_dir / f"{dataset_dir.name}_top{args.top_n}_downregulated.csv", index=False)

 dataset_summaries.append({
 "dataset": dataset_dir.name,
 "top_upregulated": len(genes["upregulated"]),
 "top_downregulated": len(genes["downregulated"]),
 "results_file": str(res_path),
 })

 print(f"✓ {dataset_dir.name}: {len(genes['upregulated'])} top up genes, {len(genes['downregulated'])} top down genes")

 if not gene_sets:
 raise SystemExit("No datasets found to analyze")

 # Compute overlaps
 overlaps = compute_overlap(gene_sets)

 # Write summary report
 summary_lines = [
 "=" * 70,
 "RANKED GENE LIST ANALYSIS & OVERLAP REPORT",
 "=" * 70,
 f"Analysis Date: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}",
 f"Top N genes per direction: {args.top_n}",
 f"FDR cutoff (optional): {args.fdr if args.fdr else 'None (all genes considered)'}",
 f"Gene ID matching: {'Using gene_name column' if args.use_gene_name else 'Using gene_id'}",
 "",
 "DATASET SUMMARY:",
 "-" * 70,
 ]

 for row in dataset_summaries:
 summary_lines.append(f"{row['dataset']}:")
 summary_lines.append(f" Top {args.top_n} upregulated: {row['top_upregulated']}")
 summary_lines.append(f" Top {args.top_n} downregulated: {row['top_downregulated']}")

 summary_lines.extend([
 "",
 "PAIRWISE OVERLAPS (UP-UP):",
 "-" * 70,
 ])

 for key, data in overlaps["up_up"].items():
 summary_lines.append(f"{key}: {data['count']} shared genes")
 summary_lines.append(f" {data['pct_a']:.1f}% of {key.split('_vs_')[0]}")
 summary_lines.append(f" {data['pct_b']:.1f}% of {key.split('_vs_')[1]}")
 if data["genes"]:
 summary_lines.append(f" Genes: {', '.join(data['genes'][:10])}" + ("..." if len(data["genes"]) > 10 else ""))

 summary_lines.extend([
 "",
 "PAIRWISE OVERLAPS (DOWN-DOWN):",
 "-" * 70,
 ])

 for key, data in overlaps["down_down"].items():
 summary_lines.append(f"{key}: {data['count']} shared genes")
 summary_lines.append(f" {data['pct_a']:.1f}% of {key.split('_vs_')[0]}")
 summary_lines.append(f" {data['pct_b']:.1f}% of {key.split('_vs_')[1]}")
 if data["genes"]:
 summary_lines.append(f" Genes: {', '.join(data['genes'][:10])}" + ("..." if len(data["genes"]) > 10 else ""))

 summary_lines.extend([
 "",
 "CROSS-DIRECTIONAL OVERLAPS (UP in A vs DOWN in B):",
 "-" * 70,
 ])

 for key, data in overlaps["up_down"].items():
 summary_lines.append(f"{key}: {data['count']} shared genes")
 if data["genes"]:
 summary_lines.append(f" Genes: {', '.join(data['genes'][:10])}" + ("..." if len(data["genes"]) > 10 else ""))

 if "shared_all" in overlaps:
 shared = overlaps["shared_all"]
 summary_lines.extend([
 "",
 "GENES SHARED ACROSS ALL DATASETS:",
 "-" * 70,
 f"Upregulated: {shared['up_count']} genes",
 ])
 if shared["upregulated"]:
 summary_lines.append(f" {', '.join(shared['upregulated'][:20])}" + ("..." if len(shared["upregulated"]) > 20 else ""))
 summary_lines.extend([
 f"Downregulated: {shared['down_count']} genes",
 ])
 if shared["downregulated"]:
 summary_lines.append(f" {', '.join(shared['downregulated'][:20])}" + ("..." if len(shared["downregulated"]) > 20 else ""))

 summary_lines.append("")
 summary_lines.append("=" * 70)

 summary_text = "\n".join(summary_lines)
 (output_dir / "RANKED_OVERLAP_REPORT.txt").write_text(summary_text, encoding="utf-8")
 print(f"\n✓ Summary saved: {output_dir / 'RANKED_OVERLAP_REPORT.txt'}")
 print(summary_text)


if __name__ == "__main__":
 main()
