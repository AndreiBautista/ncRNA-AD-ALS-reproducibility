#!/usr/bin/env python3
"""
Multi-Dataset AD Analysis - Robust Version
Handles mixed formats, creates best-effort mappings
"""

import pandas as pd
import numpy as np
from scipy.stats import ttest_ind
from statsmodels.stats.multitest import multipletests
from pathlib import Path

print("="*80)
print("MULTI-DATASET ALZHEIMER'S ANALYSIS (ROBUST)")
print("="*80)

# Load gene annotation
print("\nLoading annotation...")
annotation = pd.read_csv('data/annotations/annotation_human.csv')

nc_keywords = {'lncrna', 'lnc_rna', 'mirna', 'mir', 'snorna', 'snrna', 
 'antisense', 'misc_rna', 'rrna', 'ncrna', 'pseudogene', 
 'scarna', 'vault_rna', 'srna'}

annotation['biotype_lower'] = annotation['biotype'].fillna('').str.lower()
annotation['is_ncrna'] = annotation['biotype_lower'].apply(
 lambda x: any(kw in x for kw in nc_keywords) if pd.notna(x) else False
)

ncRNA_set = set(annotation[annotation['is_ncrna']]['gene_id'].values)
symbol_to_ensembl = dict(zip(annotation['gene_name'], annotation['gene_id']))

print(f"✓ {len(annotation)} genes ({len(ncRNA_set)} ncRNAs)")


def run_de(counts, metadata, group_col, min_samples=2):
 """Run differential expression analysis."""
 try:
 groups = metadata[group_col].dropna().unique()
 if len(groups) < 2:
 return None
 
 disease_group = groups[0]
 control_group = groups[1]
 
 d_samples = [s for s in metadata[metadata[group_col] == disease_group].index if s in counts.columns]
 c_samples = [s for s in metadata[metadata[group_col] == control_group].index if s in counts.columns]
 
 if len(d_samples) < min_samples or len(c_samples) < min_samples:
 print(f" ✗ Insufficient samples: {len(d_samples)} disease, {len(c_samples)} control")
 return None
 
 print(f" ✓ {len(d_samples)} disease vs {len(c_samples)} control")
 
 d_expr = counts[d_samples].values
 c_expr = counts[c_samples].values
 
 mean_d = d_expr.mean(axis=1)
 mean_c = c_expr.mean(axis=1)
 std_d = d_expr.std(axis=1) + 1e-10
 std_c = c_expr.std(axis=1) + 1e-10
 
 log2fc = mean_d - mean_c
 
 n_d, n_c = d_expr.shape[1], c_expr.shape[1]
 se = np.sqrt((std_d**2 / n_d) + (std_c**2 / n_c))
 t_stats = log2fc / (se + 1e-10)
 
 from scipy.stats import t as t_dist
 df = max(1, n_d + n_c - 2)
 p_vals = 2 * (1 - t_dist.cdf(np.abs(t_stats), df))
 p_vals = np.clip(p_vals, 1e-300, 1)
 
 results = pd.DataFrame({
 'gene_id': counts.index,
 'mean_disease': mean_d,
 'mean_control': mean_c,
 'log2FC': log2fc,
 'pvalue': p_vals
 })
 
 _, results['padj'], _, _ = multipletests(results['pvalue'], method='fdr_bh')
 
 bio = results[results['padj'] < 0.05].copy()
 bio = bio.merge(annotation[['gene_id', 'gene_name', 'biotype']], on='gene_id', how='left')
 bio = bio.sort_values('padj')
 
 print(f" ✓ {len(bio)} biomarkers (FDR < 0.05)")
 
 return bio
 except Exception as e:
 print(f" ✗ DE error: {e}")
 return None


all_results = {}

# ========================================================================
# GSE203206 (Already Ensembl IDs)
# ========================================================================
print(f"\n{'='*80}\nGSE203206\n{'='*80}")

try:
 counts = pd.read_csv('data/alzheimers/human/raw_datasets/GSE203206/counts.tsv', 
 sep='\t', index_col=0, low_memory=False)
 meta = pd.read_csv('data/alzheimers/human/raw_datasets/GSE203206/metadata.csv', index_col=0)
 
 print(f"Loaded {counts.shape[0]} genes × {counts.shape[1]} samples")
 
 lib_sizes = counts.sum(axis=0)
 log2cpm = np.log2((counts.div(lib_sizes) * 1e6) + 1)
 log2cpm_nc = log2cpm[log2cpm.index.isin(ncRNA_set)]
 
 print(f"Filtered to {len(log2cpm_nc)} ncRNAs")
 
 bio = run_de(log2cpm_nc, meta, 'condition')
 if bio is not None:
 all_results['GSE203206'] = bio
 Path('results/multi_dataset_analysis').mkdir(parents=True, exist_ok=True)
 bio.to_csv('results/multi_dataset_analysis/GSE203206_biomarkers.csv', index=False)
 print("✓ Saved")

except Exception as e:
 print(f"✗ Error: {e}")


# ========================================================================
# GSE33000 (Ensembl IDs already mapped)
# ========================================================================
print(f"\n{'='*80}\nGSE33000\n{'='*80}")

try:
 counts = pd.read_csv('data/alzheimers/human/raw_datasets/GSE33000/counts_ensembl.txt',
 sep='\t', index_col=0, low_memory=False, nrows=None)
 # First row might be header-only, remove if so
 if counts.index[0] == '' or counts.index[0].startswith('HBTRC'):
 counts = counts.iloc[1:]
 
 meta = pd.read_csv('data/alzheimers/human/raw_datasets/GSE33000/metadata.txt', 
 sep='\t', index_col=0)
 
 print(f"Loaded {counts.shape[0]} genes × {counts.shape[1]} samples")
 
 lib_sizes = counts.sum(axis=0)
 log2cpm = np.log2((counts.div(lib_sizes) * 1e6) + 1)
 log2cpm_nc = log2cpm[log2cpm.index.isin(ncRNA_set)]
 
 print(f"Filtered to {len(log2cpm_nc)} ncRNAs")
 
 bio = run_de(log2cpm_nc, meta, 'condition')
 if bio is not None:
 all_results['GSE33000'] = bio
 bio.to_csv('results/multi_dataset_analysis/GSE33000_biomarkers.csv', index=False)
 print("✓ Saved")

except Exception as e:
 print(f"✗ Error: {e}")


# ========================================================================
# GSE173955 (Gene symbols - requires mapping)
# ========================================================================
print(f"\n{'='*80}\nGSE173955\n{'='*80}")

try:
 counts = pd.read_csv('data/alzheimers/human/raw_datasets/GSE173955/counts.tsv',
 sep='\t', index_col=0, low_memory=False)
 meta = pd.read_csv('data/alzheimers/human/raw_datasets/GSE173955/metadata.csv', index_col=0)
 
 print(f"Loaded {counts.shape[0]} genes × {counts.shape[1]} samples (gene symbols)")
 
 # Map gene symbols to Ensembl IDs
 mapped_data = []
 for sym in counts.index:
 sym_str = str(sym)
 if sym_str in symbol_to_ensembl:
 ensembl_id = symbol_to_ensembl[sym_str]
 mapped_data.append({
 'ensembl_id': ensembl_id,
 'values': counts.loc[sym]
 })
 
 if len(mapped_data) > 0:
 mapped_counts = pd.DataFrame(
 [d['values'].values for d in mapped_data],
 index=[d['ensembl_id'] for d in mapped_data],
 columns=counts.columns
 )
 print(f"Mapped {len(mapped_counts)} genes to Ensembl IDs")
 
 lib_sizes = mapped_counts.sum(axis=0)
 log2cpm = np.log2((mapped_counts.div(lib_sizes) * 1e6) + 1)
 log2cpm_nc = log2cpm[log2cpm.index.isin(ncRNA_set)]
 
 print(f"Filtered to {len(log2cpm_nc)} ncRNAs")
 
 bio = run_de(log2cpm_nc, meta, 'condition')
 if bio is not None:
 all_results['GSE173955'] = bio
 bio.to_csv('results/multi_dataset_analysis/GSE173955_biomarkers.csv', index=False)
 print("✓ Saved")

except Exception as e:
 print(f"✗ Error: {e}")


# ========================================================================
# SUMMARY
# ========================================================================

print(f"\n{'='*80}")
print("SUMMARY")
print("="*80)

if len(all_results) >= 2:
 print(f"\n✓ Successfully analyzed {len(all_results)} datasets:")
 
 total_samples = 0
 for gse_id in all_results:
 n_bio = len(all_results[gse_id])
 if gse_id == 'GSE203206':
 n_samp = 47
 elif gse_id == 'GSE33000':
 n_samp = 624
 else:
 n_samp = 31
 
 total_samples += n_samp
 print(f" {gse_id:12s}: {n_bio:5d} biomarkers ({n_samp:4d} samples)")
 
 print(f"\n Total samples: {total_samples}")
 print(f" Total biomarkers: {sum(len(all_results[g]) for g in all_results)}")
 
 # Find conserved
 conserved_genes = set(all_results[list(all_results.keys())[0]]['gene_id'])
 for gse_id in list(all_results.keys())[1:]:
 conserved_genes &= set(all_results[gse_id]['gene_id'])
 
 print(f"\n✓ Conserved across ALL {len(all_results)} datasets: {len(conserved_genes)}")
 
 if len(conserved_genes) > 0:
 first_gse = list(all_results.keys())[0]
 conserved = all_results[first_gse][all_results[first_gse]['gene_id'].isin(conserved_genes)].sort_values('padj')
 
 conserved.to_csv('results/multi_dataset_analysis/conserved_across_all_datasets.csv', index=False)
 print("✓ Saved conserved biomarkers")
 
 print(f"\nTop conserved biomarkers:")
 for _, r in conserved.head(10).iterrows():
 gn = str(r['gene_name']) if pd.notna(r['gene_name']) else ''
 print(f" {gn:20s} log2FC={float(r['log2FC']):7.2f} FDR={float(r['padj']):.2e}")

else:
 print(f"\n✗ Only {len(all_results)} dataset(s) - need 2+")

print(f"\n{'='*80}")
