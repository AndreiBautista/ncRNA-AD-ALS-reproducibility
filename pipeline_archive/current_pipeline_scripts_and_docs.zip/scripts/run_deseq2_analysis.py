#!/usr/bin/env python3
"""
Python wrapper for DESeq2 analysis pipeline.

Runs differential expression analysis on harmonized disease datasets.
"""

import subprocess
import pandas as pd
from pathlib import Path
import sys

# Configuration
DATASETS = {
 'Alzheimer\'s Disease': {
 'counts': 'data/harmonized_datasets/alzheimers_disease_counts.csv',
 'metadata': 'data/harmonized_datasets/alzheimers_disease_metadata.csv',
 'output_dir': 'results/deseq2/alzheimers'
 },
 'ALS': {
 'counts': 'data/harmonized_datasets/als_counts.csv',
 'metadata': 'data/harmonized_datasets/als_metadata.csv',
 'output_dir': 'results/deseq2/als'
 }
}

ANNOTATION_FILE = 'data/annotations/Homo_sapiens.GRCh38.110_annotation.csv'
DESEQ2_SCRIPT = 'deseq2_analysis.R'


def check_r_packages():
 """Check if required R packages are installed."""
 print("Checking R packages...")
 r_code = '''
 required <- c("DESeq2", "BiocGenerics", "S4Vectors")
 missing <- character()
 for (pkg in required) {
 if (!require(pkg, character.only = TRUE, quietly = TRUE)) {
 missing <- c(missing, pkg)
 }
 }
 if (length(missing) > 0) {
 cat("MISSING:", paste(missing, collapse = ","))
 } else {
 cat("OK")
 }
 '''
 
 result = subprocess.run(
 ['Rscript', '-e', r_code],
 capture_output=True,
 text=True
 )
 
 if "MISSING:" in result.stdout:
 missing_pkgs = result.stdout.replace("MISSING:", "").strip().split(",")
 print(f" ⚠ Missing R packages: {', '.join(missing_pkgs)}")
 print(" Installing required packages...")
 
 install_code = '''
 if (!require("BiocManager", character.only = TRUE, quietly = TRUE)) {
 install.packages("BiocManager", repos="http://cran.r-project.org")
 }
 BiocManager::install(c("DESeq2", "BiocGenerics", "S4Vectors"), quiet = TRUE)
 '''
 
 subprocess.run(['Rscript', '-e', install_code], capture_output=True)
 print(" ✓ Packages installed")
 else:
 print(" ✓ All required R packages available")


def run_deseq2_analysis(disease_name, config):
 """Run DESeq2 analysis for a disease."""
 print(f"\n{'='*70}")
 print(f"DESeq2 ANALYSIS: {disease_name.upper()}")
 print(f"{'='*70}")
 
 # Verify input files exist
 counts_file = Path(config['counts'])
 metadata_file = Path(config['metadata'])
 
 if not counts_file.exists():
 print(f"✗ Counts file not found: {counts_file}")
 return False
 
 if not metadata_file.exists():
 print(f"✗ Metadata file not found: {metadata_file}")
 return False
 
 if not Path(ANNOTATION_FILE).exists():
 print(f"✗ Annotation file not found: {ANNOTATION_FILE}")
 return False
 
 print(f"\nInputs:")
 print(f" Counts: {counts_file}")
 print(f" Metadata: {metadata_file}")
 print(f" Annotation: {ANNOTATION_FILE}")
 print(f" Output: {config['output_dir']}")
 
 # Create output directory
 output_dir = Path(config['output_dir'])
 output_dir.mkdir(parents=True, exist_ok=True)
 
 # Run DESeq2 script
 print(f"\nRunning DESeq2...")
 cmd = [
 'Rscript',
 DESEQ2_SCRIPT,
 str(counts_file),
 str(metadata_file),
 disease_name,
 str(output_dir),
 ANNOTATION_FILE
 ]
 
 result = subprocess.run(cmd, capture_output=True, text=True)
 
 # Print output
 print(result.stdout)
 
 if result.returncode != 0:
 print(f"✗ DESeq2 analysis failed:")
 print(result.stderr)
 return False
 
 # Verify output files were created
 results_files = [
 f'{output_dir}/all_de_results.csv',
 f'{output_dir}/ncrna_de_results.csv',
 f'{output_dir}/ncrna_biomarkers.csv'
 ]
 
 created_files = []
 for result_file in results_files:
 if Path(result_file).exists():
 created_files.append(result_file)
 print(f" ✓ {Path(result_file).name}")
 
 if not created_files:
 print(f"✗ No output files generated")
 return False
 
 return True


def summarize_results():
 """Summarize DESeq2 results across diseases."""
 print(f"\n{'='*70}")
 print("ANALYSIS SUMMARY")
 print(f"{'='*70}")
 
 diseases = ['Alzheimer\'s Disease', 'ALS']
 
 for disease_name in diseases:
 output_dir = Path(DATASETS[disease_name]['output_dir'])
 biomarkers_file = output_dir / 'ncrna_biomarkers.csv'
 
 if biomarkers_file.exists():
 biomarkers = pd.read_csv(biomarkers_file)
 print(f"\n{disease_name}:")
 print(f" - Total ncRNA biomarkers (FDR < 0.05): {len(biomarkers)}")
 
 if len(biomarkers) > 0:
 upregulated = (biomarkers['log2FoldChange'] > 0).sum()
 downregulated = (biomarkers['log2FoldChange'] < 0).sum()
 print(f" - Upregulated: {upregulated}")
 print(f" - Downregulated: {downregulated}")
 
 # Top genes by FDR
 print(f" - Top 5 biomarkers:")
 for idx, row in biomarkers.head(5).iterrows():
 gene_name = row['gene_name'] if pd.notna(row['gene_name']) else row['gene_id']
 print(f" • {gene_name}: log2FC={row['log2FoldChange']:.2f}, "
 f"padj={row['padj']:.2e}")


def main():
 """Main orchestration."""
 print(f"{'='*70}")
 print("DESeq2 DIFFERENTIAL EXPRESSION ANALYSIS")
 print(f"{'='*70}")
 
 # Check R setup
 check_r_packages()
 
 # Run analysis for each disease
 all_success = True
 for disease_name, config in DATASETS.items():
 if not run_deseq2_analysis(disease_name, config):
 all_success = False
 
 if not all_success:
 print("\n✗ Some analyses failed")
 sys.exit(1)
 
 # Summarize results
 summarize_results()
 
 print(f"\n{'='*70}")
 print("✓ DESeq2 ANALYSIS COMPLETE")
 print(f"{'='*70}")
 print("\nNext steps:")
 print(" 1. Identify shared biomarkers between diseases")
 print(" 2. Generate publication-quality visualizations")
 print(" 3. Create presentation materials")


if __name__ == '__main__':
 main()
