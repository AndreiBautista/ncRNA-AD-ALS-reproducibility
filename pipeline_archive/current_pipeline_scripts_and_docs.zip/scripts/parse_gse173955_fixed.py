#!/usr/bin/env python3
"""
Parse GSE173955 series_matrix.txt properly
Extracts sample information from titles and expression data
"""

import pandas as pd
import os

print("Parsing GSE173955 series_matrix.txt...")

series_file = 'data/alzheimers/human/raw_datasets/GSE173955/GSE173955_series_matrix.txt'
output_dir = 'data/alzheimers/human/raw_datasets/GSE173955'

samples = []
phenotypes = []
expression_data = {}
in_data_table = False

with open(series_file, 'r', encoding='utf-8', errors='ignore') as f:
 lines = f.readlines()

# Find sample titles line
for i, line in enumerate(lines):
 if line.startswith('!Sample_title'):
 parts = line.rstrip().split('\t')
 sample_titles = parts[1:] # Skip the "!Sample_title" part
 
 # Parse phenotype from titles
 for title in sample_titles:
 title_clean = title.strip('"')
 samples.append(title_clean[:30]) # Shorten for clarity
 
 if 'Alzheimer' in title_clean or 'Disease' in title_clean:
 phenotypes.append('Disease')
 else:
 phenotypes.append('Control')
 
 print(f"Found {len(samples)} samples")
 print(f" Disease: {phenotypes.count('Disease')}")
 print(f" Control: {phenotypes.count('Control')}")
 break

# Extract expression data from table
print("Extracting expression data...")
for i, line in enumerate(lines):
 if '!series_matrix_table_begin' in line:
 in_data_table = True
 continue
 
 if '!series_matrix_table_end' in line:
 break
 
 if in_data_table and line.startswith('"'):
 parts = line.rstrip().split('\t')
 
 if parts[0] == '"ID_REF"':
 continue
 
 gene_id = parts[0].strip('"')
 try:
 # Extract expression values for each sample
 values = []
 for j in range(1, len(samples) + 1):
 if j < len(parts):
 val = float(parts[j].strip('"'))
 values.append(val)
 else:
 values.append(0)
 
 if len(values) == len(samples):
 expression_data[gene_id] = values
 except (ValueError, IndexError):
 continue

print(f"Extracted {len(expression_data)} genes")

if not samples or not expression_data:
 print("ERROR: No samples or expression data found!")
 exit(1)

# Create counts dataframe
counts_df = pd.DataFrame(expression_data, index=samples).T
counts_df.index.name = 'gene_id'

counts_file = os.path.join(output_dir, 'counts.tsv')
counts_df.to_csv(counts_file, sep='\t')
print(f"✓ Saved counts to {counts_file}")

# Create metadata
metadata_df = pd.DataFrame({
 'sample': samples,
 'phenotype': phenotypes
})
metadata_df.set_index('sample', inplace=True)

metadata_file = os.path.join(output_dir, 'metadata.csv')
metadata_df.to_csv(metadata_file)
print(f"✓ Saved metadata to {metadata_file}")

print(f"\nGSE173955 Parsing Summary:")
print(f" Samples: {len(samples)}")
print(f" Genes: {len(expression_data)}")
print(f" Disease: {phenotypes.count('Disease')}")
print(f" Control: {phenotypes.count('Control')}")
print(f" Ready for analysis: ✅")
