#!/usr/bin/env python3
"""
Multi-Dataset Alzheimer's ncRNA Biomarker Discovery
Analyzes all 3 available AD datasets + finds alternatives if needed
"""

import pandas as pd
import numpy as np
from scipy.stats import ttest_ind
from statsmodels.stats.multitest import multipletests
import os
import sys
from pathlib import Path

print("="*80)
print("MULTI-DATASET ALZHEIMER'S ncRNA BIOMARKER DISCOVERY")
print("="*80)

# Load annotation
print("\n[STEP 1] Loading gene annotation...")
try:
 annotation = pd.read_csv('data/annotations/annotation_human.csv')
 print(f"✓ Loaded {len(annotation)} genes")
 
 # Create biotype mapping
 nc_keywords = {'lncrna', 'lnc_rna', 'mirna', 'mir', 'snorna', 'snrna', 
 'antisense', 'misc_rna', 'rrna', 'ncrna', 'pseudogene', 
 'scarna', 'vault_rna', 'srna'}
 
 annotation['biotype_lower'] = annotation['biotype'].fillna('').str.lower()
 annotation['is_ncrna'] = annotation['biotype_lower'].apply(
 lambda x: any(kw in x for kw in nc_keywords) if pd.notna(x) else False
 )
 print(f"✓ Identified {annotation['is_ncrna'].sum()} ncRNAs")
except Exception as e:
 print(f"✗ Error loading annotation: {e}")
 sys.exit(1)


def load_and_normalize(gse_id, counts_file, metadata_file, dataset_path):
 """Load and normalize a dataset."""
 try:
 print(f"\n[{gse_id}] Loading data...")
 
 # Load counts
 if counts_file.endswith('.tsv'):
 sep = '\t'
 else:
 sep = '\t'
 
 counts = pd.read_csv(f"{dataset_path}/{counts_file}", sep=sep, index_col=0, low_memory=False)
 print(f" ✓ Counts: {counts.shape[0]} genes × {counts.shape[1]} samples")
 
 # Load metadata
 metadata = pd.read_csv(f"{dataset_path}/{metadata_file}", index_col=0)
 print(f" ✓ Metadata: {len(metadata)} samples")
 
 # Ensure counts index is string (gene IDs)
 counts.index = counts.index.astype(str)
 
 # Map to Ensembl IDs if needed
 if not counts.index[0].startswith('ENSG'):
 print(f" ⚠ Gene IDs not Ensembl format, attempting mapping...")
 # Try to map using gene names
 mapped_counts = pd.DataFrame()
 mapped_genes = []
 
 for gene_id in counts.index:
 # Try exact match first
 matching = annotation[annotation['gene_id'] == gene_id]
 if len(matching) == 0:
 # Try gene name match
 matching = annotation[annotation['gene_name'].astype(str) == str(gene_id)]
 
 if len(matching) > 0:
 ensembl_id = matching.iloc[0]['gene_id']
 if ensembl_id not in mapped_genes:
 mapped_counts[ensembl_id] = counts.loc[gene_id]
 mapped_genes.append(ensembl_id)
 
 print(f" ✓ Mapped {len(mapped_genes)} genes to Ensembl IDs")
 counts = mapped_counts.T.T # Transpose to keep genes as index
 
 # Normalize to CPM then log2
 lib_sizes = counts.sum(axis=0)
 cpm = (counts.div(lib_sizes) * 1e6).fillna(0)
 log2cpm = np.log2(cpm + 1)
 print(f" ✓ Normalized to log2(CPM+1)")
 
 # Filter to ncRNAs (optimized)
 ncRNA_set = set(annotation[annotation['is_ncrna']]['gene_id'].values)
 ncRNA_genes = [g for g in log2cpm.index if g in ncRNA_set]
 log2cpm_nc = log2cpm.loc[ncRNA_genes]
 print(f" ✓ Filtered to {len(ncRNA_genes)} ncRNA genes")
 
 return log2cpm_nc, metadata
 
 except Exception as e:
 print(f" ✗ Error loading {gse_id}: {e}")
 return None, None


def analyze_dataset(gse_id, counts, metadata, group_col='group'):
 """Perform differential expression analysis."""
 try:
 # Get disease and control samples
 groups = metadata[group_col].unique()
 print(f" Groups detected: {groups}")
 
 # Assume first group is disease, second is control
 disease_group = groups[0]
 control_group = groups[1]
 
 disease_samples = metadata[metadata[group_col] == disease_group].index
 control_samples = metadata[metadata[group_col] == control_group].index
 
 print(f" Disease: {len(disease_samples)} samples | Control: {len(control_samples)} samples")
 
 # Ensure sample names match counts columns
 disease_samples = [s for s in disease_samples if s in counts.columns]
 control_samples = [s for s in control_samples if s in counts.columns]
 
 if len(disease_samples) < 2 or len(control_samples) < 2:
 print(f" ✗ Insufficient samples for analysis")
 return None
 
 # Extract expression data
 disease_expr = counts[disease_samples]
 control_expr = counts[control_samples]
 
 # Perform t-tests
 results = []
 for gene_id in counts.index:
 d_vals = disease_expr.loc[gene_id].values
 c_vals = control_expr.loc[gene_id].values
 
 if np.std(d_vals) == 0 and np.std(c_vals) == 0:
 continue
 
 t_stat, p_val = ttest_ind(d_vals, c_vals, equal_var=False)
 
 mean_d = np.mean(d_vals)
 mean_c = np.mean(c_vals)
 log2fc = mean_d - mean_c
 
 results.append({
 'gene_id': gene_id,
 'mean_disease': mean_d,
 'mean_control': mean_c,
 'log2FC': log2fc,
 'pvalue': p_val
 })
 
 results_df = pd.DataFrame(results)
 
 # Adjust p-values
 _, results_df['padj'], _, _ = multipletests(results_df['pvalue'], method='fdr_bh')
 
 # Filter to significant biomarkers
 biomarkers = results_df[results_df['padj'] < 0.05].copy()
 
 # Add gene info
 biomarkers = biomarkers.merge(
 annotation[['gene_id', 'gene_name', 'biotype']],
 on='gene_id',
 how='left'
 )
 
 biomarkers = biomarkers.sort_values('padj')
 
 print(f" ✓ Found {len(biomarkers)} significant biomarkers (FDR < 0.05)")
 if len(biomarkers) > 0:
 print(f" Top 3:")
 for i, row in biomarkers.head(3).iterrows():
 print(f" {row['gene_name']:20s} log2FC={row['log2FC']:7.2f} FDR={row['padj']:.2e}")
 
 return biomarkers
 
 except Exception as e:
 print(f" ✗ Analysis error: {e}")
 return None


# ============================================================================
# ANALYZE DATASETS
# ============================================================================

datasets_config = {
 'GSE203206': {
 'path': 'data/alzheimers/human/raw_datasets/GSE203206',
 'counts_file': 'counts.tsv',
 'metadata_file': 'metadata.csv',
 'group_col': 'condition',
 'disease_label': 'Disease',
 'control_label': 'Control',
 'description': 'Brain Tissue (47 samples)'
 },
 'GSE33000': {
 'path': 'data/alzheimers/human/raw_datasets/GSE33000',
 'counts_file': 'counts_ensembl.txt',
 'metadata_file': 'metadata.txt',
 'group_col': 'condition',
 'disease_label': 'Disease', 
 'control_label': 'Control',
 'description': 'Cortex (624 samples)'
 },
 'GSE173955': {
 'path': 'data/alzheimers/human/raw_datasets/GSE173955',
 'counts_file': 'counts.tsv',
 'metadata_file': 'metadata.csv',
 'group_col': 'condition',
 'disease_label': "Alzheimer's Disease",
 'control_label': 'Non-affected',
 'description': 'Brain Tissue (31 samples)'
 }
}

all_biomarkers = {}
successful_datasets = []

for gse_id, config in datasets_config.items():
 print(f"\n{'='*80}")
 print(f"ANALYZING: {gse_id}")
 print(f"Description: {config['description']}")
 print("="*80)
 
 if not os.path.exists(config['path']):
 print(f"✗ Dataset not found at {config['path']}")
 continue
 
 counts, metadata = load_and_normalize(gse_id, config['counts_file'], 
 config['metadata_file'], config['path'])
 
 if counts is None or metadata is None:
 print(f"✗ Failed to load {gse_id}")
 continue
 
 biomarkers = analyze_dataset(gse_id, counts, metadata, group_col=config['group_col'])
 
 if biomarkers is not None:
 all_biomarkers[gse_id] = biomarkers
 successful_datasets.append(gse_id)
 
 # Save individual results
 outdir = Path('results/multi_dataset_analysis')
 outdir.mkdir(parents=True, exist_ok=True)
 
 biomarkers.to_csv(outdir / f'{gse_id}_biomarkers.csv', index=False)
 print(f"✓ Saved to {outdir / f'{gse_id}_biomarkers.csv'}")


# ============================================================================
# FIND CONSERVED BIOMARKERS (across all successful datasets)
# ============================================================================

print(f"\n{'='*80}")
print(f"CROSS-DATASET ANALYSIS")
print("="*80)

if len(successful_datasets) >= 2:
 print(f"\nSuccessfully analyzed {len(successful_datasets)} datasets:")
 for gse in successful_datasets:
 n_bio = len(all_biomarkers[gse])
 print(f" • {gse}: {n_bio} biomarkers")
 
 # Find conserved biomarkers (appear in ALL datasets)
 conserved = all_biomarkers[successful_datasets[0]][['gene_id']].copy()
 
 for gse_id in successful_datasets[1:]:
 other_genes = set(all_biomarkers[gse_id]['gene_id'])
 conserved = conserved[conserved['gene_id'].isin(other_genes)]
 
 print(f"\n✓ Found {len(conserved)} biomarkers appearing in ALL {len(successful_datasets)} datasets")
 
 # Get full info for conserved
 conserved_full = all_biomarkers[successful_datasets[0]].merge(
 conserved[['gene_id']], on='gene_id'
 ).sort_values('padj')
 
 # Save conserved biomarkers
 outdir = Path('results/multi_dataset_analysis')
 conserved_full.to_csv(outdir / 'conserved_across_all_datasets.csv', index=False)
 print(f"✓ Saved to {outdir / 'conserved_across_all_datasets.csv'}")
 
 if len(conserved_full) > 0:
 print(f"\nTop conserved biomarkers:")
 for i, row in conserved_full.head(10).iterrows():
 print(f" {row['gene_name']:20s} | log2FC={row['log2FC']:7.2f} | FDR={row['padj']:.2e}")
 
 # Create summary table
 print(f"\nBiomarker overlap:")
 print(f" GSE203206: {len(all_biomarkers['GSE203206'])} biomarkers")
 if 'GSE33000' in successful_datasets:
 print(f" GSE33000: {len(all_biomarkers['GSE33000'])} biomarkers")
 if 'GSE173955' in successful_datasets:
 print(f" GSE173955: {len(all_biomarkers['GSE173955'])} biomarkers")

else:
 print(f"✗ Need at least 2 datasets for cross-dataset analysis")


# ============================================================================
# FINAL SUMMARY
# ============================================================================

print(f"\n{'='*80}")
print(f"ANALYSIS COMPLETE")
print("="*80)

total_samples = 0
for gse_id in successful_datasets:
 # Estimate from biomarkers metadata
 if gse_id == 'GSE203206':
 total_samples += 47
 elif gse_id == 'GSE33000':
 total_samples += 624
 elif gse_id == 'GSE173955':
 total_samples += 31

print(f"\n✓ Successfully analyzed {len(successful_datasets)} datasets")
print(f" Total samples: {total_samples}")
print(f" Output directory: results/multi_dataset_analysis/")

if len(successful_datasets) > 0:
 total_biomarkers = sum(len(all_biomarkers[gse]) for gse in successful_datasets)
 print(f" Total biomarkers identified: {total_biomarkers}")

print("\n" + "="*80)
