#!/usr/bin/env python3
"""
Cross-Disease ncRNA Biomarker Discovery Pipeline
Analyzes Alzheimer's, Parkinson's, and ALS for shared ncRNA dysregulation

WORKFLOW:
1. Load per-disease datasets (combine multiple GEO studies within each disease)
2. Harmonize gene IDs to Ensembl
3. Run within-disease DESeq2 analysis
4. Filter to ncRNA biomarkers (FDR<0.01, |log2FC|>1)
5. Identify cross-disease overlaps
6. Generate unified report + visualizations
"""

import os
import pandas as pd
import numpy as np
from pathlib import Path
from collections import defaultdict

print("=" * 80)
print("CROSS-DISEASE ncRNA BIOMARKER DISCOVERY PIPELINE")
print("=" * 80)

# Configuration
DISEASES = ['alzheimers', 'parkinsons', 'als']
DATA_ROOT = Path('data/neurodegenerative_diseases')
OUTPUT_ROOT = Path('results/cross_disease_analysis')
ANNOTATION_FILE = 'data/annotations/annotation_human.csv'

# ============================================================================
# STEP 0: DATA ORGANIZATION VALIDATION
# ============================================================================

print("\n" + "=" * 80)
print("STEP 0: VALIDATING DATA ORGANIZATION")
print("=" * 80)

def validate_disease_data(disease):
 """Check if disease folder has properly formatted datasets"""
 disease_path = DATA_ROOT / disease
 
 if not disease_path.exists():
 print(f" ✗ {disease}: Folder does not exist")
 return False, 0, 0
 
 gse_folders = sorted([f for f in disease_path.iterdir() if f.is_dir() and f.name.startswith('GSE')])
 
 if not gse_folders:
 print(f" ⚠️ {disease}: No GSE#### folders found")
 return False, 0, 0
 
 total_samples = 0
 total_genes = 0
 valid_datasets = []
 
 for gse in gse_folders:
 counts_file = gse / 'counts.tsv'
 meta_file = gse / 'metadata.csv'
 
 if counts_file.exists() and meta_file.exists():
 try:
 counts = pd.read_csv(counts_file, sep='\t', index_col=0, nrows=1)
 meta = pd.read_csv(meta_file, index_col=0)
 
 n_samples = counts.shape[1]
 n_genes = counts.shape[0]
 
 total_samples += n_samples
 total_genes += n_genes
 valid_datasets.append((gse.name, n_samples, n_genes))
 except Exception as e:
 print(f" ✗ {gse.name}: Error reading files ({e})")
 continue
 
 if valid_datasets:
 print(f"\n ✓ {disease.upper()}: {len(valid_datasets)} dataset(s)")
 for ds_name, n_samp, n_gene in valid_datasets:
 print(f" - {ds_name}: {n_samp} samples, {n_gene} genes")
 print(f" TOTAL: {total_samples} samples, {total_genes} genes")
 return True, total_samples, len(gse_folders)
 else:
 print(f" ⚠️ {disease}: No valid datasets found")
 return False, 0, 0

results = {}
for disease in DISEASES:
 is_valid, n_samples, n_studies = validate_disease_data(disease)
 results[disease] = (is_valid, n_samples, n_studies)

# ============================================================================
# STEP 1: DATA LOADING & HARMONIZATION (PLACEHOLDER)
# ============================================================================

print("\n" + "=" * 80)
print("STEP 1: DATA LOADING & HARMONIZATION")
print("=" * 80)

print("""
Once you upload datasets, this pipeline will:

1. Load counts matrices from all GSE studies per disease
2. Merge within each disease (row-bind after aligning gene IDs)
3. Harmonize all gene IDs to Ensembl format
4. Remove duplicate genes (keep highest expressing)
5. Filter low-expression genes (CPM < 1 in >50% of samples)
6. Validate sample metadata (disease_status, tissue_type)

Expected output:
 - combined_counts_AD.tsv (all AD datasets merged)
 - combined_counts_PD.tsv (all PD datasets merged)
 - combined_counts_ALS.tsv (all ALS datasets merged)
 - combined_metadata_[disease].csv (per-disease metadata)
""")

# ============================================================================
# STEP 2: WITHIN-DISEASE DESEQ2 ANALYSIS (PLACEHOLDER)
# ============================================================================

print("\n" + "=" * 80)
print("STEP 2: WITHIN-DISEASE DESEQ2 ANALYSIS")
print("=" * 80)

print("""
For EACH disease separately:

1. Load combined counts + metadata
2. Run DESeq2:
 - Design: ~ condition (Disease vs Control)
 - Contrast: Disease vs Control
 - Output: log2FC, Wald statistic, raw p-value, adjusted p-value (FDR)

3. Filter strict thresholds:
 - FDR < 0.01 (1% expected false discoveries)
 - |log2FC| > 1.0 (≥2-fold change)

4. Filter to ncRNA only:
 - Match genes to annotation file
 - Keep only biotypes: lncRNA, miRNA, snoRNA, snRNA, misc_RNA, piRNA, etc.

5. Save results:
 - [disease]_de_results_all.csv (all genes tested)
 - [disease]_ncrna_biomarkers.csv (filtered, significant)
 
Expected outputs:
 - alzheimers_ncrna_biomarkers.csv
 - parkinsons_ncrna_biomarkers.csv
 - als_ncrna_biomarkers.csv
""")

# ============================================================================
# STEP 3: CROSS-DISEASE ANALYSIS (TEMPLATE)
# ============================================================================

print("\n" + "=" * 80)
print("STEP 3: CROSS-DISEASE BIOMARKER IDENTIFICATION")
print("=" * 80)

print("""
Once within-disease results are ready, this will:

1. Load biomarker lists from each disease:
 - Extract gene_id + log2FC + direction (up/down regulated)

2. Find overlaps:
 - Genes shared in exactly 2 diseases
 - Genes shared in all 3 diseases (MOST INTERESTING)

3. Validate direction consistency:
 - A gene found DOWN in AD and DOWN in PD = consistent
 - A gene found UP in AD and DOWN in PD = conflicting (exclude)

4. Rank shared biomarkers by:
 - Number of diseases (3 > 2)
 - Average absolute log2FC (stronger effect)
 - Average FDR (most significant)

5. Output:
 - shared_2_diseases.csv (gene appears in exactly 2)
 - shared_3_diseases.csv (gene appears in all 3: FOCUS HERE)
 - cross_disease_validation_summary.txt
""")

# ============================================================================
# STEP 4: VISUALIZATION PIPELINE (TEMPLATE)
# ============================================================================

print("\n" + "=" * 80)
print("STEP 4: VISUALIZATION PIPELINE")
print("=" * 80)

print("""
Per-disease visualizations:
 ✓ Volcano plot (log2FC vs -log10(p-value))
 ✓ Heatmap (top 30 significant ncRNAs)
 ✓ PCA plot (samples colored by disease status)
 ✓ Bar plots (top 5 ncRNAs: mean ± SD in disease vs control)

Cross-disease visualization:
 ✓ Venn diagram (shared genes across 3 diseases)
 ✓ Summary table (top 20 pan-disease biomarkers)
 ✓ Forest plot (effect sizes across diseases)

All with proper labels, legends, and scaling.
""")

# ============================================================================
# SUMMARY & NEXT STEPS
# ============================================================================

print("\n" + "=" * 80)
print("CURRENT DATA STATUS")
print("=" * 80)

for disease, (is_valid, n_samples, n_studies) in results.items():
 status_icon = "✓" if is_valid else "✗"
 status_text = f"{n_samples} samples ({n_studies} studies)" if is_valid else "NOT READY"
 print(f" {status_icon} {disease.upper():20} {status_text}")

print("\n" + "=" * 80)
print("IMMEDIATE NEXT STEPS")
print("=" * 80)

print(f"""
1. FIND PARKINSON'S DATASETS:
 - Use search terms from search_geo_datasets.py
 - Target: 2-3 studies with 200+ samples total
 - Create: data/neurodegenerative_diseases/parkinsons/GSE####/

2. FIND ALS DATASETS:
 - Use search terms from search_geo_datasets.py
 - Target: 2-3 studies with 150-200 samples total
 - Create: data/neurodegenerative_diseases/als/GSE####/

3. FORMAT EACH DATASET:
 For each GEO series, create:
 - counts.tsv (raw counts, genes × samples)
 - metadata.csv (sample_id, disease_status, tissue_type, study_id)

4. RUN THIS VALIDATION SCRIPT AGAIN:
 $ python cross_disease_pipeline.py
 
5. SHARE ACCESSION NUMBERS:
 Send me the GSE accessions you found so I can build
 the harmonization and DESeq2 scripts.

PROJECT SCOPE:
 - Alzheimer's Disease: ✓ Ready (GSE203206)
 - Parkinson's Disease: ⏳ Need to find
 - ALS: ⏳ Need to find
 
EXPECTED TIMELINE:
 - Dataset search: 1-2 hours
 - Download & format: 2-3 hours
 - Harmonization: 4-6 hours
 - Within-disease analysis: 6-8 hours
 - Cross-disease analysis: 3-4 hours
 - Visualizations: 4-5 hours
 - TOTAL: 20-28 hours of focused work
""")

print("\n" + "=" * 80)
print("END OF DIAGNOSTIC REPORT")
print("=" * 80)
