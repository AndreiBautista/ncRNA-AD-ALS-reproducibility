#!/bin/bash
# Quick Start Script - Run GEO Analysis Yourself
# Copy this file and modify as needed!

# Navigate to project
cd /Users/austinbautista/ncrna_pipeline

# Activate Python environment
source .venv/bin/activate

# Check if annotation exists
if [ ! -f "data/annotations/human.gtf" ]; then
 echo "Downloading human annotation (one-time setup)..."
 mkdir -p data/annotations
 curl -L -o data/annotations/human.gtf.gz \
 https://ftp.ebi.ac.uk/pub/databases/gencode/Gencode_human/release_44/gencode.v44.annotation.gtf.gz
 gunzip data/annotations/human.gtf.gz
 echo "✓ Annotation downloaded!"
fi

# Analyze GEO dataset
echo "Starting analysis..."
python scripts/geo_integration.py \
 --geo_id GSE33000 \
 --annotation data/annotations/human.gtf \
 --outdir results/GSE33000_my_analysis

# Show results
echo ""
echo "✓ Analysis complete!"
echo "Results saved to: results/GSE33000_my_analysis/"
echo ""
echo "View results:"
echo " open results/GSE33000_my_analysis/"
echo ""
echo "Files created:"
ls -lh results/GSE33000_my_analysis/
