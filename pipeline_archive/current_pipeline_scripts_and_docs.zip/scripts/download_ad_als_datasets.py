#!/usr/bin/env python3
"""
Download and organize Alzheimer's & ALS datasets from GEO
Creates standardized counts.tsv + metadata.csv for cross-disease analysis
"""

import os
import sys
import pandas as pd
import numpy as np
from pathlib import Path

# Add pipeline to path
sys.path.insert(0, os.path.dirname(__file__))

from pipeline.io import safe_read_table

# ============================================================================
# DATASET SPECIFICATIONS
# ============================================================================

DATASETS = {
 "alzheimers": [
 {
 "gse": "GSE203206",
 "name": "Subramaniam ADRC Brain (Occipital Lobe)",
 "tissue": "occipital_lobe",
 "controls": 8,
 "disease": 40,
 "counts_file": "GSE203206_Subramaniam.ADRC_brain.counts.tsv",
 "metadata_file": "GSE203206_metadata.csv",
 "local": True, # Already have this file
 },
 {
 "gse": "GSE173955",
 "name": "Hisayama Cohort (Hippocampus)",
 "tissue": "hippocampus",
 "controls": 10,
 "disease": 8,
 "notes": "Japanese population, high-quality annotation",
 },
 {
 "gse": "GSE95587",
 "name": "Genentech/Roche (Fusiform Gyrus)",
 "tissue": "fusiform_gyrus",
 "controls": 40,
 "disease": 77,
 "notes": "Large Genentech dataset, mixed pathology analysis",
 },
 ],
 "als": [
 {
 "gse": "GSE124439",
 "name": "NYGC ALS Consortium (Motor Cortex)",
 "tissue": "motor_cortex",
 "controls": 28,
 "disease": 148,
 "notes": "Largest ALS study, excellent annotation",
 },
 {
 "gse": "GSE116622",
 "name": "NYGC ALS - C9ORF72 & Sporadic (Brain)",
 "tissue": "brain_mixed",
 "controls": 27,
 "disease": 50,
 "notes": "Part of NYGC consortium, mixed subtypes",
 },
 {
 "gse": "GSE76220",
 "name": "Laser Capture Motor Neurons",
 "tissue": "motor_neurons_lcm",
 "controls": 9,
 "disease": 13,
 "notes": "Laser capture microdissected, highly specific",
 },
 ],
}


def ensure_folders():
 """Create necessary folder structure."""
 print("\n" + "=" * 80)
 print("CREATING FOLDER STRUCTURE")
 print("=" * 80)

 base = Path("data/neurodegenerative_diseases")

 for disease in ["alzheimers", "als"]:
 disease_path = base / disease
 disease_path.mkdir(parents=True, exist_ok=True)
 print(f"✓ {disease_path}")

 for dataset_info in DATASETS[disease]:
 gse = dataset_info["gse"]
 gse_path = disease_path / gse
 gse_path.mkdir(parents=True, exist_ok=True)
 print(f" ✓ {gse_path}")

 return base


def get_dataset_info(gse):
 """Print dataset information for manual download."""
 print(f"\n{'=' * 80}")
 print(f"DATASET: {gse}")
 print(f"{'=' * 80}")
 print(f"GEO URL: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc={gse}")
 print("\nDownload Instructions:")
 print("1. Go to the GEO page above")
 print("2. Scroll to 'Supplementary file' section")
 print("3. Download the *counts* file (usually .txt or .csv or .tsv)")
 print("4. Place in: data/neurodegenerative_diseases/[disease]/[GSE]/counts.txt")


def handle_gse203206():
 """Handle GSE203206 (already have files locally)."""
 print("\n" + "=" * 80)
 print("PROCESSING: GSE203206")
 print("=" * 80)

 source_counts = Path("GSE203206_Subramaniam.ADRC_brain.counts.tsv")
 source_metadata = Path("GSE203206_metadata.csv")

 dest_folder = Path("data/neurodegenerative_diseases/alzheimers/GSE203206")
 dest_folder.mkdir(parents=True, exist_ok=True)

 if source_counts.exists() and source_metadata.exists():
 import shutil

 shutil.copy(source_counts, dest_folder / "counts.tsv")
 shutil.copy(source_metadata, dest_folder / "metadata.csv")

 print(f"✓ Copied counts.tsv -> {dest_folder / 'counts.tsv'}")
 print(f"✓ Copied metadata.csv -> {dest_folder / 'metadata.csv'}")

 # Verify
 counts_df = pd.read_csv(dest_folder / "counts.tsv", sep="\t", index_col=0)
 metadata_df = pd.read_csv(dest_folder / "metadata.csv")

 print(f"\nVerification:")
 print(f" Counts shape: {counts_df.shape}")
 print(f" Metadata shape: {metadata_df.shape}")
 print(f" ✓ Files successfully copied and validated")

 return True
 else:
 print(f"✗ Source files not found!")
 print(f" Looking for: {source_counts}, {source_metadata}")
 return False


def create_placeholder_metadata(disease, gse, dataset_info):
 """
 Create placeholder metadata CSV for manual population.
 User will need to fill in based on actual data.
 """
 tissue = dataset_info["tissue"]
 controls_n = dataset_info["controls"]
 disease_n = dataset_info["disease"]
 total_n = controls_n + disease_n

 # Create sample IDs
 sample_ids = (
 [f"{gse}_ctrl_{i:02d}" for i in range(1, controls_n + 1)]
 + [f"{gse}_dis_{i:02d}" for i in range(1, disease_n + 1)]
 )

 disease_status = ["Control"] * controls_n + ["Disease"] * disease_n

 metadata_df = pd.DataFrame(
 {
 "sample_id": sample_ids,
 "disease_status": disease_status,
 "tissue_type": [tissue] * total_n,
 "study_id": [gse] * total_n,
 }
 )

 return metadata_df


def print_download_status():
 """Print status of which files are available."""
 print("\n" + "=" * 80)
 print("DATA AVAILABILITY STATUS")
 print("=" * 80)

 for disease, datasets in DATASETS.items():
 print(f"\n{disease.upper()}:")
 total_samples = 0

 for dataset_info in datasets:
 gse = dataset_info["gse"]
 controls = dataset_info["controls"]
 disease_n = dataset_info["disease"]
 total = controls + disease_n
 total_samples += total

 status = "✓ LOCAL" if dataset_info.get("local") else "⏳ NEED TO DOWNLOAD"

 print(f" {gse}: {total} samples ({controls} ctrl, {disease_n} dis) - {status}")

 print(f" → Total: {total_samples} samples")


def print_next_steps():
 """Print next steps for user."""
 print("\n" + "=" * 80)
 print("NEXT STEPS")
 print("=" * 80)

 print("""
For Alzheimer's Disease:
 GSE203206 - ✓ Already set up locally
 
 GSE173955 - Download from:
 https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE173955
 → Save counts file to: data/neurodegenerative_diseases/alzheimers/GSE173955/counts.txt
 → Save metadata to: data/neurodegenerative_diseases/alzheimers/GSE173955/metadata.csv

 GSE95587 - Download from:
 https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE95587
 → Save counts file to: data/neurodegenerative_diseases/alzheimers/GSE95587/counts.txt
 → Save metadata to: data/neurodegenerative_diseases/alzheimers/GSE95587/metadata.csv

For ALS:
 GSE124439 - Download from:
 https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE124439
 → Save counts file to: data/neurodegenerative_diseases/als/GSE124439/counts.txt
 → Save metadata to: data/neurodegenerative_diseases/als/GSE124439/metadata.csv

 GSE116622 - Download from:
 https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE116622
 → Save counts file to: data/neurodegenerative_diseases/als/GSE116622/counts.txt
 → Save metadata to: data/neurodegenerative_diseases/als/GSE116622/metadata.csv

 GSE76220 - Download from:
 https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE76220
 → Save counts file to: data/neurodegenerative_diseases/als/GSE76220/counts.txt
 → Save metadata to: data/neurodegenerative_diseases/als/GSE76220/metadata.csv

IMPORTANT:
 1. Save all counts files as TAB-SEPARATED (.txt or .tsv)
 2. First row should be sample names (headers)
 3. First column should be gene IDs (Ensembl format preferred: ENSG00000...)
 4. Save metadata CSV with columns: sample_id, disease_status, tissue_type, study_id
 5. disease_status should be either "Control" or "Disease"

Once all files are downloaded and organized, run:
 python cross_disease_pipeline.py

This will validate your data structure.
""")


def main():
 print("=" * 80)
 print("ncRNA BIOMARKER DISCOVERY: AD + ALS DATASET SETUP")
 print("=" * 80)

 # Create folder structure
 base_path = ensure_folders()

 # Handle GSE203206 (local files)
 handle_gse203206()

 # Print availability status
 print_download_status()

 # Print next steps
 print_next_steps()

 print("\n" + "=" * 80)
 print("SETUP COMPLETE")
 print("=" * 80)
 print("\nFolder structure created. Now download the GSE datasets and organize them.")


if __name__ == "__main__":
 main()
