#!/usr/bin/env python3
"""
Simplified Multi-Dataset ncRNA Biomarker Analysis
Focuses on GSE203206 + GSE173955 (best quality data)
"""

import os
import pandas as pd
import numpy as np
from pathlib import Path

from pipeline.io import load_annotation
from pipeline.processing import log2_cpm, filter_noncoding_genes
from pipeline.de_analysis import differential_expression, adjust_pvalues

ANNOTATION_FILE = 'data/annotations/annotation_human.csv'

def main():
 print("=" * 70)
 print("Multi-Dataset ncRNA Biomarker Analysis - Simplified")
 print("=" * 70)
 
 # Create output directories
 outdir = Path('results/alzheimers/human/multi_dataset_analysis')
 outdir.mkdir(parents=True, exist_ok=True)
 
 # Load annotation
 print("\nLoading annotation...")
 annotation = load_annotation(ANNOTATION_FILE)
 print(f" Loaded {len(annotation)} genes")
 
 all_results = {}
 all_sig = {}
 
 # ========================================================================
 # DATASET 1: GSE203206 (Ensembl IDs)
 # ========================================================================
 print("\n" + "="*70)
 print("DATASET 1: GSE203206 (Ensembl IDs)")
 print("="*70)
 
 counts_203206 = pd.read_csv('data/alzheimers/human/raw_datasets/GSE203206/counts.tsv', sep='\t', index_col=0)
 meta_203206 = pd.read_csv('data/alzheimers/human/raw_datasets/GSE203206/metadata.csv', index_col=0)
 
 # Align samples
 common = list(set(counts_203206.columns) & set(meta_203206.index))
 counts_203206 = counts_203206[common]
 meta_203206 = meta_203206.loc[common]
 
 print(f" Samples: {counts_203206.shape[1]} ({meta_203206.groupby('condition').size().to_dict()})")
 print(f" Total genes: {counts_203206.shape[0]}")
 
 # Normalize
 logcpm_203206 = log2_cpm(counts_203206)
 nc_203206 = filter_noncoding_genes(logcpm_203206, annotation, allow_missing=True)
 print(f" ncRNA genes: {nc_203206.shape[0]}")
 
 # DE analysis
 res_203206 = differential_expression(
 nc_203206, meta_203206, 
 group_col='condition', disease_label='Disease', control_label='Control'
 )
 res_203206 = adjust_pvalues(res_203206, method='fdr_bh', alpha=0.05)
 
 # Relaxed thresholds for biomarker discovery
 sig_203206 = res_203206[(res_203206['fdr'] < 0.05) & (abs(res_203206['log2FC']) > 1.0)]
 
 # Annotate
 sig_203206['gene_name'] = sig_203206.index.map(lambda x: annotation.loc[x, 'gene_name'] if x in annotation.index else x)
 sig_203206['biotype'] = sig_203206.index.map(lambda x: annotation.loc[x, 'biotype'] if x in annotation.index else 'unknown')
 
 print(f" → Significant biomarkers (FDR<0.05, |log2FC|>1.0): {len(sig_203206)}")
 all_sig['GSE203206'] = sig_203206
 all_results['GSE203206'] = res_203206
 
 # ========================================================================
 # DATASET 2: GSE173955 (Gene Symbols - convert to Ensembl IDs)
 # ========================================================================
 print("\n" + "="*70)
 print("DATASET 2: GSE173955 (Gene Symbols → Ensembl IDs)")
 print("="*70)
 
 counts_173955 = pd.read_csv('data/alzheimers/human/raw_datasets/GSE173955/counts.tsv', sep='\t', index_col=0)
 meta_173955 = pd.read_csv('data/alzheimers/human/raw_datasets/GSE173955/metadata.csv', index_col=0)
 
 # Align
 common = list(set(counts_173955.columns) & set(meta_173955.index))
 counts_173955 = counts_173955[common]
 meta_173955 = meta_173955.loc[common]
 
 print(f" Samples: {counts_173955.shape[1]} ({meta_173955.groupby('condition').size().to_dict()})")
 print(f" Total genes: {counts_173955.shape[0]}")
 
 # Convert gene symbols to Ensembl IDs
 symbol_to_ensembl = dict(zip(
 annotation['gene_name'].str.upper().values,
 annotation.index.values
 ))
 
 mapped_genes = []
 mapped_indices = []
 for i, symbol in enumerate(counts_173955.index):
 symbol_upper = str(symbol).upper()
 if symbol_upper in symbol_to_ensembl:
 ensembl_id = symbol_to_ensembl[symbol_upper]
 mapped_genes.append(ensembl_id)
 mapped_indices.append(i)
 
 print(f" Symbol → Ensembl mapping: {len(mapped_genes)}/{len(counts_173955)} genes ({100*len(mapped_genes)/len(counts_173955):.1f}%)")
 
 counts_173955_mapped = counts_173955.iloc[mapped_indices].copy()
 counts_173955_mapped.index = mapped_genes
 
 # Normalize
 logcpm_173955 = log2_cpm(counts_173955_mapped)
 nc_173955 = filter_noncoding_genes(logcpm_173955, annotation, allow_missing=True)
 print(f" ncRNA genes: {nc_173955.shape[0]}")
 
 # DE analysis
 res_173955 = differential_expression(
 nc_173955, meta_173955,
 group_col='condition', disease_label='Alzheimer\'s Disease', control_label='Non-affected'
 )
 res_173955 = adjust_pvalues(res_173955, method='fdr_bh', alpha=0.05)
 
 # Relaxed thresholds
 sig_173955 = res_173955[(res_173955['fdr'] < 0.20) & (abs(res_173955['log2FC']) > 0.5)]
 
 # Annotate
 sig_173955['gene_name'] = sig_173955.index.map(lambda x: annotation.loc[x, 'gene_name'] if x in annotation.index else x)
 sig_173955['biotype'] = sig_173955.index.map(lambda x: annotation.loc[x, 'biotype'] if x in annotation.index else 'unknown')
 
 print(f" → Significant biomarkers (FDR<0.05, |log2FC|>1.0): {len(sig_173955)}")
 all_sig['GSE173955'] = sig_173955
 all_results['GSE173955'] = res_173955
 
 # ========================================================================
 # CROSS-DATASET ANALYSIS
 # ========================================================================
 print("\n" + "="*70)
 print("CROSS-DATASET CONSERVED BIOMARKERS")
 print("="*70)
 
 # Find overlaps
 genes_203206 = set(all_sig['GSE203206'].index)
 genes_173955 = set(all_sig['GSE173955'].index)
 
 both_datasets = genes_203206.intersection(genes_173955)
 only_203206 = genes_203206 - genes_173955
 only_173955 = genes_173955 - genes_203206
 
 print(f"\nBiomarker overlap:")
 print(f" GSE203206 only: {len(only_203206)}")
 print(f" Both datasets: {len(both_datasets)}")
 print(f" GSE173955 only: {len(only_173955)}")
 
 # Create conserved biomarkers table
 if both_datasets:
 conserved_data = []
 for gene in sorted(both_datasets):
 conserved_data.append({
 'gene_id': gene,
 'gene_name': annotation.loc[gene, 'gene_name'] if gene in annotation.index else gene,
 'biotype': annotation.loc[gene, 'biotype'] if gene in annotation.index else 'unknown',
 'GSE203206_log2FC': all_sig['GSE203206'].loc[gene, 'log2FC'],
 'GSE203206_fdr': all_sig['GSE203206'].loc[gene, 'fdr'],
 'GSE173955_log2FC': all_sig['GSE173955'].loc[gene, 'log2FC'],
 'GSE173955_fdr': all_sig['GSE173955'].loc[gene, 'fdr'],
 'mean_log2FC': (all_sig['GSE203206'].loc[gene, 'log2FC'] + all_sig['GSE173955'].loc[gene, 'log2FC']) / 2,
 })
 
 conserved_df = pd.DataFrame(conserved_data)
 conserved_df = conserved_df.sort_values('mean_log2FC', key=abs, ascending=False)
 conserved_df.to_csv(outdir / 'conserved_biomarkers.csv', index=False)
 
 print(f"\nConserved Biomarkers (validated in both datasets):")
 print(conserved_df.to_string(index=False))
 
 # ========================================================================
 # SAVE RESULTS
 # ========================================================================
 for ds_name, sig in all_sig.items():
 ds_dir = outdir / ds_name
 ds_dir.mkdir(exist_ok=True)
 sig.to_csv(ds_dir / 'significant_biomarkers.csv')
 all_results[ds_name].to_csv(ds_dir / 'de_results_all.csv')
 
 # Summary report
 report_path = outdir / 'MULTI_DATASET_SUMMARY.txt'
 with open(report_path, 'w') as f:
 f.write("="*70 + "\n")
 f.write("Multi-Dataset ncRNA Biomarker Analysis - Alzheimer's Disease\n")
 f.write("="*70 + "\n\n")
 
 f.write("DATASETS ANALYZED:\n")
 f.write(" 1. GSE203206 (47 samples: 39 AD, 8 control) - Ensembl IDs\n")
 f.write(" 2. GSE173955 (18 samples: 8 AD, 10 control) - Gene symbols → Ensembl IDs\n\n")
 
 f.write("BIOMARKERS PER DATASET (FDR<0.05, |log2FC|>1.0):\n")
 for ds, sig in all_sig.items():
 f.write(f" {ds}: {len(sig)} ncRNA biomarkers\n")
 
 if both_datasets:
 f.write(f"\nCONSERVED BIOMARKERS (validated in both datasets): {len(both_datasets)}\n")
 f.write(" These genes show consistent dysregulation across independent cohorts\n")
 f.write(" Strong candidates for therapeutic targets or diagnostic markers\n")
 
 f.write("\nFILTERS APPLIED:\n")
 f.write(" - FDR-adjusted p-value < 0.05 (Benjamini-Hochberg correction)\n")
 f.write(" - |log2(fold-change)| > 1.0 (more than 2-fold dysregulation)\n")
 f.write(" - Only non-coding RNAs (ncRNAs, lncRNAs, miRNAs, snoRNAs, etc.)\n")
 
 print(f"\n✓ Analysis complete!")
 print(f"✓ Results saved to: {outdir}")
 print(f"✓ Summary: {report_path}")

if __name__ == '__main__':
 main()
