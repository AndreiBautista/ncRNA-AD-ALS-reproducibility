#!/usr/bin/env python3
"""Download GSE95587 supplementary sample files and assemble counts matrix."""

import argparse
import gzip
from io import BytesIO
from pathlib import Path
import time
import urllib.request

import pandas as pd


def parse_series_matrix_urls(series_matrix_path: Path) -> list:
 urls = []
 with gzip.open(series_matrix_path, "rt", encoding="utf-8", errors="ignore") as handle:
 for line in handle:
 if line.startswith("!Sample_supplementary_file_1"):
 # Extract URLs inside quotes
 parts = line.strip().split("\t")[1:]
 for part in parts:
 part = part.strip().strip('"')
 if part and part.upper() != "NONE":
 urls.append(part)
 break
 return urls


def download_file(url: str, dest: Path) -> None:
 dest.parent.mkdir(parents=True, exist_ok=True)
 if dest.exists():
 return
 with urllib.request.urlopen(url) as resp:
 data = resp.read()
 dest.write_bytes(data)


def sample_id_from_url(url: str) -> str:
 # GSM2516806_sample1.tsv.gz -> GSM2516806
 name = url.split("/")[-1]
 return name.split("_sample", 1)[0]


def main():
 parser = argparse.ArgumentParser(description="Build GSE95587 counts from supplementary files")
 parser.add_argument("series_matrix", help="Path to GSE95587_series_matrix.txt.gz")
 parser.add_argument("output_path", help="Output counts.tsv")
 parser.add_argument("--download_dir", default="data/neurodegenerative_diseases/alzheimers/GSE95587/supp")
 parser.add_argument("--sleep", type=float, default=0.2, help="Pause between downloads (seconds)")
 args = parser.parse_args()

 series_matrix_path = Path(args.series_matrix)
 if not series_matrix_path.exists():
 raise FileNotFoundError(series_matrix_path)

 urls = parse_series_matrix_urls(series_matrix_path)
 if not urls:
 raise RuntimeError("No supplementary URLs found in series matrix.")

 download_dir = Path(args.download_dir)
 series_list = []

 for url in urls:
 sample_id = sample_id_from_url(url)
 dest = download_dir / f"{sample_id}.tsv.gz"
 download_file(url, dest)
 time.sleep(args.sleep)

 with gzip.open(dest, "rt", encoding="utf-8", errors="ignore") as handle:
 df = pd.read_csv(handle, sep="\t", comment="#", engine="python")
 if "ID_REF" not in df.columns:
 continue
 # Use VALUE column if present, else last column
 if "VALUE" in df.columns:
 series = df.set_index("ID_REF")["VALUE"]
 else:
 series = df.set_index("ID_REF").iloc[:, -1]
 series.name = sample_id
 series_list.append(series)

 if not series_list:
 raise RuntimeError("No sample files parsed.")

 counts_df = pd.concat(series_list, axis=1)
 output_path = Path(args.output_path)
 output_path.parent.mkdir(parents=True, exist_ok=True)
 counts_df.to_csv(output_path, sep="\t")
 print("Saved:", output_path)
 print("Shape:", counts_df.shape)


if __name__ == "__main__":
 main()
