#!/usr/bin/env python3
"""
Convert GSE33000 gene symbols to Ensembl IDs for analysis
Maps gene symbols to Ensembl IDs using the annotation file
"""

import pandas as pd
import numpy as np
import os

print("Converting GSE33000 gene symbols to Ensembl IDs...")

# Load annotation mapping
annotation = pd.read_csv('data/annotations/annotation_human.csv', index_col='gene_id')
annotation = annotation.reset_index()

# Create symbol → Ensembl ID mapping
symbol_to_ensembl = {}
for idx, row in annotation.iterrows():
 gene_name = row['gene_name']
 gene_id = row['gene_id']
 if pd.notna(gene_name):
 symbol_to_ensembl[gene_name.upper()] = gene_id

print(f"Created mapping for {len(symbol_to_ensembl)} gene symbols")

# Load GSE33000 counts (genes are in first column as symbols)
counts_file = 'data/alzheimers/human/raw_datasets/GSE33000/counts.txt'
print(f"Loading counts from {counts_file}...")
counts = pd.read_csv(counts_file, sep='\t', index_col=0)

print(f"Original: {len(counts)} genes")

# Convert gene symbols to Ensembl IDs
new_index = []
new_data = []

for gene_symbol in counts.index:
 gene_symbol_upper = str(gene_symbol).upper()
 
 if gene_symbol_upper in symbol_to_ensembl:
 ensembl_id = symbol_to_ensembl[gene_symbol_upper]
 new_index.append(ensembl_id)
 # Convert to list to ensure homogeneous shape for DataFrame
 new_data.append(list(counts.loc[gene_symbol].values))

print(f"Successfully mapped: {len(new_index)} genes")
print(f"Unmapped (not in annotation): {len(counts) - len(new_index)} genes")

# Create new dataframe using list comprehension to ensure 2D array
converted_df = pd.DataFrame(new_data, index=new_index, columns=counts.columns)

# Save converted counts
output_file = 'data/alzheimers/human/raw_datasets/GSE33000/counts_ensembl.txt'
converted_df.to_csv(output_file, sep='\t')
print(f"✓ Saved converted counts to {output_file}")

# Verify metadata matches
metadata_file = 'data/alzheimers/human/raw_datasets/GSE33000/metadata.txt'
metadata = pd.read_csv(metadata_file, sep='\t', index_col=0)

print(f"\nCounts samples: {converted_df.shape[1]}")
print(f"Metadata samples: {len(metadata)}")

if converted_df.shape[1] == len(metadata):
 print("✓ Sample counts match!")
else:
 print("⚠ Warning: Sample counts don't match")

# Summary
print(f"\nGSE33000 Conversion Summary:")
print(f" Original gene symbols: {len(counts)}")
print(f" Successfully converted to Ensembl IDs: {len(new_index)}")
print(f" Conversion rate: {100*len(new_index)/len(counts):.1f}%")
print(f" Samples: {converted_df.shape[1]}")
print(f" Ready for analysis: ✅")
