#!/usr/bin/env python3
"""Print detailed metadata for a sample in GSE48350."""

from pathlib import Path
import logging

import GEOparse


def main():
 logging.getLogger("GEOparse").setLevel(logging.WARNING)

 out_dir = Path("data/neurodegenerative_diseases/alzheimers/GSE48350/geo")
 out_dir.mkdir(parents=True, exist_ok=True)

 gse = GEOparse.get_GEO("GSE48350", destdir=str(out_dir), annotate_gpl=False)

 first_gsm = next(iter(gse.gsms.values()))
 print("GSM:", first_gsm.name)
 print("Title:", first_gsm.metadata.get("title", [""])[0])
 print("Characteristics:")
 for c in first_gsm.metadata.get("characteristics_ch1", []):
 print("-", c)

 print("\nMetadata keys:")
 for k in sorted(first_gsm.metadata.keys()):
 print(k)


if __name__ == "__main__":
 main()
