#!/usr/bin/env python3
"""
Extract and prepare GSE33000 data for the ncRNA pipeline.
Creates counts.txt and metadata.txt from the raw data file.
"""
import pandas as pd
import sys

print("Loading GSE33000 raw data...")
df = pd.read_csv('GSE33000_raw_data.txt', sep='\t')

print(f"Loaded: {df.shape[0]} genes × {df.shape[1]} columns")
print(f"Columns: {list(df.columns[:5])}... (showing first 5)")

# Extract sample columns (everything after 'Transcript')
sample_cols = [c for c in df.columns if c.startswith('HBTRC')]
gene_col = 'Gene'

print(f"\nFound {len(sample_cols)} samples: {sample_cols}")

# Create counts file
counts = df[[gene_col] + sample_cols].copy()
counts.columns = ['gene_id'] + sample_cols
counts = counts.set_index('gene_id')

# Remove rows with all zeros or NaNs
counts = counts.loc[(counts != 0).any(axis=1)]
counts = counts.dropna(how='all')

print(f"\nCounts file: {counts.shape[0]} genes × {counts.shape[1]} samples")
counts.to_csv('GSE33000_counts.txt', sep='\t')
print("✓ Saved to: GSE33000_counts.txt")

# Create metadata file
# Extract disease/condition from sample name
# HBTRC_PF_Pool_1 -> assuming PF is condition, Pool is replicate
metadata = pd.DataFrame({
 'sample': sample_cols,
})

# Guess condition from sample name (you may need to adjust this)
# For now, let's create a simple one where even pools are Control, odd are Disease
metadata['condition'] = metadata['sample'].apply(
 lambda x: 'Control' if int(x.split('_')[-1]) % 2 == 0 else 'Disease'
)

print(f"\nMetadata file: {metadata.shape[0]} samples")
print(metadata)

metadata.to_csv('GSE33000_metadata.txt', sep='\t', index=False)
print("\n✓ Saved to: GSE33000_metadata.txt")

print("\n⚠️ IMPORTANT: Check GSE33000_metadata.txt and adjust 'condition' column!")
print(" Sample names appear to be: ", sample_cols)
print(" Edit the CSV to assign correct Control/Disease groups")
