#!/usr/bin/env python3
"""
Download and prepare alternative Alzheimer's datasets from GEO
"""

import urllib.request
import gzip
import os
from pathlib import Path
import pandas as pd

print("="*80)
print("DOWNLOADING PUBLIC ALZHEIMER'S DATASETS")
print("="*80)

data_dir = Path('data/alzheimers/human/raw_datasets')
data_dir.mkdir(parents=True, exist_ok=True)

datasets_to_download = {
 'GSE287651': {
 'description': 'Human entorhinal cortex at AD neuropathology onset',
 'url': 'https://ftp.ncbi.nlm.nih.gov/geo/series/GSE287nnn/GSE287651/matrix/GSE287651_series_matrix.txt.gz',
 'type': 'series_matrix'
 },
 'GSE288917': {
 'description': 'Neural stem cells: EOAD, LOAD, WT controls',
 'url': 'https://ftp.ncbi.nlm.nih.gov/geo/series/GSE288nnn/GSE288917/matrix/GSE288917_series_matrix.txt.gz',
 'type': 'series_matrix'
 },
}

for gse_id, info in datasets_to_download.items():
 print(f"\n{'='*80}")
 print(f"Attempting to download: {gse_id}")
 print(f"Description: {info['description']}")
 print("="*80)
 
 gse_dir = data_dir / gse_id
 gse_dir.mkdir(exist_ok=True)
 
 # Download series matrix file
 output_file = gse_dir / f'{gse_id}_series_matrix.txt'
 
 try:
 print(f"Downloading from GEO...")
 print(f"URL: {info['url']}")
 
 # Download gzipped file
 gz_file = str(output_file) + '.gz'
 urllib.request.urlretrieve(info['url'], gz_file)
 print(f"✓ Downloaded gzipped file ({os.path.getsize(gz_file) / 1024 / 1024:.1f} MB)")
 
 # Decompress
 with gzip.open(gz_file, 'rb') as f_in:
 with open(output_file, 'wb') as f_out:
 f_out.write(f_in.read())
 print(f"✓ Decompressed to {output_file}")
 
 # Remove gz
 os.remove(gz_file)
 
 except Exception as e:
 print(f"✗ Download failed: {e}")
 print(f" URL may be broken or file not available via FTP")
 print(f" Alternative: Download manually from GEO:")
 print(f" https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc={gse_id}")
 continue

print("\n" + "="*80)
print("NEXT STEPS")
print("="*80)
print("""
If downloads succeeded:
 1. Series matrix files need parsing (GEO-specific format)
 2. Extract expression data and sample metadata
 3. Convert to counts matrix format
 
If downloads failed:
 1. Go to: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE287651
 2. Click "Download" → "Series Matrix File(s)"
 3. Save as data/alzheimers/human/raw_datasets/GSE287651/
 
Let me know if you want help parsing these files!
""")
