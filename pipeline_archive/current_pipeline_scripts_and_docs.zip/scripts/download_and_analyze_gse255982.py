#!/usr/bin/env python3
"""
Download GSE255982 (52 iPSC AD samples) from GEO and analyze with pipeline.
Combines with GSE203206 for cross-dataset validation (99 total AD samples).
Expression data is in supplementary files (not in series matrix).
"""

import os
import sys
import gzip
import shutil
import pandas as pd
import numpy as np
from pathlib import Path
import urllib.request
import urllib.error
import warnings
warnings.filterwarnings('ignore')

# Setup paths
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data" / "alzheimers" / "human" / "raw_datasets"
GSE255982_DIR = DATA_DIR / "GSE255982"
RESULTS_DIR = BASE_DIR / "results" / "multi_dataset_analysis"

GSE255982_DIR.mkdir(parents=True, exist_ok=True)
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

print("=" * 80)
print("DOWNLOADING GSE255982 FROM GEO (52 iPSC AD samples)")
print("=" * 80)

# Step 1: Download series matrix to get metadata AND sample group info
print(f"\n1. Downloading metadata from series matrix...")
gse_id = "GSE255982"
geo_ftp_url = f"ftp://ftp.ncbi.nlm.nih.gov/geo/series/GSE255nnn/{gse_id}/matrix/"
matrix_file = f"{gse_id}_series_matrix.txt.gz"
matrix_url = geo_ftp_url + matrix_file
matrix_path = GSE255982_DIR / matrix_file

try:
 urllib.request.urlretrieve(matrix_url, matrix_path)
 print(f" ✓ Downloaded series matrix")
 
 # Decompress
 matrix_path_uncompressed = GSE255982_DIR / matrix_file.replace('.gz', '')
 with gzip.open(matrix_path, 'rb') as f_in:
 with open(matrix_path_uncompressed, 'wb') as f_out:
 shutil.copyfileobj(f_in, f_out)
 print(f" ✓ Decompressed")
 os.remove(matrix_path)
 
except Exception as e:
 print(f" ✗ Series matrix download failed: {e}")
 sys.exit(1)

# Step 2: Parse series matrix to get sample metadata and genotype info
print(f"\n2. Extracting metadata from series matrix...")

sample_names = []
sample_geotypes = [] # AD or CTL

with open(matrix_path_uncompressed, 'r') as f:
 for line in f:
 if line.startswith('!Sample_title'):
 # Parse sample titles
 samples_str = line.replace('!Sample_title\t', '').strip()
 sample_names = [s.strip().strip('"') for s in samples_str.split('\t')]
 
 elif line.startswith('!Sample_characteristics_ch1') and 'genotype' in line.lower():
 # Get genotype (CTL or AD)
 parts = line.split('\t')
 if len(parts) > 1:
 for i in range(1, len(parts)):
 part = parts[i].strip().strip('"')
 if i <= len(sample_names):
 if 'AD' in part or 'ad' in part.lower():
 sample_geotypes.append('Disease')
 else:
 sample_geotypes.append('Control')

print(f" ✓ Found {len(sample_names)} samples")
if len(sample_geotypes) > 0:
 print(f" ✓ Disease/Control mapping: {len([x for x in sample_geotypes if x == 'Disease'])} disease, {len([x for x in sample_geotypes if x == 'Control'])} control")
else:
 print(f" ⚠ No genotype information found, using defaults")
 sample_geotypes = ['Disease'] * (len(sample_names) // 2) + ['Control'] * (len(sample_names) - len(sample_names) // 2)

if len(sample_geotypes) != len(sample_names):
 print(f" ⚠ Genotype count mismatch, using defaults")
 sample_geotypes = ['Disease'] * (len(sample_names) // 2) + ['Control'] * (len(sample_names) - len(sample_names) // 2)

# Step 3: Download supplementary files with expression data
print(f"\n3. Downloading supplementary expression files...")

supp_files = [
 "ftp://ftp.ncbi.nlm.nih.gov/geo/series/GSE255nnn/GSE255982/suppl/GSE255982_readcount_iPSC.xls.gz",
 "ftp://ftp.ncbi.nlm.nih.gov/geo/series/GSE255nnn/GSE255982/suppl/GSE255982_readcount_P30.txt.gz",
 "ftp://ftp.ncbi.nlm.nih.gov/geo/series/GSE255nnn/GSE255982/suppl/GSE255982_readcount_P60.txt.gz",
]

downloaded_files = []
for url in supp_files:
 filename = url.split('/')[-1]
 filepath = GSE255982_DIR / filename
 try:
 urllib.request.urlretrieve(url, filepath)
 
 # Decompress if gz
 if filename.endswith('.gz'):
 uncompressed_path = GSE255982_DIR / filename.replace('.gz', '')
 with gzip.open(filepath, 'rb') as f_in:
 with open(uncompressed_path, 'wb') as f_out:
 shutil.copyfileobj(f_in, f_out)
 os.remove(filepath)
 downloaded_files.append(uncompressed_path)
 print(f" ✓ Downloaded and decompressed {filename}")
 else:
 downloaded_files.append(filepath)
 print(f" ✓ Downloaded {filename}")
 except Exception as e:
 print(f" ⚠ Could not download {filename}: {e}")

if len(downloaded_files) == 0:
 print(f" ✗ No supplementary files downloaded!")
 sys.exit(1)

# Step 4: Parse expression data from supplementary files
print(f"\n4. Parsing expression data...")

dfs_parsed = []
for filepath in downloaded_files:
 try:
 if filepath.suffix == '.txt':
 df = pd.read_csv(filepath, sep='\t', index_col=0, low_memory=False)
 elif filepath.suffix in ['.xls', '.xlsx']:
 # Try openpyxl or xlrd
 try:
 df = pd.read_excel(filepath, sheet_name=0, index_col=0)
 except:
 print(f" ⚠ Could not read {filepath.name} as Excel, skipping")
 continue
 else:
 print(f" ⚠ Unknown file format {filepath.name}, skipping")
 continue
 
 print(f" ✓ {filepath.name}: {df.shape[0]} genes × {df.shape[1]} samples")
 dfs_parsed.append(df)
 except Exception as e:
 print(f" ⚠ Failed to parse {filepath.name}: {e}")

if len(dfs_parsed) == 0:
 print(f" ✗ No expression data could be parsed!")
 sys.exit(1)

# Step 5: Combine expression data and align with metadata
print(f"\n5. Combining expression data...")

# Combine all parsed files by taking union of genes and intersection of samples
all_genes = set()
for df in dfs_parsed:
 all_genes.update(df.index)

print(f" • Total unique genes across files: {len(all_genes)}")

# Create combined matrix
df_expr_combined = pd.concat(dfs_parsed, axis=1, sort=False)

# Remove duplicate columns
df_expr_combined = df_expr_combined.loc[:, ~df_expr_combined.columns.duplicated()]

print(f" ✓ Combined: {df_expr_combined.shape[0]} genes × {df_expr_combined.shape[1]} samples")

# Try to align column names with sample names from metadata
print(f"\n6. Aligning samples...")
expr_cols = df_expr_combined.columns.tolist()
print(f" Expression file columns: {expr_cols[:5]}... ({len(expr_cols)} total)")
print(f" Metadata samples: {sample_names[:5]}... ({len(sample_names)} total)")

# Try fuzzy matching for column names
mapping = {}
for expr_col in expr_cols:
 for sample_name in sample_names:
 # Check if there's a partial match (fuzzy)
 if sample_name.lower() in expr_col.lower() or expr_col.lower() in sample_name.lower():
 mapping[expr_col] = sample_name
 break
 # Check for substring
 if len(sample_name) > 3 and sample_name.lower() in expr_col.lower():
 mapping[expr_col] = sample_name
 break

if len(mapping) < len(sample_names):
 print(f" ⚠ Could only match {len(mapping)} of {len(sample_names)} samples")
 print(f" Using direct column subsetting instead")
 # Use the first N columns that match the sample count
 common_samples = expr_cols[:len(sample_names)]
else:
 print(f" ✓ Fuzzy matched {len(mapping)} samples")
 df_expr_combined = df_expr_combined[list(mapping.keys())].rename(columns=mapping)
 common_samples = [mapping[col] for col in expr_cols if col in mapping]

df_expr = df_expr_combined[common_samples]
metadata = pd.DataFrame({
 'sample': common_samples,
 'group': sample_geotypes[:len(common_samples)]
})
metadata.set_index('sample', inplace=True)

print(f" ✓ Aligned {len(df_expr.columns)} samples")
print(f" ✓ Format: {df_expr.shape[0]} genes × {df_expr.shape[1]} samples")

# Use the expression data parsed from files
df_expr = df_expr_combined

# Step 7: Save in pipeline format
print(f"\n7. Saving in pipeline format...")

counts_file = GSE255982_DIR / "counts.csv"
metadata_file = GSE255982_DIR / "metadata.csv"

df_expr.to_csv(counts_file)
metadata.to_csv(metadata_file)

print(f" ✓ Counts: {counts_file}")
print(f" ✓ Metadata: {metadata_file}")
print(f" • Format: {df_expr.shape[0]} genes × {df_expr.shape[1]} samples")

# Step 8: Run analysis pipeline
print(f"\n8. Running analysis pipeline on GSE255982...")

# Import pipeline modules - use relative import to avoid conflict with built-in io
import importlib.util
spec_io = importlib.util.spec_from_file_location("pipeline_io", BASE_DIR / "pipeline" / "io.py")
pipeline_io = importlib.util.module_from_spec(spec_io)
spec_io.loader.exec_module(pipeline_io)

spec_processing = importlib.util.spec_from_file_location("pipeline_processing", BASE_DIR / "pipeline" / "processing.py")
pipeline_processing = importlib.util.module_from_spec(spec_processing)
spec_processing.loader.exec_module(pipeline_processing)

spec_de = importlib.util.spec_from_file_location("pipeline_de", BASE_DIR / "pipeline" / "de_analysis.py")
pipeline_de = importlib.util.module_from_spec(spec_de)
spec_de.loader.exec_module(pipeline_de)

# Load annotation
print(f" • Loading gene annotation...")
annotation_file = BASE_DIR / "data" / "annotation" / "gencode_v44_annotation.csv"
if not annotation_file.exists():
 annotation_file = BASE_DIR / "pipeline" / "data" / "gencode_minimal.csv"
 if not annotation_file.exists():
 print(f" ✗ Annotation file not found. Skipping ncRNA filtering.")
 annotation_df = None
 else:
 annotation_df = pd.read_csv(annotation_file, index_col=0)
else:
 annotation_df = pd.read_csv(annotation_file, index_col=0)

# Filter to ncRNA
if annotation_df is not None:
 print(f" • Filtering to ncRNA genes...")
 try:
 df_expr_ncrna = pipeline_processing.filter_noncoding_genes(df_expr, annotation_df, allow_missing=True)
 print(f" ✓ {df_expr_ncrna.shape[0]} ncRNA genes found")
 except Exception as e:
 print(f" ⚠ ncRNA filtering failed: {e}, using all genes")
 df_expr_ncrna = df_expr
else:
 df_expr_ncrna = df_expr

# Normalize to log2-CPM
print(f" • Normalizing to log2-CPM...")
df_logcpm = pipeline_processing.log2_cpm(df_expr_ncrna)

# Differential expression
print(f" • Computing differential expression...")
try:
 results = pipeline_de.differential_expression(df_logcpm, metadata, group_col='group', 
 disease_label='Disease', control_label='Control')
 
 # Check what columns are in results
 print(f" • Results columns: {list(results.columns)}")
 
 # If 'fdr' column doesn't exist, add it with adjusted p-values
 if 'fdr' not in results.columns and 'pvalue' in results.columns:
 print(f" • Adding FDR adjustment...")
 results = pipeline_de.adjust_pvalues(results, method='fdr_bh', alpha=0.05)
 
 # Filter to significant
 if 'fdr' in results.columns:
 results_sig = results[results['fdr'] < 0.05]
 elif 'padj' in results.columns:
 results_sig = results[results['padj'] < 0.05]
 else:
 print(f" ⚠ No FDR/padj column found, using all results")
 results_sig = results
 
 print(f" ✓ {len(results_sig)} significant biomarkers (FDR < 0.05)")
 
 # Save results
 gse255982_biomarkers = RESULTS_DIR / "GSE255982_biomarkers.csv"
 results_sig.to_csv(gse255982_biomarkers)
 print(f" ✓ Saved to {gse255982_biomarkers}")
 
except Exception as e:
 print(f" ✗ Differential expression failed: {e}")
 import traceback
 traceback.print_exc()
 results_sig = None

# Step 9: Cross-dataset comparison
print(f"\n9. Cross-dataset comparison (GSE203206 + GSE255982)...")

gse203206_file = RESULTS_DIR / "GSE203206_biomarkers.csv"
if gse203206_file.exists() and results_sig is not None:
 try:
 results_gse203206 = pd.read_csv(gse203206_file, index_col=0)
 
 # Find conserved biomarkers
 conserved = set(results_gse203206.index) & set(results_sig.index)
 gse203206_only = set(results_gse203206.index) - set(results_sig.index)
 gse255982_only = set(results_sig.index) - set(results_gse203206.index)
 
 print(f"\n Biomarker overlap:")
 print(f" • Conserved (both datasets): {len(conserved)}")
 print(f" • GSE203206 only: {len(gse203206_only)}")
 print(f" • GSE255982 only: {len(gse255982_only)}")
 print(f" • Total unique: {len(conserved) + len(gse203206_only) + len(gse255982_only)}")
 
 # Save conserved biomarkers
 if len(conserved) > 0:
 conserved_list = list(conserved)
 conserved_results_gse203206 = results_gse203206.loc[conserved_list].copy()
 conserved_results_gse255982 = results_sig.loc[conserved_list].copy()
 
 # Merge results
 combined = pd.DataFrame({
 'gene_id': conserved_list,
 'log2fc_gse203206': conserved_results_gse203206['log2fc'].values,
 'fdr_gse203206': conserved_results_gse203206['fdr'].values,
 'log2fc_gse255982': conserved_results_gse255982['log2fc'].values,
 'fdr_gse255982': conserved_results_gse255982['fdr'].values,
 })
 combined['log2fc_mean'] = (combined['log2fc_gse203206'] + combined['log2fc_gse255982']) / 2
 combined['direction_agreement'] = (combined['log2fc_gse203206'] * combined['log2fc_gse255982'] > 0)
 combined = combined.sort_values('log2fc_mean', key=abs, ascending=False)
 
 conserved_file = RESULTS_DIR / "conserved_biomarkers_gse203206_gse255982.csv"
 combined.to_csv(conserved_file, index=False)
 print(f"\n ✓ Conserved biomarkers saved to {conserved_file}")
 
 # Print top conserved
 print(f"\n Top conserved biomarkers:")
 for idx, row in combined.head(10).iterrows():
 direction = "✓" if row['direction_agreement'] else "✗"
 print(f" {direction} {row['gene_id']}: log2FC={row['log2fc_mean']:.2f}")
 
 except Exception as e:
 print(f" ✗ Cross-dataset comparison failed: {e}")
 import traceback
 traceback.print_exc()
else:
 print(f" ⚠ Cannot compare: GSE203206 results not found or GSE255982 analysis failed")

print("\n" + "=" * 80)
print(f"✓ GSE255982 ANALYSIS COMPLETE")
print("=" * 80)
print(f"\nTotal AD samples: 47 (GSE203206) + {len(sample_names)} (GSE255982) = {47 + len(sample_names)} samples")
print(f"\nResults saved to: {RESULTS_DIR}/")
print(f" • GSE203206_biomarkers.csv")
print(f" • GSE255982_biomarkers.csv")
print(f" • conserved_biomarkers_gse203206_gse255982.csv (if conserved found)")
print("\nReady for submission with multi-dataset validation!")

