#!/usr/bin/env python3
"""
Create 3 identical Alzheimer's test datasets from GSE203206
for multi-dataset demonstration of Path A.
"""

import pandas as pd
import os

print("Creating 3 test Alzheimer's datasets from GSE203206...")

# Load source data
counts_src = pd.read_csv('GSE203206_Subramaniam.ADRC_brain.counts.tsv', sep='\t', index_col=0)
metadata_src = pd.read_csv('GSE203206_metadata.csv', index_col=0)

print(f"Source: {len(counts_src)} genes × {len(metadata_src)} samples")

# Create 3 datasets
for i, dataset_name in enumerate(['dataset1', 'dataset2', 'dataset3'], 1):
 dataset_dir = f'data/alzheimers/human/{dataset_name}'
 os.makedirs(dataset_dir, exist_ok=True)
 
 counts_file = os.path.join(dataset_dir, f'{dataset_name}_counts.tsv')
 metadata_file = os.path.join(dataset_dir, f'{dataset_name}_metadata.csv')
 
 # Save as copies (same data, mimicking replicate datasets)
 counts_src.to_csv(counts_file, sep='\t')
 metadata_src.to_csv(metadata_file)
 
 print(f"✓ Created {dataset_name}: {counts_file}")
 print(f" {metadata_file}")

print("\nDatasets ready for analysis!")
