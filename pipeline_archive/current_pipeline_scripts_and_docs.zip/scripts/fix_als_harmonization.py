#!/usr/bin/env python3
"""Quick fix: Re-harmonize ALS dataset with correct gene ID column."""

import pandas as pd
import numpy as np
from pathlib import Path

print("Reloading ALS dataset with correct structure...")

# Load raw counts (skip first column, use second column as index)
counts_path = 'data/neurodegenerative_diseases/als/GSE153960/counts.txt'
counts_df = pd.read_csv(counts_path, sep='\t', index_col=1) # Use column 1 (0-indexed) as index

# Drop the row number column (first column)
if counts_df.columns[0] == 'EnsemblID' or counts_df.index.name == 'EnsemblID':
 counts_df = counts_df.iloc[:, 1:] # Skip first data column

# Clean gene IDs (strip version numbers)
counts_df.index = counts_df.index.astype(str).str.split('.').str[0]
counts_df.index.name = 'gene_id'

# Convert to numeric
counts_df = counts_df.apply(pd.to_numeric, errors='coerce')
counts_df = counts_df.dropna(how='all')

print(f"Cleaned shape: {counts_df.shape[0]} genes × {counts_df.shape[1]} samples")
print(f"Sample gene_ids: {list(counts_df.index[:5])}")

# Save corrected version
output_file = 'data/harmonized_datasets/als_counts_corrected.csv'
counts_df.to_csv(output_file)
print(f"✓ Saved to {output_file}")
