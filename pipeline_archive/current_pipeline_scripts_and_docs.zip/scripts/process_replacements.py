#!/usr/bin/env python3
"""
Process the replacement datasets once downloads complete
Extract TAR, decompress GZ, organize into proper folders
"""

import tarfile
import gzip
from pathlib import Path
import pandas as pd

def extract_and_organize():
 """Extract replacement datasets and organize them."""
 
 downloads = Path.home() / "Downloads"
 ncrna_pipeline = Path.home() / "ncrna_pipeline"
 base_data = ncrna_pipeline / "data" / "neurodegenerative_diseases"
 
 print("=" * 80)
 print("PROCESSING REPLACEMENT DATASETS")
 print("=" * 80)
 
 # ========================================================================
 # GSE125583 (AD replacement for GSE95587)
 # ========================================================================
 print("\n\nGSE125583 (Genentech AD - 289 samples)")
 print("-" * 80)
 
 tar_file = downloads / "GSE125583_RAW.tar"
 dest_folder = base_data / "alzheimers" / "GSE125583"
 dest_folder.mkdir(parents=True, exist_ok=True)
 
 if tar_file.exists():
 print(f" Extracting {tar_file.name}...")
 try:
 with tarfile.open(tar_file, "r") as tar:
 tar.extractall(path=dest_folder)
 print(f" ✓ Extracted to {dest_folder}")
 
 # Count extracted files
 txt_files = list(dest_folder.glob("*.txt*"))
 print(f" ✓ Found {len(txt_files)} sample files")
 
 except Exception as e:
 print(f" ✗ Error: {e}")
 else:
 print(f" ⏳ Waiting for download: {tar_file}")
 
 # ========================================================================
 # GSE153960 (ALS replacement for GSE116622)
 # ========================================================================
 print("\n\nGSE153960 (NYGC ALS - 1,838 samples)")
 print("-" * 80)
 
 gz_file = downloads / "GSE153960_counts.txt.gz"
 dest_folder = base_data / "als" / "GSE153960"
 dest_folder.mkdir(parents=True, exist_ok=True)
 
 if gz_file.exists():
 print(f" Extracting {gz_file.name}...")
 try:
 output_file = dest_folder / "counts.txt"
 with gzip.open(gz_file, "rb") as f_in:
 with open(output_file, "wb") as f_out:
 f_out.write(f_in.read())
 
 print(f" ✓ Extracted to {output_file}")
 
 # Check size
 size_mb = output_file.stat().st_size / (1024 * 1024)
 print(f" ✓ File size: {size_mb:.1f} MB")
 
 # Verify file
 with open(output_file, "r") as f:
 first_line = f.readline()
 sample_count = len(first_line.strip().split("\t")) - 1
 print(f" ✓ Samples: {sample_count}")
 
 except Exception as e:
 print(f" ✗ Error: {e}")
 else:
 print(f" ⏳ Waiting for download: {gz_file}")
 
 # ========================================================================
 # SUMMARY
 # ========================================================================
 print("\n\n" + "=" * 80)
 print("FINAL DATASET INVENTORY")
 print("=" * 80)
 
 print("\nALZHEIMER'S DISEASE:")
 for gse_folder in sorted((base_data / "alzheimers").iterdir()):
 if gse_folder.is_dir():
 files = list(gse_folder.glob("*"))
 print(f" {gse_folder.name}: {len(files)} items")
 
 print("\nALS:")
 for gse_folder in sorted((base_data / "als").iterdir()):
 if gse_folder.is_dir():
 files = list(gse_folder.glob("*"))
 print(f" {gse_folder.name}: {len(files)} items")
 
 print("\n" + "=" * 80)
 print("NEXT STEPS")
 print("=" * 80)
 print("""
Once you see ✓ marks for both GSE125583 and GSE153960:

1. Create metadata CSV files for new datasets
2. Run validation: python cross_disease_pipeline.py
3. Build analysis pipeline
4. Run DESeq2
5. Generate figures

Total expected:
 - Alzheimer's: 399 samples (47 + 63 + 289)
 - ALS: 1,849 samples (11 + 1,838)
 - TOTAL: 2,248 samples 🔬
""")

if __name__ == "__main__":
 extract_and_organize()
