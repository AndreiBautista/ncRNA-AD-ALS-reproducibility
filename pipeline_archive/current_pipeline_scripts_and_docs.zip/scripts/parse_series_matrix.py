#!/usr/bin/env python3
"""
Parse GEO series_matrix.txt files and extract expression counts
Creates counts.txt and metadata.csv for each GSE dataset
"""

import os
import sys
import re
from pathlib import Path
import pandas as pd
import numpy as np


def parse_series_matrix(series_matrix_file):
 """
 Parse GEO series_matrix.txt file
 Returns (expression_df, metadata_df)
 """
 print(f" Parsing: {series_matrix_file.name}")

 expression_data = {}
 metadata_rows = []
 in_expression = False
 sample_names = []

 with open(series_matrix_file, "r", encoding="utf-8", errors="ignore") as f:
 for line in f:
 line = line.rstrip("\n\r")

 # Skip comment lines (start with !)
 if line.startswith("!"):
 continue

 # Sample names are in format: !Series_geo_accession
 if line.startswith('"ID_REF"'):
 header = line.split('\t')
 sample_names = [h.strip('"') for h in header[1:]]
 in_expression = True
 continue

 # Read expression data
 if in_expression and line and not line.startswith('"'):
 parts = line.split("\t")
 if len(parts) > 1:
 gene_id = parts[0].strip('"')
 values = []
 for val in parts[1:]:
 try:
 values.append(float(val))
 except:
 values.append(np.nan)

 if len(values) == len(sample_names):
 expression_data[gene_id] = values

 if len(expression_data) > 0 and len(sample_names) > 0:
 expr_df = pd.DataFrame(expression_data).T
 expr_df.columns = sample_names
 print(f" ✓ Extracted: {expr_df.shape[0]} genes, {expr_df.shape[1]} samples")
 return expr_df
 else:
 print(f" ✗ Could not parse expression data")
 return None


def process_gse(disease_folder):
 """
 Process all GSE folders in a disease directory
 """
 dataset_path = Path(
 "data/neurodegenerative_diseases"
 ) / disease_folder

 if not dataset_path.exists():
 print(f"✗ {dataset_path} does not exist")
 return

 print(f"\n{disease_folder.upper()}")
 print("-" * 80)

 for gse_folder in sorted(dataset_path.iterdir()):
 if not gse_folder.is_dir():
 continue

 gse_id = gse_folder.name
 print(f"\n{gse_id}:")

 # Find series_matrix files
 series_matrix_files = list(
 gse_folder.glob("GSE*_series_matrix.txt*")
 ) + list(gse_folder.glob("GSE*_series_matrix*.txt*"))

 if len(series_matrix_files) == 0:
 print(f" ⚠ No series_matrix file found")
 print(f" Looking for: GSE*_series_matrix.txt*")
 continue

 # Use first series_matrix file (in case of duplicates)
 series_matrix_file = series_matrix_files[0]

 # Check if already has counts.txt
 counts_file = gse_folder / "counts.txt"
 if counts_file.exists():
 print(f" ✓ counts.txt already exists")
 continue

 # Parse series_matrix
 expr_df = parse_series_matrix(series_matrix_file)

 if expr_df is not None:
 # Save as counts.txt
 counts_file = gse_folder / "counts.txt"
 expr_df.to_csv(counts_file, sep="\t")
 print(f" ✓ Saved: counts.txt ({expr_df.shape[0]} genes, {expr_df.shape[1]} samples)")

 # Check if metadata.csv needs updating
 metadata_file = gse_folder / "metadata.csv"
 if metadata_file.exists():
 metadata_df = pd.read_csv(metadata_file)
 
 # Update sample_id to match actual sample names if different
 if len(metadata_df) == len(expr_df.columns):
 print(f" ✓ metadata.csv already created")
 else:
 print(f" ⚠ Sample count mismatch (metadata: {len(metadata_df)}, counts: {len(expr_df.columns)})")


def main():
 print("=" * 80)
 print("PARSE GEO SERIES_MATRIX FILES")
 print("=" * 80)

 for disease in ["alzheimers", "als"]:
 process_gse(disease)

 print("\n\n" + "=" * 80)
 print("NEXT STEPS")
 print("=" * 80)
 print("""
1. Verify each GSE folder has:
 ✓ counts.txt - expression matrix
 ✓ metadata.csv - sample metadata

2. For metadata.csv, you need to fill in disease_status:
 - Open each metadata.csv file
 - Look up samples in GEO phenotypes tab
 - Set disease_status to "Control" or "Disease"
 - Save the file

3. Once metadata is filled in, run:
 python cross_disease_pipeline.py

4. Tell me when ready and I'll build the analysis pipeline!
""")


if __name__ == "__main__":
 main()
