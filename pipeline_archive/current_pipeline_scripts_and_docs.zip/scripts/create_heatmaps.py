#!/usr/bin/env python3
"""
Generate heatmaps for presentation
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
from scipy.cluster.hierarchy import linkage, dendrogram
from scipy.spatial.distance import pdist

# Set style
sns.set_style("white")

# Create output directory
outdir = Path('results/figures')
outdir.mkdir(parents=True, exist_ok=True)

print("Loading data...")

# Load harmonized counts and metadata
ad_counts = pd.read_csv('data/harmonized_datasets/alzheimers_disease_counts.csv', index_col=0)
ad_meta = pd.read_csv('data/harmonized_datasets/alzheimers_metadata_corrected.csv', index_col=0)
ad_biomarkers = pd.read_csv('results/deseq2/alzheimers/ncrna_biomarkers.csv')

print(f"Loaded {ad_counts.shape[0]} genes × {ad_counts.shape[1]} samples")
print(f"Loaded {len(ad_biomarkers)} biomarkers")
print(f"Sample groups: {ad_meta['condition'].value_counts().to_dict()}")

# ============================================================================
# HEATMAP 1: Top 30 Biomarkers Across All Samples
# ============================================================================
print("\nCreating Heatmap 1: Top 30 AD Biomarkers...")

# Get top 30 biomarkers by FDR
top30 = ad_biomarkers.nsmallest(30, 'padj')
top30_genes = top30['gene_id'].tolist()

# Extract expression data for these genes
heatmap_data = ad_counts.loc[top30_genes].copy()

# Convert to log2(CPM+1) for better visualization
lib_sizes = ad_counts.sum(axis=0)
cpm = (heatmap_data / lib_sizes) * 1e6
log2cpm = np.log2(cpm + 1)

# Z-score normalization for better color scaling
from scipy.stats import zscore
heatmap_zscore = log2cpm.apply(zscore, axis=1)

# Add gene names as row labels
gene_names = []
for gene_id in top30_genes:
 gene_name = top30[top30['gene_id'] == gene_id]['gene_name'].values[0]
 if pd.notna(gene_name) and gene_name != 'nan':
 gene_names.append(gene_name)
 else:
 gene_names.append(gene_id[:15]) # Truncate long IDs

heatmap_zscore.index = gene_names

# Create color bar for sample groups
sample_colors = ad_meta.loc[heatmap_zscore.columns, 'condition'].map({
 'Disease': '#e74c3c', # Red
 'Control': '#3498db' # Blue
}).values

# Create figure
fig, ax = plt.subplots(figsize=(14, 12))

# Plot heatmap with hierarchical clustering
sns.clustermap(heatmap_zscore, 
 cmap='RdBu_r', 
 center=0,
 vmin=-2, vmax=2,
 col_colors=[sample_colors],
 cbar_kws={'label': 'Z-score (row-normalized)', 'shrink': 0.5},
 figsize=(14, 12),
 xticklabels=False, # Too many sample names
 yticklabels=True,
 linewidths=0.5,
 linecolor='gray',
 dendrogram_ratio=0.15,
 cbar_pos=(0.02, 0.83, 0.03, 0.15))

plt.suptitle("Top 30 Alzheimer's Disease ncRNA Biomarkers\nHierarchical Clustering of Samples", 
 fontsize=16, fontweight='bold', y=0.98)

# Add legend
from matplotlib.patches import Patch
legend_elements = [
 Patch(facecolor='#e74c3c', label='Disease (n=39)'),
 Patch(facecolor='#3498db', label='Control (n=8)')
]
plt.legend(handles=legend_elements, loc='upper left', bbox_to_anchor=(0.92, 0.95), 
 frameon=True, fancybox=True, shadow=True)

plt.savefig(outdir / 'heatmap_top30_biomarkers.png', dpi=300, bbox_inches='tight')
plt.close('all')
print(f" ✓ Saved: {outdir / 'heatmap_top30_biomarkers.png'}")


# ============================================================================
# HEATMAP 2: Top 50 Biomarkers (Simpler Version)
# ============================================================================
print("Creating Heatmap 2: Top 50 Biomarkers (Simplified)...")

# Get top 50
top50 = ad_biomarkers.nsmallest(50, 'padj')
top50_genes = top50['gene_id'].tolist()

# Extract and normalize
heatmap_data_50 = ad_counts.loc[top50_genes].copy()
cpm_50 = (heatmap_data_50 / lib_sizes) * 1e6
log2cpm_50 = np.log2(cpm_50 + 1)
heatmap_zscore_50 = log2cpm_50.apply(zscore, axis=1)

# Sort samples by group
sorted_samples = ad_meta.sort_values('condition').index
heatmap_sorted = heatmap_zscore_50[sorted_samples]

# Gene names
gene_names_50 = []
for gene_id in top50_genes:
 gene_name = top50[top50['gene_id'] == gene_id]['gene_name'].values[0]
 if pd.notna(gene_name) and gene_name != 'nan':
 gene_names_50.append(gene_name)
 else:
 gene_names_50.append(gene_id[:15])

heatmap_sorted.index = gene_names_50

# Create figure
fig, ax = plt.subplots(figsize=(16, 14))

sns.heatmap(heatmap_sorted, 
 cmap='RdBu_r', 
 center=0,
 vmin=-2, vmax=2,
 cbar_kws={'label': 'Z-score (row-normalized)'},
 xticklabels=False,
 yticklabels=True,
 linewidths=0,
 ax=ax)

# Add vertical line separating disease and control
n_disease = (ad_meta.loc[sorted_samples, 'condition'] == 'Disease').sum()
ax.axvline(x=n_disease, color='black', linewidth=3, linestyle='--')

# Add labels at top
ax.text(n_disease/2, -2, 'Disease (n=39)', ha='center', va='bottom', 
 fontsize=12, fontweight='bold', color='#e74c3c')
ax.text(n_disease + (len(sorted_samples)-n_disease)/2, -2, 'Control (n=8)', 
 ha='center', va='bottom', fontsize=12, fontweight='bold', color='#3498db')

ax.set_title("Top 50 Alzheimer's Disease ncRNA Biomarkers\nExpression Across Samples", 
 fontsize=16, fontweight='bold', pad=20)
ax.set_xlabel('Samples (sorted by group)', fontsize=12, fontweight='bold')
ax.set_ylabel('ncRNA Biomarkers', fontsize=12, fontweight='bold')

plt.tight_layout()
plt.savefig(outdir / 'heatmap_top50_sorted.png', dpi=300, bbox_inches='tight')
plt.close()
print(f" ✓ Saved: {outdir / 'heatmap_top50_sorted.png'}")


# ============================================================================
# HEATMAP 3: Top Upregulated vs Downregulated
# ============================================================================
print("Creating Heatmap 3: Up vs Down Regulated Biomarkers...")

# Get top 15 upregulated and top 15 downregulated
up_genes = ad_biomarkers[ad_biomarkers['log2FoldChange'] > 0].nsmallest(15, 'padj')
down_genes = ad_biomarkers[ad_biomarkers['log2FoldChange'] < 0].nsmallest(15, 'padj')

# Combine
combined = pd.concat([up_genes, down_genes])
combined_gene_ids = combined['gene_id'].tolist()

# Extract and normalize
heatmap_data_updown = ad_counts.loc[combined_gene_ids].copy()
cpm_updown = (heatmap_data_updown / lib_sizes) * 1e6
log2cpm_updown = np.log2(cpm_updown + 1)
heatmap_zscore_updown = log2cpm_updown.apply(zscore, axis=1)

# Sort samples
heatmap_updown_sorted = heatmap_zscore_updown[sorted_samples]

# Gene names with direction indicator
gene_names_updown = []
for _, row in combined.iterrows():
 gene_name = row['gene_name'] if pd.notna(row['gene_name']) else row['gene_id'][:15]
 direction = '↑' if row['log2FoldChange'] > 0 else '↓'
 gene_names_updown.append(f"{direction} {gene_name}")

heatmap_updown_sorted.index = gene_names_updown

# Create figure
fig, ax = plt.subplots(figsize=(16, 10))

sns.heatmap(heatmap_updown_sorted, 
 cmap='RdBu_r', 
 center=0,
 vmin=-2, vmax=2,
 cbar_kws={'label': 'Z-score (row-normalized)'},
 xticklabels=False,
 yticklabels=True,
 linewidths=0,
 ax=ax)

# Add vertical line
ax.axvline(x=n_disease, color='black', linewidth=3, linestyle='--')

# Add horizontal line separating up and down
ax.axhline(y=len(up_genes), color='yellow', linewidth=3, linestyle='--', alpha=0.7)

# Labels
ax.text(n_disease/2, -1.5, 'Disease (n=39)', ha='center', va='bottom', 
 fontsize=11, fontweight='bold', color='#e74c3c')
ax.text(n_disease + (len(sorted_samples)-n_disease)/2, -1.5, 'Control (n=8)', 
 ha='center', va='bottom', fontsize=11, fontweight='bold', color='#3498db')

ax.text(-2, len(up_genes)/2, 'Upregulated\n↑', ha='right', va='center', 
 fontsize=11, fontweight='bold', color='red', rotation=90)
ax.text(-2, len(up_genes) + len(down_genes)/2, 'Downregulated\n↓', ha='right', va='center', 
 fontsize=11, fontweight='bold', color='blue', rotation=90)

ax.set_title("Top Upregulated vs Downregulated ncRNA Biomarkers\n(Top 15 of each by FDR)", 
 fontsize=16, fontweight='bold', pad=20)
ax.set_xlabel('Samples (sorted by group)', fontsize=12, fontweight='bold')
ax.set_ylabel('ncRNA Biomarkers', fontsize=12, fontweight='bold')

plt.tight_layout()
plt.savefig(outdir / 'heatmap_updown_comparison.png', dpi=300, bbox_inches='tight')
plt.close()
print(f" ✓ Saved: {outdir / 'heatmap_updown_comparison.png'}")


# ============================================================================
# Summary
# ============================================================================
print("\n" + "="*80)
print("HEATMAP GENERATION COMPLETE")
print("="*80)
print(f"\nCreated 3 heatmaps in: {outdir}")
print(f"\n1. heatmap_top30_biomarkers.png - Hierarchical clustering of top 30")
print(f"2. heatmap_top50_sorted.png - Top 50 with samples sorted by group")
print(f"3. heatmap_updown_comparison.png - Top 15 up vs top 15 down regulated")
print(f"\n✅ All heatmaps saved at 300 DPI!")
print("="*80)
