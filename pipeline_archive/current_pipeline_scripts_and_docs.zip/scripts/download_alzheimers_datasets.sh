#!/bin/bash
# Download 3 Alzheimer's Datasets from GEO
# One at a time for reliability

cd /Users/austinbautista/ncrna_pipeline
source .venv/bin/activate

echo "=========================================="
echo "DOWNLOADING 3 ALZHEIMER'S DATASETS"
echo "=========================================="
echo ""
echo "This will take 15-30 minutes total"
echo "Each dataset: 5-10 minutes"
echo ""

# Dataset 1: GSE33000
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📥 DATASET 1/3: GSE33000"
echo " Alzheimer's brain tissue (77 samples)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
python scripts/geo_integration.py \
 --geo_id GSE33000 \
 --annotation data/annotations/human_gencode.gtf \
 --outdir results/alzheimers_3datasets/GSE33000

if [ -f "results/alzheimers_3datasets/GSE33000/counts.csv" ]; then
 echo "✓ GSE33000 downloaded successfully!"
else
 echo "✗ GSE33000 download failed"
fi

echo ""

# Dataset 2: GSE48350
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📥 DATASET 2/3: GSE48350"
echo " Alzheimer's brain tissue (253 samples)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
python scripts/geo_integration.py \
 --geo_id GSE48350 \
 --annotation data/annotations/human_gencode.gtf \
 --outdir results/alzheimers_3datasets/GSE48350

if [ -f "results/alzheimers_3datasets/GSE48350/counts.csv" ]; then
 echo "✓ GSE48350 downloaded successfully!"
else
 echo "✗ GSE48350 download failed"
fi

echo ""

# Dataset 3: GSE5281
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📥 DATASET 3/3: GSE5281"
echo " Alzheimer's brain tissue (161 samples)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
python scripts/geo_integration.py \
 --geo_id GSE5281 \
 --annotation data/annotations/human_gencode.gtf \
 --outdir results/alzheimers_3datasets/GSE5281

if [ -f "results/alzheimers_3datasets/GSE5281/counts.csv" ]; then
 echo "✓ GSE5281 downloaded successfully!"
else
 echo "✗ GSE5281 download failed"
fi

echo ""
echo "=========================================="
echo "DOWNLOAD SUMMARY"
echo "=========================================="

# Count successful downloads
SUCCESS=0
[ -f "results/alzheimers_3datasets/GSE33000/counts.csv" ] && ((SUCCESS++))
[ -f "results/alzheimers_3datasets/GSE48350/counts.csv" ] && ((SUCCESS++))
[ -f "results/alzheimers_3datasets/GSE5281/counts.csv" ] && ((SUCCESS++))

echo "Datasets downloaded: $SUCCESS/3"
echo ""

if [ $SUCCESS -eq 3 ]; then
 echo "✓ ALL DATASETS READY!"
 echo ""
 echo "NEXT STEP: Find shared biomarkers"
 echo " python scripts/analyze_biomarkers.py \\"
 echo " --root results/alzheimers_3datasets \\"
 echo " --outdir results/alzheimers_3datasets/validated_biomarkers"
elif [ $SUCCESS -gt 0 ]; then
 echo "⚠ Some datasets downloaded"
 echo " You can still analyze the ones that worked"
else
 echo "✗ No datasets downloaded"
 echo " GEO servers might be slow/unavailable"
 echo " Try again later or use different datasets"
fi

echo ""
echo "View results:"
echo " open results/alzheimers_3datasets/"
echo ""
