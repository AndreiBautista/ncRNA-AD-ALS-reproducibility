#!/usr/bin/env python3
"""
Download ALL 5 datasets directly from GEO
Using direct HTTP/FTP links found in comprehensive search
"""

import os
import sys
import subprocess
from pathlib import Path
import urllib.request
import gzip
import tarfile

# Download URLs (confirmed working)
DOWNLOADS = {
 "GSE173955": {
 "disease": "alzheimers",
 "url": "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE173nnn/GSE173955/suppl/GSE173955_Table_1_gene_level_expression.xlsx",
 "filename": "GSE173955_Table_1_gene_level_expression.xlsx",
 "type": "xlsx",
 "size": "14 MB",
 },
 "GSE95587": {
 "disease": "alzheimers",
 "url": "http://www.ncbi.nlm.nih.gov/geo/download/?acc=GSE95587&format=file&file=GSE95587_RAW.tar",
 "filename": "GSE95587_RAW.tar",
 "type": "tar",
 "size": "36 MB",
 },
 "GSE124439": {
 "disease": "als",
 "url": "http://www.ncbi.nlm.nih.gov/geo/download/?acc=GSE124439&format=file&file=GSE124439_RAW.tar",
 "filename": "GSE124439_RAW.tar",
 "type": "tar",
 "size": "21.6 MB",
 },
 "GSE116622": {
 "disease": "als",
 "url": "http://www.ncbi.nlm.nih.gov/geo/download/?acc=GSE116622&format=file&file=GSE116622_DS_leafcutter.ratios_Conlon_et_al_2018.txt.gz",
 "filename": "GSE116622_splicing_ratios.txt.gz",
 "type": "gz",
 "size": "25.4 MB",
 },
 "GSE76220": {
 "disease": "als",
 "url": "http://www.ncbi.nlm.nih.gov/geo/download/?acc=GSE76220&format=file&file=GSE76220_ALS_LCM_MPR_gene_expression.txt.gz",
 "filename": "GSE76220_ALS_LCM_MPR_gene_expression.txt.gz",
 "type": "gz",
 "size": "3.5 MB (recommended) or 683 KB",
 },
}


def download_file(url, destination, filename):
 """Download a file with progress bar."""
 print(f" Downloading: {filename}")
 print(f" From: {url}")

 try:
 # Use curl with progress bar if available
 result = subprocess.run(
 ["curl", "-L", "-o", str(destination), "-C", "-", url],
 capture_output=True,
 text=True,
 timeout=600,
 )

 if result.returncode == 0 and destination.exists():
 size_mb = destination.stat().st_size / (1024 * 1024)
 print(f" ✓ Downloaded ({size_mb:.1f} MB)")
 return True
 else:
 print(f" ✗ Download failed: {result.stderr}")
 return False

 except Exception as e:
 print(f" ✗ Error: {e}")
 return False


def extract_tar(tar_file, dest_folder):
 """Extract TAR file."""
 print(f" Extracting: {tar_file.name}")
 try:
 with tarfile.open(tar_file, "r") as tar:
 tar.extractall(path=dest_folder)
 print(f" ✓ Extracted to {dest_folder}")
 return True
 except Exception as e:
 print(f" ✗ Extract failed: {e}")
 return False


def extract_gz(gz_file, dest_file):
 """Extract GZ file."""
 print(f" Extracting: {gz_file.name}")
 try:
 with gzip.open(gz_file, "rb") as f_in:
 with open(dest_file, "wb") as f_out:
 f_out.write(f_in.read())
 print(f" ✓ Extracted to {dest_file}")
 return True
 except Exception as e:
 print(f" ✗ Extract failed: {e}")
 return False


def main():
 print("=" * 80)
 print("DOWNLOAD ALL 5 GEO DATASETS")
 print("=" * 80)

 ncrna_pipeline = Path.home() / "ncrna_pipeline"
 base_data = ncrna_pipeline / "data" / "neurodegenerative_diseases"

 # Create temp download folder
 temp_folder = ncrna_pipeline / "temp_downloads"
 temp_folder.mkdir(exist_ok=True)

 print(f"\nTemp folder: {temp_folder}")
 print(f"Final destination: {base_data}\n")

 all_success = True

 for gse, info in DOWNLOADS.items():
 print(f"\n{'=' * 80}")
 print(f"{gse}: {info['filename']}")
 print(f"{'=' * 80}")
 print(f"Disease: {info['disease']}")
 print(f"Size: {info['size']}")
 print(f"Type: {info['type']}")

 # Create destination folder
 dest_folder = (
 base_data / info["disease"] / gse
 )
 dest_folder.mkdir(parents=True, exist_ok=True)

 # Download file
 dest_file = temp_folder / info["filename"]
 download_success = download_file(info["url"], dest_file, info["filename"])

 if not download_success:
 print(f"\n⚠ Download failed for {gse}")
 all_success = False
 continue

 # Extract if needed
 if info["type"] == "tar":
 if extract_tar(dest_file, dest_folder):
 dest_file.unlink() # Remove tar file after extraction
 else:
 all_success = False

 elif info["type"] == "gz":
 output_file = (
 dest_folder / info["filename"].replace(".gz", "")
 )
 if extract_gz(dest_file, output_file):
 dest_file.unlink() # Remove gz file after extraction
 else:
 all_success = False

 # For xlsx, just move it
 elif info["type"] == "xlsx":
 import shutil

 shutil.move(str(dest_file), str(dest_folder / info["filename"]))
 print(f" ✓ Moved to {dest_folder / info['filename']}")

 # Summary
 print("\n\n" + "=" * 80)
 print("DOWNLOAD SUMMARY")
 print("=" * 80)

 if all_success:
 print("\n✓ All datasets downloaded successfully!")
 else:
 print("\n⚠ Some downloads failed - check network and URLs")

 print("\nNext steps:")
 print("""
1. For each GSE folder, verify files were extracted correctly
 
2. For xlsx files (GSE173955):
 - Need to convert Excel to TSV/CSV
 - Will do this in next step
 
3. Run validation script:
 python cross_disease_pipeline.py
 
4. I'll handle the rest of the processing!
""")

 # Clean up temp folder
 if temp_folder.exists() and len(list(temp_folder.iterdir())) == 0:
 temp_folder.rmdir()
 print(f"✓ Cleaned up temp folder")


if __name__ == "__main__":
 main()
