#!/usr/bin/env python3
"""Build metadata files for GSE48350 using GEO sample characteristics."""

from pathlib import Path
import logging

import pandas as pd
import GEOparse


def classify_individual_label(label: str) -> str:
 label_upper = label.upper()
 if label_upper == "C":
 return "Control"
 if label_upper == "AA":
 return "Disease"
 return "Unknown"


def main():
 logging.getLogger("GEOparse").setLevel(logging.WARNING)

 base_dir = Path("data/neurodegenerative_diseases/alzheimers/GSE48350")
 counts_path = base_dir / "counts.txt"
 if not counts_path.exists():
 raise FileNotFoundError(counts_path)

 counts_df = pd.read_csv(counts_path, sep="\t", nrows=0)
 sample_ids = counts_df.columns.tolist()[1:]

 geo_dir = base_dir / "geo"
 geo_dir.mkdir(parents=True, exist_ok=True)
 gse = GEOparse.get_GEO("GSE48350", destdir=str(geo_dir), annotate_gpl=False)

 sample_lookup = {}
 for gsm_name, gsm in gse.gsms.items():
 chars = gsm.metadata.get("characteristics_ch1", [])
 individual = None
 brain_region = None
 gender = None
 age = None
 for c in chars:
 c_lower = c.lower()
 if c_lower.startswith("individual:"):
 individual = c.split(":", 1)[1].strip()
 elif c_lower.startswith("brain region:"):
 brain_region = c.split(":", 1)[1].strip()
 elif c_lower.startswith("gender:"):
 gender = c.split(":", 1)[1].strip()
 elif c_lower.startswith("age"):
 age = c.split(":", 1)[1].strip()
 label = ""
 if individual:
 parts = [p.strip() for p in individual.split(",")]
 label = parts[-1] if parts else ""
 sample_lookup[gsm_name] = {
 "individual": individual,
 "label": label,
 "brain_region": brain_region,
 "gender": gender,
 "age": age,
 }

 rows = []
 missing = 0
 for sample_id in sample_ids:
 info = sample_lookup.get(sample_id)
 if not info:
 missing += 1
 info = {"label": "", "brain_region": "", "gender": "", "age": "", "individual": ""}
 disease_status = classify_individual_label(info.get("label", ""))
 rows.append({
 "sample_id": sample_id,
 "disease_status": disease_status,
 "individual": info.get("individual", ""),
 "brain_region": info.get("brain_region", ""),
 "gender": info.get("gender", ""),
 "age": info.get("age", ""),
 "study_id": "GSE48350",
 })

 meta_full = pd.DataFrame(rows)
 meta_full_path = base_dir / "metadata_full.csv"
 meta_full.to_csv(meta_full_path, index=False)

 meta_filtered = meta_full[meta_full["disease_status"].isin(["Disease", "Control"])].copy()
 meta_filtered_path = base_dir / "metadata_disease.csv"
 meta_filtered.to_csv(meta_filtered_path, index=False)

 print("Total samples in counts:", len(sample_ids))
 print("Missing metadata matches:", missing)
 print("Disease/Control counts:")
 print(meta_filtered["disease_status"].value_counts())
 print("Saved:", meta_full_path)
 print("Saved:", meta_filtered_path)


if __name__ == "__main__":
 main()
