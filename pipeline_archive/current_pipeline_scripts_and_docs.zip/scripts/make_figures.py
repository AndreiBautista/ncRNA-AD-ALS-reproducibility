#!/usr/bin/env python3
"""Generate final visualizations for ."""
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg') # Non-interactive backend
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path

OUTPUT_DIR = Path('results/figures')
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

print("Loading data...")
ad_bio = pd.read_csv('results/deseq2/alzheimers/ncrna_biomarkers.csv')
cross = pd.read_csv('results/cross_disease/disease_specific_ncrnas.csv')

print(f"Creating figures...")

# 1. Volcano
fig, ax = plt.subplots(figsize=(10, 7))
ad_bio['log10p'] = -np.log10(ad_bio['padj'])
ax.scatter(ad_bio['log2FoldChange'], ad_bio['log10p'], alpha=0.5, s=10)
ax.set_xlabel('log2 Fold Change')
ax.set_ylabel('-log10(padj)')
ax.set_title('AD ncRNA Biomarkers')
plt.savefig(OUTPUT_DIR / 'volcano.png', dpi=300, bbox_inches='tight')
plt.close()
print(" ✓ volcano.png")

# 2. Bar chart
fig, ax = plt.subplots(figsize=(8, 5))
up = (ad_bio['log2FoldChange'] > 0).sum()
down = (ad_bio['log2FoldChange'] < 0).sum()
ax.bar(['Up', 'Down'], [up, down], color=['red', 'blue'])
ax.set_ylabel('Count')
ax.set_title('Direction of Change')
plt.savefig(OUTPUT_DIR / 'direction.png', dpi=300, bbox_inches='tight')
plt.close()
print(" ✓ direction.png")

# 3. Cross-disease
fig, ax = plt.subplots(figsize=(10, 7))
ax.scatter(cross['log2FoldChange_AD_vs_ALS'], -np.log10(cross['padj']), alpha=0.3, s=10)
ax.set_xlabel('log2 FC (AD vs ALS)')
ax.set_ylabel('-log10(padj)')
ax.set_title('Cross-Disease Comparison')
plt.savefig(OUTPUT_DIR / 'cross_disease.png', dpi=300, bbox_inches='tight')
plt.close()
print(" ✓ cross_disease.png")

print(f"\n✓ Done! Files in {OUTPUT_DIR}/")
