#!/usr/bin/env python3
"""
Find and download alternative public Alzheimer's RNA-seq datasets from GEO
"""

import subprocess
import os
from pathlib import Path

print("="*80)
print("FINDING ALTERNATIVE PUBLIC ALZHEIMER'S DATASETS")
print("="*80)

# Candidate datasets (human, RNA-seq, with substantial samples)
candidates = {
 'GSE233208': {
 'description': 'Single-nucleus RNA-Seq and spatial transcriptomics of AD and Down Syndrome',
 'samples': 185,
 'organism': 'Homo sapiens',
 'note': 'LARGE DATASET - Requires special handling for single-nucleus'
 },
 'GSE255982': {
 'description': 'iPSC from late-onset sporadic AD cases',
 'samples': 52,
 'organism': 'Homo sapiens',
 'note': 'iPSC-derived cells'
 },
 'GSE288917': {
 'description': 'Neural stem cells: EOAD, LOAD, and WT controls',
 'samples': 32,
 'organism': 'Homo sapiens',
 'note': 'Derived neural stem cells'
 },
 'GSE287651': {
 'description': 'Human entorhinal cortex at AD neuropathology onset',
 'samples': 15,
 'organism': 'Homo sapiens',
 'note': 'BRAIN TISSUE - Similar to GSE203206'
 },
 'GSE252236': {
 'description': 'Myeloid trisomy 21 variant in AD',
 'samples': 14,
 'organism': 'Homo sapiens',
 'note': 'Bulk RNA-seq'
 },
 'GSE206602': {
 'description': 'Familial AD mutations (PSEN1, PSEN2, APP)',
 'samples': 12,
 'organism': 'Homo sapiens',
 'note': 'Familial AD (PSEN1, PSEN2, APP mutations)'
 },
}

print("\nKEY CANDIDATES FOR MULTI-DATASET ANALYSIS:")
print("-"*80)

for gse_id in sorted(candidates.keys(), key=lambda x: candidates[x]['samples'], reverse=True):
 info = candidates[gse_id]
 print(f"\n{gse_id}: {info['samples']:3d} samples ⭐")
 print(f" {info['description']}")
 print(f" Note: {info['note']}")

print("\n"*2)
print("="*80)
print("RECOMMENDATION FOR QUICK WIN")
print("="*80)

print("""
BEST OPTION: GSE287651 (15 brain tissue samples)
 ✓ Human brain tissue (like GSE203206)
 ✓ Entorhinal cortex at AD onset
 ✓ Likely to have same format/quality as GSE203206
 ✓ Clean 15 samples can be analyzed quickly
 ✓ Would give 47 + 15 = 62 AD samples across 2 datasets

SECOND BEST: GSE288917 (32 neural stem cell samples)
 ✓ 32 samples is substantial (large enough for power)
 ✓ EOAD/LOAD/Control structure 
 ✓ Will have clear disease/control groups
 ✓ Can cross-validate with tissue data

ALTERNATIVE: GSE255982 (52 iPSC samples)
 ✓ Largest clean dataset (52 samples)
 ✓ Late-onset sporadic AD (most common form)
 ✓ Good biological relevance
 ⚠ iPSC-derived might behave differently than tissue

LARGE BUT COMPLEX: GSE233208 (185 snRNA-seq samples)
 ✓ 185 samples would be powerful
 ✓ Single-nucleus provides cell-type resolution
 ⚠ Different preprocessing pipeline needed
 ⚠ Much more complex to work with
""")

print("="*80)
print("\nWould you like me to:")
print(" 1. Try to download GSE287651 (brain tissue - most compatible)")
print(" 2. Try to download GSE288917 (neural stem cells - larger)")
print(" 3. Try to download GSE255982 (iPSC - largest single cohort)")
print(" 4. Focus on GSE287651 + GSE288917 (combine 2 datasets)")
print("\nLet me know which you prefer and I'll attempt the download!")
