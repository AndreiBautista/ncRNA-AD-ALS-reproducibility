#!/usr/bin/env python3
"""
Multi-Species, Multi-Disease ncRNA Biomarker Analysis Orchestrator

For Science Fair Projects:
 Analyzes ncRNA biomarkers across multiple species (human, mouse, zebrafish)
 and diseases (Alzheimer's, Parkinson's, ALS) to identify promising early
 biomarker candidates for clinical translation.

SCIENCE FAIR WORKFLOW:
 1. Configure datasets in config_datasets.yaml
 2. Run: python analyze_biomarkers.py --config config_datasets.yaml
 3. Review results in biomarker_results/ directory
 4. Use findings for presentation

OUTPUT:
 - biomarker_results/top_candidates.csv (ranked biomarkers)
 - biomarker_results/biomarker_report.txt (science fair summary)
 - biomarker_results/PRESENTATION_SUMMARY.txt (presentation-ready summary)
 - biomarker_results/figures/biomarker_heatmap.png (cross-dataset visualization)
 - biomarker_results/figures/biomarker_overlap.png (dataset similarity)
 - biomarker_results/per_dataset/<dataset_id>/data (per-dataset tables)
 - biomarker_results/per_dataset/<dataset_id>/figures (per-dataset visuals)
"""

import argparse
import yaml
from pathlib import Path
import pandas as pd
import sys

from pipeline import de_analysis, io, processing, visualization
from pipeline import biomarker_analysis


def _append_plot_error(log_path: Path, message: str) -> None:
 log_path.parent.mkdir(parents=True, exist_ok=True)
 with open(log_path, 'a', encoding='utf-8') as handle:
 handle.write(message.rstrip() + "\n")


def load_config(config_path: str) -> dict:
 """
 Load dataset configuration from YAML file.
 
 Args:
 config_path: Path to config_datasets.yaml
 
 Returns:
 Dict with dataset configurations
 """
 with open(config_path, 'r') as f:
 config = yaml.safe_load(f)
 
 if not config:
 raise ValueError(f"Empty config file: {config_path}")
 
 print(f"✓ Loaded {len(config)} datasets from config")
 return config


def analyze_single_dataset(dataset_id: str, dataset_config: dict, out_dir: Path) -> tuple:
 """
 Analyze one dataset using standard pipeline.
 
 Returns:
 (results_df, metadata_dict)
 """
 print(f"\n Analyzing {dataset_id}...")
 
 # Load data
 counts = io.load_counts(dataset_config['counts_path'])
 meta = io.load_metadata(dataset_config['metadata_path'], 
 group_col=dataset_config['group_col'])
 
 # Create minimal annotation if not provided
 if 'annotation_path' in dataset_config and dataset_config['annotation_path']:
 annot = io.load_annotation(dataset_config['annotation_path'])
 else:
 annot = pd.DataFrame(
 {'gene_name': counts.index, 'biotype': 'unknown'},
 index=counts.index
 )
 
 # Normalize
 logcpm = processing.log2_cpm(counts)
 
 # DE analysis
 group_col = dataset_config['group_col']
 disease_label = dataset_config.get('disease_label')
 control_label = dataset_config.get('control_label')
 
 res = de_analysis.differential_expression(
 logcpm, meta, group_col, disease_label, control_label
 )
 res = de_analysis.adjust_pvalues(res)
 
 # Prepare output folders
 dataset_dir = out_dir / 'per_dataset' / dataset_id
 data_dir = dataset_dir / 'data'
 figures_dir = dataset_dir / 'figures'
 data_dir.mkdir(parents=True, exist_ok=True)
 figures_dir.mkdir(parents=True, exist_ok=True)

 # Save results
 out_prefix = str(data_dir / dataset_id)
 csv_path, merged = de_analysis.save_results(res, annot, out_prefix)

 # Generate per-dataset visuals
 top_genes = merged.sort_values(['fdr', 'pvalue']).index[:50].tolist()
 volcano_path = str(figures_dir / f"{dataset_id}_volcano.png")
 heatmap_path = str(figures_dir / f"{dataset_id}_top_genes_heatmap.png")

 plot_log = figures_dir / 'plot_errors.log'
 try:
 visualization.volcano_plot(merged, volcano_path, title=dataset_id)
 except Exception as e:
 message = f"{dataset_id} volcano plot failed: {e}"
 print(f" ⚠ {message}")
 _append_plot_error(plot_log, message)

 try:
 visualization.heatmap_top_genes(logcpm, top_genes, meta, group_col, heatmap_path)
 except Exception as e:
 message = f"{dataset_id} heatmap failed: {e}"
 print(f" ⚠ {message}")
 _append_plot_error(plot_log, message)
 
 # Get metadata for biomarker tracking
 metadata = {
 'species': dataset_config['species'],
 'disease': dataset_config['disease'],
 'dataset_id': dataset_id
 }
 
 return merged, metadata


def main():
 parser = argparse.ArgumentParser(
 description='Multi-species, multi-disease ncRNA biomarker discovery',
 epilog='''
EXAMPLE:
 python analyze_biomarkers.py --config config_datasets.yaml --outdir biomarker_results

SCIENCE FAIR WORKFLOW:
 1. Edit config_datasets.yaml to add your datasets
 2. Run this script to analyze all datasets
 3. Check biomarker_results/biomarker_report.txt for top candidates
 4. Use heatmap/overlap plots in your presentation
 '''
 )
 
 parser.add_argument('--config', default='config_datasets.yaml',
 help='Path to dataset configuration file (YAML)')
 parser.add_argument('--outdir', default='biomarker_results',
 help='Output directory for results')
 parser.add_argument('--species', default=None,
 help='Filter analysis to specific species (human|mouse|zebrafish)')
 parser.add_argument('--disease', default=None,
 help='Filter analysis to specific disease (alzheimers|parkinsons|als)')
 parser.add_argument('--fdr-threshold', type=float, default=0.05,
 help='FDR threshold for significant biomarkers')
 parser.add_argument('--top-n', type=int, default=20,
 help='Number of top biomarkers to report')
 
 args = parser.parse_args()
 
 # Load config
 try:
 config = load_config(args.config)
 except FileNotFoundError:
 print(f"❌ Config file not found: {args.config}")
 print(f" Create {args.config} using the template in this directory")
 sys.exit(1)
 except Exception as e:
 print(f"❌ Error loading config: {e}")
 sys.exit(1)
 
 # Filter datasets if requested
 if args.species or args.disease:
 original_count = len(config)
 config = {
 ds_id: cfg for ds_id, cfg in config.items()
 if (args.species is None or cfg.get('species') == args.species) and
 (args.disease is None or cfg.get('disease') == args.disease)
 }
 if len(config) < original_count:
 print(f" Filtered to {len(config)} datasets "
 f"(species={args.species}, disease={args.disease})")
 
 # Create output directories
 out_dir = Path(args.outdir)
 out_dir.mkdir(parents=True, exist_ok=True)
 (out_dir / 'figures').mkdir(parents=True, exist_ok=True)
 (out_dir / 'per_dataset').mkdir(parents=True, exist_ok=True)
 print(f"\n📁 Output directory: {out_dir}")
 
 # Analyze each dataset
 print(f"\n🔬 Analyzing {len(config)} datasets...")
 print("=" * 60)
 
 results_dict = {}
 dataset_metadata = {}
 failed_datasets = []
 
 for dataset_id, dataset_config in sorted(config.items()):
 try:
 # Check if data files exist
 if not Path(dataset_config['counts_path']).exists():
 print(f" ⚠ Skipping {dataset_id} (counts file not found)")
 failed_datasets.append(dataset_id)
 continue
 
 if not Path(dataset_config['metadata_path']).exists():
 print(f" ⚠ Skipping {dataset_id} (metadata file not found)")
 failed_datasets.append(dataset_id)
 continue
 
 results, metadata = analyze_single_dataset(
 dataset_id, dataset_config, out_dir
 )
 results_dict[dataset_id] = results
 dataset_metadata[dataset_id] = metadata
 
 except Exception as e:
 print(f" ❌ {dataset_id}: {e}")
 failed_datasets.append(dataset_id)
 
 if not results_dict:
 print(f"\n❌ No datasets analyzed successfully")
 if failed_datasets:
 print(f"Failed datasets: {', '.join(failed_datasets)}")
 print(f"\nTo use this script:")
 print(f"1. Edit {args.config} to point to your data files")
 print(f"2. Ensure counts and metadata files exist")
 print(f"3. Format: one dataset entry = one species + one disease")
 sys.exit(1)
 
 print(f"\n✓ Successfully analyzed {len(results_dict)} datasets")
 if failed_datasets:
 print(f" (Skipped {len(failed_datasets)}: {', '.join(failed_datasets[:3])}...)")
 
 # Cross-dataset biomarker analysis
 print(f"\n🧬 Cross-Dataset Biomarker Analysis...")
 print("=" * 60)
 
 biomarkers = biomarker_analysis.load_biomarker_results(
 results_dict, fdr_threshold=args.fdr_threshold
 )
 
 # Check if we have multiple datasets
 if len(biomarkers) < 2:
 print("⚠ Warning: Only 1 dataset analyzed. Cross-dataset analysis requires 2+ datasets.")
 print(" Add more datasets to config_datasets.yaml for comparative analysis.")
 
 # Find conserved biomarkers
 print(f"\n Finding conserved biomarkers...")
 conserved_2x = biomarker_analysis.find_conserved_biomarkers(biomarkers, min_datasets=2)
 conserved_3x = biomarker_analysis.find_conserved_biomarkers(biomarkers, min_datasets=3)
 
 conserved_pct_2x = len(conserved_2x) / max(sum(len(g) for g in biomarkers.values()), 1) * 100
 print(f" {len(conserved_2x)} biomarkers in 2+ datasets ({conserved_pct_2x:.1f}% of total)")
 print(f" {len(conserved_3x)} biomarkers in 3+ datasets")
 
 # Disease-specific analysis
 print(f"\n Analyzing by disease...")
 disease_biomarkers = biomarker_analysis.identify_disease_specific_biomarkers(
 biomarkers, dataset_metadata
 )
 
 # Species-specific analysis
 print(f"\n Analyzing by species...")
 species_biomarkers = biomarker_analysis.identify_species_specific_biomarkers(
 biomarkers, dataset_metadata
 )
 
 # Rank biomarkers
 print(f"\n Ranking biomarkers by cross-dataset consistency...")
 ranking_df = biomarker_analysis.rank_biomarkers_by_impact(
 results_dict, biomarkers, dataset_metadata
 )
 print(f" ✓ Ranked {len(ranking_df)} biomarkers")
 
 # Save ranking results
 ranking_path = out_dir / 'top_candidates.csv'
 ranking_df.to_csv(ranking_path)
 print(f"\n ✓ Saved top candidates: {ranking_path}")
 
 # Generate report
 print(f"\n Generating science fair report...")
 report_path = out_dir / 'biomarker_report.txt'
 report = biomarker_analysis.generate_biomarker_report(
 ranking_df, str(report_path), top_n=args.top_n
 )
 
 # Print summary
 summary = biomarker_analysis.summarize_biomarker_findings(
 ranking_df, disease_biomarkers, species_biomarkers
 )
 print(summary)
 
 # Generate visualizations (if multiple datasets)
 if len(biomarkers) >= 2:
 print(f"\n📊 Generating visualizations...")
 
 plot_log = out_dir / 'figures' / 'plot_errors.log'

 heatmap_path = out_dir / 'figures' / 'biomarker_heatmap.png'
 try:
 biomarker_analysis.visualize_biomarker_heatmap(
 ranking_df, biomarkers, dataset_metadata, str(heatmap_path), top_n=50
 )
 except Exception as e:
 message = f"biomarker heatmap failed: {e}"
 print(f" ⚠ {message}")
 _append_plot_error(plot_log, message)

 overlap_path = out_dir / 'figures' / 'biomarker_overlap.png'
 try:
 biomarker_analysis.visualize_biomarker_overlap(
 biomarkers, dataset_metadata, str(overlap_path)
 )
 except Exception as e:
 message = f"biomarker overlap failed: {e}"
 print(f" ⚠ {message}")
 _append_plot_error(plot_log, message)
 
 # Write summary to file
 summary_path = out_dir / 'PRESENTATION_SUMMARY.txt'
 with open(summary_path, 'w') as f:
 f.write("=" * 70 + "\n")
 f.write("SCIENCE FAIR BIOMARKER ANALYSIS - SUMMARY FOR PRESENTATION\n")
 f.write("=" * 70 + "\n\n")
 f.write(f"Analysis Date: {pd.Timestamp.now()}\n")
 f.write(f"Datasets Analyzed: {len(results_dict)}\n")
 f.write(f"Total Biomarkers Found: {sum(len(g) for g in biomarkers.values())}\n")
 f.write(f"Biomarkers in 2+ Datasets: {len(conserved_2x)}\n")
 f.write(f"Biomarkers in 3+ Datasets: {len(conserved_3x)}\n")
 f.write(summary)
 
 print(f"\n" + "=" * 60)
 print(f"✅ ANALYSIS COMPLETE")
 print(f"=" * 60)
 print(f"\n📁 Results saved to: {out_dir}")
 print(f"\n📄 Key Files:")
 print(f" • {ranking_path.name} - All ranked biomarkers")
 print(f" • {report_path.name} - Detailed report")
 print(f" • {summary_path.name} - Summary for presentation")
 if len(biomarkers) >= 2:
 print(f" • figures/biomarker_heatmap.png - Cross-dataset heatmap")
 print(f" • figures/biomarker_overlap.png - Dataset similarity")
 
 print(f"\n💡 Next Steps:")
 print(f" 1. Review top_candidates.csv for best biomarkers")
 print(f" 2. Read PRESENTATION_SUMMARY.txt for talking points")
 print(f" 3. Use heatmap/overlap plots in your science fair poster")
 print(f" 4. Validate top candidates experimentally (qPCR, etc.)")
 
 if failed_datasets:
 print(f"\n⚠️ Note: {len(failed_datasets)} datasets were skipped.")
 print(f" Add their data to the config to improve analysis.")


if __name__ == '__main__':
 main()
