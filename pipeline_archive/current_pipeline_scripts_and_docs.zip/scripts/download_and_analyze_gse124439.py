#!/usr/bin/env python3
"""
Download and analyze GSE124439 (ALS motor/frontal cortex, raw TEcount tables).
Creates raw counts, metadata, and ALS ncRNA biomarkers for -grade analysis.
"""

import os
import sys
import tarfile
import urllib.request
import pandas as pd
import numpy as np
from pathlib import Path

from pipeline import processing as pipeline_processing
from pipeline import de_analysis as pipeline_de

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data" / "neurodegenerative_diseases" / "als" / "GSE124439"
RESULTS_DIR = BASE_DIR / "results" / "multi_dataset_analysis"
ANNOT_PATH = BASE_DIR / "data" / "annotations" / "annotation_human.csv"

DATA_DIR.mkdir(parents=True, exist_ok=True)
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

GSE_ID = "GSE124439"
SERIES_MATRIX = DATA_DIR / "GSE124439_series_matrix.txt.gz"
RAW_TAR = DATA_DIR / "GSE124439_RAW.tar"
RAW_DIR = DATA_DIR / "raw_counts"

print("=" * 80)
print("DOWNLOADING GSE124439 RAW COUNTS (ALS MOTOR/FRONTAL CORTEX)")
print("=" * 80)

# ---------------------------------------------------------------------------
# 1) Ensure series matrix exists for metadata
# ---------------------------------------------------------------------------

if not SERIES_MATRIX.exists():
 print("\n1. Downloading series matrix...")
 matrix_url = f"ftp://ftp.ncbi.nlm.nih.gov/geo/series/GSE124nnn/{GSE_ID}/matrix/{GSE_ID}_series_matrix.txt.gz"
 try:
 urllib.request.urlretrieve(matrix_url, SERIES_MATRIX)
 print(" ✓ Downloaded series matrix")
 except Exception as exc:
 print(f" ✗ Failed to download series matrix: {exc}")
 sys.exit(1)
else:
 print("\n1. Series matrix already present")

# ---------------------------------------------------------------------------
# 2) Parse series matrix for sample metadata
# ---------------------------------------------------------------------------

print("\n2. Parsing metadata (ALS vs Control)...")

sample_titles = []
sample_gsm = []
sample_group = []
sample_tissue = []

with open(SERIES_MATRIX, "r", errors="ignore") as handle:
 for line in handle:
 if line.startswith("!Sample_title"):
 parts = line.strip().split("\t")[1:]
 sample_titles = [p.strip().strip('"') for p in parts]
 elif line.startswith("!Sample_geo_accession"):
 parts = line.strip().split("\t")[1:]
 sample_gsm = [p.strip().strip('"') for p in parts]
 elif line.startswith("!Sample_source_name_ch1"):
 parts = line.strip().split("\t")[1:]
 sample_tissue = [p.strip().strip('"') for p in parts]
 elif line.startswith("!Sample_characteristics_ch1") and "sample group" in line.lower():
 parts = line.strip().split("\t")[1:]
 sample_group = [p.strip().strip('"') for p in parts]

if not sample_titles or not sample_group:
 print(" ✗ Could not parse sample titles or sample groups from series matrix")
 sys.exit(1)

if len(sample_titles) != len(sample_group):
 print(" ✗ Sample count mismatch in metadata")
 sys.exit(1)

# Build status labels
status = []
for grp in sample_group:
 grp_lower = grp.lower()
 if "als" in grp_lower:
 status.append("ALS")
 elif "control" in grp_lower:
 status.append("Control")
 else:
 status.append("Other")

metadata_df = pd.DataFrame({
 "sample_title": sample_titles,
 "sample_gsm": sample_gsm if len(sample_gsm) == len(sample_titles) else [None] * len(sample_titles),
 "disease_status": status,
 "tissue_type": sample_tissue if len(sample_tissue) == len(sample_titles) else ["unknown"] * len(sample_titles),
 "study_id": GSE_ID,
}).set_index("sample_title")

# Filter to ALS vs Control only
metadata_df = metadata_df[metadata_df["disease_status"].isin(["ALS", "Control"])].copy()

print(f" ✓ Samples total: {len(sample_titles)}")
print(f" ✓ ALS: {(metadata_df['disease_status'] == 'ALS').sum()}, Control: {(metadata_df['disease_status'] == 'Control').sum()}")

if (metadata_df["disease_status"] == "ALS").sum() < 2 or (metadata_df["disease_status"] == "Control").sum() < 2:
 print(" ✗ Not enough ALS/Control samples for DE analysis")
 sys.exit(1)

# ---------------------------------------------------------------------------
# 3) Download and extract RAW counts
# ---------------------------------------------------------------------------

print("\n3. Downloading RAW tar file...")
raw_url = f"ftp://ftp.ncbi.nlm.nih.gov/geo/series/GSE124nnn/{GSE_ID}/suppl/{GSE_ID}_RAW.tar"

if not RAW_TAR.exists():
 try:
 urllib.request.urlretrieve(raw_url, RAW_TAR)
 print(f" ✓ Downloaded {RAW_TAR.name} ({RAW_TAR.stat().st_size / 1e6:.1f} MB)")
 except Exception as exc:
 print(f" ✗ Failed to download RAW tar: {exc}")
 sys.exit(1)
else:
 print(" ✓ RAW tar already present")

print("\n4. Extracting RAW counts...")
RAW_DIR.mkdir(parents=True, exist_ok=True)

if not any(RAW_DIR.iterdir()):
 try:
 with tarfile.open(RAW_TAR, "r") as tar:
 tar.extractall(RAW_DIR)
 print(" ✓ Extracted RAW counts")
 except Exception as exc:
 print(f" ✗ Extraction failed: {exc}")
 sys.exit(1)
else:
 print(" ✓ RAW counts already extracted")

# ---------------------------------------------------------------------------
# 5) Load count tables and build expression matrix
# ---------------------------------------------------------------------------

print("\n5. Loading TEcount tables...")

# Mapping for quick lookups
sample_title_map = {s.lower(): s for s in metadata_df.index}
gsm_to_title = {g: t for g, t in zip(sample_gsm, sample_titles)} if sample_gsm else {}

def normalize_sample_key(name: str) -> str:
 key = name.replace(".txt", "").replace(".tsv", "").replace(".csv", "")
 key = key.replace(".gz", "").replace("_counts", "").replace("-counts", "")
 return key

# Collect files
all_files = [p for p in RAW_DIR.rglob("*") if p.is_file()]
count_files = [p for p in all_files if p.suffix in {".txt", ".tsv", ".csv", ".gz"}]

if not count_files:
 print(" ✗ No count files found in RAW directory")
 sys.exit(1)

series_list = []
loaded = 0

for idx, fpath in enumerate(sorted(count_files)):
 sample_key = normalize_sample_key(fpath.name)
 sample_title = None

 candidates = [sample_key]
 if "_" in sample_key:
 candidates.extend(sample_key.split("_"))
 candidates.extend([c.replace("GSM", "") for c in candidates])

 for cand in candidates:
 if cand in gsm_to_title:
 sample_title = gsm_to_title[cand]
 break
 if cand.lower() in sample_title_map:
 sample_title = sample_title_map[cand.lower()]
 break

 if sample_title is None:
 for title in metadata_df.index:
 if title.lower() in sample_key.lower():
 sample_title = title
 break

 if sample_title is None:
 continue

 try:
 df = pd.read_csv(fpath, sep="\t", comment="#", low_memory=False)
 if df.empty:
 continue

 # Use first column as gene ID
 gene_col = df.columns[0]
 df = df.set_index(gene_col)

 # Pick count column
 preferred = ["count", "counts", "expected_count", "raw_count", "read_count", "num_reads", "numreads", "value"]
 count_col = None
 for col in df.columns:
 col_lower = str(col).lower()
 if any(p in col_lower for p in preferred):
 count_col = col
 break

 if count_col is None:
 numeric_cols = df.select_dtypes(include=[np.number]).columns
 if len(numeric_cols) > 0:
 count_col = numeric_cols[0]
 else:
 # Try to coerce the first data column to numeric
 count_col = df.columns[0]

 series = pd.to_numeric(df[count_col], errors="coerce").fillna(0)
 series.name = sample_title
 series_list.append(series)
 loaded += 1

 if loaded % 25 == 0:
 print(f" ✓ Loaded {loaded} samples")
 except Exception:
 continue

if not series_list:
 print(" ✗ No valid count tables loaded")
 sys.exit(1)

expr_df = pd.concat(series_list, axis=1, sort=True).fillna(0)

# Keep only metadata samples
common_samples = [s for s in metadata_df.index if s in expr_df.columns]
expr_df = expr_df[common_samples].copy()
metadata_df = metadata_df.loc[common_samples].copy()

print(f" ✓ Combined: {expr_df.shape[0]} genes × {expr_df.shape[1]} samples")

# ---------------------------------------------------------------------------
# 6) Save raw counts + metadata
# ---------------------------------------------------------------------------

counts_out = DATA_DIR / "counts.csv"
metadata_out = DATA_DIR / "metadata.csv"
expr_df.to_csv(counts_out)
metadata_df.to_csv(metadata_out)
print(f"\n6. Saved counts → {counts_out}")
print(f" Saved metadata → {metadata_out}")

# ---------------------------------------------------------------------------
# 7) Normalize + DE analysis (ncRNA only)
# ---------------------------------------------------------------------------

print("\n7. Running ncRNA differential expression...")

annot_df = pd.read_csv(ANNOT_PATH)
annot_df = annot_df.set_index("gene_id")

gene_index = expr_df.index.astype(str)
if gene_index.str.startswith("ENSG").any():
 expr_df.index = gene_index.str.split(".").str[0]

match_count = len(set(expr_df.index).intersection(set(annot_df.index)))
use_gene_name = match_count < 50

nc_keywords = set([
 "lncrna", "lnc_rna", "mirna", "mir", "snorna", "snrna",
 "antisense", "misc_rna", "rrna", "ncrna", "pseudogene",
 "scarna", "vault_rna", "srna"
])

if use_gene_name:
 annot_name = annot_df.dropna(subset=["gene_name"]).drop_duplicates("gene_name").set_index("gene_name")
 biotype_lower = annot_name["biotype"].astype(str).str.lower()
 nc_mask = biotype_lower.apply(lambda x: any(k in x for k in nc_keywords))
 nc_gene_names = set(annot_name[nc_mask].index)
 counts_ncrna = expr_df.loc[expr_df.index.intersection(nc_gene_names)].copy()
else:
 counts_ncrna = pipeline_processing.filter_noncoding_genes(expr_df, annot_df, allow_missing=True)

if counts_ncrna.empty:
 print(" ✗ No ncRNA genes detected after annotation mapping")
 sys.exit(1)

logcpm = pipeline_processing.log2_cpm(counts_ncrna)

results = pipeline_de.differential_expression(
 logcpm,
 metadata_df,
 group_col="disease_status",
 disease_label="ALS",
 control_label="Control",
 method="welch",
)

results = pipeline_de.adjust_pvalues(results, alpha=0.05)

# Merge annotations
results = results.reset_index()
if use_gene_name:
 annot_name = annot_df.dropna(subset=["gene_name"]).drop_duplicates("gene_name").set_index("gene_name")
 results["gene_name"] = results["gene_id"]
 results = results.merge(
 annot_name[["biotype"]],
 left_on="gene_name",
 right_index=True,
 how="left",
 )
else:
 results = results.merge(
 annot_df[["gene_name", "biotype"]],
 left_on="gene_id",
 right_index=True,
 how="left",
 )

# Ensure padj naming for consistency
results = results.rename(columns={"fdr": "padj"})

# Filter to ncRNA biotypes
results = pipeline_processing.filter_results_to_ncrna(results)

# Sort by padj then |log2FC|
results = results.sort_values(["padj", "pvalue", "log2FC"], ascending=[True, True, False])

# Save
out_file = RESULTS_DIR / "GSE124439_biomarkers.csv"
results.to_csv(out_file, index=False)

print(f"\n✓ ALS ncRNA biomarkers saved → {out_file}")
print(f"✓ Total ncRNA biomarkers (FDR < 0.05): {(results['padj'] < 0.05).sum()}")
print("=" * 80)
