#!/usr/bin/env python3
"""
 Strict Reanalysis: Apply rigorous thresholds
FDR < 0.01, |log2FC| > 1, comprehensive reporting
"""

import pandas as pd
import numpy as np
import os
from pathlib import Path

# ============================================================================
# 1. LOAD BIOMARKER FILES
# ============================================================================

print("=" * 80)
print(" STRICT BIOMARKER REANALYSIS")
print("=" * 80)

results_dir = Path("results/multi_dataset_analysis")
ad_biomarkers = pd.read_csv(results_dir / "GSE203206_biomarkers.csv")
als_biomarkers = pd.read_csv(results_dir / "GSE124439_biomarkers.csv")

als_metadata_path = Path("data/neurodegenerative_diseases/als/GSE124439/metadata.csv")
als_metadata = pd.read_csv(als_metadata_path) if als_metadata_path.exists() else None

print(f"\n✓ Loaded GSE203206 (AD): {len(ad_biomarkers)} biomarkers")
print(f"✓ Loaded GSE124439 (ALS): {len(als_biomarkers)} biomarkers")

# ============================================================================
# 2. APPLY STRICT THRESHOLDS
# ============================================================================

print("\n" + "=" * 80)
print("CRITERION 3: RIGOROUS STATISTICS - THRESHOLDS")
print("=" * 80)

# Original thresholds (current)
ad_fdr05 = ad_biomarkers[ad_biomarkers['padj'] < 0.05].sort_values('padj')
ad_fdr01 = ad_biomarkers[ad_biomarkers['padj'] < 0.01].sort_values('padj')
ad_fc1 = ad_biomarkers[np.abs(ad_biomarkers['log2FC']) > 1]
ad_strict = ad_biomarkers[(ad_biomarkers['padj'] < 0.01) & (np.abs(ad_biomarkers['log2FC']) > 1)].sort_values('padj')

als_fdr05 = als_biomarkers[als_biomarkers['padj'] < 0.05].sort_values('padj')
als_fdr01 = als_biomarkers[als_biomarkers['padj'] < 0.01].sort_values('padj')
als_fc1 = als_biomarkers[np.abs(als_biomarkers['log2FC']) > 1]
als_strict = als_biomarkers[(als_biomarkers['padj'] < 0.01) & (np.abs(als_biomarkers['log2FC']) > 1)].sort_values('padj')

print("\nALZHEIMER'S DISEASE (GSE203206, 47 samples)")
print("-" * 80)
print(f" FDR < 0.05, any |log2FC| : {len(ad_fdr05):,} biomarkers (current standard)")
print(f" FDR < 0.01, any |log2FC| : {len(ad_fdr01):,} biomarkers")
print(f" FDR < 0.05, |log2FC| > 1 : {len(ad_fc1[ad_fc1['padj'] < 0.05]):,} biomarkers")
print(f" FDR < 0.01, |log2FC| > 1 ★ : {len(ad_strict):,} biomarkers ← GRADE")

print("\nALS (GSE124439, motor/frontal cortex)")
print("-" * 80)
print(f" FDR < 0.05, any |log2FC| : {len(als_fdr05):,} biomarkers (current standard)")
print(f" FDR < 0.01, any |log2FC| : {len(als_fdr01):,} biomarkers")
print(f" FDR < 0.05, |log2FC| > 1 : {len(als_fc1[als_fc1['padj'] < 0.05]):,} biomarkers")
print(f" FDR < 0.01, |log2FC| > 1 ★ : {len(als_strict):,} biomarkers ← GRADE")

# ============================================================================
# 3. DESCRIPTIVE STATISTICS FOR TOP BIOMARKERS
# ============================================================================

print("\n" + "=" * 80)
print("TOP 10 AD BIOMARKERS (by FDR, thresholds)")
print("=" * 80)

if len(ad_strict) > 0:
 ad_top10 = ad_strict.head(10)
 print("\n{:<20} {:<15} {:<12} {:<12} {:<10} {:<12}".format(
 "Gene", "log2FC", "Control μ", "Disease μ", "FDR", "Type"
 ))
 print("-" * 80)
 for idx, row in ad_top10.iterrows():
 print("{:<20} {:<15.3f} {:<12.3f} {:<12.3f} {:<10.2e} {:<12}".format(
 row['gene_name'][:20] if pd.notna(row['gene_name']) else 'unknown',
 row['log2FC'],
 row['mean_control'],
 row['mean_disease'],
 row['padj'],
 row['biotype'][:12]
 ))
else:
 print("(No biomarkers meet FDR < 0.01, |log2FC| > 1 threshold)")
 print("\nTOP 10 with FDR < 0.05 instead:")
 ad_top10 = ad_fdr05.head(10)
 print("\n{:<20} {:<15} {:<12} {:<12} {:<10} {:<12}".format(
 "Gene", "log2FC", "Control μ", "Disease μ", "FDR", "Type"
 ))
 print("-" * 80)
 for idx, row in ad_top10.iterrows():
 print("{:<20} {:<15.3f} {:<12.3f} {:<12.3f} {:<10.2e} {:<12}".format(
 row['gene_name'][:20] if pd.notna(row['gene_name']) else 'unknown',
 row['log2FC'],
 row['mean_control'],
 row['mean_disease'],
 row['padj'],
 row['biotype'][:12]
 ))

print("\n" + "=" * 80)
print("TOP 10 ALS BIOMARKERS (by FDR, thresholds)")
print("=" * 80)

if len(als_strict) > 0:
 als_top10 = als_strict.head(10)
 print("\n{:<20} {:<15} {:<12} {:<12} {:<10} {:<12}".format(
 "Gene", "log2FC", "Control μ", "Disease μ", "FDR", "Type"
 ))
 print("-" * 80)
 for idx, row in als_top10.iterrows():
 print("{:<20} {:<15.3f} {:<12.3f} {:<12.3f} {:<10.2e} {:<12}".format(
 row['gene_name'][:20] if pd.notna(row['gene_name']) else 'unknown',
 row['log2FC'],
 row['mean_control'],
 row['mean_disease'],
 row['padj'],
 row['biotype'][:12]
 ))
else:
 print("(No biomarkers meet FDR < 0.01, |log2FC| > 1 threshold)")
 print("\nTOP 10 with FDR < 0.05 instead:")
 als_top10 = als_fdr05.head(10)
 print("\n{:<20} {:<15} {:<12} {:<12} {:<10} {:<12}".format(
 "Gene", "log2FC", "Control μ", "Disease μ", "FDR", "Type"
 ))
 print("-" * 80)
 for idx, row in als_top10.iterrows():
 print("{:<20} {:<15.3f} {:<12.3f} {:<12.3f} {:<10.2e} {:<12}".format(
 row['gene_name'][:20] if pd.notna(row['gene_name']) else 'unknown',
 row['log2FC'],
 row['mean_control'],
 row['mean_disease'],
 row['padj'],
 row['biotype'][:12]
 ))

# ============================================================================
# 4. CROSS-DISEASE ANALYSIS: IDENTIFY SHARED ncRNAs
# ============================================================================

print("\n" + "=" * 80)
print("CRITERION 5: CROSS-DISEASE ANALYSIS - DIRECTIONALITY CHECK")
print("=" * 80)

# Find shared ncRNAs by gene ID
ad_genes = set(ad_fdr05['gene_id'].values)
als_genes = set(als_fdr05['gene_id'].values)
shared_genes = ad_genes.intersection(als_genes)
use_gene_name = False

if len(shared_genes) == 0 and 'gene_name' in ad_fdr05.columns and 'gene_name' in als_fdr05.columns:
 ad_names = set(ad_fdr05['gene_name'].dropna().values)
 als_names = set(als_fdr05['gene_name'].dropna().values)
 shared_genes = ad_names.intersection(als_names)
 use_gene_name = True

print(f"\nAD biomarkers (FDR < 0.05): {len(ad_genes)}")
print(f"ALS biomarkers (FDR < 0.05): {len(als_genes)}")
print(f"Shared genes (both diseases): {len(shared_genes)}")

if len(shared_genes) > 0:
 # Create shared biomarker table
 if use_gene_name:
 ad_shared = ad_biomarkers[ad_biomarkers['gene_name'].isin(shared_genes)].copy()
 als_shared = als_biomarkers[als_biomarkers['gene_name'].isin(shared_genes)].copy()
 merged_shared = ad_shared.merge(
 als_shared[['gene_name', 'log2FC', 'padj', 'pvalue']],
 on='gene_name',
 suffixes=('_AD', '_ALS')
 )
 else:
 ad_shared = ad_biomarkers[ad_biomarkers['gene_id'].isin(shared_genes)].copy()
 als_shared = als_biomarkers[als_biomarkers['gene_id'].isin(shared_genes)].copy()
 merged_shared = ad_shared.merge(
 als_shared[['gene_id', 'log2FC', 'padj', 'pvalue']],
 on='gene_id',
 suffixes=('_AD', '_ALS')
 )
 
 # Check directionality
 same_direction = (
 (merged_shared['log2FC_AD'] > 0) & (merged_shared['log2FC_ALS'] > 0) |
 (merged_shared['log2FC_AD'] < 0) & (merged_shared['log2FC_ALS'] < 0)
 ).sum()
 
 print(f"\nShared ncRNAs with SAME directionality: {same_direction}")
 print(f"Shared ncRNAs with OPPOSITE directionality: {len(merged_shared) - same_direction}")
 
 if len(merged_shared) > 0:
 print("\nTop 10 SHARED ncRNAs:")
 print("\n{:<20} {:<12} {:<12} {:<12} {:<12}".format(
 "Gene", "log2FC_AD", "log2FC_ALS", "FDR_AD", "FDR_ALS"
 ))
 print("-" * 70)
 for idx, row in merged_shared.head(10).iterrows():
 gene_name = row['gene_name'][:20] if pd.notna(row['gene_name']) else 'unknown'
 print("{:<20} {:<12.3f} {:<12.3f} {:<12.2e} {:<12.2e}".format(
 gene_name,
 row['log2FC_AD'],
 row['log2FC_ALS'],
 row['padj_AD'],
 row['padj_ALS']
 ))
else:
 print("\n⚠️ No shared biomarkers found at FDR < 0.05 threshold")
 print(" This suggests disease-specific dysregulation patterns")

# ============================================================================
# 5. SAVE CURATED BIOMARKER TABLES FOR REPORT
# ============================================================================

print("\n" + "=" * 80)
print("SAVING -GRADE BIOMARKER TABLES")
print("=" * 80)

output_dir = results_dir / "isef_analysis"
output_dir.mkdir(exist_ok=True)

# AD biomarkers - all FDR < 0.05 for report
ad_biomarkers[['gene_id', 'gene_name', 'biotype', 'mean_disease', 'mean_control', 
 'log2FC', 'pvalue', 'padj']].to_csv(
 output_dir / "AD_biomarkers_all_FDR05.csv", index=False
)
print(f"✓ {len(ad_fdr05)} AD biomarkers (FDR < 0.05) → AD_biomarkers_all_FDR05.csv")

# AD biomarkers - strict for narrative
if len(ad_strict) > 0:
 ad_strict[['gene_id', 'gene_name', 'biotype', 'mean_disease', 'mean_control', 
 'log2FC', 'pvalue', 'padj']].to_csv(
 output_dir / "AD_biomarkers_strict_FDR01_FC1.csv", index=False
 )
 print(f"✓ {len(ad_strict)} AD biomarkers (FDR < 0.01, |log2FC| > 1) → AD_biomarkers_strict_FDR01_FC1.csv")
else:
 print(f"⚠️ 0 AD biomarkers meet strict threshold (will use FDR < 0.05)")

# ALS biomarkers - all
als_biomarkers[['gene_id', 'gene_name', 'biotype', 'mean_disease', 'mean_control', 
 'log2FC', 'pvalue', 'padj']].to_csv(
 output_dir / "ALS_biomarkers_all_FDR05.csv", index=False
)
print(f"✓ {len(als_fdr05)} ALS biomarkers (FDR < 0.05) → ALS_biomarkers_all_FDR05.csv")

if len(als_strict) > 0:
 als_strict[['gene_id', 'gene_name', 'biotype', 'mean_disease', 'mean_control', 
 'log2FC', 'pvalue', 'padj']].to_csv(
 output_dir / "ALS_biomarkers_strict_FDR01_FC1.csv", index=False
 )
 print(f"✓ {len(als_strict)} ALS biomarkers (FDR < 0.01, |log2FC| > 1) → ALS_biomarkers_strict_FDR01_FC1.csv")

# Shared biomarkers
if len(shared_genes) > 0:
 merged_shared.to_csv(
 output_dir / "Shared_ncRNAs_AD_ALS.csv", index=False
 )
 print(f"✓ {len(merged_shared)} shared ncRNAs → Shared_ncRNAs_AD_ALS.csv")

# Top 10 tables for report
ad_fdr05.head(10)[['gene_id', 'gene_name', 'biotype', 'mean_disease', 'mean_control', 
 'log2FC', 'padj']].to_csv(
 output_dir / "AD_top10_for_report.csv", index=False
)
print(f"✓ Top 10 AD biomarkers → AD_top10_for_report.csv")

als_fdr05.head(10)[['gene_id', 'gene_name', 'biotype', 'mean_disease', 'mean_control', 
 'log2FC', 'padj']].to_csv(
 output_dir / "ALS_top10_for_report.csv", index=False
)
print(f"✓ Top 10 ALS biomarkers → ALS_top10_for_report.csv")

# ============================================================================
# 6. SUMMARY FOR DEFENSE PREP
# ============================================================================

print("\n" + "=" * 80)
print("DEFENSE TALKING POINTS - KEY NUMBERS")
print("=" * 80)

als_cases = int((als_metadata['disease_status'] == 'ALS').sum()) if als_metadata is not None else 0
als_controls = int((als_metadata['disease_status'] == 'Control').sum()) if als_metadata is not None else 0
als_total = als_cases + als_controls

if len(ad_strict) > 0:
 top_ad_row = ad_strict.iloc[0]
else:
 top_ad_row = ad_fdr05.iloc[0]

if len(als_strict) > 0:
 top_als_row = als_strict.iloc[0]
else:
 top_als_row = als_fdr05.iloc[0]

top_ad_gene = top_ad_row['gene_name'] if pd.notna(top_ad_row.get('gene_name', None)) else top_ad_row['gene_id']
top_als_gene = top_als_row['gene_name'] if pd.notna(top_als_row.get('gene_name', None)) else top_als_row['gene_id']

print(f"""
1. DATA FOUNDATION:
 • Alzheimer's: 47 samples (38 disease, 9 control)
 • ALS: {als_total} samples ({als_cases} ALS, {als_controls} control)
 • Total: {47 + als_total} human samples
 • Platform: Bulk RNA-seq (raw counts)

2. STATISTICAL RESULTS:
 • AD biomarkers (FDR < 0.05): {len(ad_fdr05):,}
 • ALS biomarkers (FDR < 0.05): {len(als_fdr05):,}
 • AD biomarkers ( strict: FDR < 0.01, |log2FC| > 1): {len(ad_strict):,}
 • ALS biomarkers ( strict: FDR < 0.01, |log2FC| > 1): {len(als_strict):,}
 • Shared ncRNAs (both diseases): {len(shared_genes)}

3. EFFECT SIZES:
 • Top AD biomarker: {top_ad_gene} (log2FC={top_ad_row['log2FC']:.2f})
 • Top ALS biomarker: {top_als_gene} (log2FC={top_als_row['log2FC']:.2f})

4. CROSS-DISEASE INSIGHT:
 • Limited shared biomarkers suggest disease-specific patterns
 • Tissue-specific differences explain lack of full overlap
 • ncRNA regulation may be disease-specific

5. NEXT STEPS (VALIDATION):
 • Pathway enrichment → identify shared mechanisms
 • Literature validation → verify prior AD/ALS association
 • Blood biomarker testing → clinical application
""")

print("=" * 80)
print(" STRICT ANALYSIS COMPLETE")
print("=" * 80)
