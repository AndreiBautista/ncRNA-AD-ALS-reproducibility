#!/usr/bin/env python3
"""
GEO Dataset Search Helper
Print recommended search terms and shows what to look for
"""

print("=" * 80)
print("CROSS-DISEASE ncRNA BIOMARKER DISCOVERY")
print("Dataset Search & Collection Guide")
print("=" * 80)

search_queries = {
 "Parkinson's Disease": {
 "primary_search": '("Parkinson disease" OR "Parkinson\'s disease" OR "PD" OR "idiopathic parkinsonism") AND ("RNA-seq" OR "RNA sequencing") AND ("brain" OR "midbrain" OR "substantia nigra") AND ("homo sapiens") NOT ("single cell" OR "scRNA")',
 "alternative_tissue": '("Parkinson disease") AND ("RNA-seq") AND ("blood" OR "lymphocyte" OR "peripheral") AND ("homo sapiens")',
 "what_to_look_for": [
 "✓ Study designs: postmortem brain OR patient-derived cells",
 "✓ Tissue: Substantia nigra, striatum, prefrontal cortex, midbrain",
 "✓ Sample sizes: 30+ patients, 15+ controls recommended",
 "✓ Data format: raw counts (counts.csv) or TPM matrix",
 "✓ Metadata: clear disease/control labels"
 ],
 "red_flags": [
 "✗ Single-cell sequencing (scRNA-seq) - too complex",
 "✗ Cell culture only - not representative",
 "✗ Underpowered (<15 per group) - low statistical power",
 "✗ Missing raw counts - can't use DESeq2"
 ]
 },
 "ALS": {
 "primary_search": '(("amyotrophic lateral sclerosis" OR "ALS" OR "Motor Neuron Disease" OR "MND") AND ("RNA-seq" OR "RNA sequencing") AND ("motor neuron" OR "motor cortex" OR "spinal cord" OR "brain") AND ("homo sapiens") NOT ("single cell" OR "scRNA"))',
 "alternative_tissue": '("ALS" OR "amyotrophic lateral sclerosis") AND ("RNA-seq") AND ("fibroblast" OR "iPSC") AND ("homo sapiens")',
 "what_to_look_for": [
 "✓ Study designs: postmortem tissue OR patient-derived iPSCs",
 "✓ Tissue: Motor cortex, spinal cord, motor neurons",
 "✓ Sample sizes: 20+ ALS, 10+ controls minimum",
 "✓ Data format: raw counts (HTSeq output, STAR counts)",
 "✓ Metadata: clear ALS vs control distinction"
 ],
 "red_flags": [
 "✗ Only familial ALS (fALS) without sporadic ALS (sALS)",
 "✗ Microscopy-based only - no RNA data",
 "✗ Small sample size (<15 per group)",
 "✗ No raw counts available"
 ]
 }
}

for disease, info in search_queries.items():
 print(f"\n{'='*80}")
 print(f"{disease.upper()}")
 print(f"{'='*80}")
 
 print(f"\n📍 PRIMARY SEARCH TERM (paste into GEO):")
 print(f" {info['primary_search']}\n")
 
 print(f"📍 ALTERNATIVE SEARCH (if primary returns <5 studies):")
 print(f" {info['alternative_tissue']}\n")
 
 print("✓ WHAT TO LOOK FOR:")
 for item in info['what_to_look_for']:
 print(f" {item}")
 
 print("\n✗ RED FLAGS (avoid these):")
 for flag in info['red_flags']:
 print(f" {flag}")

print(f"\n{'='*80}")
print("HOW TO ACCESS GEO DATASETS")
print(f"{'='*80}")

print("""
1. Go to: https://www.ncbi.nlm.nih.gov/geo/
2. Click "Advanced Search" 
3. Paste the search term (or modify it)
4. Filter by:
 - Organism: Homo sapiens
 - Study type: Expression profiling by high throughput sequencing
 - Date: 2015 - 2024 (recent, better quality)

5. For each promising result:
 - Click on the GEO Series (GSE####)
 - Read the abstract & manuscript
 - Download the supplementary files:
 - counts.csv / counts.txt / STAR counts
 - series_matrix.txt OR sample metadata table
 - Extract into: data/neurodegenerative_diseases/[disease]/GSE####/

EXPECTED OUTPUTS:
 - counts.tsv (genes × samples, raw expression counts)
 - metadata.csv (sample_id, disease_status, tissue, study)
""")

print(f"\n{'='*80}")
print("TARGET SUMMARY")
print(f"{'='*80}")
print(f"""
ALZHEIMER'S DISEASE (AD):
 Current: GSE203206 (47 samples)
 Goal: Add 1-2 datasets to reach 150-200 samples total
 Status: ✓ READY

PARKINSON'S DISEASE (PD):
 Current: NEED TO FIND
 Goal: 200+ samples (preferably 3+ studies)
 Priority: HIGH

ALS:
 Current: NEED TO FIND
 Goal: 150-200 samples (preferably 2-3 studies)
 Priority: HIGH

NEXT STEP:
 → Search GEO using terms above
 → Collect GSE accession numbers (e.g., GSE111932)
 → Download files
 → Report back with accessions
""")

print(f"\n{'='*80}")
print("QUICK REFERENCE: RECENT HIGH-QUALITY STUDIES")
print(f"{'='*80}")
print("""
These are EXAMPLES - you should verify they're available:

Parkinson's:
 - GSE111932: "Parkinson's disease brain RNA-seq" (likely candidate)
 - GSE54282: "miRNA expression in PD" (check if includes protein coding)
 - GSE40967: "Gene expression in Parkinson's brain" (postmortem)

ALS:
 - GSE153960: "Motor cortex transcriptomics in ALS" (likely candidate)
 - GSE112119: "Spinal cord RNA-seq in ALS" (likely candidate)
 - GSE27894: "postmortem ALS spinal cord" (older but valid)

⚠️ VERIFY these exist before using - GEO database is constantly updated
""")
