#!/usr/bin/env python3
"""Organize results folders into clean data/ and figures/ structure."""
import argparse
from pathlib import Path
import shutil


FIGURE_PATTERNS = (
 "*_volcano.png",
 "*_heatmap.png",
 "*_top_genes_heatmap.png",
 "biomarker_heatmap.png",
 "biomarker_overlap.png",
 "conserved_upset.png",
 "ncRNA_significant_counts.png",
)

DATA_PATTERNS = (
 "*_differential_results.csv",
 "local_differential_results.csv",
)

ROOT_KEEP = {
 "top_candidates.csv",
 "biomarker_report.txt",
 "PRESENTATION_SUMMARY.txt",
}


def _log(log_path: Path, message: str) -> None:
 log_path.parent.mkdir(parents=True, exist_ok=True)
 with open(log_path, "a", encoding="utf-8") as handle:
 handle.write(message.rstrip() + "\n")


def _move_file(src: Path, dest_dir: Path, log_path: Path) -> None:
 dest_dir.mkdir(parents=True, exist_ok=True)
 dest = dest_dir / src.name
 if dest.exists():
 _log(log_path, f"SKIP exists: {dest}")
 return
 shutil.move(str(src), str(dest))
 _log(log_path, f"MOVE {src} -> {dest}")


def _organize_dataset_dir(dataset_dir: Path, log_path: Path) -> None:
 data_dir = dataset_dir / "data"
 figures_dir = dataset_dir / "figures"
 data_dir.mkdir(parents=True, exist_ok=True)
 figures_dir.mkdir(parents=True, exist_ok=True)

 for pattern in FIGURE_PATTERNS:
 for src in dataset_dir.glob(pattern):
 _move_file(src, figures_dir, log_path)

 for pattern in DATA_PATTERNS:
 for src in dataset_dir.glob(pattern):
 _move_file(src, data_dir, log_path)


def organize_root(root: Path) -> None:
 log_path = root / "organize_results.log"
 _log(log_path, f"Organizing root: {root}")

 figures_dir = root / "figures"
 data_dir = root / "data"
 figures_dir.mkdir(parents=True, exist_ok=True)
 data_dir.mkdir(parents=True, exist_ok=True)

 for pattern in FIGURE_PATTERNS:
 for src in root.glob(pattern):
 _move_file(src, figures_dir, log_path)

 for pattern in DATA_PATTERNS:
 for src in root.glob(pattern):
 if src.name in ROOT_KEEP:
 continue
 _move_file(src, data_dir, log_path)

 per_dataset_dir = root / "per_dataset"
 if per_dataset_dir.exists():
 for dataset_dir in per_dataset_dir.iterdir():
 if dataset_dir.is_dir():
 _organize_dataset_dir(dataset_dir, log_path)

 for child in root.iterdir():
 if child.is_dir() and child.name != "per_dataset":
 nested = child / "per_dataset"
 if nested.exists():
 for dataset_dir in nested.iterdir():
 if dataset_dir.is_dir():
 _organize_dataset_dir(dataset_dir, log_path)


def main() -> None:
 parser = argparse.ArgumentParser(
 description="Organize results folders into data/ and figures/ structure"
 )
 parser.add_argument(
 "--root",
 default="results",
 help="Root results folder to organize (default: results)",
 )
 args = parser.parse_args()

 root = Path(args.root).expanduser().resolve()
 if not root.exists():
 raise FileNotFoundError(f"Root not found: {root}")

 organize_root(root)
 print(f"Organized: {root}")
 print(f"Log: {root / 'organize_results.log'}")


if __name__ == "__main__":
 main()
