#!/usr/bin/env python3
"""Build metadata files for GSE153960 using GEO sample characteristics."""

from pathlib import Path
import logging
import re

import pandas as pd
import GEOparse


def normalize_sample_id(sample_id: str) -> str:
 return sample_id.strip()


def match_sample_id(sample_id: str, lookup: dict) -> str:
 if sample_id in lookup:
 return sample_id
 # Try trimming suffix like "-2"
 trimmed = re.sub(r"-\d+$", "", sample_id)
 if trimmed in lookup:
 return trimmed
 return ""


def classify_group(group: str) -> str:
 if not group:
 return "Unknown"
 group_lower = group.lower()
 if "non-neurological control" in group_lower:
 return "Control"
 if "als spectrum mnd" in group_lower and "other neurological" not in group_lower:
 return "Disease"
 if "als" in group_lower and "other neurological" not in group_lower:
 return "Disease"
 return "Other"


def main():
 logging.getLogger("GEOparse").setLevel(logging.WARNING)

 base_dir = Path("data/neurodegenerative_diseases/als/GSE153960")
 counts_path = base_dir / "counts.txt"
 if not counts_path.exists():
 raise FileNotFoundError(counts_path)

 counts_df = pd.read_csv(counts_path, sep="\t", nrows=0)
 sample_ids = [normalize_sample_id(s) for s in counts_df.columns[1:]]

 geo_dir = base_dir / "geo"
 geo_dir.mkdir(parents=True, exist_ok=True)
 gse = GEOparse.get_GEO("GSE153960", destdir=str(geo_dir), annotate_gpl=False)

 sample_lookup = {}
 for gsm_name, gsm in gse.gsms.items():
 chars = gsm.metadata.get("characteristics_ch1", [])
 group = None
 sample_alt = None
 for c in chars:
 c_lower = c.lower()
 if c_lower.startswith("group:"):
 group = c.split(":", 1)[1].strip()
 if c_lower.startswith("sample id alt:"):
 sample_alt = c.split(":", 1)[1].strip()
 if sample_alt:
 sample_lookup[sample_alt] = group

 rows = []
 missing = 0
 for sample_id in sample_ids:
 key = match_sample_id(sample_id, sample_lookup)
 group = sample_lookup.get(key) if key else None
 if not group:
 missing += 1
 rows.append({
 "sample_id": sample_id,
 "group": group if group else "Unknown",
 "disease_status": classify_group(group),
 "tissue_type": "brain_multiple_regions",
 "study_id": "GSE153960",
 })

 meta_full = pd.DataFrame(rows)
 meta_full_path = base_dir / "metadata_full.csv"
 meta_full.to_csv(meta_full_path, index=False)

 meta_filtered = meta_full[meta_full["disease_status"].isin(["Disease", "Control"])].copy()
 meta_filtered_path = base_dir / "metadata_disease.csv"
 meta_filtered.to_csv(meta_filtered_path, index=False)

 print("Total samples in counts:", len(sample_ids))
 print("Missing group matches:", missing)
 print("Disease/Control counts:")
 print(meta_filtered["disease_status"].value_counts())
 print("Saved:", meta_full_path)
 print("Saved:", meta_filtered_path)


if __name__ == "__main__":
 main()
