#!/usr/bin/env python3
"""
Path A Implementation: Download proper gene annotations and set up multi-disease/multi-species structure.

This script:
1. Downloads Ensembl GTF files (or uses BiomaRt)
2. Extracts gene_id, gene_name, and biotype information
3. Creates proper annotation CSVs for each species
4. Sets up directory structure for 3 diseases × 3 species

Run with: python setup_path_a.py
"""

import os
import pandas as pd
import urllib.request
import gzip
import shutil
from pathlib import Path

def download_ensembl_gtf(species_info, output_dir='data/annotations'):
 """
 Download Ensembl GTF files and extract gene annotation.
 
 species_info: dict with {'name': 'hsapiens', 'url': '...', 'filename': '...'}
 """
 os.makedirs(output_dir, exist_ok=True)
 
 print(f"\n{'='*70}")
 print(f"Downloading annotation for: {species_info['display_name']}")
 print(f"{'='*70}")
 
 # Download GTF file
 url = species_info['url']
 gtf_filename = os.path.join(output_dir, species_info['filename'])
 
 if os.path.exists(gtf_filename):
 print(f"✓ {gtf_filename} already exists, skipping download")
 else:
 print(f"Downloading: {url}")
 try:
 urllib.request.urlretrieve(url, gtf_filename + '.gz')
 print(f"✓ Downloaded {gtf_filename}.gz")
 
 # Decompress
 print(f"Decompressing...")
 with gzip.open(gtf_filename + '.gz', 'rb') as f_in:
 with open(gtf_filename, 'wb') as f_out:
 shutil.copyfileobj(f_in, f_out)
 os.remove(gtf_filename + '.gz')
 print(f"✓ Decompressed to {gtf_filename}")
 except Exception as e:
 print(f"✗ Download failed: {e}")
 print(f" Alternative: Download manually from https://ftp.ensembl.org/pub/")
 return None
 
 # Parse GTF file
 print(f"Parsing GTF file...")
 genes = []
 gene_counter = 0
 
 with open(gtf_filename, 'r') as f:
 for line in f:
 if line.startswith('#'):
 continue
 
 fields = line.rstrip('\n').split('\t')
 if len(fields) < 9:
 continue
 
 # Only process gene features
 if fields[2] != 'gene':
 continue
 
 # Parse attributes (9th column)
 attrs_str = fields[8]
 attrs = {}
 
 for attr in attrs_str.split(';'):
 attr = attr.strip()
 if '=' in attr:
 key, val = attr.split('=', 1)
 attrs[key.strip()] = val.strip('"')
 
 # Extract gene information
 genes.append({
 'gene_id': attrs.get('gene_id', ''),
 'gene_name': attrs.get('gene_name', ''),
 'biotype': attrs.get('gene_biotype', 'unknown'),
 'chromosome': fields[0],
 'start': int(fields[3]),
 'end': int(fields[4])
 })
 
 gene_counter += 1
 if gene_counter % 10000 == 0:
 print(f" Parsed {gene_counter} genes...")
 
 print(f"✓ Total genes parsed: {gene_counter}")
 
 # Create DataFrame
 df = pd.DataFrame(genes)
 
 # Save as CSV
 csv_filename = gtf_filename.replace('.gtf', '_annotation.csv')
 df.to_csv(csv_filename, index=False)
 print(f"✓ Saved to: {csv_filename}")
 
 # Print summary
 print(f"\nAnnotation Summary:")
 print(f" Total genes: {len(df)}")
 print(f" ncRNA types found:")
 nc_keywords = ['lncrna', 'mirna', 'snorna', 'snrna', 'antisense', 'circrna', 'picrna']
 for keyword in nc_keywords:
 count = df['biotype'].str.lower().str.contains(keyword, na=False).sum()
 if count > 0:
 print(f" - {keyword.upper()}: {count}")
 
 return csv_filename


def setup_directory_structure():
 """Create directory structure for multi-disease, multi-species analysis."""
 
 diseases = ['alzheimers', 'parkinsons', 'als']
 species = ['human', 'mouse', 'zebrafish']
 
 base_dir = 'results'
 
 print(f"\n{'='*70}")
 print(f"Setting up directory structure")
 print(f"{'='*70}")
 
 for disease in diseases:
 for sp in species:
 path = os.path.join(base_dir, disease, sp)
 os.makedirs(path, exist_ok=True)
 os.makedirs(os.path.join(path, 'figures'), exist_ok=True)
 print(f"✓ Created: {path}")
 
 # Create cross-disease comparison directory
 cross_dir = os.path.join(base_dir, 'cross_disease_comparison')
 os.makedirs(cross_dir, exist_ok=True)
 print(f"✓ Created: {cross_dir}")


def create_config_file():
 """Create YAML configuration file for multi-disease analysis."""
 
 config_content = """# Multi-Disease, Multi-Species ncRNA Biomarker Discovery
# Path A: Annotation-based ncRNA identification

analysis:
 type: "path_a_ncrnabiomarkers"
 description: "Strict ncRNA biomarker discovery across 3 diseases × 3 species"
 
 strict_filters:
 fdr_threshold: 0.01 # standard: very stringent
 log2fc_threshold: 1.5 # standard: large effect size (3-fold)
 min_species: 1 # Start with any species, will validate across
 
 ncrna_types:
 - lncRNA # Long non-coding RNA
 - lincRNA # Long intergenic ncRNA
 - miRNA # microRNA
 - snoRNA # Small nucleolar RNA
 - snRNA # Small nuclear RNA
 - circRNA # Circular RNA
 - piRNA # PIWI-interacting RNA
 - antisense # Antisense RNA

diseases:
 
 # ========== ALZHEIMER'S DISEASE ==========
 alzheimers:
 description: "Alzheimer's disease - neuroinflammation & amyloid/tau pathology"
 
 human:
 dataset_name: "GSE203206_Subramaniam"
 source: "Synapse / publicly available"
 counts_file: "GSE203206_Subramaniam.ADRC_brain.counts.tsv"
 metadata_file: "GSE203206_metadata.csv"
 annotation_file: "data/annotations/annotation_human.csv"
 group_column: "condition"
 disease_label: "Alzheimer"
 control_label: "Control"
 notes: "n=624 samples, 24,448 genes"
 
 mouse:
 dataset_name: "APP/PS1 or 5xFAD transgenic model"
 source: "GEO (search: APP/PS1 RNA-seq)"
 counts_file: "data/alzheimers/mouse/counts.csv"
 metadata_file: "data/alzheimers/mouse/metadata.csv"
 annotation_file: "data/annotations/annotation_mouse.csv"
 group_column: "genotype"
 disease_label: "APP_PS1" # or 5xFAD
 control_label: "WT"
 notes: "TBD - search GEO for high-quality dataset"
 
 zebrafish:
 dataset_name: "Tau transgenic or amyloid model"
 source: "GEO (search: zebrafish tau OR amyloid RNA-seq)"
 counts_file: "data/alzheimers/zebrafish/counts.csv"
 metadata_file: "data/alzheimers/zebrafish/metadata.csv"
 annotation_file: "data/annotations/annotation_zebrafish.csv"
 group_column: "treatment"
 disease_label: "tau"
 control_label: "control"
 notes: "TBD - may need to use morpholino knockdown model"

 # ========== PARKINSON'S DISEASE ==========
 parkinsons:
 description: "Parkinson's disease - dopaminergic neurodegeneration"
 
 human:
 dataset_name: "Human substantia nigra PD vs. control"
 source: "GEO (GSE40958, GSE20164, or similar)"
 counts_file: "data/parkinsons/human/counts.csv"
 metadata_file: "data/parkinsons/human/metadata.csv"
 annotation_file: "data/annotations/annotation_human.csv"
 group_column: "condition"
 disease_label: "Parkinson"
 control_label: "Control"
 notes: "TBD - search GEO for substantia nigra bulk RNA-seq"
 
 mouse:
 dataset_name: "MPTP-induced Parkinsonism model"
 source: "GEO (search: MPTP mouse dopamine RNA-seq)"
 counts_file: "data/parkinsons/mouse/counts.csv"
 metadata_file: "data/parkinsons/mouse/metadata.csv"
 annotation_file: "data/annotations/annotation_mouse.csv"
 group_column: "treatment"
 disease_label: "MPTP"
 control_label: "saline"
 notes: "TBD"
 
 zebrafish:
 dataset_name: "Rotenone or pesticide toxicity model"
 source: "GEO (search: zebrafish dopamine rotenone RNA-seq)"
 counts_file: "data/parkinsons/zebrafish/counts.csv"
 metadata_file: "data/parkinsons/zebrafish/metadata.csv"
 annotation_file: "data/annotations/annotation_zebrafish.csv"
 group_column: "treatment"
 disease_label: "rotenone"
 control_label: "control"
 notes: "TBD - alternative: 6-OHDA model"

 # ========== AMYOTROPHIC LATERAL SCLEROSIS ==========
 als:
 description: "ALS - motor neuron selective degeneration"
 
 human:
 dataset_name: "Human motor neurons or spinal cord ALS vs. control"
 source: "GEO / Synapse (search: ALS RNA-seq spinal cord)"
 counts_file: "data/als/human/counts.csv"
 metadata_file: "data/als/human/metadata.csv"
 annotation_file: "data/annotations/annotation_human.csv"
 group_column: "condition"
 disease_label: "ALS"
 control_label: "Control"
 notes: "TBD - GSE124020, GSE112356, or similar"
 
 mouse:
 dataset_name: "SOD1-G93A ALS transgenic model"
 source: "GEO (search: SOD1 ALS mouse RNA-seq)"
 counts_file: "data/als/mouse/counts.csv"
 metadata_file: "data/als/mouse/metadata.csv"
 annotation_file: "data/annotations/annotation_mouse.csv"
 group_column: "genotype"
 disease_label: "SOD1_G93A"
 control_label: "WT"
 notes: "TBD"
 
 zebrafish:
 dataset_name: "SMN knockdown or SMN knockdown model"
 source: "GEO (search: zebrafish SMN ALS RNA-seq)"
 counts_file: "data/als/zebrafish/counts.csv"
 metadata_file: "data/als/zebrafish/metadata.csv"
 annotation_file: "data/annotations/annotation_zebrafish.csv"
 group_column: "morpholino"
 disease_label: "SMN_knockdown"
 control_label: "control"
 notes: "TBD"

# Output configuration
output:
 base_dir: "results"
 structure: "disease/species"
 naming_convention: "{disease}_{species}_top_ncrnas.csv"
 
# Figures to generate
figures:
 - volcano_plot # Significance vs. effect size
 - bar_plot_top_genes # Top up/down regulated ncRNAs
 - heatmap # Expression across samples
 - pca # Sample clustering
 - cross_species_heatmap # Conserved ncRNAs across species
 - overlap_plot # ncRNA presence across species/diseases
"""
 
 with open('config_multi_disease.yaml', 'w') as f:
 f.write(config_content)
 
 print(f"\n{'='*70}")
 print(f"Created configuration file: config_multi_disease.yaml")
 print(f"{'='*70}")


def create_data_download_guide():
 """Create a guide for finding and downloading datasets."""
 
 guide_content = """# Data Download Guide for Multi-Disease ncRNA Analysis

## What You Need for Each Disease/Species Combination

For EACH of the 9 datasets (3 diseases × 3 species), you need:

1. **counts.csv** - Expression matrix (genes × samples)
 - Rows: gene IDs (Ensembl IDs like ENSG00000123456)
 - Columns: sample names
 - Values: raw counts or normalized values

2. **metadata.csv** - Sample information
 - Rows: sample names (must match columns in counts)
 - Columns: condition/group, age, sex, brain region, etc.
 - Must have a column (group_col) that says "disease_label" vs "control_label"

3. **annotation_[species].csv** - Gene information
 - Already downloaded in setup_path_a.py ✓
 - Contains: gene_id, gene_name, biotype

---

## GEO Dataset Search Strategy

### For HUMAN datasets, search GEO (www.ncbi.nlm.nih.gov/geo) with:

**Alzheimer's:**
- "Alzheimer's disease brain RNA-seq" 
- "AD substantia nigra tissue RNA-seq"
- "dementia hippocampus transcriptome"
- Good datasets: GSE203206 ✓ (already have), GSE122063, GSE33000

**Parkinson's:**
- "Parkinson's disease substantia nigra RNA-seq"
- "PD dopaminergic neurons transcriptome"
- "neurodegeneration parkinsonism RNA-seq"
- Good datasets: GSE20164, GSE40958, GSE111031

**ALS:**
- "ALS spinal cord RNA-seq"
- "motor neuron degeneration transcriptome"
- "SOD1 ALS patient tissue RNA-seq"
- Good datasets: GSE112356, GSE124020, GSE137810

### For MOUSE model datasets, search with:

**Alzheimer's:**
- "APP/PS1 mouse brain RNA-seq"
- "5xFAD transgenic model transcriptome"
- Result format: Usually GSMxxxxx entries need to be combined
- Extraction: Use `geo_integration.py` in the pipeline

**Parkinson's:**
- "MPTP mouse brain RNA-seq"
- "dopamine neuron degeneration transcriptome"

**ALS:**
- "SOD1-G93A mouse spinal cord RNA-seq"
- "motor neuron transgenic disease model"

### For ZEBRAFISH datasets, search:

- "zebrafish disease model RNA-seq" + {disease}
- "danio rerio neurodegeneration transcriptome"
- May need BioProject (www.ncbi.nlm.nih.gov/bioproject)
- Filter by: RNA-seq, whole organism or neural tissue

---

## How to Download from GEO

### Method 1: Series Matrix File (EASIEST)
1. Go to GEO, find your GSE number (e.g., GSE203206)
2. Scroll to "Series Matrix File(s)"
3. Download: Series Matrix (compressed)
4. Use `geo_integration.py` in our pipeline to parse

### Method 2: GEO Query (Python)
```python
from GEOparse import get_gse

gse = get_gse("GSE203206", download=True)
# Extracts counts, metadata, sample info automatically
```

### Method 3: Supplementary Files
1. Some studies provide raw counts in supplementary files
2. Download directly and organize as counts.csv + metadata.csv

---

## File Organization Example

After downloading, organize like this:

```
data/
├── annotations/
│ ├── annotation_human.csv ← Downloaded by setup_path_a.py ✓
│ ├── annotation_mouse.csv ← Downloaded by setup_path_a.py ✓
│ └── annotation_zebrafish.csv ← Downloaded by setup_path_a.py ✓
│
├── alzheimers/
│ ├── human/
│ │ ├── counts.csv ← GSE203206 data ✓ (already have)
│ │ └── metadata.csv ← GSE203206 metadata ✓ (already have)
│ ├── mouse/
│ │ ├── counts.csv ← Search GEO, download, rename
│ │ └── metadata.csv ← Extract from GEO metadata
│ └── zebrafish/
│ ├── counts.csv
│ └── metadata.csv
│
├── parkinsons/
│ ├── human/
│ │ ├── counts.csv
│ │ └── metadata.csv
│ ├── mouse/
│ │ ├── counts.csv
│ │ └── metadata.csv
│ └── zebrafish/
│ ├── counts.csv
│ └── metadata.csv
│
└── als/
 ├── human/
 │ ├── counts.csv
 │ └── metadata.csv
 ├── mouse/
 │ ├── counts.csv
 │ └── metadata.csv
 └── zebrafish/
 ├── counts.csv
 └── metadata.csv
```

---

## Quick Dataset Recommendations (Starting Point)

**START WITH THESE (easiest to work with):**
1. ✓ Alzheimer's Human: GSE203206 (already downloaded)
2. Parkinson's Human: GSE40958 (well-curated, large)
3. ALS Human: GSE112356 (motor neurons, nice metadata)

**Then add ONE from each model organism:**
4. Alzheimer's Mouse: Search "APP/PS1 RNA-seq" on GEO
5. Parkinson's Mouse: Search "MPTP mouse RNA-seq" on GEO
6. ALS Mouse: Search "SOD1-G93A RNA-seq" on GEO

**Zebrafish can wait** (fewer datasets available, but add for maximum impact)

---

## Pro Tips for Data Wrangling

- Some GEO datasets have weird formats → Use `pipeline/io.py::safe_read_table()` 
- Check metadata column names vary → Use `group_col` parameter in config
- Different gene ID systems (ENSG vs. gene names) → Annotation must match!
- Test with 1-2 datasets first, then scale to 9

"""
 
 with open('DATA_DOWNLOAD_GUIDE.md', 'w') as f:
 f.write(guide_content)
 
 print("\n✓ Created: DATA_DOWNLOAD_GUIDE.md")
 print(" (See this file for GEO search strategy and data organization)")


def main():
 """Run full setup for Path A."""
 
 print("\n" + "="*70)
 print(" PATH A IMPLEMENTATION SETUP")
 print(" Proper Annotation + Multi-Disease/Multi-Species Analysis")
 print("="*70)
 
 # Ensembl species information (Release 104, current as of Feb 2025)
 species_list = [
 {
 'name': 'hsapiens',
 'display_name': 'Human (Homo sapiens, GRCh38)',
 'url': 'https://ftp.ensembl.org/pub/release-110/gtf/homo_sapiens/Homo_sapiens.GRCh38.110.gtf.gz',
 'filename': 'Homo_sapiens.GRCh38.110.gtf'
 },
 {
 'name': 'mmusculus',
 'display_name': 'Mouse (Mus musculus, GRCm39)',
 'url': 'https://ftp.ensembl.org/pub/release-110/gtf/mus_musculus/Mus_musculus.GRCm39.110.gtf.gz',
 'filename': 'Mus_musculus.GRCm39.110.gtf'
 },
 {
 'name': 'drerio',
 'display_name': 'Zebrafish (Danio rerio, GRCz11)',
 'url': 'https://ftp.ensembl.org/pub/release-110/gtf/danio_rerio/Danio_rerio.GRCz11.110.gtf.gz',
 'filename': 'Danio_rerio.GRCz11.110.gtf'
 }
 ]
 
 # Step 1: Download annotations
 print("\n[Step 1/4] Downloading gene annotations from Ensembl...")
 for species in species_list:
 download_ensembl_gtf(species)
 
 # Step 2: Set up directory structure
 print("\n[Step 2/4] Setting up directory structure...")
 setup_directory_structure()
 
 # Step 3: Create configuration file
 print("\n[Step 3/4] Creating configuration file...")
 create_config_file()
 
 # Step 4: Create data download guide
 print("\n[Step 4/4] Creating data download guide...")
 create_data_download_guide()
 
 # Summary
 print("\n" + "="*70)
 print(" SETUP COMPLETE!")
 print("="*70)
 print("""
Next steps:

1. View the comprehensive guide:
 cat PATH_A_IMPLEMENTATION_GUIDE.md

2. Review available datasets:
 cat DATA_DOWNLOAD_GUIDE.md

3. Download human Parkinson's and ALS data from GEO:
 - Parkinson's: GSE40958 or GSE20164
 - ALS: GSE112356 or GSE124020

4. Organize data into:
 data/parkinsons/human/counts.csv
 data/parkinsons/human/metadata.csv
 data/als/human/counts.csv
 data/als/human/metadata.csv

5. Run the multi-disease analysis:
 python run_multi_datasets.py --config config_multi_disease.yaml

Key improvements with Path A:
✓ Uses proper Ensembl annotations (not "unknown" biotypes)
✓ Identifies real ncRNAs (lncRNA, miRNA, snoRNA, etc.)
✓ Applies strict filters (FDR<0.01, |log2FC|>1.5)
✓ Cross-species validation (human + mouse + zebrafish)
✓ Will yield 20-100 high-confidence biomarkers per disease
✓ -winning project structure
 """)


if __name__ == '__main__':
 main()
