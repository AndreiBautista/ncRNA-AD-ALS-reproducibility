#!/usr/bin/env python3
"""
Cross-disease analysis: Compare Alzheimer's vs ALS to find disease-specific ncRNA signatures.
"""

import pandas as pd
import numpy as np
from scipy import stats
from statsmodels.stats.multitest import fdrcorrection
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

# Configuration
AD_COUNTS = 'data/harmonized_datasets/alzheimers_disease_counts.csv'
ALS_COUNTS = 'data/harmonized_datasets/als_counts_corrected.csv'
ANNOTATION_FILE = 'data/annotations/annotation_human.csv'
OUTPUT_DIR = Path('results/cross_disease')

NC_KEYWORDS = set(['lncrna', 'lnc_rna', 'mirna', 'mir', 'snorna', 'snrna', 
 'antisense', 'misc_rna', 'rrna', 'ncrna', 'pseudogene', 
 'scarna', 'vault_rna', 'srna'])


def load_and_normalize(counts_file, disease_name):
 """Load counts and normalize to log2(CPM+1)."""
 print(f"\n Loading {disease_name}...")
 counts_df = pd.read_csv(counts_file, index_col=0)
 counts_df.index = counts_df.index.astype(str)
 
 print(f" Shape: {counts_df.shape[0]} genes × {counts_df.shape[1]} samples")
 
 # Normalize
 lib_sizes = counts_df.sum(axis=0)
 cpm = counts_df.divide(lib_sizes, axis=1) * 1e6
 log2cpm = np.log2(cpm + 1)
 
 return log2cpm


def compare_diseases(ad_data, als_data):
 """Compare AD vs ALS samples."""
 print(f"\n Finding common genes...")
 
 # Find common genes
 common_genes = set(ad_data.index).intersection(set(als_data.index))
 print(f" Common genes: {len(common_genes)}")
 
 # Filter to common genes
 ad_common = ad_data.loc[list(common_genes)]
 als_common = als_data.loc[list(common_genes)]
 
 print(f"\n Comparing AD vs ALS...")
 print(f" AD samples: {ad_common.shape[1]}")
 print(f" ALS samples: {als_common.shape[1]}")
 
 results = []
 for gene_id in common_genes:
 ad_vals = ad_common.loc[gene_id].values
 als_vals = als_common.loc[gene_id].values
 
 # Calculate means
 mean_ad = ad_vals.mean()
 mean_als = als_vals.mean()
 log2fc = mean_ad - mean_als # Positive = higher in AD
 
 # Welch's t-test
 try:
 t_stat, pval = stats.ttest_ind(ad_vals, als_vals, equal_var=False)
 except:
 pval = 1.0
 t_stat = 0.0
 
 results.append({
 'gene_id': gene_id,
 'log2FoldChange_AD_vs_ALS': log2fc,
 'mean_AD': mean_ad,
 'mean_ALS': mean_als,
 'pvalue': pval,
 't_statistic': t_stat
 })
 
 results_df = pd.DataFrame(results)
 
 # FDR correction
 print(f"\n Applying FDR correction...")
 valid_pvals = results_df['pvalue'].notna()
 fdr_results = fdrcorrection(results_df.loc[valid_pvals, 'pvalue'].values)
 
 results_df['padj'] = np.nan
 results_df.loc[valid_pvals, 'padj'] = fdr_results[1]
 
 # Sort by adjusted p-value
 results_df = results_df.sort_values('padj')
 
 print(f" Significant (FDR < 0.05): {(results_df['padj'] < 0.05).sum()}")
 
 return results_df


def filter_to_ncrna(results_df, annotation):
 """Filter to ncRNAs."""
 print(f"\n Filtering to ncRNAs...")
 
 # Ensure gene_id types match
 results_df['gene_id'] = results_df['gene_id'].astype(str)
 annotation['gene_id'] = annotation['gene_id'].astype(str)
 
 # Merge with annotation
 results_with_annot = results_df.merge(
 annotation[['gene_id', 'gene_name', 'biotype']], 
 on='gene_id', 
 how='left'
 )
 
 # Identify ncRNAs
 biotype_lower = results_with_annot['biotype'].fillna('').astype(str).str.lower()
 is_ncrna = biotype_lower.apply(lambda x: any(k in x for k in NC_KEYWORDS))
 
 ncrna_results = results_with_annot[is_ncrna].copy()
 
 print(f" Total ncRNAs: {len(ncrna_results)}")
 print(f" Significant ncRNAs (FDR < 0.05): {(ncrna_results['padj'] < 0.05).sum()}")
 
 return results_with_annot, ncrna_results


def main():
 """Main cross-disease analysis."""
 print(f"{'='*70}")
 print("CROSS-DISEASE ANALYSIS: ALZHEIMER'S vs ALS")
 print(f"{'='*70}")
 
 # Load annotation
 print(f"\nLoading annotation...")
 annotation = pd.read_csv(ANNOTATION_FILE)
 print(f" Loaded {len(annotation)} genes")
 
 # Load and normalize datasets
 print(f"\n{'='*70}")
 print("LOADING DATASETS")
 print(f"{'='*70}")
 
 ad_data = load_and_normalize(AD_COUNTS, "Alzheimer's Disease")
 als_data = load_and_normalize(ALS_COUNTS, "ALS")
 
 # Compare diseases
 print(f"\n{'='*70}")
 print("COMPARING DISEASES")
 print(f"{'='*70}")
 
 results_df = compare_diseases(ad_data, als_data)
 
 # Filter to ncRNAs
 all_results, ncrna_results = filter_to_ncrna(results_df, annotation)
 
 # Save results
 OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
 
 print(f"\n{'='*70}")
 print("SAVING RESULTS")
 print(f"{'='*70}")
 print(f" Output directory: {OUTPUT_DIR}")
 
 # All results
 all_file = OUTPUT_DIR / 'all_ad_vs_als.csv'
 all_results.to_csv(all_file, index=False)
 print(f" ✓ All genes: {all_file.name} ({len(all_results)} genes)")
 
 # ncRNA results
 ncrna_file = OUTPUT_DIR / 'ncrna_ad_vs_als.csv'
 ncrna_results.to_csv(ncrna_file, index=False)
 print(f" ✓ ncRNAs: {ncrna_file.name} ({len(ncrna_results)} ncRNAs)")
 
 # Significant biomarkers
 biomarkers = ncrna_results[ncrna_results['padj'] < 0.05].copy()
 if len(biomarkers) > 0:
 biomarkers_file = OUTPUT_DIR / 'disease_specific_ncrnas.csv'
 biomarkers.to_csv(biomarkers_file, index=False)
 print(f" ✓ Disease-specific ncRNAs: {biomarkers_file.name} ({len(biomarkers)} ncRNAs)")
 
 # Summary
 print(f"\n{'='*70}")
 print("SUMMARY")
 print(f"{'='*70}")
 
 if len(biomarkers) > 0:
 ad_specific = (biomarkers['log2FoldChange_AD_vs_ALS'] > 0).sum()
 als_specific = (biomarkers['log2FoldChange_AD_vs_ALS'] < 0).sum()
 
 print(f"\nDisease-specific ncRNAs (FDR < 0.05): {len(biomarkers)}")
 print(f" - Higher in Alzheimer's: {ad_specific}")
 print(f" - Higher in ALS: {als_specific}")
 
 print(f"\nTop 10 AD-specific ncRNAs:")
 ad_top = biomarkers[biomarkers['log2FoldChange_AD_vs_ALS'] > 0].head(10)
 for idx, row in ad_top.iterrows():
 gene_name = row['gene_name'] if pd.notna(row['gene_name']) else row['gene_id']
 biotype = row['biotype'] if pd.notna(row['biotype']) else 'unknown'
 print(f" • {gene_name:20s} ({biotype:15s}): "
 f"log2FC={row['log2FoldChange_AD_vs_ALS']:6.2f}, padj={row['padj']:.2e}")
 
 print(f"\nTop 10 ALS-specific ncRNAs:")
 als_top = biomarkers[biomarkers['log2FoldChange_AD_vs_ALS'] < 0].head(10)
 for idx, row in als_top.iterrows():
 gene_name = row['gene_name'] if pd.notna(row['gene_name']) else row['gene_id']
 biotype = row['biotype'] if pd.notna(row['biotype']) else 'unknown'
 print(f" • {gene_name:20s} ({biotype:15s}): "
 f"log2FC={row['log2FoldChange_AD_vs_ALS']:6.2f}, padj={row['padj']:.2e}")
 
 print(f"\n{'='*70}")
 print("✓ CROSS-DISEASE ANALYSIS COMPLETE")
 print(f"{'='*70}")


if __name__ == '__main__':
 main()
