#!/usr/bin/env python3
"""
Helper to manually download and organize raw count files from GEO
Series_matrix files don't contain raw counts - need supplementary files
"""

import sys

print("""
╔════════════════════════════════════════════════════════════════════════════╗
║ IMPORTANT: NEED RAW COUNTS, NOT SERIES_MATRIX ║
╚════════════════════════════════════════════════════════════════════════════╝

The series_matrix files you downloaded don't contain the raw expression counts.
They only have metadata. We need the supplementary files with actual counts.

For each dataset, you need to:

1. GO BACK TO GEO
2. Look for SUPPLEMENTARY FILES (not series_matrix)
3. Look for files with: "counts", "expression", or "matrix" in the name
4. Download those instead

Here are direct links to the supplementary files:

ALZHEIMER'S:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

GSE173955 (Hisayama - Hippocampus)
 → https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE173955
 → Look for: GSE173955_gene_expression.xlsx or similar
 → This should be in "Supplementary file" section
 
GSE95587 (Genentech - Fusiform Gyrus) 
 → https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE95587
 → Look for: Expression matrix or counts file
 → Usually .txt.gz or .csv.gz

ALS:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

GSE124439 (NYGC Motor Cortex)
 → https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE124439
 → Look for: FPKM, counts, or expression matrix
 
GSE116622 (NYGC C9ORF72 & Sporadic)
 → https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE116622
 → Look for: Expression data file
 
GSE76220 (Laser Capture Motor Neurons)
 → https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE76220
 → Look for: ALS_LCM or expression file

═══════════════════════════════════════════════════════════════════════════════

WHAT TO DOWNLOAD:
 ✓ Files with "counts", "expression", "fpkm", "matrix" in name
 ✓ Usually .txt, .csv, .tsv (tab or comma separated)
 ✓ Not .xml, .pdf, .html
 ✓ Should be in section labeled "Supplementary file"

WHAT NOT TO DOWNLOAD:
 ✗ series_matrix files (metadata only - what you have now)
 ✗ Samples GSM#### files (individual files - too many)
 ✗ SRA files (raw sequencing - requires alignment)

═══════════════════════════════════════════════════════════════════════════════

After downloading the REAL count files:

1. Save to Downloads/
2. Run this again to organize them properly
3. I'll preview them and build the analysis

═══════════════════════════════════════════════════════════════════════════════
""")
