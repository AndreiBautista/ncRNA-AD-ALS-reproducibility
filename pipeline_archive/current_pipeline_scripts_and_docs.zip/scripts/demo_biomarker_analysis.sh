#!/bin/bash
# Quick Biomarker Demo - Shows you how it works
# Then you can download real GEO datasets yourself

cd /Users/austinbautista/ncrna_pipeline
source .venv/bin/activate

echo "=========================================="
echo "BIOMARKER DISCOVERY DEMO"
echo "=========================================="
echo ""
echo "This demo shows you:"
echo " 1. How to analyze datasets"
echo " 2. What output files you get"
echo " 3. Where to find biomarker results"
echo ""

# Use test data (instant)
echo "Analyzing test dataset..."
python scripts/run_pipeline.py \
 --counts examples/data/example_expression_matrix.csv \
 --metadata examples/data/test_metadata_6samples.csv \
 --annotation examples/data/test_annotation.csv \
 --group_col Condition \
 --disease_label Disease \
 --control_label Control \
 --outdir results/demo_biomarkers/dataset1

echo ""
echo "✓ Demo complete!"
echo ""
echo "YOUR RESULTS ARE IN:"
echo " results/demo_biomarkers/dataset1/per_dataset/local/data/"
echo ""
echo "KEY FILES:"
echo " - dataset_summary.csv = Overview stats"
echo " - DE_summary.csv = All significant genes"
echo " - biomarker_candidates.csv = Top biomarkers"
echo ""
echo "OPEN RESULTS FOLDER:"
echo " open results/demo_biomarkers/dataset1/per_dataset/local/data/"
echo ""
echo "=========================================="
echo "TO DOWNLOAD REAL GEO DATASETS:"
echo "=========================================="
echo ""
echo "Run this for each dataset you want:"
echo ""
echo " python scripts/geo_integration.py \\"
echo " --geo_id GSE33000 \\"
echo " --annotation data/annotations/human_gencode.gtf \\"
echo " --outdir results/my_analysis/GSE33000"
echo ""
echo "Find datasets at: https://www.ncbi.nlm.nih.gov/geo/"
echo ""
