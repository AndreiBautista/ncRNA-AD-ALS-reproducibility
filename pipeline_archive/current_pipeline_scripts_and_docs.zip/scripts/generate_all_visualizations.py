#!/usr/bin/env python3
"""
Generate comprehensive visualizations for presentation
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path

# Set style
plt.style.use('seaborn-v0_8-darkgrid')
sns.set_palette("Set2")

# Create output directory
outdir = Path('results/figures')
outdir.mkdir(parents=True, exist_ok=True)

print("Loading data...")
# Load AD biomarkers
ad_bio = pd.read_csv('results/deseq2/alzheimers/ncrna_biomarkers.csv')

# Load cross-disease comparison
cross = pd.read_csv('results/cross_disease/disease_specific_ncrnas.csv')

print(f"Loaded {len(ad_bio)} AD biomarkers and {len(cross)} disease-specific ncRNAs")

# ============================================================================
# FIGURE 1: Volcano Plot - Alzheimer's Disease Biomarkers
# ============================================================================
print("\n Creating Figure 1: AD Volcano Plot...")
fig, ax = plt.subplots(figsize=(10, 8))

# All genes
scatter = ax.scatter(ad_bio['log2FoldChange'], 
 -np.log10(ad_bio['padj']),
 c='gray', alpha=0.3, s=20, label='Significant ncRNAs')

# Top 10 by significance
top10 = ad_bio.nsmallest(10, 'padj')
ax.scatter(top10['log2FoldChange'], 
 -np.log10(top10['padj']),
 c='red', s=100, alpha=0.7, edgecolor='black', linewidth=1,
 label='Top 10 biomarkers', zorder=5)

# Add gene labels for top 5
top5 = ad_bio.nsmallest(5, 'padj')
for _, row in top5.iterrows():
 gene_name = row['gene_name'] if pd.notna(row['gene_name']) else row['gene_id']
 ax.annotate(gene_name, 
 xy=(row['log2FoldChange'], -np.log10(row['padj'])),
 xytext=(10, 5), textcoords='offset points',
 fontsize=9, fontweight='bold',
 bbox=dict(boxstyle='round,pad=0.3', fc='yellow', alpha=0.7),
 arrowprops=dict(arrowstyle='->', connectionstyle='arc3,rad=0'))

ax.axhline(-np.log10(0.05), color='blue', linestyle='--', linewidth=1, alpha=0.5, label='FDR=0.05')
ax.axvline(0, color='black', linestyle='-', linewidth=0.5)

ax.set_xlabel('log₂ Fold Change (Disease / Control)', fontsize=12, fontweight='bold')
ax.set_ylabel('-log₁₀(FDR-adjusted p-value)', fontsize=12, fontweight='bold')
ax.set_title("Alzheimer's Disease ncRNA Biomarkers\n(n=1,733 significant, FDR<0.05)", 
 fontsize=14, fontweight='bold', pad=20)
ax.legend(loc='upper right', frameon=True, fancybox=True, shadow=True)
ax.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig(outdir / 'volcano_alzheimers.png', dpi=300, bbox_inches='tight')
plt.close()
print(f" ✓ Saved: {outdir / 'volcano_alzheimers.png'}")


# ============================================================================
# FIGURE 2: Up vs Down Regulation Bar Chart
# ============================================================================
print("Creating Figure 2: Regulation Direction...")
fig, ax = plt.subplots(figsize=(8, 6))

up = (ad_bio['log2FoldChange'] > 0).sum()
down = (ad_bio['log2FoldChange'] < 0).sum()

bars = ax.bar(['Upregulated\n(Disease > Control)', 
 'Downregulated\n(Disease < Control)'],
 [up, down],
 color=['#e74c3c', '#3498db'],
 edgecolor='black', linewidth=2, alpha=0.8)

# Add value labels on bars
for bar in bars:
 height = bar.get_height()
 ax.text(bar.get_x() + bar.get_width()/2., height,
 f'{int(height):,}\n({height/len(ad_bio)*100:.1f}%)',
 ha='center', va='bottom', fontsize=14, fontweight='bold')

ax.set_ylabel('Number of ncRNA Biomarkers', fontsize=12, fontweight='bold')
ax.set_title("Direction of Regulation in Alzheimer's Disease\n(n=1,733 significant ncRNAs)", 
 fontsize=14, fontweight='bold', pad=20)
ax.set_ylim(0, max(up, down) * 1.15)
ax.grid(axis='y', alpha=0.3)

plt.tight_layout()
plt.savefig(outdir / 'regulation_direction.png', dpi=300, bbox_inches='tight')
plt.close()
print(f" ✓ Saved: {outdir / 'regulation_direction.png'}")


# ============================================================================
# FIGURE 3: Cross-Disease Comparison Volcano
# ============================================================================
print("Creating Figure 3: Cross-Disease Volcano...")
fig, ax = plt.subplots(figsize=(12, 8))

# AD-specific (positive log2FC)
ad_spec = cross[cross['log2FoldChange_AD_vs_ALS'] > 0]
als_spec = cross[cross['log2FoldChange_AD_vs_ALS'] < 0]

ax.scatter(ad_spec['log2FoldChange_AD_vs_ALS'], 
 -np.log10(ad_spec['padj']),
 c='#e74c3c', alpha=0.4, s=30, label=f'AD-specific (n={len(ad_spec):,})')

ax.scatter(als_spec['log2FoldChange_AD_vs_ALS'], 
 -np.log10(als_spec['padj']),
 c='#3498db', alpha=0.4, s=30, label=f'ALS-specific (n={len(als_spec):,})')

# Top 5 AD-specific
top5_ad = ad_spec.nsmallest(5, 'padj')
ax.scatter(top5_ad['log2FoldChange_AD_vs_ALS'], 
 -np.log10(top5_ad['padj']),
 c='darkred', s=150, alpha=0.9, edgecolor='black', linewidth=1.5, zorder=5)

for _, row in top5_ad.iterrows():
 gene_name = row['gene_name'] if pd.notna(row['gene_name']) else row['gene_id']
 ax.annotate(f"{gene_name}\n({row['biotype']})", 
 xy=(row['log2FoldChange_AD_vs_ALS'], -np.log10(row['padj'])),
 xytext=(10, 5), textcoords='offset points',
 fontsize=8, fontweight='bold',
 bbox=dict(boxstyle='round,pad=0.3', fc='#ffcccc', alpha=0.8),
 arrowprops=dict(arrowstyle='->', connectionstyle='arc3,rad=0.2'))

# Top 5 ALS-specific
top5_als = als_spec.nsmallest(5, 'padj')
ax.scatter(top5_als['log2FoldChange_AD_vs_ALS'], 
 -np.log10(top5_als['padj']),
 c='darkblue', s=150, alpha=0.9, edgecolor='black', linewidth=1.5, zorder=5)

for _, row in top5_als.iterrows():
 gene_name = row['gene_name'] if pd.notna(row['gene_name']) else row['gene_id']
 ax.annotate(f"{gene_name}\n({row['biotype']})", 
 xy=(row['log2FoldChange_AD_vs_ALS'], -np.log10(row['padj'])),
 xytext=(-10, 5), textcoords='offset points',
 fontsize=8, fontweight='bold', ha='right',
 bbox=dict(boxstyle='round,pad=0.3', fc='#ccccff', alpha=0.8),
 arrowprops=dict(arrowstyle='->', connectionstyle='arc3,rad=-0.2'))

ax.axvline(0, color='black', linestyle='-', linewidth=1)
ax.axhline(-np.log10(0.05), color='gray', linestyle='--', linewidth=1, alpha=0.5)

ax.set_xlabel('log₂ Fold Change (AD / ALS)', fontsize=12, fontweight='bold')
ax.set_ylabel('-log₁₀(FDR-adjusted p-value)', fontsize=12, fontweight='bold')
ax.set_title("Disease-Specific ncRNA Signatures\nAlzheimer's Disease vs. ALS\n(n=5,955 significant, FDR<0.05)", 
 fontsize=14, fontweight='bold', pad=20)
ax.legend(loc='upper right', frameon=True, fancybox=True, shadow=True, fontsize=11)
ax.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig(outdir / 'cross_disease_volcano.png', dpi=300, bbox_inches='tight')
plt.close()
print(f" ✓ Saved: {outdir / 'cross_disease_volcano.png'}")


# ============================================================================
# FIGURE 4: Biotype Distribution
# ============================================================================
print("Creating Figure 4: Biotype Distribution...")
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))

# AD biomarkers
biotype_counts_ad = ad_bio['biotype'].value_counts().head(10)
bars1 = ax1.barh(range(len(biotype_counts_ad)), biotype_counts_ad.values, 
 color=sns.color_palette("husl", len(biotype_counts_ad)))
ax1.set_yticks(range(len(biotype_counts_ad)))
ax1.set_yticklabels(biotype_counts_ad.index, fontsize=10)
ax1.set_xlabel('Number of Biomarkers', fontsize=11, fontweight='bold')
ax1.set_title("Alzheimer's Disease Biomarkers\nTop 10 ncRNA Biotypes", 
 fontsize=12, fontweight='bold')
ax1.invert_yaxis()
ax1.grid(axis='x', alpha=0.3)

for i, (count, biotype) in enumerate(zip(biotype_counts_ad.values, biotype_counts_ad.index)):
 ax1.text(count + 20, i, f'{count} ({count/len(ad_bio)*100:.1f}%)', 
 va='center', fontsize=9, fontweight='bold')

# Cross-disease
biotype_counts_cross = cross['biotype'].value_counts().head(10)
bars2 = ax2.barh(range(len(biotype_counts_cross)), biotype_counts_cross.values,
 color=sns.color_palette("husl", len(biotype_counts_cross)))
ax2.set_yticks(range(len(biotype_counts_cross)))
ax2.set_yticklabels(biotype_counts_cross.index, fontsize=10)
ax2.set_xlabel('Number of Disease-Specific ncRNAs', fontsize=11, fontweight='bold')
ax2.set_title("AD vs ALS Comparison\nTop 10 ncRNA Biotypes", 
 fontsize=12, fontweight='bold')
ax2.invert_yaxis()
ax2.grid(axis='x', alpha=0.3)

for i, (count, biotype) in enumerate(zip(biotype_counts_cross.values, biotype_counts_cross.index)):
 ax2.text(count + 50, i, f'{count} ({count/len(cross)*100:.1f}%)', 
 va='center', fontsize=9, fontweight='bold')

plt.tight_layout()
plt.savefig(outdir / 'biotype_distribution.png', dpi=300, bbox_inches='tight')
plt.close()
print(f" ✓ Saved: {outdir / 'biotype_distribution.png'}")


# ============================================================================
# FIGURE 5: Top Biomarkers Table Figure
# ============================================================================
print("Creating Figure 5: Top Biomarkers Table...")
fig, ax = plt.subplots(figsize=(14, 10))
ax.axis('tight')
ax.axis('off')

# Top 15 biomarkers
top15 = ad_bio.nsmallest(15, 'padj')[['gene_name', 'gene_id', 'biotype', 
 'log2FoldChange', 'pvalue', 'padj']].copy()
top15['log2FC'] = top15['log2FoldChange'].round(2)
top15['p-value'] = top15['pvalue'].apply(lambda x: f'{x:.2e}')
top15['FDR'] = top15['padj'].apply(lambda x: f'{x:.2e}')
top15['Direction'] = top15['log2FoldChange'].apply(lambda x: '↑ Up' if x > 0 else '↓ Down')

table_data = top15[['gene_name', 'biotype', 'log2FC', 'Direction', 'FDR']].values
col_labels = ['Gene', 'Biotype', 'log₂FC', 'Regulation', 'FDR']

table = ax.table(cellText=table_data, colLabels=col_labels, 
 cellLoc='left', loc='center',
 colWidths=[0.2, 0.3, 0.12, 0.15, 0.15])

table.auto_set_font_size(False)
table.set_fontsize(10)
table.scale(1, 2.5)

# Style header
for i in range(len(col_labels)):
 cell = table[(0, i)]
 cell.set_facecolor('#2c3e50')
 cell.set_text_props(weight='bold', color='white', fontsize=11)

# Style rows
for i in range(1, len(table_data) + 1):
 for j in range(len(col_labels)):
 cell = table[(i, j)]
 if i % 2 == 0:
 cell.set_facecolor('#ecf0f1')
 else:
 cell.set_facecolor('white')
 
 # Highlight direction column
 if j == 3: # Direction column
 if '↑' in table_data[i-1][j]:
 cell.set_facecolor('#ffcccc')
 else:
 cell.set_facecolor('#cce5ff')

ax.set_title("Top 15 Alzheimer's Disease ncRNA Biomarkers\n(Ranked by FDR-adjusted p-value)", 
 fontsize=14, fontweight='bold', pad=20)

plt.savefig(outdir / 'top_biomarkers_table.png', dpi=300, bbox_inches='tight')
plt.close()
print(f" ✓ Saved: {outdir / 'top_biomarkers_table.png'}")


# ============================================================================
# Summary Statistics
# ============================================================================
print("\n" + "="*80)
print("VISUALIZATION SUMMARY")
print("="*80)
print(f"\nCreated 5 publication-quality figures in: {outdir}")
print(f"\n1. volcano_alzheimers.png - AD biomarker volcano plot")
print(f"2. regulation_direction.png - Up/down regulation comparison")
print(f"3. cross_disease_volcano.png - AD vs ALS disease specificity")
print(f"4. biotype_distribution.png - ncRNA type distributions")
print(f"5. top_biomarkers_table.png - Top 15 biomarkers summary table")

print(f"\n📊 All figures saved at 300 DPI for publication quality")
print(f"📄 Text summary: results/COMPREHENSIVE_SUMMARY.txt")
print(f"\n✅ presentation materials ready!")
print("="*80)
