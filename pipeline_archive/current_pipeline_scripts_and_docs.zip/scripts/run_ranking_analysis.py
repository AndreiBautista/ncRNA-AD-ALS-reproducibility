#!/usr/bin/env python3
"""
Optional wrapper to integrate ranked overlap analysis into the main pipeline.
Can be called after run_pipeline.py or run_multi_datasets.py.

Usage:
 python run_ranking_analysis.py --results-dir results/multi_run --top-n 100
"""
import subprocess
import sys
from pathlib import Path
import argparse


def main():
 parser = argparse.ArgumentParser(
 description="Run ranked gene overlap analysis on pipeline results"
 )
 parser.add_argument("--results-dir", default="results/multi_run",
 help="Results directory from run_pipeline.py or run_multi_datasets.py")
 parser.add_argument("--top-n", type=int, default=100,
 help="Top N genes per direction to extract")
 parser.add_argument("--fdr", type=float, default=None,
 help="Optional FDR cutoff for pre-filtering")
 parser.add_argument("--use-gene-name", action="store_true",
 help="Match on gene names instead of gene IDs")
 args = parser.parse_args()

 # Verify results directory exists
 results_dir = Path(args.results_dir)
 if not (results_dir / "per_dataset").exists():
 print(f"Error: {results_dir}/per_dataset not found")
 print(f"Make sure to run the main pipeline first")
 sys.exit(1)

 # Build command
 script_path = Path(__file__).parent / "ranked_gene_overlap.py"
 cmd = [
 sys.executable,
 str(script_path),
 "--root", str(results_dir),
 "--top_n", str(args.top_n),
 ]
 
 if args.fdr is not None:
 cmd.extend(["--fdr", str(args.fdr)])
 
 if args.use_gene_name:
 cmd.append("--use-gene-name")

 print(f"Running ranked gene overlap analysis...")
 print(f"Command: {' '.join(cmd)}\n")
 
 result = subprocess.run(cmd, capture_output=False)
 sys.exit(result.returncode)


if __name__ == "__main__":
 main()
