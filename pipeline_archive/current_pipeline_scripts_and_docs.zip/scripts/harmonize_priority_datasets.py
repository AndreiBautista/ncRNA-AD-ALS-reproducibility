#!/usr/bin/env python3
"""
Simplified harmonization: Focus on datasets with proper Ensembl IDs first.

Priority datasets (Ensembl IDs):
- GSE203206 (AD, 47 samples, Ensembl IDs)
- GSE153960 (ALS, 1,660 samples, Ensembl IDs with versions)

Secondary datasets (require mapping):
- GSE48350 (AD, 253 samples, Affy probe IDs)
- GSE76220 (ALS, 12 samples, Entrez IDs)
- GSE173955 (AD, 31 samples, XLSX with gene symbols)

Strategy:
1. Load priority datasets, normalize gene IDs
2. Merge within disease on common Ensembl genes
3. Generate DESeq2-ready matrices
4. Later: Add secondary datasets via ID mapping
"""

import pandas as pd
import numpy as np
from pathlib import Path

# Core configuration
PRIORITIES = {
 'Alzheimer\'s Disease': {
 'GSE203206': 'data/neurodegenerative_diseases/alzheimers/GSE203206/counts.tsv',
 },
 'ALS': {
 'GSE153960': 'data/neurodegenerative_diseases/als/GSE153960/counts.txt',
 }
}

OUTPUT_DIR = Path('data/harmonized_datasets')


def load_dataset(gse_id, counts_path):
 """Load a dataset and detect/normalize gene IDs."""
 print(f"\n Loading {gse_id}...")
 
 # Determine separator
 if counts_path.endswith('.tsv'):
 sep = '\t'
 elif counts_path.endswith('.csv'):
 sep = ','
 else:
 sep = '\t' # Assume TSV for .txt
 
 # Load with low_memory=False to handle mixed dtypes
 try:
 counts_df = pd.read_csv(counts_path, sep=sep, index_col=0, dtype=float)
 # If dtypes failed, try with object and convert
 except ValueError:
 counts_df = pd.read_csv(counts_path, sep=sep, index_col=0, dtype=object)
 # Convert numeric columns
 for col in counts_df.columns:
 counts_df[col] = pd.to_numeric(counts_df[col], errors='coerce')
 
 print(f" Original shape: {counts_df.shape[0]} genes × {counts_df.shape[1]} samples")
 
 # Normalization: Strip version numbers and handle IDs
 new_index = []
 for gene_id in counts_df.index:
 # Strip version (e.g., ENSG00000000003.14 → ENSG00000000003)
 if isinstance(gene_id, str) and '.' in gene_id:
 gene_id = gene_id.split('.')[0]
 new_index.append(gene_id)
 
 counts_df.index = new_index
 counts_df.index.name = 'gene_id'
 
 # Remove rows with all NaN
 counts_df = counts_df.dropna(how='all')
 
 # Convert to float
 counts_df = counts_df.apply(pd.to_numeric, errors='coerce')
 
 # Remove genes with NaN values
 counts_df = counts_df.dropna(how='all', axis=0)
 
 print(f" After cleanup: {counts_df.shape[0]} genes × {counts_df.shape[1]} samples")
 
 return counts_df


def merge_datasets(disease_name, datasets_dict):
 """Merge datasets for a disease on common genes."""
 print(f"\n{'='*70}")
 print(f"{disease_name.upper()}")
 print(f"{'='*70}")
 
 loaded = {}
 
 # Load all datasets
 for gse_id, counts_path in datasets_dict.items():
 try:
 counts_df = load_dataset(gse_id, counts_path)
 loaded[gse_id] = counts_df
 except Exception as e:
 print(f" ✗ Error: {e}")
 continue
 
 if not loaded:
 print(f"✗ No datasets loaded for {disease_name}")
 return None, None
 
 # Find common genes
 common_genes = set(list(loaded.values())[0].index)
 for counts_df in list(loaded.values())[1:]:
 common_genes = common_genes.intersection(set(counts_df.index))
 
 print(f"\n Merging {len(loaded)} dataset{'s' if len(loaded) != 1 else ''}:")
 for gse_id in loaded.keys():
 print(f" - {gse_id}: {loaded[gse_id].shape}")
 
 print(f"\n Common genes: {len(common_genes)}")
 
 if len(common_genes) == 0:
 print(f" ✗ No common genes found!")
 return None, None
 
 # Merge on common genes
 merged_list = [loaded[gse_id].loc[list(common_genes)] for gse_id in loaded.keys()]
 merged_counts = pd.concat(merged_list, axis=1)
 
 print(f" Merged: {merged_counts.shape[0]} genes × {merged_counts.shape[1]} samples")
 
 # Create metadata
 merged_meta = []
 for gse_id in loaded.keys():
 meta_path = Path(PRIORITIES[disease_name][gse_id]).parent / 'metadata.csv'
 if meta_path.exists():
 meta = pd.read_csv(meta_path, index_col=0)
 meta['dataset'] = gse_id
 merged_meta.append(meta)
 
 if merged_meta:
 merged_meta = pd.concat(merged_meta, axis=0)
 print(f" Metadata: {merged_meta.shape[0]} samples")
 return merged_counts, merged_meta
 else:
 print(f" ⚠ No metadata found")
 return merged_counts, None


def main():
 """Main harmonization."""
 print(f"{'='*70}")
 print("HARMONIZATION: PRIORITY DATASETS (ENSEMBL IDs)")
 print(f"{'='*70}")
 
 OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
 
 # Process each disease
 results = {}
 for disease_name, datasets_dict in PRIORITIES.items():
 counts, meta = merge_datasets(disease_name, datasets_dict)
 
 if counts is not None:
 # Save counts
 disease_key = disease_name.lower().replace("'", "").replace(" ", "_")
 counts_file = OUTPUT_DIR / f'{disease_key}_counts.csv'
 counts.to_csv(counts_file)
 print(f"\n ✓ Saved counts to {counts_file.name}")
 
 # Save metadata
 if meta is not None:
 meta_file = OUTPUT_DIR / f'{disease_key}_metadata.csv'
 meta.to_csv(meta_file)
 print(f" ✓ Saved metadata to {meta_file.name}")
 
 results[disease_name] = {
 'counts': counts,
 'metadata': meta,
 'counts_file': str(counts_file),
 'metadata_file': str(meta_file) if meta is not None else None
 }
 
 # Summary
 print(f"\n{'='*70}")
 print("SUMMARY")
 print(f"{'='*70}")
 
 for disease_name, result in results.items():
 counts = result['counts']
 print(f"\n{disease_name}:")
 print(f" - Counts: {counts.shape[0]} genes × {counts.shape[1]} samples")
 print(f" - File: {result['counts_file']}")
 if result['metadata'] is not None:
 print(f" - Metadata: {result['metadata'].shape[0]} samples")
 print(f" - File: {result['metadata_file']}")
 
 print(f"\n{'='*70}")
 print("Ready for DESeq2 analysis!")
 print(f"{'='*70}")


if __name__ == '__main__':
 main()
