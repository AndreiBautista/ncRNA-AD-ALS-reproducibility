#!/usr/bin/env python3
"""
Process downloaded files:
1. Extract Excel files to CSV
2. Re-extract the large TAR file based on what's actually downloaded
3. Organize all data into standard format
"""

import os
import tarfile
import gzip
from pathlib import Path
import pandas as pd

def handle_excel_file(gse_folder):
 """Convert Excel file to CSV/TSV format."""
 excel_files = list(gse_folder.glob("*.xlsx"))
 
 if len(excel_files) == 0:
 return False
 
 excel_file = excel_files[0]
 print(f" Found Excel file: {excel_file.name}")
 
 try:
 # Read Excel
 df = pd.read_excel(excel_file, sheet_name=0)
 print(f" Shape: {df.shape}")
 
 # Set first column as index (gene names)
 if df.shape[1] > 1:
 df = df.set_index(df.columns[0])
 
 # Save as TSV
 output_file = gse_folder / "counts.txt"
 df.to_csv(output_file, sep="\t")
 print(f" ✓ Converted to counts.txt ({df.shape[0]} genes, {df.shape[1]} samples)")
 
 return True
 except Exception as e:
 print(f" ✗ Error processing Excel: {e}")
 return False


def check_tar_file(tar_file):
 """Check if TAR file is valid and list contents."""
 print(f" Checking TAR file: {tar_file.name} ({tar_file.stat().st_size / (1024*1024):.1f} MB)")
 
 try:
 with tarfile.open(tar_file, "r") as tar:
 members = tar.getmembers()
 print(f" Contains {len(members)} files")
 
 # Show first few
 for i, member in enumerate(members[:5]):
 print(f" - {member.name}")
 
 if len(members) > 5:
 print(f" ... and {len(members) - 5} more")
 
 return True, tar
 except Exception as e:
 print(f" ✗ TAR file issue: {e}")
 return False, None


def extract_tar_properly(tar_file, dest_folder):
 """Extract TAR file with better error handling."""
 print(f" Extracting {tar_file.name}...")
 
 try:
 # Try different tar modes
 for mode in ["r", "r:gz", "r:bz2", "r:xz"]:
 try:
 with tarfile.open(str(tar_file), mode) as tar:
 tar.extractall(path=dest_folder)
 print(f" ✓ Extracted successfully (mode: {mode})")
 return True
 except:
 continue
 
 print(f" ✗ Could not extract with any mode")
 return False
 
 except Exception as e:
 print(f" ✗ Extraction error: {e}")
 return False


def main():
 print("=" * 80)
 print("PROCESS DOWNLOADED FILES")
 print("=" * 80)
 
 base_path = Path("data/neurodegenerative_diseases")
 
 # Process Alzheimer's
 print("\n\nALZHEIMER'S DATASETS")
 print("-" * 80)
 
 for gse_folder in sorted((base_path / "alzheimers").iterdir()):
 if not gse_folder.is_dir():
 continue
 
 gse = gse_folder.name
 print(f"\n{gse}:")
 
 # Check for Excel files
 if list(gse_folder.glob("*.xlsx")):
 print(" Processing Excel file...")
 handle_excel_file(gse_folder)
 
 # Check for TAR files
 tar_files = list(gse_folder.glob("*.tar*"))
 if tar_files:
 tar_file = tar_files[0]
 valid, tar_obj = check_tar_file(tar_file)
 if valid:
 extract_tar_properly(tar_file, gse_folder)
 
 # Process ALS
 print("\n\nALS DATASETS")
 print("-" * 80)
 
 for gse_folder in sorted((base_path / "als").iterdir()):
 if not gse_folder.is_dir():
 continue
 
 gse = gse_folder.name
 print(f"\n{gse}:")
 
 # Check for Excel files
 if list(gse_folder.glob("*.xlsx")):
 print(" Processing Excel file...")
 handle_excel_file(gse_folder)
 
 # Check for TAR files 
 tar_files = list(gse_folder.glob("*.tar*"))
 if tar_files:
 tar_file = tar_files[0]
 valid, tar_obj = check_tar_file(tar_file)
 if valid:
 extract_tar_properly(tar_file, gse_folder)
 
 # Final check
 print("\n\n" + "=" * 80)
 print("FINAL FILE CHECK")
 print("=" * 80)
 
 for disease in ["alzheimers", "als"]:
 print(f"\n{disease.upper()}:")
 for gse_folder in sorted((base_path / disease).iterdir()):
 if gse_folder.is_dir():
 files = list(gse_folder.glob("*"))
 counts_files = [f for f in files if "count" in f.name.lower() and f.is_file()]
 print(f" {gse_folder.name}: {len(files)} items ({len(counts_files)} count files)")

if __name__ == "__main__":
 main()
