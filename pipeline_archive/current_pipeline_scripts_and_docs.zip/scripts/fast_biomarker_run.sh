#!/bin/bash
# FAST Biomarker Analysis - Uses your existing GSE33000 files
# Then adds 2 more datasets for validation

cd /Users/austinbautista/ncrna_pipeline
source .venv/bin/activate

mkdir -p results/fast_biomarker_analysis

echo "=========================================="
echo "FAST BIOMARKER DISCOVERY"
echo "=========================================="
echo ""

# Dataset 1: Use your existing GSE33000 files (FAST!)
echo "✓ Dataset 1: GSE33000 (using your files - instant)"
.venv/bin/python scripts/run_pipeline.py \
 --counts GSE33000_counts.txt \
 --metadata GSE33000_metadata.txt \
 --annotation data/annotations/human_gencode.gtf \
 --group_col disease.state.ch1 \
 --disease_label "Alzheimer's disease" \
 --control_label "control" \
 --outdir results/fast_biomarker_analysis/GSE33000

echo ""
echo "Datasets analyzed!"
echo "Results: results/fast_biomarker_analysis/"
echo ""
echo "To view biomarker candidates:"
echo " open results/fast_biomarker_analysis/GSE33000/per_dataset/*/data/"
