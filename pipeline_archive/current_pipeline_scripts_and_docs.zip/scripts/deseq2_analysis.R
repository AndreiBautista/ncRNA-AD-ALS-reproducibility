#!/usr/bin/env Rscript
"""
DESeq2 Differential Expression Analysis for ncRNAs

This script performs:
1. Loads count matrix and metadata
2. Creates DESeq2 object with condition groups
3. Runs DESeq2 pipeline (normalization, estimation, testing)
4. Filters to ncRNAs based on biotype
5. Outputs results with log2FC, p-values, adjusted p-values
"""

# Install/load required packages
packages <- c("DESeq2", "BiocGenerics", "S4Vectors")
for (pkg in packages) {
  if (!require(pkg, character.only = TRUE)) {
    if (!require("BiocManager", character.only = TRUE)) {
      install.packages("BiocManager")
    }
    BiocManager::install(pkg)
    library(pkg, character.only = TRUE)
  }
}

library(DESeq2)
library(dplyr)

# Parse command line arguments
args <- commandArgs(trailingOnly = TRUE)
counts_file <- args[1]
metadata_file <- args[2]
disease_name <- args[3]
output_dir <- args[4]
annotation_file <- args[5]

cat(sprintf("DESeq2 Analysis for %s\n", disease_name))
cat(sprintf("Counts: %s\n", counts_file))
cat(sprintf("Metadata: %s\n", metadata_file))
cat(sprintf("Annotation: %s\n", annotation_file))
cat("\n")

# Load data
cat("Loading count matrix...\n")
counts <- read.csv(counts_file, row.names = 1, check.names = FALSE)
counts <- as.matrix(counts)
mode(counts) <- "numeric"

cat(sprintf("  Genes: %d, Samples: %d\n", nrow(counts), ncol(counts)))

# Load metadata
cat("Loading metadata...\n")
metadata <- read.csv(metadata_file, row.names = 1)
cat(sprintf("  Samples in metadata: %d\n", nrow(metadata)))

# Ensure sample order matches
samples <- intersect(colnames(counts), rownames(metadata))
cat(sprintf("  Common samples: %d\n", length(samples)))

counts <- counts[, samples]
metadata <- metadata[samples, ]

# Load annotation
cat("Loading annotation...\n")
annotation <- read.csv(annotation_file)
rownames(annotation) <- annotation$gene_id
cat(sprintf("  Genes in annotation: %d\n", nrow(annotation)))

# Get disease status from metadata
# Try common group column names
group_col <- NA
for (col in c("group", "condition", "disease", "status")) {
  if (col %in% colnames(metadata)) {
    group_col <- col
    break
  }
}

if (is.na(group_col)) {
  stop("Could not find condition column in metadata. Available: ", 
       paste(colnames(metadata), collapse = ", "))
}

cat(sprintf("Using condition column: '%s'\n", group_col))
cat(sprintf("Groups: %s\n", paste(unique(metadata[[group_col]]), collapse = ", ")))

# Create DESeq2 object
cat("\nCreating DESeq2 object...\n")
colData <- metadata
rowData <- annotation[rownames(counts), ]

dds <- DESeqDataSetFromMatrix(
  countData = counts,
  colData = colData,
  design = formula(paste("~", group_col))
)

# Set reference level (control should be ref)
# Try common control labels
control_label <- NA
for (label in c("Control", "control", "WT", "wt", "Normal", "normal")) {
  if (label %in% unique(dds[[group_col]])) {
    control_label <- label
    break
  }
}

if (!is.na(control_label)) {
  dds[[group_col]] <- factor(dds[[group_col]], levels = c(control_label, 
                                                            setdiff(unique(dds[[group_col]]), control_label)))
  cat(sprintf("Reference level set to: %s\n", control_label))
}

# Pre-filtering: remove genes with very low counts
keep <- rowSums(counts(dds)) >= 10
dds <- dds[keep, ]
cat(sprintf("After filtering (>=10 counts): %d genes\n", nrow(dds)))

# Run DESeq2
cat("\nRunning DESeq2 analysis...\n")
dds <- DESeq(dds)

# Get results
cat("Extracting results...\n")
res <- results(dds, contrast = c(group_col, 
                                  setdiff(unique(dds[[group_col]]), control_label)[1],
                                  control_label))

# Add gene information
res_df <- data.frame(res)
res_df$gene_id <- rownames(res)
res_df$gene_name <- annotation[rownames(res), "gene_name"]
res_df$biotype <- annotation[rownames(res), "biotype"]

# Reorder columns
res_df <- res_df[, c("gene_id", "gene_name", "biotype", "baseMean", "log2FoldChange", 
                      "lfcSE", "stat", "pvalue", "padj")]

# Remove rows with NA padj
res_df <- res_df[!is.na(res_df$padj), ]

# Sort by adjusted p-value
res_df <- res_df[order(res_df$padj), ]

# Identify ncRNAs
ncRNA_keywords <- c("lncrna", "lnc_rna", "mirna", "mir", "snorna", "snoRNA", 
                    "snrna", "antisense", "misc_rna", "rrna", "ncrna", "pseudogene", 
                    "scarna", "vault_rna", "srna")

is_ncrna <- tolower(res_df$biotype) %in% tolower(ncRNA_keywords) | 
            grepl(paste(ncRNA_keywords, collapse = "|"), tolower(res_df$biotype))

cat(sprintf("\nResults:\n"))
cat(sprintf("  Total genes tested: %d\n", nrow(res_df)))
cat(sprintf("  ncRNAs identified: %d\n", sum(is_ncrna, na.rm = TRUE)))
cat(sprintf("  Significant (FDR < 0.05): %d\n", sum(res_df$padj < 0.05, na.rm = TRUE)))
cat(sprintf("  Significant ncRNAs (FDR < 0.05): %d\n", 
            sum(is_ncrna & res_df$padj < 0.05, na.rm = TRUE)))

# Save results
cat(sprintf("\nSaving results to %s/\n", output_dir))

# Create output directory
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

# Save all results
all_results_file <- file.path(output_dir, "all_de_results.csv")
write.csv(res_df, all_results_file, row.names = FALSE)
cat(sprintf("  ✓ All results: %s\n", all_results_file))

# Save ncRNA results
ncrna_results <- res_df[is_ncrna, ]
if (nrow(ncrna_results) > 0) {
  ncrna_file <- file.path(output_dir, "ncrna_de_results.csv")
  write.csv(ncrna_results, ncrna_file, row.names = FALSE)
  cat(sprintf("  ✓ ncRNA results: %s\n", ncrna_file))
}

# Save significant ncRNA biomarkers
significant_ncrna <- ncrna_results[ncrna_results$padj < 0.05, ]
if (nrow(significant_ncrna) > 0) {
  biomarkers_file <- file.path(output_dir, "ncrna_biomarkers.csv")
  write.csv(significant_ncrna, biomarkers_file, row.names = FALSE)
  cat(sprintf("  ✓ ncRNA biomarkers (FDR<0.05): %s\n", biomarkers_file))
}

cat("\n✓ DESeq2 analysis complete!\n")
