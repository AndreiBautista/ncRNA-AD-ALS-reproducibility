"""
GEO integration utilities for the ncRNA pipeline.

Provides:
- fetch_geo: download and parse GEO (GSE) into counts, metadata, annotation
- run_pipeline_on_gse: end-to-end wrapper that runs the existing pipeline

This module is best-effort: GEO studies vary in format. It attempts series_matrix first,
then GSM tables, then supplementary files. It coerces counts to numeric and fills missing values.
"""
import os
import re
import logging
from pathlib import Path
from typing import Optional, Tuple

import pandas as pd
import numpy as np

try:
 import GEOparse
except Exception as e:
 raise ImportError("GEOparse is required: pip install GEOparse") from e

# Import pipeline modules
from pipeline import processing, de_analysis, visualization

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)


def _safe_read_table(path: str) -> pd.DataFrame:
 """Read a delimited table with common separators. Returns DataFrame."""
 if not os.path.exists(path):
 raise FileNotFoundError(path)
 for sep in [',', '\t', ';', '\s+']:
 try:
 df = pd.read_csv(path, sep=sep, engine='python', header=0)
 if df.shape[1] > 1:
 return df
 except Exception:
 continue
 return pd.read_csv(path, engine='python')


def _coerce_counts(df: pd.DataFrame) -> pd.DataFrame:
 """Coerce DataFrame values to numeric counts; fill NAs with zeros."""
 df = df.copy()
 # Attempt to convert all non-index columns to numeric
 for c in df.columns:
 try:
 df[c] = pd.to_numeric(df[c], errors='coerce')
 except Exception:
 df[c] = pd.to_numeric(df[c].astype(str).str.replace('[^0-9\.eE\-]', '', regex=True), errors='coerce')
 df = df.fillna(0)
 return df


def fetch_geo(gse_id: str, out_dir: str = 'results', annotate_gpl: bool = True) -> Tuple[pd.DataFrame, pd.DataFrame, Optional[pd.DataFrame]]:
 """
 Download and parse a GEO Series (GSE) into (counts_df, metadata_df, annot_df).

 Returns:
 counts_df: DataFrame indexed by gene id (rows) with sample columns
 metadata_df: DataFrame indexed by sample name with metadata columns
 annot_df: Optional DataFrame indexed by gene id with gene_name/biotype if available

 This function tries, in order: series_matrix table, per-GSM tables, supplementary files.
 """
 out_dir = Path(out_dir) / gse_id
 out_dir.mkdir(parents=True, exist_ok=True)
 logger.info('Fetching %s into %s', gse_id, out_dir)

 gse = GEOparse.get_GEO(geo=gse_id, destdir=str(out_dir), annotate_gpl=annotate_gpl)

 counts_df = None
 annot_df = None

 # 1) Try series_matrix parsed table
 if hasattr(gse, 'table') and isinstance(gse.table, pd.DataFrame) and not gse.table.empty:
 logger.info('Using series_matrix table for counts')
 counts_df = gse.table.copy()
 # Often the first column is ID_REF or ID
 if counts_df.columns[0].lower() in ('id_ref', 'id', 'probe_id'):
 counts_df = counts_df.set_index(counts_df.columns[0])
 else:
 counts_df = counts_df.set_index(counts_df.columns[0])

 # 2) Try assembling from GSM tables
 if counts_df is None:
 logger.info('Attempting to assemble counts from GSM tables')
 gsm_tables = []
 sample_names = []
 for gsm_name, gsm in gse.gsms.items():
 try:
 t = gsm.table
 # prefer columns named VALUE, value, or last column as numeric
 if 'VALUE' in t.columns:
 series = t.set_index(t.columns[0])['VALUE']
 elif 'value' in t.columns:
 series = t.set_index(t.columns[0])['value']
 else:
 # take last column
 series = t.set_index(t.columns[0]).iloc[:, -1]
 series.name = gsm_name
 gsm_tables.append(series)
 sample_names.append(gsm_name)
 except Exception:
 continue
 if gsm_tables:
 counts_df = pd.concat(gsm_tables, axis=1)

 # 3) Try supplementary files
 if counts_df is None:
 logger.info('No table found; checking supplementary files in %s', out_dir)
 # download supplementary files if present
 try:
 gse.download_supplementary_files(destdir=str(out_dir))
 except Exception:
 pass
 # search for plausible count files
 candidates = list(out_dir.rglob('*'))
 count_files = [p for p in candidates if p.suffix.lower() in ('.txt', '.csv', '.tsv') and re.search(r'count|count_matrix|raw|matrix', p.name, re.I)]
 if count_files:
 for p in count_files:
 try:
 df = _safe_read_table(str(p))
 if df.shape[1] > 1:
 counts_df = df.set_index(df.columns[0])
 logger.info('Loaded counts from supplementary file %s', p.name)
 break
 except Exception:
 continue

 if counts_df is None:
 raise RuntimeError(f'Could not locate expression/count matrix for {gse_id}.')

 # Coerce to numeric counts and clean sample names
 counts_df.index = counts_df.index.astype(str)
 counts_df.columns = [str(c).strip() for c in counts_df.columns]
 counts_df = _coerce_counts(counts_df)

 # Build metadata from GSMs
 meta_rows = []
 for gsm_name, gsm in gse.gsms.items():
 row = {
 'sample': gsm_name,
 'title': gsm.metadata.get('title', [''])[0] if gsm.metadata.get('title') else '',
 'source_name_ch1': gsm.metadata.get('source_name_ch1', [''])[0] if gsm.metadata.get('source_name_ch1') else '',
 'description': gsm.metadata.get('description', [''])[0] if gsm.metadata.get('description') else ''
 }
 # characteristics_ch1 often includes 'condition: Disease' etc. Flatten into fields
 chars = gsm.metadata.get('characteristics_ch1', [])
 for c in chars:
 if ':' in c:
 k, v = [x.strip() for x in c.split(':', 1)]
 # sanitize key
 k = re.sub(r'[^0-9A-Za-z_]', '_', k)
 row[k] = v
 meta_rows.append(row)
 if meta_rows:
 metadata_df = pd.DataFrame(meta_rows).set_index('sample')
 else:
 # fallback: try to use columns of counts as sample list
 metadata_df = pd.DataFrame(index=counts_df.columns)

 # Try to build annotation from GPL (platform) if available
 if gse.gpls and annotate_gpl:
 # use first platform
 try:
 first_gpl = next(iter(gse.gpls.values()))
 gpl_table = first_gpl.table
 if 'GENE' in gpl_table.columns or 'Gene Symbol' in gpl_table.columns or 'Gene symbol' in gpl_table.columns:
 # attempt to build mapping
 gene_name_cols = [c for c in gpl_table.columns if re.search(r'gene|symbol|gene_symbol', c, re.I)]
 gid_col = gpl_table.columns[0]
 annot_df = pd.DataFrame({
 'gene_name': gpl_table[gene_name_cols[0]].astype(str) if gene_name_cols else pd.Series('', index=gpl_table.index)
 }, index=gpl_table[gid_col].astype(str))
 else:
 annot_df = None
 except Exception:
 annot_df = None
 else:
 annot_df = None

 return counts_df, metadata_df, annot_df


def run_pipeline_on_gse(gse_id: str,
 results_base: str = 'results',
 group_col_hint: Optional[str] = None,
 disease_label: Optional[str] = None,
 control_label: Optional[str] = None,
 top_n: int = 50,
 pseudocount: float = 1.0):
 """
 End-to-end: fetch GEO, prepare files, run the ncRNA pipeline and save results.

 Outputs saved under `results/<GSE_ID>/`:
 counts.csv, metadata.csv, differential_results.csv, heatmap.png, violin_plots.png
 """
 base = Path(results_base) / gse_id
 base.mkdir(parents=True, exist_ok=True)

 counts_df, metadata_df, annot_df = fetch_geo(gse_id, out_dir=results_base)

 # Save raw parsed outputs
 counts_path = base / 'counts.csv'
 metadata_path = base / 'metadata.csv'
 counts_df.to_csv(counts_path)
 metadata_df.to_csv(metadata_path)
 logger.info('Saved counts -> %s', counts_path)
 logger.info('Saved metadata -> %s', metadata_path)

 # Attempt to detect a grouping column
 group_col = None
 if group_col_hint and group_col_hint in metadata_df.columns:
 group_col = group_col_hint
 else:
 candidates = [c for c in metadata_df.columns if re.search(r'group|condition|status|phenotype|disease|case', c, re.I)]
 if candidates:
 group_col = candidates[0]

 if group_col is None:
 raise RuntimeError('Could not find a grouping column in metadata. Provide group_col_hint or adjust metadata.')

 if disease_label is None or control_label is None:
 # Attempt to infer disease/control labels from unique values
 vals = metadata_df[group_col].astype(str).unique()
 if len(vals) >= 2:
 # choose the two most frequent values as disease/control
 vc = metadata_df[group_col].astype(str).value_counts()
 control_label = vc.index[-1] if control_label is None else control_label
 disease_label = vc.index[0] if disease_label is None else disease_label
 else:
 raise RuntimeError('Need at least two groups in metadata to infer disease/control labels.')

 # Align columns to metadata index
 common_samples = [s for s in counts_df.columns if s in metadata_df.index]
 if not common_samples:
 # Attempt safe name matching (strip non-alphanum)
 meta_idx = metadata_df.index.astype(str).str.replace(r'[^A-Za-z0-9_\-\.]', '', regex=True)
 col_idx = pd.Index([str(c).replace(' ', '') for c in counts_df.columns])
 mapping = {}
 for orig_col in counts_df.columns:
 key = str(orig_col).replace(' ', '')
 matches = meta_idx[meta_idx == key]
 if len(matches):
 mapping[orig_col] = metadata_df.index[meta_idx == key][0]
 if mapping:
 counts_df = counts_df.rename(columns=mapping)
 common_samples = [s for s in counts_df.columns if s in metadata_df.index]

 if not common_samples:
 raise RuntimeError('No overlapping sample names between counts and metadata after heuristics.')

 counts_df = counts_df[common_samples]

 # Proceed with pipeline
 if annot_df is None:
 # if annotation missing, create minimal annot with gene_id as index
 annot_df = pd.DataFrame({'gene_name': counts_df.index}, index=counts_df.index)

 # Filter to non-coding
 nc_counts = processing.filter_noncoding_genes(counts_df, annot_df, allow_missing=True)
 if nc_counts.empty:
 raise RuntimeError('No non-coding genes found after filtering.')

 logcpm = processing.log2_cpm(nc_counts, pseudocount=pseudocount)

 res = de_analysis.differential_expression(logcpm, metadata_df, group_col, disease_label, control_label)
 res = de_analysis.adjust_pvalues(res)

 # Save differential results
 diff_path = base / 'differential_results.csv'
 out_csv, merged = de_analysis.save_results(res, annot_df, str(base / 'differential'))
 # save_results already writes <out_prefix>_differential_results.csv; ensure file moved to standard name
 try:
 merged.to_csv(diff_path)
 except Exception:
 merged.to_csv(str(diff_path))
 logger.info('Saved differential results -> %s', diff_path)

 # Top genes
 top_genes = merged.sort_values(['fdr', 'pvalue']).index[:top_n].tolist()

 # Heatmap
 heatmap_out = base / 'heatmap.png'
 visualization.heatmap_top_genes(logcpm, top_genes, metadata_df, group_col, str(heatmap_out))
 logger.info('Saved heatmap -> %s', heatmap_out)

 # Box/violin plots for top genes
 try:
 import matplotlib.pyplot as plt
 import seaborn as sns

 violin_out = base / 'violin_top_genes.png'
 sel = logcpm.loc[logcpm.index.intersection(top_genes)]
 if not sel.empty:
 # melt for seaborn
 dfm = sel.reset_index().melt(id_vars=sel.index.name or 'gene_id', var_name='sample', value_name='log2CPM')
 dfm = dfm.rename(columns={dfm.columns[0]: 'gene'})
 dfm['group'] = dfm['sample'].map(metadata_df[group_col].astype(str))
 g = sns.catplot(data=dfm, x='group', y='log2CPM', col='gene', kind='violin', sharey=False, col_wrap=4)
 plt.tight_layout()
 plt.savefig(violin_out, dpi=150)
 plt.close()
 logger.info('Saved violin plots -> %s', violin_out)
 except Exception as e:
 logger.warning('Could not create violin plots: %s', e)

 return {
 'counts': str(counts_path),
 'metadata': str(metadata_path),
 'differential': str(diff_path),
 'heatmap': str(heatmap_out)
 }
