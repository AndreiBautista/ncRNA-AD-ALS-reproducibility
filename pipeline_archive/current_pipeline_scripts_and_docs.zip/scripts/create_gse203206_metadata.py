#!/usr/bin/env python
# Create metadata for GSE203206 based on sample name prefixes

import pandas as pd

# Read just the header to get sample names
with open('GSE203206_Subramaniam.ADRC_brain.counts.tsv', 'r') as f:
 header = f.readline().strip().split('\t')

# Extract sample names (skip first empty column)
samples = header[1:]

# Create metadata based on prefix
metadata = []
for sample in samples:
 prefix = sample.split('_')[0]
 if prefix == 'C':
 condition = 'Control'
 elif prefix in ['E', 'L']:
 condition = 'Disease' # E and L are both disease samples
 else:
 condition = 'Unknown'
 
 metadata.append({
 'sample': sample,
 'condition': condition,
 'prefix': prefix
 })

# Convert to DataFrame and save
df = pd.DataFrame(metadata)
df.to_csv('GSE203206_metadata.csv', index=False)

print(f"✓ Created metadata for {len(samples)} samples")
print(f" Control: {len(df[df['condition']=='Control'])}")
print(f" Disease: {len(df[df['condition']=='Disease'])}")
print(f"\nSaved to: GSE203206_metadata.csv")
