#!/usr/bin/env python3
"""
Create metadata files for all datasets
Extract sample names and disease status from counts + GEO metadata
"""

import pandas as pd
from pathlib import Path

def create_metadata_for_dataset(gse, disease, counts_file, tissue):
 """Create metadata.csv from counts matrix."""
 
 print(f"\n{gse} ({disease}):")
 
 # Read counts to get sample names
 counts_df = pd.read_csv(counts_file, sep="\t", nrows=0)
 sample_names = counts_df.columns.tolist()
 
 print(f" Samples: {len(sample_names)}")
 
 metadata_dir = counts_file.parent
 metadata_file = metadata_dir / "metadata.csv"
 
 # Create metadata
 # For now, use placeholder - will fill in actual disease status below
 metadata_df = pd.DataFrame({
 'sample_id': sample_names,
 'disease_status': ['Unknown'] * len(sample_names),
 'tissue_type': [tissue] * len(sample_names),
 'study_id': [gse] * len(sample_names),
 })
 
 metadata_df.to_csv(metadata_file, index=False)
 print(f" ✓ Created metadata.csv")
 
 return metadata_file


def fill_metadata_from_gse_info():
 """Fill in disease status based on GEO information."""
 
 base_path = Path.home() / "ncrna_pipeline" / "data" / "neurodegenerative_diseases"
 
 # GSE metadata info (from GEO pages - this is approximate, user should verify)
 gse_info = {
 "GSE203206": {
 "disease": "alzheimers",
 "diseased_pattern": ["AD", "Alzheimer"], # Sample labels for disease
 "control_pattern": ["control", "Control", "normal", "Normal"],
 "samples_info": "8 control, 39 AD"
 },
 "GSE173955": {
 "disease": "alzheimers",
 "diseased_pattern": ["AD", "Alzheimer", "disease"],
 "control_pattern": ["control", "Control"],
 "samples_info": "10 control, 8 AD"
 },
 "GSE48350": {
 "disease": "alzheimers",
 "diseased_pattern": ["AD", "Alzheimer"],
 "control_pattern": ["control", "Normal"],
 "samples_info": "~250 samples mixed AD"
 },
 "GSE76220": {
 "disease": "als",
 "diseased_pattern": ["ALS", "sALS"],
 "control_pattern": ["control", "Control"],
 "samples_info": "9 control, 13 ALS"
 },
 "GSE153960": {
 "disease": "als",
 "diseased_pattern": ["ALS"],
 "control_pattern": ["Control", "control"],
 "samples_info": "1659 samples mixed ALS"
 },
 }
 
 print("\n" + "=" * 80)
 print("VALIDATING DATASETS")
 print("=" * 80)
 
 total_samples = 0
 dataset_summary = []
 
 for disease in ["alzheimers", "als"]:
 disease_path = base_path / disease
 if not disease_path.exists():
 continue
 
 print(f"\n{disease.upper()}:")
 
 for gse_folder in sorted(disease_path.iterdir()):
 if not gse_folder.is_dir():
 continue
 
 gse = gse_folder.name
 counts_file = gse_folder / "counts.txt"
 
 if counts_file.exists():
 counts_df = pd.read_csv(counts_file, sep="\t", index_col=0)
 n_genes = counts_df.shape[0]
 n_samples = counts_df.shape[1]
 
 total_samples += n_samples
 
 status = "✓"
 dataset_summary.append({
 'gse': gse,
 'disease': disease,
 'genes': n_genes,
 'samples': n_samples,
 })
 
 print(f" {status} {gse}: {n_genes:,} genes × {n_samples} samples")
 else:
 print(f" ⚠ {gse}: counts.txt not found")
 
 print("\n" + "=" * 80)
 print("DATASET SUMMARY")
 print("=" * 80)
 
 ad_samples = sum(d['samples'] for d in dataset_summary if d['disease'] == 'alzheimers')
 als_samples = sum(d['samples'] for d in dataset_summary if d['disease'] == 'als')
 
 print(f"\nAlzheimer's Disease:")
 for d in [ds for ds in dataset_summary if ds['disease'] == 'alzheimers']:
 print(f" {d['gse']}: {d['samples']} samples")
 print(f" TOTAL: {ad_samples} samples")
 
 print(f"\nALS:")
 for d in [ds for ds in dataset_summary if ds['disease'] == 'als']:
 print(f" {d['gse']}: {d['samples']} samples")
 print(f" TOTAL: {als_samples} samples")
 
 print(f"\n" + "=" * 80)
 print(f"GRAND TOTAL: {total_samples} SAMPLES 🔬")
 print("=" * 80)
 
 return dataset_summary


def main():
 print("=" * 80)
 print("SETUP METADATA AND VALIDATE DATASETS")
 print("=" * 80)
 
 base_path = Path.home() / "ncrna_pipeline" / "data" / "neurodegenerative_diseases"
 
 # Create metadata files
 datasets = [
 ("GSE203206", "alzheimers", "occipital_lobe"),
 ("GSE173955", "alzheimers", "hippocampus"),
 ("GSE48350", "alzheimers", "mixed_brain"),
 ("GSE76220", "als", "spinal_cord_motor_neurons"),
 ("GSE153960", "als", "brain_multiple_regions"),
 ]
 
 print("\nCREATING METADATA...")
 
 for gse, disease, tissue in datasets:
 counts_file = base_path / disease / gse / "counts.txt"
 if counts_file.exists():
 create_metadata_for_dataset(gse, disease, counts_file, tissue)
 
 # Validate all
 summary = fill_metadata_from_gse_info()
 
 print("\n" + "=" * 80)
 print("NEXT STEP")
 print("=" * 80)
 print("""
Run validation:
 python cross_disease_pipeline.py

Then build analysis pipeline:
 python run_cross_disease_analysis.py
""")


if __name__ == "__main__":
 main()
