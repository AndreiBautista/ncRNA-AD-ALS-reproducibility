#!/usr/bin/env python3
"""
Simple standalone script to test visualization and generate plots
"""
import matplotlib
matplotlib.use('Agg') # Non-interactive backend
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np
from pathlib import Path

# Load the CSV that was already created
csv_file = 'results/GSE33000_analysis/per_dataset/local_differential_results.csv'
print(f"Loading {csv_file}...")
df = pd.read_csv(csv_file, index_col=0)

print(f"Loaded {df.shape[0]} genes")
print(f"Columns: {df.columns.tolist()}")

# Create volcano plot
print("\n1. Creating volcano plot...")
df_copy = df.copy()
df_copy['negLog10FDR'] = -np.log10(df_copy['fdr'].replace(0, 1e-300))

plt.figure(figsize=(6, 5))
sns.scatterplot(x='log2FC', y='negLog10FDR', data=df_copy, hue='significant', palette={True: 'red', False: 'grey'}, legend=False)
plt.axhline(-np.log10(0.05), color='black', linestyle='--', linewidth=0.7)
plt.xlabel('log2FC (disease - control)')
plt.ylabel('-log10(FDR)')
plt.title('Volcano Plot')
plt.tight_layout()
volcano_path = 'results/GSE33000_analysis/per_dataset/local_volcano_fixed.png'
plt.savefig(volcano_path, dpi=300, bbox_inches='tight')
plt.close()
print(f" ✓ Saved: {volcano_path}")

print("\nDone! Check the PNG files in results/GSE33000_analysis/per_dataset/")
