#!/usr/bin/env python3
"""
Extract expression counts from GSE48350 series_matrix file
Parse and organize for analysis
"""

import gzip
import pandas as pd
from pathlib import Path

def parse_gse48350():
 """Parse GSE48350 series matrix to extract expression data."""
 
 downloads = Path.home() / "Downloads"
 series_matrix = downloads / "GSE48350_series_matrix.txt.gz"
 
 print("=" * 80)
 print("EXTRACTING GSE48350")
 print("=" * 80)
 
 if not series_matrix.exists():
 print(f"✗ File not found: {series_matrix}")
 return False
 
 print(f"\nParsing: {series_matrix.name}")
 print("Size: 57 MB (will take a moment...)\n")
 
 try:
 # Read the gzipped file
 with gzip.open(series_matrix, 'rt', encoding='utf-8', errors='ignore') as f:
 lines = f.readlines()
 
 print(f"Total lines read: {len(lines)}")
 
 # Find where expression data starts
 # Series matrix format has !Series metadata, then expression data
 expression_start = 0
 for i, line in enumerate(lines):
 if line.startswith('"ID_REF"') or line.startswith('ID_REF'):
 expression_start = i
 print(f"Found header at line {i}")
 print(f"Header: {line[:100]}...")
 break
 
 if expression_start == 0:
 print("✗ Could not find expression data header")
 # Try looking for any tab-separated data
 for i in range(len(lines)-1, max(0, len(lines)-1000), -1):
 if '\t' in lines[i] and not lines[i].startswith('!'):
 print(f"Trying from line {i}")
 expression_start = i - 100
 break
 
 # Parse expression data
 data_lines = [l.strip() for l in lines[expression_start:] if l.strip() and not l.startswith('!')]
 
 if len(data_lines) < 2:
 print("✗ Could not parse expression data")
 return False
 
 # Parse header and data
 header = data_lines[0].split('\t')
 sample_names = [h.strip('"') for h in header[1:]]
 
 print(f"Samples found: {len(sample_names)}")
 print(f"First few samples: {sample_names[:5]}")
 
 # Parse expression rows
 expression_data = {}
 for line in data_lines[1:]:
 parts = line.split('\t')
 if len(parts) > 1:
 gene_id = parts[0].strip('"')
 try:
 values = [float(v) for v in parts[1:]]
 if len(values) == len(sample_names):
 expression_data[gene_id] = values
 except:
 pass
 
 print(f"Genes extracted: {len(expression_data)}")
 
 if len(expression_data) < 100:
 print("✗ Too few genes extracted")
 return False
 
 # Create DataFrame
 expr_df = pd.DataFrame(expression_data).T
 expr_df.columns = sample_names
 
 print(f"✓ Expression data shape: {expr_df.shape}")
 
 # Save to destination
 dest_folder = Path.home() / "ncrna_pipeline" / "data" / "neurodegenerative_diseases" / "alzheimers" / "GSE48350"
 dest_folder.mkdir(parents=True, exist_ok=True)
 
 output_file = dest_folder / "counts.txt"
 expr_df.to_csv(output_file, sep="\t")
 
 print(f"✓ Saved to {output_file}")
 print(f" Genes: {expr_df.shape[0]}")
 print(f" Samples: {expr_df.shape[1]}")
 
 return True
 
 except Exception as e:
 print(f"✗ Error: {e}")
 import traceback
 traceback.print_exc()
 return False


def main():
 print("\nAttempting to extract GSE48350...\n")
 success = parse_gse48350()
 
 if success:
 print("\n" + "=" * 80)
 print("SUCCESS!")
 print("=" * 80)
 print("""
GSE48350 (AD, 253 samples) is now ready!

Next: Create metadata CSV and validate

Expected final Alzheimer's dataset:
 - GSE203206: 47 samples
 - GSE173955: 63 samples
 - GSE48350: 253 samples
 - TOTAL: 363 samples ✓ EXCELLENT

Then proceed with ALS (1,659 samples) and analysis pipeline!
""")
 else:
 print("\n✗ Could not extract GSE48350")
 print("Alternative: We can still proceed with the 110 AD samples we have")

if __name__ == "__main__":
 main()
