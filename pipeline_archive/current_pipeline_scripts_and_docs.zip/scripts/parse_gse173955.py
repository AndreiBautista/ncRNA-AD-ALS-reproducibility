#!/usr/bin/env python3
"""
Parse GSE173955 series_matrix.txt format into separate counts and metadata files
Correctly handles tab-separated columns with multiple values
"""

import pandas as pd
import os

series_matrix_file = 'GSE173955_series_matrix.txt'
output_dir = 'data/alzheimers/human/raw_datasets/GSE173955'

os.makedirs(output_dir, exist_ok=True)

print("Parsing GSE173955 series_matrix.txt...")

samples = []
sample_phenotype = {}
data = {}

with open(series_matrix_file, 'r', encoding='utf-8', errors='ignore') as f:
 lines = f.readlines()

# Extract sample titles to determine disease status
for i, line in enumerate(lines):
 if line.startswith('!Sample_title'):
 # Parse sample titles
 parts = line.rstrip().split('\t')
 samples = parts[1:] # Remove '!Sample_title'
 
 # Determine phenotype from title
 for sample in samples:
 sample = sample.strip('"')
 if 'Alzheimer' in sample or 'Disease' in sample:
 sample_phenotype[sample] = 'Disease'
 else:
 sample_phenotype[sample] = 'Control'
 
 print(f"Found {len(samples)} samples")
 print(f" Disease: {sum(1 for p in sample_phenotype.values() if p == 'Disease')}")
 print(f" Control: {sum(1 for p in sample_phenotype.values() if p == 'Control')}")
 break

# Extract expression data from table
print("Extracting expression data...")
in_table = False
gene_count = 0

for i, line in enumerate(lines):
 if '!series_matrix_table_begin' in line:
 in_table = True
 continue
 
 if '!series_matrix_table_end' in line:
 break
 
 if in_table:
 if line.startswith('"ID_REF"'):
 continue
 
 if line.strip().startswith('"') and not line.startswith('!'):
 parts = line.rstrip().split('\t')
 if len(parts) > 1:
 gene_id = parts[0].strip('"')
 try:
 values = []
 for j in range(1, len(samples) + 1):
 val = float(parts[j].strip('"'))
 values.append(val)
 
 if values: # Only store if we got values
 data[gene_id] = values
 gene_count += 1
 except (ValueError, IndexError):
 continue

print(f"Extracted {gene_count} genes")

if not samples or not data:
 print("ERROR: No samples or data extracted!")
 exit(1)

# Create counts DataFrame
sample_names = [s.strip('"') for s in samples]
counts_df = pd.DataFrame(data, index=sample_names).T
counts_df.index.name = 'gene_id'
counts_file = os.path.join(output_dir, 'counts.tsv')
counts_df.to_csv(counts_file, sep='\t')
print(f"✓ Saved counts to {counts_file}")

# Create metadata DataFrame
metadata_list = []
for sample in sample_names:
 metadata_list.append({
 'sample': sample,
 'phenotype': sample_phenotype.get(sample, 'Control')
 })

metadata_df = pd.DataFrame(metadata_list).set_index('sample')
metadata_file = os.path.join(output_dir, 'metadata.csv')
metadata_df.to_csv(metadata_file)
print(f"✓ Saved metadata to {metadata_file}")

print(f"\nSummary:")
print(f" Samples: {len(sample_names)}")
print(f" Genes: {gene_count}")
print(f" Disease: {(metadata_df['phenotype'] == 'Disease').sum()}")
print(f" Control: {(metadata_df['phenotype'] == 'Control').sum()}")
