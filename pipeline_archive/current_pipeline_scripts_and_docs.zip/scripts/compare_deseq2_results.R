#!/usr/bin/env Rscript
# Compare DESeq2 results across datasets and export top genes.
#
# Usage:
#   Rscript scripts/compare_deseq2_results.R --input res_AD.csv,res_PD.csv,res_FTD.csv --labels AD,PD,FTD --outdir results/compare
#
# Expected input columns:
#   - log2FoldChange
#   - padj
#   - gene (or row names if gene column missing)

suppressWarnings(suppressMessages({
  library(optparse)
  library(dplyr)
  library(readr)
  library(tibble)
  library(VennDiagram)
  library(grid)
}))

option_list <- list(
  make_option(c("-i", "--input"), type = "character", help = "Comma-separated list of DESeq2 result CSVs"),
  make_option(c("-l", "--labels"), type = "character", help = "Comma-separated dataset labels matching inputs"),
  make_option(c("-o", "--outdir"), type = "character", default = "results/compare", help = "Output directory"),
  make_option(c("--padj"), type = "double", default = 0.1, help = "Adjusted p-value cutoff"),
  make_option(c("--lfc"), type = "double", default = 0.5, help = "Absolute log2 fold-change cutoff"),
  make_option(c("--top_n"), type = "integer", default = 20, help = "Top N genes per direction"),
  make_option(c("--venn"), type = "logical", default = TRUE, help = "Create a Venn diagram (2-3 datasets only)")
)

parser <- OptionParser(option_list = option_list)
args <- parse_args(parser)

if (is.null(args$input)) {
  stop("--input is required")
}

inputs <- strsplit(args$input, ",")[[1]]
inputs <- trimws(inputs)
labels <- if (!is.null(args$labels)) trimws(strsplit(args$labels, ",")[[1]]) else NULL

if (is.null(labels)) {
  labels <- tools::file_path_sans_ext(basename(inputs))
}

if (length(labels) != length(inputs)) {
  stop("Number of labels must match number of input files")
}

outdir <- args$outdir
if (!dir.exists(outdir)) {
  dir.create(outdir, recursive = TRUE, showWarnings = FALSE)
}

read_res <- function(path) {
  df <- readr::read_csv(path, show_col_types = FALSE)
  if (!("gene" %in% colnames(df))) {
    df <- tibble::rownames_to_column(df, var = "gene")
  }
  df
}

filter_sig <- function(df, padj_cut, lfc_cut) {
  df %>%
    filter(!is.na(padj), !is.na(log2FoldChange)) %>%
    filter(padj < padj_cut, abs(log2FoldChange) > lfc_cut)
}

extract_top <- function(df, top_n, direction) {
  if (direction == "up") {
    df %>% filter(log2FoldChange > 0)
  } else {
    df %>% filter(log2FoldChange < 0)
  } %>%
    arrange(padj) %>%
    head(top_n)
}

sig_sets <- list()
summary_rows <- list()
for (i in seq_along(inputs)) {
  label <- labels[[i]]
  df <- read_res(inputs[[i]])
  sig <- filter_sig(df, args$padj, args$lfc)
  sig_sets[[label]] <- unique(sig$gene)

  up <- extract_top(sig, args$top_n, "up")
  down <- extract_top(sig, args$top_n, "down")

  write_csv(sig, file.path(outdir, paste0(label, "_significant.csv")))
  write_csv(up, file.path(outdir, paste0(label, "_top_up.csv")))
  write_csv(down, file.path(outdir, paste0(label, "_top_down.csv")))

  summary_rows[[label]] <- tibble(
    dataset = label,
    significant_genes = nrow(sig),
    padj_cutoff = args$padj,
    log2fc_cutoff = args$lfc,
    top_n = args$top_n
  )

  message(sprintf("%s: %d significant genes", label, nrow(sig)))
}

summary_df <- bind_rows(summary_rows)
summary_path <- file.path(outdir, "summary_stats.csv")
write_csv(summary_df, summary_path)

if (length(sig_sets) >= 2) {
  labels_vec <- names(sig_sets)
  if (length(sig_sets) >= 2) {
    for (i in 1:(length(sig_sets) - 1)) {
      for (j in (i + 1):length(sig_sets)) {
        overlap <- intersect(sig_sets[[i]], sig_sets[[j]])
        overlap_path <- file.path(outdir, paste0(labels_vec[[i]], "_vs_", labels_vec[[j]], "_overlap.csv"))
        write_csv(tibble(gene = overlap), overlap_path)
        message(sprintf("Overlap %s vs %s: %d", labels_vec[[i]], labels_vec[[j]], length(overlap)))
      }
    }
  }

  shared_all <- Reduce(intersect, sig_sets)
  write_csv(tibble(gene = shared_all), file.path(outdir, "shared_all_datasets.csv"))
  message(sprintf("Shared across all: %d", length(shared_all)))
}

if (args$venn && length(sig_sets) >= 2 && length(sig_sets) <= 3) {
  venn_path <- file.path(outdir, "venn_overlap.png")
  png(venn_path, width = 1200, height = 900, res = 150)
  grid.newpage()
  venn.plot <- VennDiagram::venn.diagram(
    x = sig_sets,
    filename = NULL,
    fill = c("#4C78A8", "#F58518", "#54A24B")[seq_along(sig_sets)],
    alpha = 0.5,
    cex = 1.2,
    cat.cex = 1.1,
    main = "Significant Gene Overlap"
  )
  grid.draw(venn.plot)
  dev.off()
  message(sprintf("Venn diagram saved: %s", venn_path))
} else if (args$venn) {
  message("Venn diagram skipped (requires 2-3 datasets).")
}
