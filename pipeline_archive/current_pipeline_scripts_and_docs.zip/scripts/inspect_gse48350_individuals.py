#!/usr/bin/env python3
"""Summarize individual labels in GSE48350 characteristics to infer diagnosis."""

from collections import Counter
from pathlib import Path
import logging

import GEOparse


def main():
 logging.getLogger("GEOparse").setLevel(logging.WARNING)

 out_dir = Path("data/neurodegenerative_diseases/alzheimers/GSE48350/geo")
 out_dir.mkdir(parents=True, exist_ok=True)

 gse = GEOparse.get_GEO("GSE48350", destdir=str(out_dir), annotate_gpl=False)

 labels = []
 examples = []
 for gsm_name, gsm in gse.gsms.items():
 chars = gsm.metadata.get("characteristics_ch1", [])
 individual = None
 for c in chars:
 if c.lower().startswith("individual:"):
 individual = c.split(":", 1)[1].strip()
 break
 if individual:
 parts = [p.strip() for p in individual.split(",")]
 label = parts[-1] if parts else ""
 labels.append(label)
 if len(examples) < 10:
 examples.append((gsm_name, individual, label))

 counter = Counter(labels)
 print("Individual label counts:")
 for val, cnt in counter.most_common():
 print(f"- {val}: {cnt}")

 print("\nExamples:")
 for gsm, individual, label in examples:
 print(gsm, "|", individual, "|", label)


if __name__ == "__main__":
 main()
