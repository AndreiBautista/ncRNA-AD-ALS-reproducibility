#!/usr/bin/env python3
"""
Helper script to organize downloaded datasets from ~/Downloads
Copies counts files and helps you create metadata
"""

import os
import shutil
import gzip
from pathlib import Path
import pandas as pd

DOWNLOADS = Path.home() / "Downloads"
NCRNA_PIPELINE = Path.home() / "ncrna_pipeline"

# ============================================================================
# DATASET INFO - What files to look for in each GSE
# ============================================================================

DATASET_INFO = {
 "alzheimers": {
 "GSE173955": {
 "disease": "alzheimers",
 "tissues": ["hippocampus"],
 "expected_files": ["GSE173955", "counts"],
 "samples_info": "10 controls, 8 disease samples",
 },
 "GSE95587": {
 "disease": "alzheimers", 
 "tissues": ["fusiform_gyrus"],
 "expected_files": ["GSE95587", "counts"],
 "samples_info": "40 controls, 77 disease samples",
 },
 },
 "als": {
 "GSE124439": {
 "disease": "als",
 "tissues": ["motor_cortex"],
 "expected_files": ["GSE124439", "counts"],
 "samples_info": "28 controls, 148 disease samples",
 },
 "GSE116622": {
 "disease": "als",
 "tissues": ["brain"],
 "expected_files": ["GSE116622"],
 "samples_info": "27 controls, 50 disease samples",
 },
 "GSE76220": {
 "disease": "als",
 "tissues": ["motor_neurons_lcm"],
 "expected_files": ["GSE76220"],
 "samples_info": "9 controls, 13 disease samples",
 },
 },
}


def find_files_in_downloads():
 """Find all relevant files in Downloads folder."""
 print("\n" + "=" * 80)
 print("SCANNING DOWNLOADS FOLDER")
 print("=" * 80)
 print(f"\nLooking in: {DOWNLOADS}")

 files_found = {}

 for gse_dict in [DATASET_INFO["alzheimers"], DATASET_INFO["als"]]:
 for gse, info in gse_dict.items():
 print(f"\n{gse}:")

 # Look for files matching this GSE
 matching_files = []
 for item in DOWNLOADS.iterdir():
 if item.is_file() and gse in item.name:
 matching_files.append(item)
 print(f" ✓ Found: {item.name}")

 if gse not in files_found:
 files_found[gse] = []
 files_found[gse].extend(matching_files)

 if len(matching_files) == 0:
 print(f" ⚠ No files found for {gse}")

 return files_found


def organize_file(source_file, gse):
 """Move and organize a file for a GSE dataset."""

 # Find which disease this belongs to
 disease = None
 for d in ["alzheimers", "als"]:
 if gse in DATASET_INFO.get(d, {}):
 disease = d
 break

 if disease is None:
 print(f"✗ Could not determine disease for {gse}")
 return False

 dest_folder = NCRNA_PIPELINE / "data" / "neurodegenerative_diseases" / disease / gse
 dest_folder.mkdir(parents=True, exist_ok=True)

 # Determine output filename
 if "counts" in source_file.name.lower() or "expression" in source_file.name.lower():
 output_name = "counts.txt"
 else:
 output_name = source_file.name

 dest_file = dest_folder / output_name

 # Handle gzipped files
 if source_file.suffix == ".gz":
 print(f" Extracting: {source_file.name}")
 with gzip.open(source_file, "rb") as f_in:
 with open(dest_file, "wb") as f_out:
 f_out.write(f_in.read())
 print(f" ✓ Extracted to: {dest_file}")
 else:
 # Copy file
 shutil.copy2(source_file, dest_file)
 print(f" ✓ Copied to: {dest_file}")

 return True


def create_metadata_template(disease, gse):
 """Create a template metadata.csv for the user to fill in."""

 # Get sample count from info
 info = None
 for d in ["alzheimers", "als"]:
 if gse in DATASET_INFO.get(d, {}):
 info = DATASET_INFO[d][gse]
 break

 if info is None:
 print(f"✗ No info found for {gse}")
 return False

 dest_folder = (
 NCRNA_PIPELINE / "data" / "neurodegenerative_diseases" / disease / gse
 )
 metadata_file = dest_folder / "metadata.csv"

 # Try to read counts.txt to get exact sample names
 counts_file = dest_folder / "counts.txt"
 sample_names = []

 if counts_file.exists():
 try:
 with open(counts_file, "r") as f:
 first_line = f.readline().strip()
 sample_names = first_line.split("\t")
 # First column is usually gene ID, skip it
 if sample_names:
 sample_names = sample_names[1:]
 except Exception as e:
 print(f" ⚠ Could not read sample names from counts.txt: {e}")

 # If we got sample names, use them. Otherwise, create placeholders
 if len(sample_names) == 0:
 # Parse sample count from info string
 info_str = info.get("samples_info", "")
 print(f" ℹ Sample info: {info_str}")
 print(
 f" ⚠ Could not auto-detect sample names - creating template with placeholders"
 )
 print(f" You'll need to edit this manually")

 # Try to extract counts
 try:
 import re

 matches = re.findall(r"(\d+)\s+controls?, (\d+)\s+disease", info_str)
 if matches:
 controls_n, disease_n = int(matches[0][0]), int(matches[0][1])
 sample_names = (
 [f"{gse}_ctrl_{i:02d}" for i in range(1, controls_n + 1)]
 + [f"{gse}_dis_{i:02d}" for i in range(1, disease_n + 1)]
 )
 except Exception as e:
 print(f" Could not parse sample counts: {e}")

 if len(sample_names) > 0:
 disease_status = (
 ["Control"] * (len(sample_names) // 2)
 + ["Disease"] * (len(sample_names) - len(sample_names) // 2)
 )

 metadata_df = pd.DataFrame(
 {
 "sample_id": sample_names,
 "disease_status": disease_status,
 "tissue_type": info.get("tissues", ["unknown"])[0],
 "study_id": [gse] * len(sample_names),
 }
 )

 metadata_df.to_csv(metadata_file, index=False)
 print(f" ✓ Created metadata template: {metadata_file}")
 print(f" IMPORTANT: Edit this file to set correct disease_status!")
 print(f" Rows: {len(metadata_df)}")
 return True

 return False


def main():
 print("=" * 80)
 print("ORGANIZE DOWNLOADED DATASETS")
 print("=" * 80)

 # Find files
 files_found = find_files_in_downloads()

 if len(files_found) == 0:
 print("\n✗ No datasets found in Downloads!")
 print(f"Expected to find files like: GSE173955*, GSE95587*, etc.")
 return

 # Ask user for confirmation
 print("\n" + "=" * 80)
 print("SUMMARY")
 print("=" * 80)

 total_files = sum(len(v) for v in files_found.values())
 print(f"\nFound {total_files} files across {len(files_found)} datasets")

 response = input("\nProceed with organizing these files? (yes/no): ").strip().lower()

 if response not in ["yes", "y"]:
 print("Cancelled.")
 return

 # Organize files
 print("\n" + "=" * 80)
 print("ORGANIZING FILES")
 print("=" * 80)

 for gse, file_list in files_found.items():
 print(f"\n{gse}:")

 for source_file in file_list:
 # Find disease
 disease = None
 for d in ["alzheimers", "als"]:
 if gse in DATASET_INFO.get(d, {}):
 disease = d
 break

 if disease:
 organize_file(source_file, gse)

 # Create metadata template
 create_metadata_template(disease, gse)

 # Final instructions
 print("\n" + "=" * 80)
 print("NEXT STEPS")
 print("=" * 80)
 print("""
1. For each dataset, edit the metadata.csv file:
 - Open: data/neurodegenerative_diseases/[disease]/[GSE]/metadata.csv
 - Edit disease_status column:
 * Set to "Control" for control samples
 * Set to "Disease" for disease samples
 * Look up in GEO paper or phenotypes tab
 
2. Verify counts.txt files are properly formatted:
 - First row: sample names (tab-separated)
 - First column: gene IDs
 - All other values: numeric counts (integers)

3. Run validation:
 python cross_disease_pipeline.py

4. Once validated, tell me and I'll build the analysis pipeline!
""")

 print("\n" + "=" * 80)
 print("COMPLETE!")
 print("=" * 80)


if __name__ == "__main__":
 main()
