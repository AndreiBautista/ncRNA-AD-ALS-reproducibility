#!/usr/bin/env python3
"""
Download and setup the 3 replacement datasets
Much better alternatives that are confirmed working
"""

import subprocess
import gzip
from pathlib import Path

BASE = Path.home() / "ncrna_pipeline"
DATASETS = Path.home() / "Downloads"

print("""
╔════════════════════════════════════════════════════════════════════════════╗
║ DOWNLOADING 3 REPLACEMENT DATASETS (CONFIRMED WORKING) ║
╚════════════════════════════════════════════════════════════════════════════╝

TARGET DATASETS:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

REPLACING GSE95587 (AD, failed) with:
→ GSE125583 (AD, 289 samples - Genentech/Fusiform Gyrus)

REPLACING GSE116622 (ALS splicing only) with:
→ GSE153960 (ALS, 1,838 samples - NYGC massive cohort)

TOTAL WILL BE:
 Alzheimer's: 47 + 63 + 289 = 399 samples ✓ EXCELLENT
 ALS: 11 + 1,838 = 1,849 samples ✓ EXTRAORDINARY
 TOTAL: 2,248 samples - Publication-quality mega-study!

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

DOWNLOADING...
""")

# Create download folder
downloads_folder = BASE / "temp_downloads_replacements"
downloads_folder.mkdir(exist_ok=True)

downloads = [
 {
 "name": "GSE125583 (AD - Genentech)",
 "gse": "GSE125583",
 "disease": "alzheimers",
 "url": "ftp://ftp.ncbi.nlm.nih.gov/geo/series/GSE125nnn/GSE125583/suppl/GSE125583_RAW.tar",
 "type": "tar",
 "size": "87.4 MB",
 },
 {
 "name": "GSE153960 (ALS - NYGC Massive)",
 "gse": "GSE153960",
 "disease": "als",
 "url": "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE153nnn/GSE153960/suppl/GSE153960_Gene_counts_matrix_RSEM_Prudencio_et_al_2020.txt.gz",
 "type": "gz",
 "size": "67.8 MB",
 },
]

for dataset in downloads:
 print(f"\n{'=' * 80}")
 print(f"DOWNLOADING: {dataset['name']}")
 print(f"{'=' * 80}")
 print(f"Size: {dataset['size']}")
 
 dest_file = downloads_folder / f"{dataset['gse']}.{'tar' if dataset['type'] == 'tar' else 'txt.gz'}"
 
 # Use curl to download
 print(f"\nCommand:\ncurl -L -o {dest_file.name} '{dataset['url']}'")
 print("\nPaste this into terminal to download, then tell me when 'File downloaded' appears.\n")

print(f"""
╔════════════════════════════════════════════════════════════════════════════╗
║ QUICK START ║
╚════════════════════════════════════════════════════════════════════════════╝

Run these commands in your terminal:

# Download GSE125583 (87.4 MB)
curl -L -o ~/Downloads/GSE125583_RAW.tar \\
 'ftp://ftp.ncbi.nlm.nih.gov/geo/series/GSE125nnn/GSE125583/suppl/GSE125583_RAW.tar'

# Download GSE153960 (67.8 MB)
curl -L -o ~/Downloads/GSE153960_counts.txt.gz \\
 'https://ftp.ncbi.nlm.nih.gov/geo/series/GSE153nnn/GSE153960/suppl/GSE153960_Gene_counts_matrix_RSEM_Prudencio_et_al_2020.txt.gz'

Wait for both to finish (should be ~5-10 minutes total on normal internet)

Then tell me: "downloads complete" and I'll process them!

Or, if you want me to try downloading directly, let me know and I'll attempt it.
""")
