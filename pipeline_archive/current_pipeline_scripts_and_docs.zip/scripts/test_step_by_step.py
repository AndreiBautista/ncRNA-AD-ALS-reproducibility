#!/usr/bin/env python3
"""Test pipeline step by step"""
from pipeline import io, processing, de_analysis, visualization
import pandas as pd
from pathlib import Path

print("Step 1: Loading counts...")
counts = io.load_counts('GSE33000_counts.txt')
print(f"✓ Loaded {counts.shape[0]} genes × {counts.shape[1]} samples")

print("\nStep 2: Loading metadata...")
meta = io.load_metadata('GSE33000_metadata.txt', 'condition')
print(f"✓ Loaded {meta.shape[0]} samples")
print(f" Conditions: {meta['condition'].unique()}")

print("\nStep 3: Creating dummy annotation...")
annot = pd.DataFrame({'gene_name': counts.index, 'biotype': 'unknown'}, index=counts.index)
print(f"✓ Created annotation for {annot.shape[0]} genes")

print("\nStep 4: Normalizing...")
logcpm = processing.log2_cpm(counts)
print(f"✓ Normalized shape: {logcpm.shape}")

print("\nStep 5: Running DE analysis...")
res = de_analysis.differential_expression(logcpm, meta, 'condition', 'Disease', 'Control')
res = de_analysis.adjust_pvalues(res)
print(f"✓ Tested {res.shape[0]} genes")
sig = (res['fdr'] < 0.05).sum()
print(f" Significant genes: {sig}")

print("\nStep 6: Saving results...")
csv_path, merged = de_analysis.save_results(res, annot, 'test_out')
print(f"✓ Saved to: {csv_path}")

print("\nStep 7: Creating volcano plot...")
outdir = Path('test_results')
outdir.mkdir(exist_ok=True)
volcano_path = str(outdir / 'test_volcano.png')
try:
 visualization.volcano_plot(merged, volcano_path, title='Test')
 print(f"✓ Saved volcano plot: {volcano_path}")
except Exception as e:
 print(f"✗ Error: {e}")

print("\nStep 8: Creating heatmap...")
top_genes = merged.sort_values(['fdr', 'pvalue']).index[:50].tolist()
heatmap_path = str(outdir / 'test_heatmap.png')
try:
 visualization.heatmap_top_genes(logcpm, top_genes, meta, 'condition', heatmap_path)
 print(f"✓ Saved heatmap: {heatmap_path}")
except Exception as e:
 print(f"✗ Error: {e}")

print("\nAll tests completed!")
