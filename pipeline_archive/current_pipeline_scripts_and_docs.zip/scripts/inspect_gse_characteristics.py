#!/usr/bin/env python3
"""Inspect GEO characteristics fields and value counts for a GSE."""

import argparse
from collections import Counter
from pathlib import Path
import logging

import GEOparse


def main():
 parser = argparse.ArgumentParser(description="Inspect GEO characteristics fields")
 parser.add_argument("gse_id", help="GSE accession (e.g., GSE116622)")
 parser.add_argument("--outdir", default="data/neurodegenerative_diseases", help="Download directory")
 parser.add_argument("--max_values", type=int, default=10, help="Max values to show per key")
 args = parser.parse_args()

 logging.getLogger("GEOparse").setLevel(logging.WARNING)

 out_dir = Path(args.outdir) / args.gse_id / "geo"
 out_dir.mkdir(parents=True, exist_ok=True)

 gse = GEOparse.get_GEO(args.gse_id, destdir=str(out_dir), annotate_gpl=False)

 key_counts = {}
 examples = []
 for gsm_name, gsm in gse.gsms.items():
 chars = gsm.metadata.get("characteristics_ch1", [])
 row = []
 for c in chars:
 if ":" in c:
 key, value = [x.strip() for x in c.split(":", 1)]
 key_lower = key.lower()
 key_counts.setdefault(key_lower, Counter())[value] += 1
 row.append(f"{key_lower}: {value}")
 if len(examples) < 5:
 examples.append((gsm_name, row))

 print(f"GSE: {args.gse_id}")
 print(f"Samples: {len(gse.gsms)}")
 print("\nExamples:")
 for gsm_name, row in examples:
 print(f"- {gsm_name}: {', '.join(row)[:200]}")

 print("\nField summaries:")
 for key in sorted(key_counts.keys()):
 values = key_counts[key]
 if len(values) <= 1:
 continue
 print(f"\n{key}:")
 for val, cnt in values.most_common(args.max_values):
 print(f" - {val}: {cnt}")


if __name__ == "__main__":
 main()
