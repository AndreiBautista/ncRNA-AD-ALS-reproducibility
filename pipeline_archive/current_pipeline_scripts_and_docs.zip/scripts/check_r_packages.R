#!/usr/bin/env Rscript
# Check and install R packages for DESeq2 analysis

packages <- c('DESeq2', 'BiocGenerics', 'S4Vectors')
missing <- character()

cat("Checking R packages...\n")
for (pkg in packages) {
  if (!require(pkg, character.only = TRUE, quietly = TRUE)) {
    missing <- c(missing, pkg)
  }
}

if (length(missing) > 0) {
  cat(sprintf("Installing missing packages: %s\n", paste(missing, collapse = ", ")))
  
  if (!require('BiocManager', character.only = TRUE, quietly = TRUE)) {
    install.packages('BiocManager', repos='http://cran.r-project.org')
  }
  
  BiocManager::install(missing, quiet = FALSE, update = FALSE)
  cat("✓ Installation complete\n")
} else {
  cat("✓ All required packages available\n")
}
