#!/usr/bin/env python3
"""Build a counts matrix for GSE125583 from the RAW tar archive."""

import argparse
import tarfile
import gzip
from io import BytesIO
from pathlib import Path

import pandas as pd


def extract_sample_id(name: str) -> str:
 # GSM3577568_sample1.tsv.gz -> GSM3577568
 return name.split("_sample", 1)[0]


def main():
 parser = argparse.ArgumentParser(description="Assemble counts from GSE125583 RAW tar")
 parser.add_argument("tar_path", help="Path to GSE125583_RAW.tar")
 parser.add_argument("output_path", help="Output counts.tsv path")
 args = parser.parse_args()

 tar_path = Path(args.tar_path)
 if not tar_path.exists():
 raise FileNotFoundError(tar_path)

 series_list = []
 with tarfile.open(tar_path, "r") as tar:
 members = [m for m in tar.getmembers() if m.name.endswith(".tsv.gz")]
 members.sort(key=lambda m: m.name)
 for member in members:
 f = tar.extractfile(member)
 if f is None:
 continue
 raw = f.read()
 with gzip.GzipFile(fileobj=BytesIO(raw)) as gz:
 df = pd.read_csv(gz, sep="\t", comment="#")
 if "ID_REF" not in df.columns or "count" not in df.columns:
 continue
 sample_id = extract_sample_id(member.name)
 series = df.set_index("ID_REF")["count"]
 series.name = sample_id
 series_list.append(series)

 if not series_list:
 raise RuntimeError("No samples extracted from tar.")

 counts_df = pd.concat(series_list, axis=1)
 output_path = Path(args.output_path)
 output_path.parent.mkdir(parents=True, exist_ok=True)
 counts_df.to_csv(output_path, sep="\t")
 print("Saved:", output_path)
 print("Shape:", counts_df.shape)


if __name__ == "__main__":
 main()
