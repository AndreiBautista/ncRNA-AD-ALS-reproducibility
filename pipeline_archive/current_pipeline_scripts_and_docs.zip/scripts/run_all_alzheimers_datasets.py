#!/usr/bin/env python3
"""
Path A: Multi-Dataset ncRNA Biomarker Discovery for Alzheimer's Disease
Analyzes 3 human Alzheimer's datasets and identifies conserved ncRNA biomarkers
"""

import os
import pandas as pd
import numpy as np
from pathlib import Path

# Import pipeline modules
from pipeline.io import load_annotation
from pipeline.processing import log2_cpm, filter_noncoding_genes
from pipeline.de_analysis import differential_expression, adjust_pvalues

# Configuration
ANNOTATION_FILE = 'data/annotations/annotation_human.csv'
DATASETS = {
 'GSE203206': {
 'counts': 'data/alzheimers/human/raw_datasets/GSE203206/counts.tsv',
 'metadata': 'data/alzheimers/human/raw_datasets/GSE203206/metadata.csv',
 'group_col': 'condition',
 'disease_label': 'Disease',
 'control_label': 'Control'
 },
 'GSE173955': {
 'counts': 'data/alzheimers/human/raw_datasets/GSE173955/counts.tsv',
 'metadata': 'data/alzheimers/human/raw_datasets/GSE173955/metadata.csv',
 'group_col': 'condition',
 'disease_label': 'Alzheimer\'s Disease',
 'control_label': 'Non-affected'
 },
 'GSE33000': {
 'counts': 'data/alzheimers/human/raw_datasets/GSE33000/counts_ensembl.txt',
 'metadata': 'data/alzheimers/human/raw_datasets/GSE33000/metadata.txt',
 'group_col': 'condition',
 'disease_label': 'Disease',
 'control_label': 'Control'
 }
}

def load_dataset(dataset_name, config):
 """Load counts and metadata for a dataset"""
 try:
 counts = pd.read_csv(config['counts'], sep='\t', index_col=0)
 metadata = pd.read_csv(config['metadata'], index_col=0)
 
 # Align samples
 common_samples = list(set(counts.columns) & set(metadata.index))
 counts = counts[common_samples]
 metadata = metadata.loc[common_samples]
 
 print(f"✓ {dataset_name}: {counts.shape[0]} genes, {counts.shape[1]} samples")
 return counts, metadata
 except Exception as e:
 print(f"✗ {dataset_name}: {str(e)}")
 return None, None

def analyze_dataset(dataset_name, counts, metadata, annotation, config):
 """Analyze single dataset"""
 print(f"\n{'='*60}")
 print(f"Analyzing {dataset_name}")
 print(f"{'='*60}")
 
 # Normalize
 logcpm = log2_cpm(counts)
 
 # Filter to ncRNAs
 nc_counts = filter_noncoding_genes(logcpm, annotation, allow_missing=True)
 print(f" ncRNA genes: {nc_counts.shape[0]}")
 
 # DE analysis
 results = differential_expression(
 nc_counts, 
 metadata, 
 group_col=config['group_col'],
 disease_label=config['disease_label'],
 control_label=config['control_label']
 )
 
 # Adjust p-values for multiple testing
 results = adjust_pvalues(results, method='fdr_bh', alpha=0.01)
 
 # Add annotations
 results['gene_name'] = results.index.map(
 lambda x: annotation.loc[x, 'gene_name'] if x in annotation.index else x
 )
 results['biotype'] = results.index.map(
 lambda x: annotation.loc[x, 'biotype'] if x in annotation.index else 'unknown'
 )
 
 # Significant biomarkers (FDR-adjusted)
 sig = results[(results['fdr'] < 0.01) & (abs(results['log2FC']) > 1.5)]
 print(f" Significant ncRNA biomarkers: {len(sig)}")
 
 return results, sig

def main():
 print("=" * 70)
 print("Path A: Multi-Dataset ncRNA Biomarker Discovery")
 print("Alzheimer's Disease - Human Datasets")
 print("=" * 70)
 
 # Create output directories
 outdir = Path('results/alzheimers/human/multi_dataset_analysis')
 outdir.mkdir(parents=True, exist_ok=True)
 
 # Load annotation
 print("\nLoading annotation...")
 annotation = load_annotation(ANNOTATION_FILE)
 print(f" Loaded {len(annotation)} genes")
 
 # Load and analyze all datasets
 all_results = {}
 all_sig = {}
 dataset_sizes = {}
 
 for dataset_name, config in DATASETS.items():
 counts, metadata = load_dataset(dataset_name, config)
 if counts is None:
 print(f"⚠️ Skipping {dataset_name}")
 continue
 
 dataset_sizes[dataset_name] = counts.shape[1] # number of samples
 results, sig = analyze_dataset(dataset_name, counts, metadata, annotation, config)
 
 all_results[dataset_name] = results
 all_sig[dataset_name] = sig
 
 # Save per-dataset results
 dataset_dir = outdir / dataset_name
 dataset_dir.mkdir(exist_ok=True)
 
 results.to_csv(dataset_dir / 'de_results.csv')
 sig.to_csv(dataset_dir / 'significant_biomarkers.csv')
 
 print(f" ✓ Saved results to {dataset_dir}")
 
 # Cross-dataset analysis
 print(f"\n{'='*60}")
 print("CROSS-DATASET ANALYSIS")
 print(f"{'='*60}")
 
 if len(all_sig) >= 2:
 # Find conserved biomarkers
 all_biomarker_sets = [set(all_sig[ds].index) for ds in all_sig.keys()]
 
 # Biomarkers in all datasets
 conserved_all = all_biomarker_sets[0]
 for bs in all_biomarker_sets[1:]:
 conserved_all = conserved_all.intersection(bs)
 
 # Biomarkers in at least 2 datasets
 conserved_2plus = all_biomarker_sets[0]
 for bs in all_biomarker_sets[1:]:
 conserved_2plus = conserved_2plus.union(bs)
 
 conserved_count = {}
 for gene in conserved_2plus:
 conserved_count[gene] = sum(1 for bs in all_biomarker_sets if gene in bs)
 
 print(f"\nConserved biomarkers found in:")
 for n_datasets in sorted(set(conserved_count.values()), reverse=True):
 genes_in_n = [g for g, n in conserved_count.items() if n == n_datasets]
 print(f" {n_datasets} dataset(s): {len(genes_in_n)} genes")
 if n_datasets >= 2:
 print(f" Examples: {', '.join(genes_in_n[:5])}")
 
 # Summary table
 summary_data = []
 for gene in sorted(conserved_2plus):
 gene_data = {
 'gene_id': gene,
 'gene_name': annotation.loc[gene, 'gene_name'] if gene in annotation.index else gene,
 'biotype': annotation.loc[gene, 'biotype'] if gene in annotation.index else 'unknown',
 'n_datasets': conserved_count[gene]
 }
 
 # Add per-dataset stats
 for ds in all_sig.keys():
 if gene in all_sig[ds].index:
 row = all_sig[ds].loc[gene]
 gene_data[f'{ds}_log2fc'] = row['log2FC']
 gene_data[f'{ds}_fdr'] = row['fdr']
 else:
 gene_data[f'{ds}_log2fc'] = np.nan
 gene_data[f'{ds}_fdr'] = np.nan
 
 summary_data.append(gene_data)
 
 summary_df = pd.DataFrame(summary_data)
 summary_df = summary_df.sort_values('n_datasets', ascending=False)
 summary_df.to_csv(outdir / 'conserved_biomarkers_summary.csv', index=False)
 
 print(f"\n✓ Conserved biomarkers summary saved")
 print(f" Total: {len(summary_df)} genes found in 2+ datasets")
 
 # Print top conserved
 print(f"\nTop Conserved ncRNA Biomarkers:")
 print(summary_df.head(10).to_string())
 
 # Generate summary report
 report_path = outdir / 'MULTI_DATASET_ANALYSIS_REPORT.txt'
 with open(report_path, 'w') as f:
 f.write("=" * 70 + "\n")
 f.write("Multi-Dataset ncRNA Biomarker Analysis - Alzheimer's Disease\n")
 f.write("Path A Framework\n")
 f.write("=" * 70 + "\n\n")
 
 f.write("DATASETS ANALYZED:\n")
 for ds in all_sig.keys():
 f.write(f" {ds}: {dataset_sizes[ds]} samples\n")
 
 f.write("\nBIOMAARKERS PER DATASET:\n")
 for ds in sorted(all_sig.keys()):
 n_sig = len(all_sig[ds])
 f.write(f" {ds}: {n_sig} ncRNA biomarkers\n")
 
 if len(all_sig) >= 2:
 f.write("\nCONSERVED BIOMARKERS (2+ datasets):\n")
 for n_datasets in sorted(set(conserved_count.values()), reverse=True):
 genes_in_n = [g for g, n in conserved_count.items() if n == n_datasets]
 f.write(f" {n_datasets} dataset(s): {len(genes_in_n)} genes\n")
 
 f.write("\nIMPLICATIONS:\n")
 f.write(" Multi-dataset validation demonstrates reproducibility across\n")
 f.write(" independent patient cohorts and experimental batches.\n")
 f.write(" Conserved biomarkers are robust candidates for therapeutic targets.\n")
 
 print(f"\n✓ Analysis complete! Results saved to {outdir}")
 print(f"✓ Report: {report_path}")

if __name__ == '__main__':
 main()
