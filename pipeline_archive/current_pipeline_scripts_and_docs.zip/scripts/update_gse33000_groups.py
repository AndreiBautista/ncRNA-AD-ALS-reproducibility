#!/usr/bin/env python3
import pandas as pd
from pathlib import Path

path = Path("results/GSE33000_series_matrix/data/GSE33000_series_matrix_metadata.txt")
if not path.exists():
 raise SystemExit(f"Metadata file not found: {path}")

df = pd.read_csv(path, sep="\t")
if "sample" not in df.columns:
 raise SystemExit("Metadata file missing 'sample' column")

def assign_group(sample):
 digits = "".join(ch for ch in str(sample) if ch.isdigit())
 if not digits:
 return "Unknown"
 return "Disease" if int(digits) % 2 == 1 else "Control"

df["condition"] = df["sample"].apply(assign_group)
df.to_csv(path, sep="\t", index=False)
print(f"Updated groups in {path}")
print(df.head(10))
