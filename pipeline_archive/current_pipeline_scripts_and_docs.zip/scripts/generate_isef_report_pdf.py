#!/usr/bin/env python3
"""Generate an -ready PDF report with tables and figures."""

from pathlib import Path
import pandas as pd

from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import (
 SimpleDocTemplate,
 Paragraph,
 Spacer,
 Table,
 TableStyle,
 Image,
 PageBreak,
)

from pipeline import processing as proc
from pipeline import de_analysis as de
from scipy import stats

BASE_DIR = Path(__file__).resolve().parent.parent
OUT_PATH = BASE_DIR / "ISEF_REPORT.pdf"

AD_COUNTS_PATH = BASE_DIR / "data" / "alzheimers" / "human" / "raw_datasets" / "GSE203206" / "counts.tsv"
AD_COUNTS_FALLBACK = BASE_DIR / "data" / "alzheimers" / "human" / "raw_datasets" / "GSE203206" / "counts.csv"
AD_META_PATH = BASE_DIR / "data" / "alzheimers" / "human" / "raw_datasets" / "GSE203206" / "metadata.csv"

ALS_COUNTS_PATH = BASE_DIR / "data" / "neurodegenerative_diseases" / "als" / "GSE124439" / "counts.csv"
ALS_META_PATH = BASE_DIR / "data" / "neurodegenerative_diseases" / "als" / "GSE124439" / "metadata.csv"

AD_BIO_PATH = BASE_DIR / "results" / "multi_dataset_analysis" / "GSE203206_biomarkers.csv"
ALS_BIO_PATH = BASE_DIR / "results" / "multi_dataset_analysis" / "GSE124439_biomarkers.csv"

SHARED_PATH = BASE_DIR / "results" / "multi_dataset_analysis" / "isef_analysis" / "Shared_ncRNAs_AD_ALS.csv"
FIG_DIR = BASE_DIR / "results" / "isef_figures"

FIGURES = [
 ("AD volcano plot", FIG_DIR / "ad_volcano.png"),
 ("AD heatmap (top 30 ncRNAs)", FIG_DIR / "ad_heatmap_top30.png"),
 ("AD PCA plot", FIG_DIR / "ad_pca.png"),
 ("AD top-3 bar plots", FIG_DIR / "ad_top3_barplots.png"),
 ("ALS volcano plot", FIG_DIR / "als_volcano.png"),
 ("ALS heatmap (top 30 ncRNAs)", FIG_DIR / "als_heatmap_top30.png"),
 ("ALS PCA plot", FIG_DIR / "als_pca.png"),
 ("ALS top-3 bar plots", FIG_DIR / "als_top3_barplots.png"),
 ("AD vs ALS Venn diagram", FIG_DIR / "ad_als_venn.png"),
 ("AD ROC curve", FIG_DIR / "ad_roc_auc.png"),
 ("ALS ROC curve", FIG_DIR / "als_roc_auc.png"),
]


def load_counts(path_primary: Path, path_fallback: Path) -> pd.DataFrame:
 if path_primary.exists():
 df = pd.read_csv(path_primary, sep='\t', index_col=0, low_memory=False)
 else:
 df = pd.read_csv(path_fallback, index_col=0, low_memory=False)
 df.index = df.index.astype(str).str.split('.').str[0]
 return df


def get_group_col(metadata: pd.DataFrame, preferred: str = None) -> str:
 if preferred and preferred in metadata.columns:
 return preferred
 try:
 return de.detect_group_column(metadata)
 except ValueError:
 for candidate in ['disease_status', 'diagnosis', 'group', 'condition']:
 if candidate in metadata.columns:
 return candidate
 raise


def infer_labels(metadata: pd.DataFrame, group_col: str):
 values = list(metadata[group_col].value_counts().index)
 value_lower = {v: str(v).lower() for v in values}

 disease_keywords = ['disease', 'case', 'treatment', 'affected', 'als', 'ad', 'alzheimer']
 control_keywords = ['control', 'healthy', 'normal']

 disease_label = next((v for v in values if any(k in value_lower[v] for k in disease_keywords)), None)
 control_label = next((v for v in values if any(k in value_lower[v] for k in control_keywords)), None)

 if disease_label is None and control_label is None and len(values) == 2:
 control_label = metadata[group_col].value_counts().idxmin()
 disease_label = [v for v in values if v != control_label][0]
 elif disease_label is None and control_label is not None and len(values) == 2:
 disease_label = [v for v in values if v != control_label][0]
 elif control_label is None and disease_label is not None and len(values) == 2:
 control_label = [v for v in values if v != disease_label][0]

 if disease_label is None or control_label is None:
 disease_label, control_label, _, _ = de.validate_groups(metadata, group_col)

 return disease_label, control_label


def fdr_col(df: pd.DataFrame) -> str:
 return 'padj' if 'padj' in df.columns else 'fdr'


def top_genes(df: pd.DataFrame, n: int = 3) -> pd.DataFrame:
 col = fdr_col(df)
 return df.sort_values(col).head(n)


def make_table(data, col_widths=None):
 table = Table(data, colWidths=col_widths)
 table.setStyle(TableStyle([
 ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#f2f2f2')),
 ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
 ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
 ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
 ('FONTSIZE', (0, 0), (-1, -1), 9),
 ('BOTTOMPADDING', (0, 0), (-1, 0), 6),
 ('GRID', (0, 0), (-1, -1), 0.25, colors.grey),
 ]))
 return table


def format_float(value, decimals=3):
 return f"{value:.{decimals}f}"


def format_sci(value, digits=2):
 return f"{value:.{digits}e}"


def main():
 styles = getSampleStyleSheet()
 title_style = styles['Title']
 body_style = styles['BodyText']
 heading_style = styles['Heading2']

 ad_counts = load_counts(AD_COUNTS_PATH, AD_COUNTS_FALLBACK)
 als_counts = pd.read_csv(ALS_COUNTS_PATH, index_col=0)

 ad_meta = pd.read_csv(AD_META_PATH, index_col=0)
 als_meta = pd.read_csv(ALS_META_PATH, index_col=0)

 ad_group_col = get_group_col(ad_meta)
 als_group_col = get_group_col(als_meta, preferred='disease_status')

 ad_disease, ad_control = infer_labels(ad_meta, ad_group_col)
 als_disease, als_control = infer_labels(als_meta, als_group_col)

 ad_counts_by_group = ad_meta[ad_group_col].value_counts().to_dict()
 als_counts_by_group = als_meta[als_group_col].value_counts().to_dict()

 ad_bio = pd.read_csv(AD_BIO_PATH)
 als_bio = pd.read_csv(ALS_BIO_PATH)

 ad_fdr = fdr_col(ad_bio)
 als_fdr = fdr_col(als_bio)

 ad_sig = int((ad_bio[ad_fdr] < 0.05).sum())
 als_sig = int((als_bio[als_fdr] < 0.05).sum())

 ad_top = top_genes(ad_bio, n=3)
 als_top = top_genes(als_bio, n=3)

 ad_logcpm = proc.log2_cpm(ad_counts)
 als_logcpm = proc.log2_cpm(als_counts)

 ad_samples = ad_logcpm.columns.intersection(ad_meta.index)
 als_samples = als_logcpm.columns.intersection(als_meta.index)
 ad_logcpm = ad_logcpm[ad_samples]
 als_logcpm = als_logcpm[als_samples]

 ad_disease_samples = ad_meta[ad_meta[ad_group_col] == ad_disease].index
 ad_control_samples = ad_meta[ad_meta[ad_group_col] == ad_control].index

 als_disease_samples = als_meta[als_meta[als_group_col] == als_disease].index
 als_control_samples = als_meta[als_meta[als_group_col] == als_control].index

 def stats_for_gene(logcpm, gene, disease_samples, control_samples):
 if gene not in logcpm.index:
 return None
 d = logcpm.loc[gene, disease_samples].dropna()
 c = logcpm.loc[gene, control_samples].dropna()
 tstat, pval = stats.ttest_ind(d, c, equal_var=False, nan_policy='omit')
 if pd.isna(tstat):
 tstat = 0.0
 if pd.isna(pval):
 pval = 1.0
 return {
 'mean_disease': float(d.mean()),
 'sd_disease': float(d.std()),
 'mean_control': float(c.mean()),
 'sd_control': float(c.std()),
 'tstat': float(tstat),
 'pvalue': float(pval)
 }

 ad_stats = {}
 for _, row in ad_top.iterrows():
 gene_id = row['gene_id'] if 'gene_id' in row else row.name
 ad_stats[gene_id] = stats_for_gene(ad_logcpm, gene_id, ad_disease_samples, ad_control_samples)

 als_stats = {}
 for _, row in als_top.iterrows():
 gene_id = row['gene_id'] if 'gene_id' in row else row.name
 als_stats[gene_id] = stats_for_gene(als_logcpm, gene_id, als_disease_samples, als_control_samples)

 shared_count = 0
 if SHARED_PATH.exists():
 shared = pd.read_csv(SHARED_PATH)
 shared_count = len(shared)

 story = []
 story.append(Paragraph(" Project Report: ncRNA Biomarkers in AD and ALS", title_style))
 story.append(Spacer(1, 0.2 * inch))

 story.append(Paragraph("Data Tables", heading_style))
 story.append(Paragraph("Table A. Sample counts (unit: samples, n)", body_style))
 table_a = [
 ["Dataset", "Disease group (n)", "Control group (n)", "Tissue/Source"],
 ["AD (GSE203206)", f"{ad_disease} = {ad_counts_by_group.get(ad_disease, 0)}",
 f"{ad_control} = {ad_counts_by_group.get(ad_control, 0)}", "Human brain bulk RNA-seq"],
 ["ALS (GSE124439)", f"{als_disease} = {als_counts_by_group.get(als_disease, 0)}",
 f"{als_control} = {als_counts_by_group.get(als_control, 0)}", "Human brain bulk RNA-seq"],
 ]
 story.append(make_table(table_a, col_widths=[1.6 * inch, 1.5 * inch, 1.5 * inch, 2.0 * inch]))
 story.append(Spacer(1, 0.2 * inch))

 story.append(Paragraph("Table B. Top ncRNA biomarkers (unit: log2FC)", body_style))
 table_b = [["Dataset", "Gene", "log2FC", "p value", "FDR (padj)", "Direction"]]
 for label, df, fdr_colname in [("AD", ad_top, ad_fdr), ("ALS", als_top, als_fdr)]:
 for _, row in df.iterrows():
 direction = "Up" if row['log2FC'] > 0 else "Down"
 table_b.append([
 label,
 row.get('gene_name', row.get('gene_id', 'NA')),
 format_float(row['log2FC']),
 format_sci(row['pvalue']),
 format_sci(row[fdr_colname]),
 direction,
 ])
 story.append(make_table(table_b, col_widths=[0.7 * inch, 1.3 * inch, 0.9 * inch, 1.1 * inch, 1.1 * inch, 0.7 * inch]))
 story.append(Spacer(1, 0.2 * inch))

 story.append(Paragraph("Table C. Descriptive statistics for top ncRNAs (unit: log2-CPM)", body_style))
 table_c = [["Dataset", "Gene", "Disease mean ± SD", "Control mean ± SD"]]
 for label, df, stats_map in [("AD", ad_top, ad_stats), ("ALS", als_top, als_stats)]:
 for _, row in df.iterrows():
 gene_id = row.get('gene_id', row.name)
 gene_name = row.get('gene_name', gene_id)
 stat = stats_map.get(gene_id)
 if not stat:
 continue
 disease_str = f"{format_float(stat['mean_disease'])} ± {format_float(stat['sd_disease'])}"
 control_str = f"{format_float(stat['mean_control'])} ± {format_float(stat['sd_control'])}"
 table_c.append([label, gene_name, disease_str, control_str])
 story.append(make_table(table_c, col_widths=[0.7 * inch, 1.6 * inch, 1.6 * inch, 1.6 * inch]))
 story.append(Spacer(1, 0.2 * inch))

 story.append(Paragraph("Table D. Welch t-test statistics for top ncRNAs", body_style))
 table_d = [["Dataset", "Gene", "t value", "p value"]]
 for label, df, stats_map in [("AD", ad_top, ad_stats), ("ALS", als_top, als_stats)]:
 for _, row in df.iterrows():
 gene_id = row.get('gene_id', row.name)
 gene_name = row.get('gene_name', gene_id)
 stat = stats_map.get(gene_id)
 if not stat:
 continue
 table_d.append([
 label,
 gene_name,
 format_float(stat['tstat']),
 format_sci(stat['pvalue']),
 ])
 story.append(make_table(table_d, col_widths=[0.7 * inch, 1.6 * inch, 1.2 * inch, 1.3 * inch]))
 story.append(Spacer(1, 0.2 * inch))

 story.append(Paragraph("Table D. Cross-disease overlap", body_style))
 table_e = [["Metric", "Value"], ["Shared ncRNAs (AD vs ALS, FDR < 0.05)", str(shared_count)]]
 story.append(make_table(table_e, col_widths=[3.8 * inch, 1.0 * inch]))
 story.append(PageBreak())

 story.append(Paragraph("Figures", heading_style))
 story.append(Paragraph("Each figure includes a title, labeled axes with units, and a legend where applicable.", body_style))
 story.append(Spacer(1, 0.2 * inch))

 for caption, fig_path in FIGURES:
 story.append(Paragraph(caption, body_style))
 if fig_path.exists():
 img = Image(str(fig_path))
 img.drawHeight = 3.2 * inch
 img.drawWidth = 5.5 * inch
 story.append(img)
 else:
 story.append(Paragraph(f"Missing figure: {fig_path.name}", body_style))
 story.append(Spacer(1, 0.2 * inch))

 story.append(PageBreak())

 story.append(Paragraph("Figure-by-Figure Analysis", heading_style))
 fig_analysis = [
 "Figure 1 (AD volcano plot): The x-axis shows log2FC (disease minus control) and the y-axis shows -log10(FDR). Genes farther from zero show larger changes, and higher points show stronger significance. This supports the selection of top AD biomarkers.",
 "Figure 2 (AD heatmap): The top 30 ncRNAs are shown with z-scored expression across samples. Consistent color shifts between disease and control columns indicate coordinated expression changes in AD.",
 "Figure 3 (AD PCA plot): Each point represents a sample, and separation between disease and control indicates a global shift in ncRNA expression in AD.",
 "Figure 4 (AD top-3 bar plots): Mean log2-CPM with SD shows lower disease expression for LINC01013, ADGRB3-DT, and AMMECR1LP1, matching negative log2FC values.",
 "Figure 5 (ALS volcano plot): The most significant ALS ncRNAs appear high on the plot, indicating low FDR and supporting the ALS biomarker list.",
 "Figure 6 (ALS heatmap): The top 30 ncRNAs show consistent expression differences between ALS and control samples, supporting the ALS disease signature.",
 "Figure 7 (ALS PCA plot): Separation of disease and control samples across the first two components indicates systematic expression differences in ALS.",
 "Figure 8 (ALS top-3 bar plots): Higher disease means for TUSC7, MAPK8IP1P2, and LINC02560 match positive log2FC values and show group-level shifts.",
 "Figure 9 (AD vs ALS Venn diagram): The overlap highlights shared ncRNAs, supporting cross-disease consistency.",
 "Figure 10 (AD ROC curve): A curve above the diagonal indicates better-than-random separation of AD disease and control samples using the top ncRNAs.",
 "Figure 11 (ALS ROC curve): A curve above the diagonal indicates discrimination between ALS disease and control samples using the top ncRNAs.",
 ]
 for text in fig_analysis:
 story.append(Paragraph(text, body_style))
 story.append(Spacer(1, 0.12 * inch))

 story.append(PageBreak())

 story.append(Paragraph("Statistical Analysis", heading_style))
 stats_text = (
 "Descriptive statistics were computed as mean and standard deviation of log2-CPM for disease and control groups. "
 "Inferential statistics were computed using Welch two-sample t-tests, followed by Benjamini-Hochberg FDR correction. "
 f"Significant ncRNAs were identified at FDR < 0.05. AD yielded {ad_sig} significant ncRNAs and ALS yielded {als_sig} significant ncRNAs."
 )
 story.append(Paragraph(stats_text, body_style))
 story.append(Spacer(1, 0.2 * inch))

 story.append(Paragraph("Written Description", heading_style))
 narrative = (
 "Expression profiles were compared between disease and control groups for AD and ALS. "
 "Strong shifts were observed in multiple ncRNAs, and the most significant changes were summarized in Table B. "
 "In AD, LINC01013, ADGRB3-DT, and AMMECR1LP1 were reduced in disease compared with controls, "
 "as shown by negative log2FC values and lower means in Table C. "
 "In ALS, TUSC7, MAPK8IP1P2, and LINC02560 were elevated in disease compared with controls, "
 "as shown by positive log2FC values and higher means in Table C. "
 "A shared set of ncRNAs was detected across AD and ALS, supporting cross-disease overlap. "
 "ROC curves indicated separation of disease and control using the top 10 ncRNAs, supporting diagnostic potential."
 )
 story.append(Paragraph(narrative, body_style))
 story.append(Spacer(1, 0.2 * inch))

 story.append(PageBreak())
 story.append(Paragraph("Appendix: Raw Data and Code", heading_style))
 story.append(Paragraph("Raw data sources (public GEO):", body_style))
 story.append(Paragraph("- AD: GSE203206 (counts.tsv, metadata.csv)", body_style))
 story.append(Paragraph("- ALS: GSE124439 (counts.csv, metadata.csv)", body_style))
 story.append(Spacer(1, 0.12 * inch))
 story.append(Paragraph("Code used for analysis and figures:", body_style))
 story.append(Paragraph("- generate_isef_figures.py", body_style))
 story.append(Paragraph("- generate_isef_report_pdf.py", body_style))
 story.append(Paragraph("- pipeline/processing.py", body_style))
 story.append(Paragraph("- pipeline/de_analysis.py", body_style))
 story.append(Paragraph("- pipeline/visualization.py", body_style))

 doc = SimpleDocTemplate(
 str(OUT_PATH),
 pagesize=letter,
 rightMargin=0.75 * inch,
 leftMargin=0.75 * inch,
 topMargin=0.75 * inch,
 bottomMargin=0.75 * inch,
 title=" Project Report"
 )
 doc.build(story)
 print(f"Report written to {OUT_PATH}")


if __name__ == "__main__":
 main()
