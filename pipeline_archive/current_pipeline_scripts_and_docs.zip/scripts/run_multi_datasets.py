#!/usr/bin/env python3
"""Batch runner for multiple datasets without using config_datasets.yaml."""
import argparse
from pathlib import Path
import sys

ROOT_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT_DIR))

from scripts.run_pipeline import analyze_dataset


def _derive_dataset_id(counts_path: str) -> str:
 return Path(counts_path).stem


def main() -> None:
 parser = argparse.ArgumentParser(
 description="Run multiple datasets by passing repeated counts/metadata pairs",
 epilog="""
EXAMPLE:
 python run_multi_datasets.py \
 --counts data/ds1_counts.txt --metadata data/ds1_metadata.txt \
 --counts data/ds2_counts.txt --metadata data/ds2_metadata.txt \
 --group_col condition --disease_label Disease --control_label Control \
 --outdir results/multi_run
 """,
 )
 parser.add_argument("--counts", action="append", required=True,
 help="Counts file path (repeat for each dataset)")
 parser.add_argument("--metadata", action="append", required=True,
 help="Metadata file path (repeat for each dataset)")
 parser.add_argument("--dataset_id", action="append",
 help="Optional dataset ID (repeat to match counts/metadata)")
 parser.add_argument("--annotation", default=None,
 help="Optional annotation file (GTF/CSV) used for all datasets")
 parser.add_argument("--group_col", default=None,
 help="Metadata column for groups (auto-detected if not provided)")
 parser.add_argument("--disease_label", default=None,
 help="Disease group label (auto-inferred if not provided)")
 parser.add_argument("--control_label", default=None,
 help="Control group label (auto-inferred if not provided)")
 parser.add_argument("--method", choices=["welch", "deseq2"], default="welch",
 help="DE method: welch (default) or deseq2 (requires raw counts)")
 parser.add_argument("--raw_counts", action="append",
 help="Raw counts file path (repeat for each dataset, required for deseq2)")
 parser.add_argument("--outdir", default="results/multi_run",
 help="Output directory for all datasets")
 parser.add_argument("--top_n", type=int, default=50,
 help="Number of top genes to show in heatmap")
 parser.add_argument("--pseudocount", type=float, default=1.0,
 help="Pseudocount added before log2 normalization")

 args = parser.parse_args()

 if len(args.counts) != len(args.metadata):
 raise ValueError("--counts and --metadata must be provided the same number of times")

 if args.dataset_id and len(args.dataset_id) != len(args.counts):
 raise ValueError("--dataset_id must match the number of datasets")

 if args.method == "deseq2":
 if not args.raw_counts or len(args.raw_counts) != len(args.counts):
 raise ValueError("--raw_counts must be provided for each dataset when using deseq2")

 outdir = Path(args.outdir)
 outdir.mkdir(parents=True, exist_ok=True)
 (outdir / "per_dataset").mkdir(parents=True, exist_ok=True)

 results = {}
 for idx, (counts_path, metadata_path) in enumerate(zip(args.counts, args.metadata)):
 dataset_id = args.dataset_id[idx] if args.dataset_id else _derive_dataset_id(counts_path)
 counts_path = Path(counts_path)
 metadata_path = Path(metadata_path)

 if not counts_path.exists():
 print(f"⚠ Skipping {dataset_id} (counts file not found)")
 continue
 if not metadata_path.exists():
 print(f"⚠ Skipping {dataset_id} (metadata file not found)")
 continue

 raw_counts_path = None
 if args.method == "deseq2":
 raw_counts_path = args.raw_counts[idx]

 out_prefix = str(outdir / "per_dataset" / dataset_id)
 try:
 res = analyze_dataset(
 counts_path=str(counts_path),
 metadata_path=str(metadata_path),
 annotation_path=args.annotation,
 group_col=args.group_col,
 disease_label=args.disease_label,
 control_label=args.control_label,
 out_prefix=out_prefix,
 pseudocount=args.pseudocount,
 top_n=args.top_n,
 method=args.method,
 raw_counts_path=raw_counts_path,
 )
 results[dataset_id] = res
 except Exception as exc:
 print(f"✗ {dataset_id} failed: {exc}")

 if not results:
 print("\nNo datasets analyzed successfully.")
 sys.exit(1)

 print("\n✅ Batch analysis complete.")
 print(f"Results: {outdir}")


if __name__ == "__main__":
 main()
