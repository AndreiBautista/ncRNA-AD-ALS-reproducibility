#!/usr/bin/env python3
"""
Automated downloader for GSE datasets from GEO
Downloads raw counts and metadata, attempts to organize automatically
"""

import os
import sys
import subprocess
import tempfile
from pathlib import Path
import pandas as pd

# Try to import GEOparse - install if needed
try:
 import GEOparse
except ImportError:
 print("Installing GEOparse...")
 subprocess.check_call([sys.executable, "-m", "pip", "install", "GEOparse"])
 import GEOparse

# ============================================================================
# DATASET MAPPING
# ============================================================================

DATASETS_TO_DOWNLOAD = {
 "alzheimers": [
 {"gse": "GSE173955", "description": "Hisayama Cohort (Hippocampus)"},
 {"gse": "GSE95587", "description": "Genentech/Roche (Fusiform Gyrus)"},
 ],
 "als": [
 {"gse": "GSE124439", "description": "NYGC ALS Consortium (Motor Cortex)"},
 {"gse": "GSE116622", "description": "NYGC ALS - C9ORF72 & Sporadic"},
 {"gse": "GSE76220", "description": "Laser Capture Motor Neurons"},
 ],
}


def download_gse(gse_id, disease):
 """
 Download GSE dataset and try to extract counts & metadata.
 Returns True if successful.
 """
 print(f"\n{'=' * 80}")
 print(f"DOWNLOADING: {gse_id}")
 print(f"{'=' * 80}")

 dest_folder = (
 Path(f"data/neurodegenerative_diseases/{disease}/{gse_id}").absolute()
 )
 dest_folder.mkdir(parents=True, exist_ok=True)

 try:
 print(f"Fetching from GEO...")
 gse = GEOparse.get_GEO(geo=gse_id, destdir=str(dest_folder))

 print(f" ✓ Downloaded GSE object")

 # Try to extract counts matrix
 print(f"\nSearching for expression data...")
 found_counts = False

 # Check if GSM files have expression data
 if hasattr(gse, "gsms") and len(gse.gsms) > 0:
 print(f" Found {len(gse.gsms)} GSM samples")

 # Try to build counts matrix from GSM data
 try:
 counts_dict = {}
 for gsm_name in sorted(gse.gsms.keys()):
 gsm = gse.gsms[gsm_name]
 if hasattr(gsm, "table") and len(gsm.table) > 0:
 table = gsm.table
 if "VALUE" in table.columns:
 counts_dict[gsm_name] = dict(zip(table.index, table["VALUE"]))

 if len(counts_dict) > 0:
 # Attempt to create DataFrame
 genes = set()
 for d in counts_dict.values():
 genes.update(d.keys())

 genes = sorted(list(genes))
 counts_data = []
 for gene in genes:
 row = [counts_dict[sample].get(gene, 0) for sample in counts_dict]
 counts_data.append(row)

 counts_df = pd.DataFrame(
 counts_data, index=genes, columns=list(counts_dict.keys())
 )

 if counts_df.shape[0] > 100: # At least 100 genes
 counts_file = dest_folder / "counts.tsv"
 counts_df.to_csv(counts_file, sep="\t")
 print(f" ✓ Extracted counts: {counts_df.shape}")
 found_counts = True
 except Exception as e:
 print(f" Failed to build counts from GSM: {e}")

 # Check supplementary files for counts data
 if not found_counts and hasattr(gse, "metadata") and "supplementary_file" in gse.metadata:
 print(f"\n Checking supplementary files...")
 supp_files = gse.metadata.get("supplementary_file", [])
 if isinstance(supp_files, str):
 supp_files = [supp_files]

 for supp_file in supp_files:
 if any(x in supp_file.lower() for x in ["count", "expr", "matrix"]):
 print(f" → Found: {supp_file.split('/')[-1]}")

 # Create placeholder metadata
 print(f"\nCreating placeholder metadata...")
 try:
 # Extract GSM metadata
 metadata_list = []

 if hasattr(gse, "gsms"):
 for gsm_name in gse.gsms.keys():
 gsm = gse.gsms[gsm_name]
 metadata_list.append(
 {
 "sample_id": gsm_name,
 "disease_status": "Unknown", # User must fill in
 "tissue_type": "Unknown", # User must fill in
 "study_id": gse_id,
 }
 )

 if len(metadata_list) > 0:
 metadata_df = pd.DataFrame(metadata_list)
 metadata_file = dest_folder / "metadata.csv"
 metadata_df.to_csv(metadata_file, index=False)
 print(f" ✓ Created placeholder metadata: {len(metadata_list)} samples")
 else:
 print(f" ⚠ Could not extract sample information")

 except Exception as e:
 print(f" ⚠ Error creating metadata: {e}")

 return True

 except Exception as e:
 print(f"✗ Failed to download {gse_id}: {e}")
 print(f" Manual download required from:")
 print(f" https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc={gse_id}")
 return False


def print_manual_download_guide():
 """Print guide for manual download if automated fails."""
 print("\n" + "=" * 80)
 print("MANUAL DOWNLOAD GUIDE")
 print("=" * 80)

 print("""
If automated download fails, download manually from GEO:

For each dataset:
 1. Go to: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=[GSE_ID]
 2. Scroll to "Supplementary file" section
 3. Look for files containing:
 - "counts" or "gene_expression" or "matrix"
 - Usually .txt.gz, .csv.gz, or .tsv.gz
 4. Download and extract the file
 5. Save as: data/neurodegenerative_diseases/[disease]/[GSE]/counts.txt
 6. Create metadata.csv with columns:
 sample_id, disease_status, tissue_type, study_id

Alternatively, try downloading from NCBI SRA:
 - Many GEO studies link to raw sequencing data in SRA
 - Use: prefetch & fastq-dump (from SRA Toolkit)
 - Then use alignment pipeline to generate counts
""")


def main():
 print("=" * 80)
 print("AUTOMATED GEO DATASET DOWNLOADER")
 print("=" * 80)

 total_downloaded = 0
 failed_downloads = []

 for disease, datasets in DATASETS_TO_DOWNLOAD.items():
 print(f"\n\n{'#' * 80}")
 print(f"# {disease.upper()}")
 print(f"{'#' * 80}")

 for dataset_info in datasets:
 gse = dataset_info["gse"]
 desc = dataset_info["description"]

 print(f"\n{desc}")
 print(f"GSE: {gse}")

 success = download_gse(gse, disease)

 if success:
 total_downloaded += 1
 else:
 failed_downloads.append((gse, disease))

 # Summary
 print("\n\n" + "=" * 80)
 print("DOWNLOAD SUMMARY")
 print("=" * 80)

 print(f"\n✓ Successfully downloaded: {total_downloaded} datasets")

 if len(failed_downloads) > 0:
 print(f"✗ Failed downloads: {len(failed_downloads)}")
 for gse, disease in failed_downloads:
 print(f" - {gse} ({disease})")
 print_manual_download_guide()

 print("\n" + "=" * 80)
 print("NEXT STEPS")
 print("=" * 80)
 print("""
1. For each dataset folder, verify:
 - counts.txt or counts.tsv exists and contains tab-separated data
 - metadata.csv exists with proper columns
 
2. Edit metadata.csv files to fill in:
 - disease_status: "Control" or "Disease" 
 - tissue_type: specific brain region

3. Run validation:
 python cross_disease_pipeline.py

4. Once validated, I'll build the full analysis pipeline!
""")


if __name__ == "__main__":
 main()
