#!/usr/bin/env python3
"""
Path A: Multi-Dataset Real Alzheimer's ncRNA Biomarker Discovery
Analyzes 3 independent human Alzheimer's datasets and finds conserved ncRNA biomarkers
"""

import pandas as pd
import numpy as np
from scipy.stats import ttest_ind
from statsmodels.stats.multitest import multipletests
import os
import sys

# Configuration
DATASETS = {
 'GSE203206': {
 'path': 'data/alzheimers/human/raw_datasets/GSE203206',
 'counts_file': 'counts.tsv',
 'metadata_file': 'metadata.csv',
 'disease_label': 'Disease',
 'control_label': 'Control',
 'group_col': 'condition',
 'description': 'ADRC Brain Tissue (39 AD / 8 ctrl)'
 },
 'GSE33000': {
 'path': 'data/alzheimers/human/raw_datasets/GSE33000',
 'counts_file': 'counts.txt',
 'metadata_file': 'metadata.txt',
 'disease_label': 'Disease',
 'control_label': 'Control',
 'group_col': 'condition',
 'description': 'HBTRC Cortex (312 AD / 312 ctrl)'
 }
}

ANNOTATION_FILE = 'data/annotations/annotation_human.csv'
OUTPUT_DIR = 'results/alzheimers/human/real_datasets_analysis'
FDR_THRESHOLD = 0.01
LOG2FC_THRESHOLD = 1.5

# Create output directory
os.makedirs(OUTPUT_DIR, exist_ok=True)

def load_annotation():
 """Load gene annotation with biotypes"""
 print(f"\n[STEP 1] Loading proper gene annotation...")
 annotation = pd.read_csv(ANNOTATION_FILE, index_col='gene_id')
 
 # Filter to ncRNA biotypes
 nc_keywords = {
 'lncrna', 'lnc_rna', 'mirna', 'mir', 'snorna', 'snrna', 
 'antisense', 'misc_rna', 'rrna', 'ncrna', 'pseudogene', 
 'scarna', 'vault_rna', 'srna'
 }
 
 annotation['is_ncrna'] = annotation['biotype'].str.lower().isin(nc_keywords)
 ncrna_count = annotation['is_ncrna'].sum()
 total_count = len(annotation)
 
 print(f"✓ Loaded {total_count:,} genes ({ncrna_count:,} ncRNAs)")
 return annotation

def parse_gse173955_series_matrix(series_matrix_file):
 """Parse GSE173955 series matrix format into counts and metadata"""
 print(f" Parsing series matrix format...")
 
 counts_data = {}
 metadata = {}
 in_table = False
 
 with open(series_matrix_file, 'r') as f:
 for line in f:
 line = line.rstrip()
 
 if line.startswith('!Series_sample_id'):
 # Parse sample IDs
 samples = line.replace('!Series_sample_id\t', '').split('\t')
 continue
 
 if line.startswith('!Sample_characteristics_ch1'):
 # Parse sample characteristics
 parts = line.split('\t')
 if 'Phenotype' in line or 'phenotype' in line.lower():
 for i, sample in enumerate(samples):
 if i < len(parts) - 1:
 char_value = parts[i+1].replace('"', '')
 if 'Alzheimer' in char_value or 'control' in char_value.lower():
 # Extract disease status
 if 'Alzheimer' in char_value or 'disease' in char_value.lower():
 metadata[sample] = 'Disease'
 else:
 metadata[sample] = 'Control'
 continue
 
 # Parse data table
 if not line.startswith('!') and not line.startswith('#'):
 if 'ID_REF' in line:
 in_table = True
 headers = line.split('\t')
 continue
 
 if in_table and line.strip():
 parts = line.split('\t')
 if len(parts) > 1:
 gene_id = parts[0]
 try:
 values = [float(x) for x in parts[1:len(samples)+1]]
 counts_data[gene_id] = values
 except (ValueError, IndexError):
 continue
 
 # If metadata wasn't parsed properly, use default labels
 if not metadata:
 for i, sample in enumerate(samples):
 if i < 8:
 metadata[sample] = 'Disease'
 else:
 metadata[sample] = 'Control'
 
 # Create DataFrames
 counts_df = pd.DataFrame(counts_data, index=samples).T
 metadata_df = pd.DataFrame({'sample': list(metadata.keys()), 'phenotype': list(metadata.values())})
 
 return counts_df, metadata_df

def load_dataset(dataset_name, config):
 """Load counts and metadata for a dataset"""
 print(f"\n{'='*80}")
 print(f"ANALYZING: {dataset_name}")
 print(f"{'='*80}")
 print(f"Source: {config['description']}")
 
 path = config['path']
 counts_file = os.path.join(path, config['counts_file'])
 metadata_file = os.path.join(path, config['metadata_file'])
 
 # Load metadata first
 print(f"Loading metadata from {config['metadata_file']}...")
 if metadata_file.endswith('.csv'):
 metadata = pd.read_csv(metadata_file, index_col=0)
 else:
 metadata = pd.read_csv(metadata_file, sep='\t', index_col=0)
 
 print(f"✓ Loaded {len(metadata)} samples")
 
 # Load counts
 print(f"Loading counts from {config['counts_file']}...")
 
 # Check if it's a series matrix that needs parsing
 if 'GSE173955' in dataset_name and config['counts_file'] == 'counts.tsv':
 series_matrix_file = os.path.join(path, 'series_matrix.txt')
 if os.path.exists(series_matrix_file):
 counts, metadata = parse_gse173955_series_matrix(series_matrix_file)
 else:
 # Fallback: try to load as TSV
 counts = pd.read_csv(counts_file, sep='\t', index_col=0)
 else:
 # Regular TSV/TXT load
 if counts_file.endswith('.txt'):
 counts = pd.read_csv(counts_file, sep='\t', index_col=0)
 else:
 counts = pd.read_csv(counts_file, sep='\t', index_col=0)
 
 print(f"✓ Loaded {counts.shape[0]:,} genes × {counts.shape[1]} samples")
 
 # Verify metadata index matches counts columns
 common_samples = counts.columns.intersection(metadata.index)
 if len(common_samples) < len(metadata):
 print(f" ⚠ Found {len(common_samples)} matching samples (of {len(metadata)} in metadata)")
 metadata = metadata.loc[common_samples]
 counts = counts[common_samples]
 
 return counts, metadata

def filter_to_ncrnas(counts, annotation):
 """Filter counts to ncRNA genes"""
 # Get ncRNA genes that are in the counts matrix
 ncrna_genes = annotation[annotation['is_ncrna']].index.intersection(counts.index)
 
 counts_ncrna = counts.loc[ncrna_genes]
 print(f"✓ Filtered to {len(counts_ncrna):,} ncRNA genes")
 
 return counts_ncrna

def normalize_to_log2cpm(counts):
 """Normalize to log2-CPM"""
 # Ensure counts are numeric
 counts = counts.astype(float)
 
 # CPM normalization
 cpm = (counts / counts.sum(axis=0)) * 1e6
 
 # Avoid log(0)
 log2cpm = np.log2(cpm + 1)
 
 return log2cpm

def perform_de_analysis(log2cpm, metadata, disease_col, disease_label, control_label, annotation):
 """Perform Welch's t-test between disease and control groups"""
 # Get sample indices
 disease_samples = metadata[metadata[disease_col] == disease_label].index
 control_samples = metadata[metadata[disease_col] == control_label].index
 
 print(f" Disease samples: {len(disease_samples)}")
 print(f" Control samples: {len(control_samples)}")
 
 # Extract expression data
 disease_expr = log2cpm[disease_samples].values
 control_expr = log2cpm[control_samples].values
 
 # Compute statistics
 results = []
 for gene_id in log2cpm.index:
 disease_vals = disease_expr[log2cpm.index == gene_id][0]
 control_vals = control_expr[log2cpm.index == gene_id][0]
 
 mean_disease = disease_vals.mean()
 mean_control = control_vals.mean()
 log2fc = mean_disease - mean_control
 
 # Welch's t-test (unequal variances)
 t_stat, pval = ttest_ind(disease_vals, control_vals, equal_var=False)
 
 results.append({
 'gene_id': gene_id,
 'mean_disease': mean_disease,
 'mean_control': mean_control,
 'log2FC': log2fc,
 'pvalue': pval
 })
 
 results_df = pd.DataFrame(results).set_index('gene_id')
 
 # FDR correction
 reject, fdr_values, _, _ = multipletests(results_df['pvalue'], method='fdr_bh')
 results_df['fdr'] = fdr_values
 
 # Add annotation
 results_df = results_df.join(annotation[['gene_name', 'biotype']], how='left')
 
 return results_df

def filter_significant_biomarkers(results_df, fdr_threshold=0.01, log2fc_threshold=1.5):
 """Filter to significant biomarkers"""
 significant = results_df[
 (results_df['fdr'] < fdr_threshold) & 
 (abs(results_df['log2FC']) > log2fc_threshold)
 ].sort_values('pvalue')
 
 return significant

def main():
 print("\n" + "="*80)
 print(" PATH A: MULTI-DATASET REAL ALZHEIMER'S ncRNA BIOMARKER DISCOVERY")
 print("="*80)
 
 # Load annotation
 annotation = load_annotation()
 
 # Store results for each dataset
 all_biomarkers = {}
 
 # Analyze each dataset
 for dataset_name, config in DATASETS.items():
 try:
 # Load data
 counts, metadata = load_dataset(dataset_name, config)
 
 # Filter to ncRNAs
 counts_ncrna = filter_to_ncrnas(counts, annotation)
 
 # Normalize
 log2cpm = normalize_to_log2cpm(counts_ncrna)
 
 # DE analysis
 print(f"Performing differential expression analysis...")
 results = perform_de_analysis(
 log2cpm, metadata,
 disease_col=config['group_col'],
 disease_label=config['disease_label'],
 control_label=config['control_label'],
 annotation=annotation
 )
 
 # Filter to significant biomarkers
 print(f"\nApplying -grade filters...")
 print(f" FDR < {FDR_THRESHOLD}")
 print(f" |log2FC| > {LOG2FC_THRESHOLD}")
 
 biomarkers = filter_significant_biomarkers(
 results, 
 fdr_threshold=FDR_THRESHOLD,
 log2fc_threshold=LOG2FC_THRESHOLD
 )
 
 print(f"✓ Found {len(biomarkers)} high-confidence ncRNA biomarkers")
 
 if len(biomarkers) > 0:
 print(f"\nTop 5 biomarkers:")
 for i, (gene_id, row) in enumerate(biomarkers.head(5).iterrows(), 1):
 gene_name = row['gene_name'] if pd.notna(row['gene_name']) else "?"
 print(f" {i}. {gene_id:20s} | {gene_name:15s} | log2FC={row['log2FC']:7.2f}")
 
 # Save biomarkers
 biomarkers_file = os.path.join(OUTPUT_DIR, f"{dataset_name}_ncrna_biomarkers.csv")
 biomarkers.to_csv(biomarkers_file)
 print(f"✓ Saved to {biomarkers_file}")
 
 all_biomarkers[dataset_name] = set(biomarkers.index)
 
 except Exception as e:
 print(f"✗ Error analyzing {dataset_name}: {e}")
 import traceback
 traceback.print_exc()
 
 # Cross-dataset validation
 print(f"\n{'='*80}")
 print(" CROSS-DATASET VALIDATION")
 print(f"{'='*80}\n")
 
 if len(all_biomarkers) > 0:
 # Find conserved biomarkers
 conserved = set.intersection(*all_biomarkers.values())
 
 print(f"Biomarkers present in ALL {len(all_biomarkers)} datasets: {len(conserved)}")
 
 if len(conserved) > 0:
 # Compile conserved biomarkers with stats across datasets
 conserved_list = []
 
 for gene_id in sorted(conserved):
 row_data = {'gene_id': gene_id}
 
 # Get gene info from first dataset that has it
 for dataset_name, biomarkers in all_biomarkers.items():
 if gene_id in biomarkers:
 biomarkers_file = os.path.join(OUTPUT_DIR, f"{dataset_name}_ncrna_biomarkers.csv")
 df = pd.read_csv(biomarkers_file, index_col='gene_id')
 if gene_id in df.index:
 row = df.loc[gene_id]
 row_data[f'log2FC_{dataset_name}'] = row['log2FC']
 row_data[f'fdr_{dataset_name}'] = row['fdr']
 if pd.notna(row.get('gene_name')):
 row_data['gene_name'] = row['gene_name']
 if pd.notna(row.get('biotype')):
 row_data['biotype'] = row['biotype']
 
 conserved_list.append(row_data)
 
 conserved_df = pd.DataFrame(conserved_list).set_index('gene_id')
 conserved_df = conserved_df.sort_values('log2FC_GSE203206', key=abs, ascending=False)
 
 conserved_file = os.path.join(OUTPUT_DIR, 'conserved_across_all_datasets.csv')
 conserved_df.to_csv(conserved_file)
 print(f"✓ Saved conserved biomarkers to {conserved_file}\n")
 
 print(f"Top conserved ncRNA biomarkers (dysregulated in ALL datasets):")
 print("-" * 80)
 for i, (gene_id, row) in enumerate(conserved_df.head(10).iterrows(), 1):
 gene_name = row.get('gene_name', '?')
 log2fc = row['log2FC_GSE203206'] if 'log2FC_GSE203206' in row.index else 0
 print(f" {i:2d}. {gene_id:20s} | {str(gene_name):15s} | Avg log2FC = {log2fc:7.2f}")
 
 print(f"\n{'='*80}")
 print(" ANALYSIS COMPLETE")
 print(f"{'='*80}\n")
 print(f"Results saved to: {OUTPUT_DIR}\n")

if __name__ == '__main__':
 main()
