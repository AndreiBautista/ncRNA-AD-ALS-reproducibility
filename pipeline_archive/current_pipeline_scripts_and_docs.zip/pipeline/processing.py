"""Data processing: normalization and filtering to non-coding RNAs."""
from typing import Optional
import numpy as np
import pandas as pd


def cpm(counts: pd.DataFrame) -> pd.DataFrame:
 lib_sizes = counts.sum(axis=0)
 lib_sizes = lib_sizes.replace(0, np.nan)
 return counts.divide(lib_sizes, axis=1) * 1e6


def log2_cpm(counts: pd.DataFrame, pseudocount: float = 1.0) -> pd.DataFrame:
 c = cpm(counts)
 return np.log2(c + pseudocount)


def filter_noncoding_genes(counts_df: pd.DataFrame, annot_df: pd.DataFrame, allow_missing: bool = False) -> pd.DataFrame:
 nc_keywords = set(['lncrna', 'lnc_rna', 'mirna', 'mir', 'snoRNA'.lower(), 'snrna', 'antisense', 'misc_rna', 'rrna', 'ncRNA'.lower(), 'pseudogene', 'scarna', 'vault_rna', 'srna'])
 if 'biotype' in annot_df.columns:
 biotype = annot_df['biotype'].astype(str).fillna('').str.lower()
 mask = biotype.apply(lambda x: any(k in x for k in nc_keywords))
 nc_genes = annot_df[mask].index.intersection(counts_df.index)
 else:
 nc_genes = counts_df.index[:0]
 if len(nc_genes) == 0 and not allow_missing:
 raise ValueError('No non-coding genes detected. Check annotation file and keyword mapping.')
 return counts_df.loc[counts_df.index.intersection(nc_genes)].copy()


def filter_results_to_ncrna(results_df: pd.DataFrame) -> pd.DataFrame:
 """
 Filter a DE results dataframe to retain only ncRNA biotypes.
 
 Args:
 results_df: Results dataframe with 'biotype' column (from annotation merge)
 
 Returns:
 Filtered dataframe containing only ncRNA entries
 """
 nc_keywords = set(['lncrna', 'lnc_rna', 'mirna', 'mir', 'snorna', 'snrna', 
 'antisense', 'misc_rna', 'rrna', 'ncrna', 'pseudogene', 
 'scarna', 'vault_rna', 'srna'])
 
 if 'biotype' not in results_df.columns:
 return results_df.copy()
 
 biotype = results_df['biotype'].astype(str).fillna('').str.lower()
 mask = biotype.apply(lambda x: any(k in x for k in nc_keywords))
 return results_df[mask].copy()
