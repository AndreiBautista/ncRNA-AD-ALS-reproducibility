"""I/O utilities: loading counts, metadata, annotation and downloading GEO/Synapse data.

These functions attempt to be robust and give clear error messages if optional download libraries
are missing. They do not change scientific logic from the original script; they only modularize I/O.
"""
from pathlib import Path
import pandas as pd
import os


def safe_read_table(path: str) -> pd.DataFrame:
 """
 Read a delimited table file with automatic separator detection.
 Supports: CSV, TSV, TXT, and other common delimiters.
 """
 path = Path(path)
 if not path.exists():
 raise FileNotFoundError(f"File not found: {path}")
 # Try common separators (tab first for .txt files)
 separators = ['\t', ',', ';', ' ']
 for sep in separators:
 try:
 df = pd.read_csv(path, sep=sep, engine='python')
 if df.shape[1] > 1:
 return df
 except Exception:
 continue
 # Fallback: try without specific separator
 return pd.read_csv(path, engine='python')


def load_counts(counts_path: str) -> pd.DataFrame:
 df = safe_read_table(counts_path)
 if df.shape[1] < 2:
 raise ValueError('Counts must have gene id and at least one sample column')
 gene_col = df.columns[0]
 df = df.rename(columns={gene_col: 'gene_id'}).set_index('gene_id')
 # Normalize Ensembl-like IDs by stripping version suffixes (e.g., ENSG... .14)
 df.index = df.index.astype(str).str.replace(r'\.\d+$', '', regex=True)
 # Coerce numeric where possible
 df = df.apply(pd.to_numeric, errors='coerce')
 if df.isna().all().all():
 raise ValueError('Counts file contains no numeric values after parsing')
 return df


def load_metadata(metadata_path: str, group_col: str = None) -> pd.DataFrame:
 """
 Load sample metadata from CSV/TSV.
 
 Args:
 metadata_path: Path to metadata file
 group_col: Column name indicating sample groups (optional; can be auto-detected later)
 
 Returns:
 DataFrame with samples as index
 
 Raises:
 ValueError: If file cannot be parsed or required column missing
 """
 meta = safe_read_table(metadata_path)
 
 # Validate group column if specified
 if group_col and group_col not in meta.columns:
 raise ValueError(
 f"Grouping column '{group_col}' not found in metadata. "
 f"Available columns: {list(meta.columns)}"
 )
 
 # Find sample ID column and set as index
 sample_id_cols = [c for c in ['sample', 'sample_id', 'sampleName', 'Sample'] if c in meta.columns]
 if sample_id_cols:
 meta = meta.set_index(sample_id_cols[0])
 else:
 # Default to first column if no standard sample ID column found
 meta = meta.set_index(meta.columns[0])
 
 return meta


def load_annotation(annotation_path: str) -> pd.DataFrame:
 """
 Load gene annotation from GTF, GFF, CSV, or TXT files.
 Expected columns: gene_id, gene_name (or Name), biotype (or gene_type)
 """
 path = Path(annotation_path)
 if path.suffix.lower() in ['.gtf', '.gff', '.gff3']:
 # For brevity, fallback to reading as table and parsing attributes if present
 cols = ['seqname', 'source', 'feature', 'start', 'end', 'score', 'strand', 'frame', 'attributes']
 df = pd.read_csv(path, sep='\t', comment='#', header=None, names=cols, engine='python')
 # take 'gene' features if present
 genes = df[df['feature'].str.lower() == 'gene'].copy()
 if genes.empty:
 genes = df.copy()
 def parse_attr(s):
 d = {}
 if pd.isna(s):
 return d
 for p in [p.strip() for p in str(s).split(';') if p.strip()]:
 if ' ' in p:
 k, v = p.split(' ', 1)
 d[k] = v.strip().strip('"')
 return d
 parsed = genes['attributes'].apply(parse_attr)
 gene_id = parsed.apply(lambda x: x.get('gene_id') or x.get('ID'))
 gene_name = parsed.apply(lambda x: x.get('gene_name') or x.get('Name'))
 biotype = parsed.apply(lambda x: x.get('gene_biotype') or x.get('gene_type') or x.get('biotype'))
 annot = pd.DataFrame({'gene_id': gene_id, 'gene_name': gene_name, 'biotype': biotype}).dropna(subset=['gene_id']).set_index('gene_id')
 return annot
 else:
 # Handles CSV, TXT, TSV, and other delimited files
 df = safe_read_table(path)
 candidates = [c for c in df.columns if c.lower() in ('gene_id', 'gene', 'id')]
 gene_col = candidates[0] if candidates else df.columns[0]
 df = df.rename(columns={gene_col: 'gene_id'}).set_index('gene_id')
 colmap = {}
 for c in df.columns:
 if c.lower() in ('gene_name', 'name', 'symbol'):
 colmap[c] = 'gene_name'
 if c.lower() in ('biotype', 'gene_biotype', 'gene_type', 'type'):
 colmap[c] = 'biotype'
 df = df.rename(columns=colmap)
 return df


def download_geo(gse_id: str, outdir: str) -> dict:
 """Download expression and metadata for a GEO Series using GEOparse.
 Returns dict with keys: counts, metadata, annotation (paths)
 """
 outdir = Path(outdir)
 outdir.mkdir(parents=True, exist_ok=True)
 try:
 import GEOparse
 except Exception:
 raise ImportError('GEOparse is required for GEO downloads. Install with: pip install GEOparse')
 gse = GEOparse.get_GEO(geo=gse_id, destdir=str(outdir))
 # Best-effort: try to extract table; users should validate results for each dataset
 counts_path = outdir / f"{gse_id}_counts.csv"
 # Attempt to extract table from GSE, otherwise instruct user to provide counts
 try:
 gsm_tables = {gsm_name: gsm.table for gsm_name, gsm in gse.gsms.items() if hasattr(gse.gsms[gsm_name], 'table')}
 if gsm_tables:
 dfs = []
 for name, tbl in gsm_tables.items():
 tbl = tbl.reset_index(drop=True)
 dfs.append(tbl)
 dfs[0].to_csv(counts_path)
 metadata_path = outdir / f"{gse_id}_metadata.csv"
 meta = pd.DataFrame({gsm: {'title': gse.gsms[gsm].metadata.get('title', [''])[0],
 'source_name': gse.gsms[gsm].metadata.get('source_name_ch1', [''])[0]}
 for gsm in gse.gsms}).T
 meta.to_csv(metadata_path)
 return {'counts': str(counts_path), 'metadata': str(metadata_path), 'annotation': ''}
 except Exception:
 pass
 # If automatic parsing failed, return directory and available files so the app can present options
 available = [str(p) for p in outdir.glob('*')]
 return {'counts': '', 'metadata': '', 'annotation': '', 'gse_dir': str(outdir), 'available_files': available}


def download_synapse(syn_id: str, outdir: str) -> dict:
 outdir = Path(outdir)
 outdir.mkdir(parents=True, exist_ok=True)
 try:
 import synapseclient
 except Exception:
 raise ImportError('synapseclient is required for Synapse downloads. Install with: pip install synapseclient')
 syn = synapseclient.Synapse()
 syn.login(silent=True)
 entity = syn.get(syn_id, downloadLocation=str(outdir))
 return {'counts': '', 'metadata': '', 'annotation': ''}
