"""Data ingestion and harmonization utilities for multi-cohort RNA-seq analyses."""

from __future__ import annotations

from pathlib import Path
from typing import Tuple, Optional
import re
import pandas as pd


def safe_read_table(path: str, file_format: str = "auto") -> pd.DataFrame:
    file_path = Path(path)
    if not file_path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    if file_format in {"csv", "tsv"}:
        sep = "," if file_format == "csv" else "\t"
        return pd.read_csv(file_path, sep=sep, low_memory=False)

    if file_path.suffix.lower() == ".csv":
        return pd.read_csv(file_path, low_memory=False)

    if file_path.suffix.lower() in {".tsv", ".txt"}:
        return pd.read_csv(file_path, sep="\t", low_memory=False)

    for sep in ["\t", ",", ";"]:
        try:
            df = pd.read_csv(file_path, sep=sep, low_memory=False)
            if df.shape[1] > 1:
                return df
        except Exception:
            continue

    raise ValueError(f"Could not parse tabular file: {file_path}")


def load_counts_matrix(path: str, file_format: str = "auto") -> pd.DataFrame:
    df = safe_read_table(path, file_format=file_format)
    gene_col = df.columns[0]
    df = df.rename(columns={gene_col: "gene_id"}).set_index("gene_id")
    df.index = df.index.astype(str).str.replace(r"\.\d+$", "", regex=True)
    df = df.apply(pd.to_numeric, errors="coerce")
    return df


def load_metadata(path: str, group_col: str) -> pd.DataFrame:
    meta = safe_read_table(path)
    sample_candidates = [c for c in ["sample", "sample_id", "sample_name", "Sample", "geo_accession"] if c in meta.columns]
    if sample_candidates:
        meta = meta.set_index(sample_candidates[0])
    else:
        meta = meta.set_index(meta.columns[0])

    if group_col not in meta.columns:
        raise ValueError(f"Grouping column '{group_col}' not found in metadata columns: {list(meta.columns)}")

    return meta


def load_annotation(path: Optional[str]) -> Optional[pd.DataFrame]:
    if not path:
        return None
    p = Path(path)
    if not p.exists():
        return None

    annot = safe_read_table(str(p))
    gene_col_candidates = [c for c in annot.columns if c.lower() in {"gene_id", "gene", "id", "ensembl_gene_id"}]
    if not gene_col_candidates:
        gene_col = annot.columns[0]
    else:
        gene_col = gene_col_candidates[0]

    annot = annot.rename(columns={gene_col: "gene_id"})
    annot["gene_id"] = annot["gene_id"].astype(str).str.replace(r"\.\d+$", "", regex=True)

    renames = {}
    for col in annot.columns:
        low = col.lower()
        if low in {"gene_name", "symbol", "name"}:
            renames[col] = "gene_name"
        if low in {"gene_biotype", "biotype", "gene_type", "type"}:
            renames[col] = "biotype"
    annot = annot.rename(columns=renames)
    return annot


def harmonize_sample_labels(metadata: pd.DataFrame, group_col: str, disease_label: str, control_label: str) -> pd.DataFrame:
    out = metadata.copy()
    group_series = out[group_col].astype(str)

    def _map_group(value: str) -> str:
        v = value.strip().lower()
        if v == str(disease_label).strip().lower():
            return "disease"
        if v == str(control_label).strip().lower():
            return "control"
        if any(k in v for k in ["disease", "case", "als", "ad", "alzheimer", "parkinson"]):
            return "disease"
        if any(k in v for k in ["control", "healthy", "normal", "wt"]):
            return "control"
        return "unknown"

    out["harmonized_group"] = group_series.apply(_map_group)
    unknown = (out["harmonized_group"] == "unknown").sum()
    if unknown > 0:
        raise ValueError(f"Could not harmonize {unknown} samples. Check metadata labels in column '{group_col}'.")
    return out


def harmonize_gene_ids(counts_df: pd.DataFrame, annotation_df: Optional[pd.DataFrame]) -> pd.DataFrame:
    if annotation_df is None or "gene_id" not in annotation_df.columns:
        return counts_df

    valid = set(annotation_df["gene_id"].dropna().astype(str))
    overlap = counts_df.index.intersection(valid)
    if len(overlap) == 0:
        return counts_df

    return counts_df.loc[overlap].copy()


def standardize_counts_to_gene_symbols(counts_df: pd.DataFrame, annotation_df: Optional[pd.DataFrame]) -> pd.DataFrame:
    """Standardize gene IDs to uppercase gene symbols with optional Ensembl mapping.

    Steps:
    1) Remove Ensembl version suffixes (ENSG...\.5 -> ENSG...)
    2) Map Ensembl IDs to symbols using annotation reference
    3) Uppercase all resulting symbols for consistent casing
    4) Aggregate duplicate symbols by mean expression
    """
    out = counts_df.copy()
    idx = out.index.astype(str).str.replace(r"\.\d+$", "", regex=True)

    ensembl_to_symbol = {}
    if annotation_df is not None and {"gene_id", "gene_name"}.issubset(set(annotation_df.columns)):
        ref = annotation_df[["gene_id", "gene_name"]].copy()
        ref["gene_id"] = ref["gene_id"].astype(str).str.replace(r"\.\d+$", "", regex=True)
        ref["gene_name"] = ref["gene_name"].astype(str).str.strip()
        ref = ref[ref["gene_name"].notna()]
        ref = ref[ref["gene_name"] != ""]
        ensembl_to_symbol = dict(zip(ref["gene_id"], ref["gene_name"]))

    mapped = []
    for g in idx:
        symbol = ensembl_to_symbol.get(g, g)
        mapped.append(str(symbol).strip().upper())

    out.index = pd.Index(mapped, name="gene_symbol")
    out = out[~out.index.isin(["", "NAN", "NONE"])].copy()
    if out.index.has_duplicates:
        out = out.groupby(level=0).mean()
    return out


def align_samples(counts_df: pd.DataFrame, metadata_df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    common = counts_df.columns.intersection(metadata_df.index)
    if len(common) > 0:
        return counts_df.loc[:, common].copy(), metadata_df.loc[common].copy()

    def _normalize_sample_id(value: object) -> str:
        text = str(value).strip().upper()
        return re.sub(r"[^A-Z0-9]", "", text)

    counts_cols = pd.Index(counts_df.columns.astype(str))
    counts_norm = counts_cols.map(_normalize_sample_id)

    # Try multiple metadata aliases if the metadata index is not directly aligned.
    candidate_series = [("index", pd.Series(metadata_df.index.astype(str), index=metadata_df.index))]
    alias_cols = [
        "sample",
        "sample_id",
        "sample_name",
        "Sample",
        "geo_accession",
        "title",
        "source_name_ch1",
    ]
    for col in alias_cols:
        if col in metadata_df.columns:
            candidate_series.append((col, metadata_df[col].astype(str)))

    best_pairs = []
    for col_name, ser in candidate_series:
        norm_to_meta_index = {}
        for meta_idx, raw_value in ser.items():
            norm = _normalize_sample_id(raw_value)
            if norm and norm not in norm_to_meta_index:
                norm_to_meta_index[norm] = meta_idx

        pairs = []
        for c_col, c_norm in zip(counts_cols, counts_norm):
            meta_idx = norm_to_meta_index.get(c_norm)
            if meta_idx is not None:
                pairs.append((c_col, meta_idx))

        if len(pairs) > len(best_pairs):
            best_pairs = pairs

    if len(best_pairs) == 0:
        counts_examples = ", ".join(list(map(str, counts_df.columns[:5])))
        meta_examples = ", ".join(list(map(str, metadata_df.index[:5])))
        raise ValueError(
            "No overlapping sample IDs between counts matrix and metadata "
            f"(counts examples: [{counts_examples}]; metadata index examples: [{meta_examples}])"
        )

    matched_counts_cols = [c for c, _ in best_pairs]
    matched_meta_index = [m for _, m in best_pairs]
    aligned_counts = counts_df.loc[:, matched_counts_cols].copy()
    aligned_counts.columns = matched_meta_index
    aligned_meta = metadata_df.loc[matched_meta_index].copy()

    if aligned_meta.index.has_duplicates:
        # Keep first occurrence to enforce one sample per metadata index.
        aligned_meta = aligned_meta[~aligned_meta.index.duplicated(keep="first")]
        aligned_counts = aligned_counts.loc[:, aligned_meta.index]

    return aligned_counts, aligned_meta
