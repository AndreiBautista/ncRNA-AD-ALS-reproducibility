"""Robustness assessment utilities for classifier stability and significance."""

from __future__ import annotations

from typing import Dict, List
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler


def evaluate_seed_stability(X: pd.DataFrame, y: pd.Series, features: List[str], seeds: List[int]) -> pd.DataFrame:
    rows = []
    for seed in seeds:
        cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=seed)
        aucs = []
        for tr, te in cv.split(X[features], y):
            scaler = StandardScaler()
            xtr = scaler.fit_transform(X.iloc[tr][features])
            xte = scaler.transform(X.iloc[te][features])
            model = LogisticRegression(max_iter=2000, class_weight="balanced", random_state=seed)
            model.fit(xtr, y.iloc[tr])
            prob = model.predict_proba(xte)[:, 1]
            aucs.append(roc_auc_score(y.iloc[te], prob))
        rows.append({"seed": seed, "auc_mean": float(np.mean(aucs)), "auc_std": float(np.std(aucs))})
    return pd.DataFrame(rows)


def evaluate_class_imbalance_strategies(X: pd.DataFrame, y: pd.Series, features: List[str]) -> pd.DataFrame:
    strategies = [None, "balanced"]
    rows = []
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

    for strategy in strategies:
        aucs = []
        for tr, te in cv.split(X[features], y):
            scaler = StandardScaler()
            xtr = scaler.fit_transform(X.iloc[tr][features])
            xte = scaler.transform(X.iloc[te][features])
            model = LogisticRegression(max_iter=2000, class_weight=strategy, random_state=42)
            model.fit(xtr, y.iloc[tr])
            prob = model.predict_proba(xte)[:, 1]
            aucs.append(roc_auc_score(y.iloc[te], prob))
        rows.append({
            "class_weight": str(strategy),
            "auc_mean": float(np.mean(aucs)),
            "auc_std": float(np.std(aucs)),
        })
    return pd.DataFrame(rows)


def permutation_test_auc(
    X: pd.DataFrame,
    y: pd.Series,
    features: List[str],
    n_permutations: int = 200,
    seed: int = 42,
) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=seed)

    scaler = StandardScaler()
    model = LogisticRegression(max_iter=2000, class_weight="balanced", random_state=seed)

    observed_aucs = []
    for tr, te in cv.split(X[features], y):
        xtr = scaler.fit_transform(X.iloc[tr][features])
        xte = scaler.transform(X.iloc[te][features])
        model.fit(xtr, y.iloc[tr])
        prob = model.predict_proba(xte)[:, 1]
        observed_aucs.append(roc_auc_score(y.iloc[te], prob))
    observed = float(np.mean(observed_aucs))

    perm_aucs = []
    for _ in range(n_permutations):
        y_perm = pd.Series(rng.permutation(y.values), index=y.index)
        aucs = []
        for tr, te in cv.split(X[features], y_perm):
            xtr = scaler.fit_transform(X.iloc[tr][features])
            xte = scaler.transform(X.iloc[te][features])
            model.fit(xtr, y_perm.iloc[tr])
            prob = model.predict_proba(xte)[:, 1]
            aucs.append(roc_auc_score(y_perm.iloc[te], prob))
        perm_aucs.append(float(np.mean(aucs)))

    pval = float((1 + sum(a >= observed for a in perm_aucs)) / (1 + len(perm_aucs)))
    return pd.DataFrame({
        "observed_auc": [observed],
        "mean_permuted_auc": [float(np.mean(perm_aucs))],
        "permutation_pvalue": [pval],
        "n_permutations": [n_permutations],
    })
