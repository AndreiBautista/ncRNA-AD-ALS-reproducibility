"""Reporting utilities for final markdown summary."""

from __future__ import annotations

from pathlib import Path
from typing import Dict, Optional
import pandas as pd


def _table_lines(df: pd.DataFrame) -> list[str]:
    if df.empty:
        return []
    try:
        return df.to_markdown(index=False).splitlines()
    except Exception:
        return df.to_string(index=False).splitlines()


def write_final_summary(
    out_path: str,
    de_overview: pd.DataFrame,
    replication_summary: pd.DataFrame,
    model_summary: pd.DataFrame,
    robustness_tables: Dict[str, pd.DataFrame],
    convergence_summary: pd.DataFrame,
    baseline_comparison_summary: Optional[pd.DataFrame] = None,
) -> None:
    p = Path(out_path)
    p.parent.mkdir(parents=True, exist_ok=True)

    lines = []
    lines.append("# Phase 2 ncRNA Validation Framework Summary")
    lines.append("")
    lines.append("## Scientific Caution")
    lines.append("Findings represent statistical association and predictive performance only.")
    lines.append("No causal biological effect is inferred from this dry-lab analysis alone.")
    lines.append("")

    lines.append("## External Validation Overview")
    if de_overview.empty:
        lines.append("No DE summary available.")
    else:
        lines.extend(_table_lines(de_overview))
    lines.append("")

    lines.append("## External Replication (Fixed ncRNA Panel)")
    if replication_summary.empty:
        lines.append("No replication summary available.")
    else:
        lines.extend(_table_lines(replication_summary))
    lines.append("")

    lines.append("## Model Comparison")
    if model_summary.empty:
        lines.append("No model summary available.")
    else:
        lines.extend(_table_lines(model_summary))
    lines.append("")

    lines.append("## Panel vs Baselines Across Datasets")
    if baseline_comparison_summary is None or baseline_comparison_summary.empty:
        lines.append("No panel-vs-baseline comparison summary available.")
    else:
        lines.extend(_table_lines(baseline_comparison_summary))
    lines.append("")

    lines.append("## Robustness")
    for name, table in robustness_tables.items():
        lines.append(f"### {name}")
        if table.empty:
            lines.append("No results.")
        else:
            lines.extend(_table_lines(table))
        lines.append("")

    lines.append("## Cross-Disease Framework Summary")
    if convergence_summary.empty:
        lines.append("No convergence summary available.")
    else:
        lines.extend(_table_lines(convergence_summary))
    lines.append("")

    lines.append("## Limitations")
    lines.append("- Public cohorts can contain technical and clinical heterogeneity.")
    lines.append("- Postmortem tissue may introduce RNA quality effects.")
    lines.append("- Target/pathway interpretation depends on external mapping resources.")
    lines.append("- External replication confirms consistency, not causality.")

    p.write_text("\n".join(lines), encoding="utf-8")
