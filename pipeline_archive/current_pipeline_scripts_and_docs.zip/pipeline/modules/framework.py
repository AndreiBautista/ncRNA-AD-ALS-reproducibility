"""Reusable cross-disease framework summaries for Phase 2 outputs."""

from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler
from scipy.stats import ttest_ind


def summarize_validation_by_disease(validation_table: pd.DataFrame) -> pd.DataFrame:
    if validation_table.empty:
        return pd.DataFrame()

    valid = validation_table[validation_table["present"]].copy()
    if valid.empty:
        return pd.DataFrame(columns=["disease", "gene_id", "mean_log2FC", "mean_fdr", "n_datasets"])

    out = (
        valid.groupby(["disease", "gene_id"])
        .agg(
            mean_log2FC=("log2FC", "mean"),
            mean_fdr=("fdr", "mean"),
            n_datasets=("dataset_id", "nunique"),
        )
        .reset_index()
    )
    return out


def summarize_model_transportability(model_summary: pd.DataFrame) -> pd.DataFrame:
    if model_summary.empty:
        return pd.DataFrame()

    cols = [c for c in ["model", "auc", "accuracy", "f1", "sensitivity", "specificity", "auc_ci_low", "auc_ci_high"] if c in model_summary.columns]
    out = model_summary[cols].copy()
    out["generalization_gap_to_best_auc"] = out["auc"].max() - out["auc"] if "auc" in out.columns else np.nan
    return out.sort_values("auc", ascending=False) if "auc" in out.columns else out


def _compute_binary_metrics(y_true: np.ndarray, y_prob: np.ndarray) -> dict:
    y_pred = (y_prob >= 0.5).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
    specificity = tn / (tn + fp) if (tn + fp) > 0 else np.nan
    sensitivity = tp / (tp + fn) if (tp + fn) > 0 else np.nan
    return {
        "auc": roc_auc_score(y_true, y_prob),
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "f1": f1_score(y_true, y_pred, zero_division=0),
        "sensitivity": sensitivity,
        "specificity": specificity,
    }


def _top_de_features_train_only(X_train: pd.DataFrame, y_train: pd.Series, k: int, exclude: list[str] | None = None) -> list[str]:
    exclude = set(exclude or [])
    candidates = [c for c in X_train.columns if c not in exclude]
    if not candidates:
        return []

    disease = X_train.loc[y_train == 1, candidates]
    control = X_train.loc[y_train == 0, candidates]
    scores = []
    for gene in candidates:
        stat = ttest_ind(disease[gene].values, control[gene].values, equal_var=False, nan_policy="omit")
        p = float(stat.pvalue) if np.isfinite(stat.pvalue) else 1.0
        scores.append((gene, p))
    scores.sort(key=lambda x: x[1])
    return [g for g, _ in scores[:k]]


def compute_biomarker_generalization_scores(validation_table: pd.DataFrame) -> pd.DataFrame:
    """Score how consistently each fixed biomarker generalizes across datasets.

    Score combines coverage (presence rate), directional consistency, and significance support.
    """
    if validation_table.empty:
        return pd.DataFrame()

    rows = []
    by_gene = validation_table.groupby("gene_id")
    n_datasets_total = validation_table["dataset_id"].nunique()

    for gene_id, sub in by_gene:
        present = sub[sub["present"]].copy()
        present_count = int(present.shape[0])
        presence_rate = present_count / n_datasets_total if n_datasets_total > 0 else 0.0

        if present.empty:
            rows.append(
                {
                    "gene_id": gene_id,
                    "datasets_present": 0,
                    "presence_rate": 0.0,
                    "direction_consistency": 0.0,
                    "significance_support": 0.0,
                    "generalization_score": 0.0,
                }
            )
            continue

        sign_values = np.sign(present["log2FC"].astype(float).values)
        direction_consistency = float(abs(np.mean(sign_values)))

        fdr_vals = present["fdr"].astype(float).values
        valid_fdr = fdr_vals[np.isfinite(fdr_vals)]
        if len(valid_fdr) == 0:
            significance_support = 0.0
        else:
            sig_fraction = float(np.mean(valid_fdr < 0.05))
            significance_support = 0.5 * sig_fraction + 0.5 * float(1.0 - min(np.mean(valid_fdr), 1.0))

        score = float((0.4 * presence_rate) + (0.35 * direction_consistency) + (0.25 * significance_support))

        rows.append(
            {
                "gene_id": gene_id,
                "datasets_present": present_count,
                "presence_rate": presence_rate,
                "direction_consistency": direction_consistency,
                "significance_support": significance_support,
                "generalization_score": score,
            }
        )

    return pd.DataFrame(rows).sort_values("generalization_score", ascending=False).reset_index(drop=True)


def run_pooled_panel_vs_baselines(
    expr_df: pd.DataFrame,
    groups: pd.Series,
    known_ncrnas: list[str],
    n_splits: int = 5,
    random_repeats: int = 100,
    seed: int = 42,
) -> pd.DataFrame:
    """Compare fixed panel vs random-gene and top-DE baselines using pooled CV."""
    if expr_df.empty:
        return pd.DataFrame()

    common = expr_df.columns.intersection(groups.index)
    X = expr_df.loc[:, common].T
    y = groups.loc[common].map({"control": 0, "disease": 1}).astype(int)

    fixed_features = [g for g in known_ncrnas if g in X.columns]
    if len(fixed_features) < 2:
        return pd.DataFrame()
    baseline_pool = [g for g in X.columns if g not in fixed_features]

    rng = np.random.default_rng(seed)
    cv = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    k = len(fixed_features)
    if len(baseline_pool) < k:
        return pd.DataFrame()

    rows = []
    for fold, (tr, te) in enumerate(cv.split(X, y), start=1):
        X_train = X.iloc[tr]
        X_test = X.iloc[te]
        y_train = y.iloc[tr]
        y_test = y.iloc[te]

        scaler = StandardScaler()

        # Fixed panel
        model = LogisticRegression(max_iter=2000, class_weight="balanced", random_state=seed)
        xtr = scaler.fit_transform(X_train[fixed_features])
        xte = scaler.transform(X_test[fixed_features])
        model.fit(xtr, y_train)
        prob = model.predict_proba(xte)[:, 1]
        m = _compute_binary_metrics(y_test.values, prob)
        m.update({"scenario": "pooled_cv", "feature_set": "fixed_panel", "fold": fold, "n_features": k})
        rows.append(m)

        # Top DE baseline (training-fold only)
        top_de = _top_de_features_train_only(X_train, y_train, k=k, exclude=fixed_features)
        if len(top_de) >= 2:
            model = LogisticRegression(max_iter=2000, class_weight="balanced", random_state=seed)
            xtr = scaler.fit_transform(X_train[top_de])
            xte = scaler.transform(X_test[top_de])
            model.fit(xtr, y_train)
            prob = model.predict_proba(xte)[:, 1]
            m = _compute_binary_metrics(y_test.values, prob)
            m.update({"scenario": "pooled_cv", "feature_set": "top_de_baseline", "fold": fold, "n_features": len(top_de)})
            rows.append(m)

        # Random-gene baseline (mean across repeats)
        aucs = []
        accs = []
        f1s = []
        for _ in range(random_repeats):
            feat = rng.choice(baseline_pool, size=k, replace=False).tolist()
            model = LogisticRegression(max_iter=2000, class_weight="balanced", random_state=seed)
            xtr = scaler.fit_transform(X_train[feat])
            xte = scaler.transform(X_test[feat])
            model.fit(xtr, y_train)
            prob = model.predict_proba(xte)[:, 1]
            aucs.append(roc_auc_score(y_test, prob))
            pred = (prob >= 0.5).astype(int)
            accs.append(accuracy_score(y_test, pred))
            f1s.append(f1_score(y_test, pred, zero_division=0))

        rows.append(
            {
                "scenario": "pooled_cv",
                "feature_set": "random_genes_baseline",
                "fold": fold,
                "n_features": k,
                "auc": float(np.mean(aucs)),
                "accuracy": float(np.mean(accs)),
                "precision": np.nan,
                "recall": np.nan,
                "f1": float(np.mean(f1s)),
                "sensitivity": np.nan,
                "specificity": np.nan,
            }
        )

    return pd.DataFrame(rows)


def run_cross_disease_transportability(
    dataset_artifacts: dict,
    known_ncrnas: list[str],
    random_repeats: int = 100,
    seed: int = 42,
) -> pd.DataFrame:
    """Run AD->ALS and ALS->AD transportability with panel and baselines."""
    records = []
    rng = np.random.default_rng(seed)

    diseases = sorted({str(v["disease"]).lower() for v in dataset_artifacts.values()})
    if "alzheimers" not in diseases or "als" not in diseases:
        return pd.DataFrame()

    disease_pairs = [("alzheimers", "als"), ("als", "alzheimers")]
    for train_dis, test_dis in disease_pairs:
        train_sets = [v for v in dataset_artifacts.values() if str(v["disease"]).lower() == train_dis]
        test_sets = [v for v in dataset_artifacts.values() if str(v["disease"]).lower() == test_dis]
        if not train_sets or not test_sets:
            continue

        train_expr = pd.concat([d["log2cpm"] for d in train_sets], axis=1)
        test_expr = pd.concat([d["log2cpm"] for d in test_sets], axis=1)
        train_grp = pd.concat([d["groups"] for d in train_sets])
        test_grp = pd.concat([d["groups"] for d in test_sets])

        common = train_expr.index.intersection(test_expr.index)
        if len(common) == 0:
            continue

        X_train = train_expr.loc[common].T
        X_test = test_expr.loc[common].T
        X_train = X_train.fillna(0.0)
        X_test = X_test.fillna(0.0)
        y_train = train_grp.map({"control": 0, "disease": 1}).astype(int)
        y_test = test_grp.map({"control": 0, "disease": 1}).astype(int)

        if y_train.nunique() < 2 or y_test.nunique() < 2:
            continue

        fixed_features = [g for g in known_ncrnas if g in X_train.columns and g in X_test.columns]
        if len(fixed_features) < 2:
            continue
        k = len(fixed_features)
        baseline_pool = [g for g in common if g not in fixed_features]
        if len(baseline_pool) < k:
            continue

        scaler = StandardScaler()

        # Fixed panel
        model = LogisticRegression(max_iter=2000, class_weight="balanced", random_state=seed)
        xtr = scaler.fit_transform(X_train[fixed_features])
        xte = scaler.transform(X_test[fixed_features])
        model.fit(xtr, y_train)
        prob = model.predict_proba(xte)[:, 1]
        m = _compute_binary_metrics(y_test.values, prob)
        m.update({
            "scenario": f"train_{train_dis}_test_{test_dis}",
            "feature_set": "fixed_panel",
            "n_features": k,
        })
        records.append(m)

        # Top-DE baseline from training disease only
        top_de = _top_de_features_train_only(X_train, y_train, k=k, exclude=fixed_features)
        top_de = [g for g in top_de if g in X_test.columns]
        if len(top_de) >= 2:
            model = LogisticRegression(max_iter=2000, class_weight="balanced", random_state=seed)
            xtr = scaler.fit_transform(X_train[top_de])
            xte = scaler.transform(X_test[top_de])
            model.fit(xtr, y_train)
            prob = model.predict_proba(xte)[:, 1]
            m = _compute_binary_metrics(y_test.values, prob)
            m.update({
                "scenario": f"train_{train_dis}_test_{test_dis}",
                "feature_set": "top_de_baseline",
                "n_features": len(top_de),
            })
            records.append(m)

        # Random baseline averaged over repeats
        aucs = []
        accs = []
        f1s = []
        for _ in range(random_repeats):
            feat = rng.choice(baseline_pool, size=k, replace=False).tolist()
            model = LogisticRegression(max_iter=2000, class_weight="balanced", random_state=seed)
            xtr = scaler.fit_transform(X_train[feat])
            xte = scaler.transform(X_test[feat])
            model.fit(xtr, y_train)
            prob = model.predict_proba(xte)[:, 1]
            aucs.append(roc_auc_score(y_test, prob))
            pred = (prob >= 0.5).astype(int)
            accs.append(accuracy_score(y_test, pred))
            f1s.append(f1_score(y_test, pred, zero_division=0))

        records.append(
            {
                "scenario": f"train_{train_dis}_test_{test_dis}",
                "feature_set": "random_genes_baseline",
                "n_features": k,
                "auc": float(np.mean(aucs)),
                "accuracy": float(np.mean(accs)),
                "precision": np.nan,
                "recall": np.nan,
                "f1": float(np.mean(f1s)),
                "sensitivity": np.nan,
                "specificity": np.nan,
            }
        )

    return pd.DataFrame(records)


def summarize_panel_vs_baselines(
    pooled_comparison: pd.DataFrame,
    transportability: pd.DataFrame,
) -> pd.DataFrame:
    tables = []
    if not pooled_comparison.empty:
        tables.append(pooled_comparison)
    if not transportability.empty:
        tables.append(transportability)
    if not tables:
        return pd.DataFrame()

    combined = pd.concat(tables, ignore_index=True)
    metric_cols = [c for c in ["auc", "accuracy", "f1", "sensitivity", "specificity"] if c in combined.columns]
    summary = (
        combined.groupby(["scenario", "feature_set"])[metric_cols]
        .mean(numeric_only=True)
        .reset_index()
        .sort_values(["scenario", "auc"], ascending=[True, False])
    )
    return summary
