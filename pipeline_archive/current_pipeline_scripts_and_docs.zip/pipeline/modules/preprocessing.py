"""Preprocessing routines with leakage-safe transformations."""

from __future__ import annotations

from typing import Dict, Optional
import numpy as np
import pandas as pd

NCRNA_KEYWORDS = {
    "lncrna", "lnc_rna", "mirna", "mir", "snorna", "snrna", "antisense",
    "misc_rna", "rrna", "ncrna", "pseudogene", "scarna", "vault_rna", "srna"
}

PROTEIN_KEYWORDS = {"protein_coding", "coding"}


def handle_missing_values(counts_df: pd.DataFrame, min_fraction: float = 0.5) -> pd.DataFrame:
    out = counts_df.copy()
    keep = out.notna().mean(axis=1) >= min_fraction
    out = out.loc[keep]
    out = out.fillna(0.0)
    return out


def normalize_cpm(counts_df: pd.DataFrame) -> pd.DataFrame:
    lib_sizes = counts_df.sum(axis=0).replace(0, np.nan)
    cpm = counts_df.divide(lib_sizes, axis=1) * 1e6
    return cpm.fillna(0.0)


def log_transform(expr_df: pd.DataFrame, pseudocount: float = 1.0) -> pd.DataFrame:
    return np.log2(expr_df + pseudocount)


def split_gene_sets(expr_df: pd.DataFrame, annotation_df: Optional[pd.DataFrame]) -> Dict[str, pd.DataFrame]:
    if annotation_df is None or "biotype" not in annotation_df.columns:
        return {
            "all": expr_df,
            "ncrna": expr_df.copy(),
            "protein_coding": expr_df.copy(),
        }

    biotype = annotation_df.set_index("gene_id")["biotype"].astype(str).str.lower()
    biotype = biotype.reindex(expr_df.index).fillna("")

    ncrna_mask = biotype.apply(lambda x: any(k in x for k in NCRNA_KEYWORDS))
    protein_mask = biotype.apply(lambda x: any(k in x for k in PROTEIN_KEYWORDS))

    return {
        "all": expr_df,
        "ncrna": expr_df.loc[ncrna_mask[ncrna_mask].index].copy(),
        "protein_coding": expr_df.loc[protein_mask[protein_mask].index].copy(),
    }


def preprocess_counts(
    counts_df: pd.DataFrame,
    annotation_df: Optional[pd.DataFrame],
    pseudocount: float = 1.0,
) -> Dict[str, pd.DataFrame]:
    cleaned = handle_missing_values(counts_df)
    cpm = normalize_cpm(cleaned)
    log2cpm = log_transform(cpm, pseudocount=pseudocount)
    partitions = split_gene_sets(log2cpm, annotation_df)
    return {"cleaned_counts": cleaned, "cpm": cpm, "log2cpm": log2cpm, **partitions}
