"""Phase 2 validation framework modules package."""

from .configuration import load_config, validate_config, ensure_output_dirs
from .orchestrator import run_pipeline
from .validation import (
    validate_fixed_biomarkers,
    summarize_external_validation,
    summarize_external_validation_by_dataset,
    build_dataset_gene_matrix,
)
from .framework import (
    summarize_validation_by_disease,
    summarize_model_transportability,
    compute_biomarker_generalization_scores,
    run_pooled_panel_vs_baselines,
    run_cross_disease_transportability,
    summarize_panel_vs_baselines,
)

__all__ = [
    "load_config",
    "validate_config",
    "ensure_output_dirs",
    "run_pipeline",
    "validate_fixed_biomarkers",
    "summarize_external_validation",
    "summarize_external_validation_by_dataset",
    "build_dataset_gene_matrix",
    "summarize_validation_by_disease",
    "summarize_model_transportability",
    "compute_biomarker_generalization_scores",
    "run_pooled_panel_vs_baselines",
    "run_cross_disease_transportability",
    "summarize_panel_vs_baselines",
]
