"""Publication-style figure generation utilities."""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional
import importlib.util
import importlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_curve, auc

if importlib.util.find_spec("networkx") is not None:
    nx = importlib.import_module("networkx")
else:
    nx = None


plt.style.use("seaborn-v0_8-whitegrid")
matplotlib.rcParams.update({
    "font.size": 11,
    "axes.titlesize": 14,
    "axes.labelsize": 12,
    "axes.titleweight": "bold",
    "legend.frameon": False,
    "figure.facecolor": "white",
    "axes.facecolor": "white",
    "grid.alpha": 0.25,
})


def _save(fig: plt.Figure, base_path: Path, save_png: bool = True, save_pdf: bool = True, dpi: int = 300) -> None:
    base_path.parent.mkdir(parents=True, exist_ok=True)
    if save_png:
        fig.savefig(base_path.with_suffix(".png"), dpi=dpi, bbox_inches="tight")
    if save_pdf:
        fig.savefig(base_path.with_suffix(".pdf"), dpi=dpi, bbox_inches="tight")
    plt.close(fig)


def plot_pca(expr_df: pd.DataFrame, groups: pd.Series, out_base: Path, **kwargs) -> None:
    samples = expr_df.columns.intersection(groups.index)
    x = expr_df[samples].T
    y = groups.loc[samples]

    scaler = StandardScaler()
    x_scaled = scaler.fit_transform(x)
    pca = PCA(n_components=2)
    coords = pca.fit_transform(x_scaled)

    fig, ax = plt.subplots(figsize=(7, 6))
    for label, color in [("control", "#4C78A8"), ("disease", "#F58518")]:
        mask = y == label
        ax.scatter(coords[mask, 0], coords[mask, 1], s=50, alpha=0.85, label=label, c=color)

    ax.set_xlabel(f"PC1 ({pca.explained_variance_ratio_[0]*100:.1f}% var)")
    ax.set_ylabel(f"PC2 ({pca.explained_variance_ratio_[1]*100:.1f}% var)")
    ax.set_title("PCA: Disease vs Control")
    ax.legend(frameon=False)
    ax.grid(alpha=0.2)
    _save(fig, out_base, **kwargs)


def plot_volcano(de_df: pd.DataFrame, out_base: Path, fdr_threshold: float = 0.05, **kwargs) -> None:
    if de_df.empty:
        return
    y = -np.log10(np.clip(de_df["fdr"].values, 1e-300, None))
    x = de_df["log2FC"].values
    sig = de_df["fdr"].values < fdr_threshold

    fig, ax = plt.subplots(figsize=(7, 6))
    ax.scatter(x[~sig], y[~sig], s=8, alpha=0.4, c="#7F7F7F")
    ax.scatter(x[sig], y[sig], s=10, alpha=0.8, c="#D62728")
    ax.axhline(-np.log10(fdr_threshold), linestyle="--", linewidth=1.0, c="black")
    ax.set_xlabel("log2 Fold Change")
    ax.set_ylabel("-log10(FDR)")
    ax.set_title("Volcano Plot")
    ax.grid(alpha=0.2)
    _save(fig, out_base, **kwargs)


def plot_heatmap(expr_df: pd.DataFrame, genes: List[str], out_base: Path, **kwargs) -> None:
    sel = [g for g in genes if g in expr_df.index]
    if len(sel) == 0:
        return

    z = expr_df.loc[sel]
    z = z.sub(z.mean(axis=1), axis=0).div(z.std(axis=1).replace(0, np.nan), axis=0).fillna(0)

    fig, ax = plt.subplots(figsize=(10, max(4, len(sel) * 0.3)))
    im = ax.imshow(z.values, aspect="auto", cmap="coolwarm", vmin=-2.5, vmax=2.5)
    ax.set_yticks(np.arange(len(sel)))
    ax.set_yticklabels(sel, fontsize=8)
    ax.set_xticks(np.arange(len(z.columns)))
    ax.set_xticklabels(z.columns, rotation=90, fontsize=6)
    ax.set_title("Heatmap (z-score)")
    fig.colorbar(im, ax=ax, fraction=0.02, pad=0.02)
    _save(fig, out_base, **kwargs)


def plot_venn_like(counts: Dict[str, int], out_base: Path, **kwargs) -> None:
    fig, ax = plt.subplots(figsize=(7, 4))
    names = list(counts.keys())
    values = [counts[k] for k in names]
    ax.bar(names, values, color=["#4C78A8", "#F58518", "#54A24B"][: len(names)])
    ax.set_ylabel("Count")
    ax.set_title("Dataset Set Sizes / Overlap Summary")
    for i, v in enumerate(values):
        ax.text(i, v, str(v), ha="center", va="bottom", fontsize=9)
    _save(fig, out_base, **kwargs)


def plot_roc_from_predictions(pred_df: pd.DataFrame, out_base: Path, **kwargs) -> None:
    if pred_df.empty:
        return

    fig, ax = plt.subplots(figsize=(6, 6))
    for model_name, sub in pred_df.groupby("model"):
        fpr, tpr, _ = roc_curve(sub["y_true"], sub["y_prob"])
        auc_val = auc(fpr, tpr)
        ax.plot(fpr, tpr, linewidth=2, label=f"{model_name} (AUC={auc_val:.3f})")
    ax.plot([0, 1], [0, 1], linestyle="--", c="gray")
    ax.set_xlabel("1 - Specificity")
    ax.set_ylabel("Sensitivity")
    ax.set_title("ROC Curves")
    ax.legend(frameon=False, fontsize=8)
    ax.grid(alpha=0.2)
    _save(fig, out_base, **kwargs)


def plot_biomarker_boxplots(expr_df: pd.DataFrame, groups: pd.Series, biomarkers: List[str], out_base: Path, **kwargs) -> None:
    genes = [g for g in biomarkers if g in expr_df.index]
    if not genes:
        return

    n = len(genes)
    fig, axes = plt.subplots(n, 1, figsize=(7, max(3, 2.2 * n)), squeeze=False)
    for i, gene in enumerate(genes):
        ax = axes[i, 0]
        row = expr_df.loc[gene]
        d = row[groups[groups == "disease"].index].values
        c = row[groups[groups == "control"].index].values
        ax.boxplot([c, d], labels=["control", "disease"], patch_artist=True)
        ax.set_title(gene)
        ax.set_ylabel("log2-CPM")
        ax.grid(alpha=0.2, axis="y")
    fig.suptitle("Known ncRNA Biomarkers", y=1.0)
    fig.tight_layout()
    _save(fig, out_base, **kwargs)


def plot_model_comparison(summary_df: pd.DataFrame, out_base: Path, **kwargs) -> None:
    if summary_df.empty:
        return

    disp = summary_df.copy()
    disp = disp.sort_values("auc", ascending=False).reset_index(drop=True)
    disp["label"] = (
        disp["model"]
        .str.replace("_fixed_panel", "", regex=False)
        .str.replace("_", " ", regex=False)
        .str.title()
    )

    fig, ax = plt.subplots(figsize=(8, 5))
    bars = ax.bar(disp["label"], disp["auc"], color="#4C78A8")
    ax.set_ylim(0, 1)
    ax.set_ylabel("AUC")
    ax.set_title("Model Comparison (Fixed Biomarker Panel)")
    ax.tick_params(axis="x", rotation=25)
    ax.grid(alpha=0.2, axis="y")
    for b, v in zip(bars, disp["auc"]):
        ax.text(b.get_x() + b.get_width() / 2, v + 0.02, f"{v:.2f}", ha="center", va="bottom", fontsize=8)
    _save(fig, out_base, **kwargs)


def plot_replication_summary(rep_df: pd.DataFrame, out_base: Path, **kwargs) -> None:
    if rep_df.empty:
        return

    if "concordance_rate" in rep_df.columns:
        value_col = "concordance_rate"
        ylabel = "Direction Concordance Rate"
        title = "External Replication Summary"
    elif "presence_rate" in rep_df.columns:
        value_col = "presence_rate"
        ylabel = "Dataset Presence Rate"
        title = "External Validation Presence Summary"
    else:
        return

    fig, ax = plt.subplots(figsize=(8, 5))
    disp = rep_df.sort_values(value_col, ascending=False).reset_index(drop=True)
    bars = ax.bar(disp["gene_id"], disp[value_col], color="#54A24B")
    ax.set_ylim(0, 1)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.tick_params(axis="x", rotation=25)
    for b, v in zip(bars, disp[value_col]):
        if np.isfinite(v):
            ax.text(b.get_x() + b.get_width() / 2, v + 0.02, f"{v:.2f}", ha="center", va="bottom", fontsize=8)
    _save(fig, out_base, **kwargs)


def plot_generalization_scores(scores_df: pd.DataFrame, out_base: Path, **kwargs) -> None:
    if scores_df.empty:
        return
    disp = scores_df.sort_values("generalization_score", ascending=True)
    fig, ax = plt.subplots(figsize=(8, 4.8))
    bars = ax.barh(disp["gene_id"], disp["generalization_score"], color="#2E8B57")
    ax.set_xlim(0, 1)
    ax.set_xlabel("Generalization Score")
    ax.set_title("Biomarker Cross-Dataset Generalization")
    ax.grid(alpha=0.2, axis="x")
    for b, v in zip(bars, disp["generalization_score"]):
        ax.text(v + 0.01, b.get_y() + b.get_height() / 2, f"{v:.2f}", va="center", fontsize=8)
    _save(fig, out_base, **kwargs)


def plot_transportability(transport_df: pd.DataFrame, out_base: Path, **kwargs) -> None:
    if transport_df.empty:
        return
    use = transport_df.copy()
    use = use.dropna(subset=["auc"])
    if use.empty:
        return

    scenarios = list(dict.fromkeys(use["scenario"].tolist()))
    feature_sets = list(dict.fromkeys(use["feature_set"].tolist()))

    x = np.arange(len(scenarios))
    width = 0.8 / max(len(feature_sets), 1)
    fig, ax = plt.subplots(figsize=(9, 5))

    palette = {
        "fixed_panel": "#1f77b4",
        "top_de_baseline": "#ff7f0e",
        "random_genes_baseline": "#7f7f7f",
    }

    for i, fs in enumerate(feature_sets):
        sub = use[use["feature_set"] == fs].set_index("scenario")
        vals = [float(sub.loc[s, "auc"]) if s in sub.index else np.nan for s in scenarios]
        offset = (i - (len(feature_sets) - 1) / 2) * width
        bars = ax.bar(x + offset, vals, width=width, label=fs.replace("_", " "), color=palette.get(fs, "#4C78A8"))
        for b, v in zip(bars, vals):
            if np.isfinite(v):
                ax.text(b.get_x() + b.get_width() / 2, v + 0.02, f"{v:.2f}", ha="center", va="bottom", fontsize=8)

    ax.set_xticks(x)
    ax.set_xticklabels([s.replace("_", " ") for s in scenarios], rotation=15)
    ax.set_ylim(0, 1)
    ax.set_ylabel("AUC")
    ax.set_title("Cross-Disease Transportability")
    ax.legend(frameon=False, fontsize=8)
    ax.grid(alpha=0.2, axis="y")
    _save(fig, out_base, **kwargs)


def plot_panel_vs_baselines_summary(summary_df: pd.DataFrame, out_base: Path, **kwargs) -> None:
    if summary_df.empty or "auc" not in summary_df.columns:
        return

    use = summary_df.copy().dropna(subset=["auc"])
    if use.empty:
        return

    scenarios = list(dict.fromkeys(use["scenario"].tolist()))
    feature_sets = list(dict.fromkeys(use["feature_set"].tolist()))
    x = np.arange(len(scenarios))
    width = 0.8 / max(len(feature_sets), 1)

    fig, ax = plt.subplots(figsize=(10, 5.5))
    palette = {
        "fixed_panel": "#1f77b4",
        "top_de_baseline": "#ff7f0e",
        "random_genes_baseline": "#7f7f7f",
    }

    for i, fs in enumerate(feature_sets):
        sub = use[use["feature_set"] == fs].set_index("scenario")
        vals = [float(sub.loc[s, "auc"]) if s in sub.index else np.nan for s in scenarios]
        offset = (i - (len(feature_sets) - 1) / 2) * width
        ax.bar(x + offset, vals, width=width, label=fs.replace("_", " "), color=palette.get(fs, "#4C78A8"))

    ax.set_xticks(x)
    ax.set_xticklabels([s.replace("_", " ") for s in scenarios], rotation=20)
    ax.set_ylim(0, 1)
    ax.set_ylabel("AUC")
    ax.set_title("Panel vs Baselines Across Scenarios")
    ax.legend(frameon=False, fontsize=8)
    ax.grid(alpha=0.2, axis="y")
    _save(fig, out_base, **kwargs)


def plot_dataset_panel_coverage(by_dataset_df: pd.DataFrame, out_base: Path, **kwargs) -> None:
    if by_dataset_df.empty:
        return
    req = {"dataset_id", "panel_genes_present", "panel_genes_significant"}
    if not req.issubset(set(by_dataset_df.columns)):
        return

    disp = by_dataset_df.copy().sort_values("dataset_id")
    x = np.arange(len(disp))
    width = 0.36

    fig, ax = plt.subplots(figsize=(8.5, 4.8))
    b1 = ax.bar(x - width / 2, disp["panel_genes_present"], width=width, color="#4C78A8", label="present")
    b2 = ax.bar(x + width / 2, disp["panel_genes_significant"], width=width, color="#F58518", label="significant")

    ax.set_xticks(x)
    ax.set_xticklabels(disp["dataset_id"], rotation=15)
    ymax = max(5, int(max(disp["panel_genes_present"].max(), disp["panel_genes_significant"].max())) + 1)
    ax.set_ylim(0, ymax)
    ax.set_ylabel("Number of Panel Genes")
    ax.set_title("Fixed Panel Coverage by Dataset")
    ax.legend(frameon=False)
    ax.grid(alpha=0.2, axis="y")

    for bars in (b1, b2):
        for bar in bars:
            h = bar.get_height()
            ax.text(bar.get_x() + bar.get_width() / 2, h + 0.05, f"{int(h)}", ha="center", va="bottom", fontsize=8)

    _save(fig, out_base, **kwargs)


def plot_network(graph, out_base: Path, **kwargs) -> None:
    if nx is None or graph is None or graph.number_of_nodes() == 0:
        return
    pos = nx.spring_layout(graph, seed=42)
    colors = []
    for n in graph.nodes:
        t = graph.nodes[n].get("node_type", "unknown")
        colors.append({"ncrna": "#F58518", "gene": "#4C78A8", "pathway": "#54A24B"}.get(t, "#7F7F7F"))
    fig, ax = plt.subplots(figsize=(10, 8))
    nx.draw_networkx(graph, pos=pos, node_color=colors, node_size=300, font_size=7, ax=ax, arrows=True)
    ax.set_title("ncRNA-Target-Pathway Network")
    ax.axis("off")
    _save(fig, out_base, **kwargs)
