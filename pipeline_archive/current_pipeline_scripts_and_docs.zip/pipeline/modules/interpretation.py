"""Biological interpretation: target mapping, network construction, and pathway enrichment hooks."""

from __future__ import annotations

from pathlib import Path
from typing import Optional, List, Dict
import importlib.util
import importlib
import numpy as np
import pandas as pd
from scipy.stats import hypergeom

if importlib.util.find_spec("networkx") is not None:
    nx = importlib.import_module("networkx")
else:
    nx = None


KEY_PATHWAY_TERMS = ["neuroinflammation", "autophagy", "immune", "proteostasis"]


def load_target_map(path: Optional[str]) -> pd.DataFrame:
    if not path:
        return pd.DataFrame(columns=["ncrna", "target_gene"])
    p = Path(path)
    if not p.exists():
        return pd.DataFrame(columns=["ncrna", "target_gene"])
    df = pd.read_csv(p)
    expected = {"ncrna", "target_gene"}
    if not expected.issubset(df.columns):
        raise ValueError(f"Target map must contain columns: {expected}")
    return df[["ncrna", "target_gene"]].dropna().drop_duplicates()


def load_pathway_map(path: Optional[str]) -> pd.DataFrame:
    if not path:
        return pd.DataFrame(columns=["pathway", "gene"])
    p = Path(path)
    if not p.exists():
        return pd.DataFrame(columns=["pathway", "gene"])
    df = pd.read_csv(p)
    expected = {"pathway", "gene"}
    if not expected.issubset(df.columns):
        raise ValueError(f"Pathway map must contain columns: {expected}")
    return df[["pathway", "gene"]].dropna().drop_duplicates()


def build_regulatory_network(known_ncrnas: List[str], target_map: pd.DataFrame, pathway_map: pd.DataFrame):
    if nx is None:
        return None

    g = nx.DiGraph()

    for n in known_ncrnas:
        g.add_node(n, node_type="ncrna")

    for _, row in target_map.iterrows():
        if row["ncrna"] not in known_ncrnas:
            continue
        g.add_node(row["target_gene"], node_type="gene")
        g.add_edge(row["ncrna"], row["target_gene"], edge_type="ncrna_target")

    for _, row in pathway_map.iterrows():
        pathway = f"pathway::{row['pathway']}"
        gene = row["gene"]
        if gene in g.nodes:
            g.add_node(pathway, node_type="pathway")
            g.add_edge(gene, pathway, edge_type="gene_pathway")

    return g


def summarize_network_hubs(graph) -> pd.DataFrame:
    if graph is None or graph.number_of_nodes() == 0:
        return pd.DataFrame(columns=["node", "node_type", "degree", "betweenness"])
    deg = dict(graph.degree())
    btw = nx.betweenness_centrality(graph)
    rows = []
    for n in graph.nodes:
        rows.append({
            "node": n,
            "node_type": graph.nodes[n].get("node_type", "unknown"),
            "degree": deg.get(n, 0),
            "betweenness": btw.get(n, 0.0),
        })
    return pd.DataFrame(rows).sort_values(["degree", "betweenness"], ascending=False)


def keyword_pathway_enrichment(target_genes: List[str], pathway_map: pd.DataFrame) -> pd.DataFrame:
    if pathway_map.empty or not target_genes:
        return pd.DataFrame(columns=["keyword", "matched_pathways", "matched_genes", "pvalue"])

    all_genes = set(pathway_map["gene"])
    query_genes = set(target_genes).intersection(all_genes)
    M = len(all_genes)
    n = len(query_genes)
    rows = []

    for keyword in KEY_PATHWAY_TERMS:
        subset = pathway_map[pathway_map["pathway"].str.lower().str.contains(keyword)]
        subset_genes = set(subset["gene"])
        N = len(subset_genes)
        k = len(query_genes.intersection(subset_genes))
        p = float(hypergeom.sf(k - 1, M, n, N)) if M > 0 and n > 0 and N > 0 else np.nan
        rows.append({
            "keyword": keyword,
            "matched_pathways": int(subset["pathway"].nunique()),
            "matched_genes": k,
            "pvalue": p,
        })

    out = pd.DataFrame(rows).sort_values("pvalue")
    return out
