"""Cross-disease convergence analysis utilities."""

from __future__ import annotations

from typing import Tuple
import numpy as np
import pandas as pd
from scipy.stats import hypergeom


def compare_disease_de_tables(
    de_a: pd.DataFrame,
    de_b: pd.DataFrame,
    disease_a: str,
    disease_b: str,
    fdr_threshold: float = 0.05,
    universe_size: int | None = None,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    sig_a = de_a[de_a["fdr"] < fdr_threshold].copy()
    sig_b = de_b[de_b["fdr"] < fdr_threshold].copy()

    shared = sig_a.index.intersection(sig_b.index)
    overlap = pd.DataFrame({
        "gene_id": shared,
        f"{disease_a}_log2FC": sig_a.loc[shared, "log2FC"].values,
        f"{disease_b}_log2FC": sig_b.loc[shared, "log2FC"].values,
        f"{disease_a}_fdr": sig_a.loc[shared, "fdr"].values,
        f"{disease_b}_fdr": sig_b.loc[shared, "fdr"].values,
    })
    overlap["effect_concordant"] = np.sign(overlap[f"{disease_a}_log2FC"]) == np.sign(overlap[f"{disease_b}_log2FC"])

    if universe_size is None:
        universe_size = len(de_a.index.union(de_b.index))

    M = int(universe_size)
    n = int(len(sig_a))
    N = int(len(sig_b))
    k = int(len(shared))
    p_hyper = float(hypergeom.sf(k - 1, M, n, N)) if M > 0 else np.nan

    summary = pd.DataFrame({
        "disease_a": [disease_a],
        "disease_b": [disease_b],
        "significant_a": [n],
        "significant_b": [N],
        "shared_significant": [k],
        "hypergeometric_pvalue": [p_hyper],
        "concordance_rate": [float(overlap["effect_concordant"].mean()) if k > 0 else np.nan],
    })

    return overlap.sort_values(["effect_concordant", f"{disease_a}_fdr", f"{disease_b}_fdr"], ascending=[False, True, True]), summary
