"""Differential expression analysis for all genes, ncRNAs, and protein-coding genes."""

from __future__ import annotations

from typing import Dict, List
import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests


def hedges_g(x: np.ndarray, y: np.ndarray) -> float:
    n1, n2 = len(x), len(y)
    if n1 < 2 or n2 < 2:
        return np.nan
    s1 = np.var(x, ddof=1)
    s2 = np.var(y, ddof=1)
    pooled = np.sqrt(((n1 - 1) * s1 + (n2 - 1) * s2) / (n1 + n2 - 2))
    if pooled == 0:
        return 0.0
    d = (np.mean(x) - np.mean(y)) / pooled
    correction = 1.0 - (3.0 / (4.0 * (n1 + n2) - 9.0))
    return correction * d


def run_welch_de(expr_df: pd.DataFrame, groups: pd.Series) -> pd.DataFrame:
    disease_samples = groups[groups == "disease"].index
    control_samples = groups[groups == "control"].index

    if len(disease_samples) < 2 or len(control_samples) < 2:
        raise ValueError("Need at least 2 disease and 2 control samples for DE")

    rows = []
    for gene in expr_df.index:
        d = expr_df.loc[gene, disease_samples].astype(float).values
        c = expr_df.loc[gene, control_samples].astype(float).values

        t_stat, pval = stats.ttest_ind(d, c, equal_var=False, nan_policy="omit")
        if np.isnan(pval):
            pval = 1.0
        if np.isnan(t_stat):
            t_stat = 0.0

        mean_d = float(np.mean(d))
        mean_c = float(np.mean(c))
        rows.append({
            "gene_id": gene,
            "mean_disease": mean_d,
            "mean_control": mean_c,
            "log2FC": mean_d - mean_c,
            "effect_size_hedges_g": hedges_g(d, c),
            "test_statistic": float(t_stat),
            "pvalue": float(pval),
        })

    out = pd.DataFrame(rows).set_index("gene_id")
    out["fdr"] = multipletests(out["pvalue"], method="fdr_bh")[1]
    out["significant"] = out["fdr"] < 0.05
    out = out.sort_values(["fdr", "pvalue"])
    return out


def _flag_known_biomarkers(de_df: pd.DataFrame, known: List[str]) -> pd.DataFrame:
    out = de_df.copy()
    out["is_known_biomarker"] = out.index.isin(known)
    return out


def run_de_partitions(
    partition_map: Dict[str, pd.DataFrame],
    groups: pd.Series,
    known_biomarkers: List[str],
) -> Dict[str, pd.DataFrame]:
    results: Dict[str, pd.DataFrame] = {}
    for name, matrix in partition_map.items():
        if name in {"cleaned_counts", "cpm", "log2cpm"}:
            continue
        if matrix.empty:
            results[name] = pd.DataFrame()
            continue
        de_df = run_welch_de(matrix, groups)
        de_df = _flag_known_biomarkers(de_df, known_biomarkers)
        results[name] = de_df
    return results


def summarize_known_biomarkers(de_df: pd.DataFrame, known: List[str], fdr_threshold: float = 0.05) -> pd.DataFrame:
    records = []
    for gene in known:
        if gene not in de_df.index:
            records.append({
                "gene_id": gene,
                "present": False,
                "significant": False,
                "log2FC": np.nan,
                "fdr": np.nan,
                "direction": "missing",
            })
            continue

        row = de_df.loc[gene]
        log2fc = float(row["log2FC"])
        fdr = float(row["fdr"])
        records.append({
            "gene_id": gene,
            "present": True,
            "significant": fdr < fdr_threshold,
            "log2FC": log2fc,
            "fdr": fdr,
            "direction": "down" if log2fc < 0 else "up",
        })

    return pd.DataFrame(records)
