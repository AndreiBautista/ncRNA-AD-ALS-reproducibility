"""End-to-end orchestration for the Phase 2 dry-lab ncRNA framework."""

from __future__ import annotations

from typing import Dict
import pandas as pd

from .configuration import PipelineConfig, ensure_output_dirs
from .data_loading import (
    load_counts_matrix,
    load_metadata,
    load_annotation,
    harmonize_sample_labels,
    harmonize_gene_ids,
    standardize_counts_to_gene_symbols,
    align_samples,
)
from .preprocessing import preprocess_counts
from .ml import (
    evaluate_models,
    save_ml_results,
    export_logistic_biomarker_importance,
    export_single_gene_vs_panel_auc,
    export_transportability_validation,
    export_coefficient_stability_by_dataset,
    export_permutation_validation,
    export_cross_disease_effect_direction_consistency,
    export_framework_master_summary_table,
    export_external_dataset_replication_summary,
    export_pathway_enrichment_analysis,
    export_regulatory_network_interpretation,
    export_model_calibration_analysis,
    export_cross_cohort_logfc_matrix,
    export_gene_biological_profiles,
    export_framework_method_summary,
    export_reproducibility_statement,
    export_additional_external_dataset_replication,
    export_permutation_label_validation,
    export_gene_biological_profiles_mechanistic,
    export_leave_one_dataset_out_validation,
    export_bootstrap_model_performance_ci,
    export_decision_threshold_robustness_analysis,
    export_coverage_stratified_performance_analysis,
    export_calibration_decomposition_analysis,
    export_covariate_sensitivity_analysis,
    export_framework_master_summary_extended_text,
    export_normalization_robustness_analysis,
    export_gene_ablation_analysis,
    export_bidirectional_cross_disease_transfer,
    export_random_panel_negative_control,
    export_visual_provenance_manifest,
)
from .robustness import evaluate_seed_stability, evaluate_class_imbalance_strategies, permutation_test_auc
from .interpretation import load_target_map, load_pathway_map, build_regulatory_network, summarize_network_hubs, keyword_pathway_enrichment
from .validation import (
    validate_fixed_biomarkers,
    summarize_external_validation,
    summarize_external_validation_by_dataset,
    build_dataset_gene_matrix,
)
from .framework import summarize_validation_by_disease, summarize_model_transportability
from .framework import (
    compute_biomarker_generalization_scores,
    run_pooled_panel_vs_baselines,
    run_cross_disease_transportability,
    summarize_panel_vs_baselines,
)
from .figures import (
    plot_roc_from_predictions,
    plot_model_comparison,
    plot_replication_summary,
    plot_network,
    plot_generalization_scores,
    plot_transportability,
    plot_panel_vs_baselines_summary,
    plot_dataset_panel_coverage,
)
from .reporting import write_final_summary


def run_pipeline(config: PipelineConfig) -> Dict[str, pd.DataFrame]:
    dirs = ensure_output_dirs(config)
    reference_annotation = load_annotation(config.annotation_reference_path)
    panel_genes = [g.strip().upper() for g in config.known_ncrna_biomarkers]

    # Dataset loading + preprocessing for fixed-panel validation only.
    dataset_artifacts: Dict[str, Dict[str, pd.DataFrame]] = {}
    validation_tables = []
    panel_presence_rows = []

    for ds in config.datasets:
        counts = load_counts_matrix(ds.counts_path, ds.file_format)
        meta = load_metadata(ds.metadata_path, ds.group_col)
        annot = load_annotation(ds.annotation_path)
        if annot is not None:
            counts = harmonize_gene_ids(counts, annot)

        # Global harmonization to uppercase gene symbols using reference annotation.
        counts = standardize_counts_to_gene_symbols(counts, reference_annotation)

        meta = harmonize_sample_labels(meta, ds.group_col, ds.disease_label, ds.control_label)
        counts, meta = align_samples(counts, meta)

        processed = preprocess_counts(counts, annot, pseudocount=config.analysis.pseudocount)
        groups = meta["harmonized_group"]

        log2cpm = processed["log2cpm"]
        if log2cpm.index.has_duplicates:
            log2cpm = log2cpm.groupby(level=0).mean()

        log2cpm.to_csv(dirs["cleaned"] / f"{ds.dataset_id}_log2cpm.csv")

        # External validation only on fixed biomarker panel.
        val_table = validate_fixed_biomarkers(
            log2cpm,
            groups,
            panel_genes,
            dataset_id=ds.dataset_id,
            disease=ds.disease,
        )
        val_table.to_csv(dirs["validation"] / f"{ds.dataset_id}_fixed_biomarker_validation.csv", index=False)
        validation_tables.append(val_table)

        dataset_artifacts[ds.dataset_id] = {
            "groups": groups,
            "log2cpm": log2cpm,
            "disease": pd.Series([ds.disease]).iloc[0],
            "role": pd.Series([ds.role]).iloc[0],
            "metadata": meta,
        }

        present_panel = [g for g in panel_genes if g in log2cpm.index]
        missing_panel = [g for g in panel_genes if g not in log2cpm.index]
        panel_presence_rows.append({
            "dataset_id": ds.dataset_id,
            "disease": ds.disease,
            "panel_genes_present_after_harmonization": len(present_panel),
            "panel_genes_total": len(panel_genes),
            "present_genes": ";".join(present_panel),
            "missing_genes": ";".join(missing_panel),
        })

    # Unified gene-symbol intersection across all datasets (post-harmonization).
    unified_genes = []
    if dataset_artifacts:
        all_indices = [v["log2cpm"].index for v in dataset_artifacts.values()]
        inter = all_indices[0]
        for idx in all_indices[1:]:
            inter = inter.intersection(idx)
        unified_genes = sorted(inter.tolist())

    pd.DataFrame({"gene_symbol": unified_genes}).to_csv(
        dirs["framework"] / "unified_gene_intersection.csv", index=False
    )

    panel_presence_df = pd.DataFrame(panel_presence_rows)
    panel_presence_df.to_csv(
        dirs["validation"] / "panel_presence_after_harmonization.csv", index=False
    )

    validation_table = pd.concat(validation_tables, ignore_index=True) if validation_tables else pd.DataFrame()
    replication_summary = summarize_external_validation(validation_table)
    validation_by_dataset = summarize_external_validation_by_dataset(
        validation_table,
        fdr_threshold=config.analysis.fdr_threshold,
    )
    log2fc_by_dataset = build_dataset_gene_matrix(validation_table, "log2FC")
    fdr_by_dataset = build_dataset_gene_matrix(validation_table, "fdr")

    validation_table.to_csv(dirs["validation"] / "all_datasets_fixed_biomarker_validation.csv", index=False)
    replication_summary.to_csv(dirs["validation"] / "fixed_biomarker_validation_summary.csv", index=False)
    validation_by_dataset.to_csv(dirs["validation"] / "fixed_biomarker_validation_by_dataset.csv", index=False)
    log2fc_by_dataset.to_csv(dirs["validation"] / "fixed_biomarker_log2fc_by_dataset.csv", index=False)
    fdr_by_dataset.to_csv(dirs["validation"] / "fixed_biomarker_fdr_by_dataset.csv", index=False)
    biomarker_generalization = compute_biomarker_generalization_scores(validation_table)
    biomarker_generalization.to_csv(dirs["framework"] / "biomarker_generalization_scores.csv", index=False)
    plot_replication_summary(replication_summary, dirs["figures"] / "replication_summary", save_png=config.output.save_png, save_pdf=config.output.save_pdf, dpi=config.output.dpi)
    plot_generalization_scores(biomarker_generalization, dirs["figures"] / "biomarker_generalization", save_png=config.output.save_png, save_pdf=config.output.save_pdf, dpi=config.output.dpi)
    plot_dataset_panel_coverage(validation_by_dataset, dirs["figures"] / "dataset_panel_coverage", save_png=config.output.save_png, save_pdf=config.output.save_pdf, dpi=config.output.dpi)

    # Build combined matrix for fixed-panel model comparison.
    dataset_ids = [ds.dataset_id for ds in config.datasets]
    expr_list = []
    group_list = []
    for dsid in dataset_ids:
        expr = dataset_artifacts[dsid]["log2cpm"]
        grp = dataset_artifacts[dsid]["groups"]
        expr_list.append(expr)
        group_list.append(grp)

    # Shared genes across cohorts for baseline and random-panel controls.
    shared_genes = expr_list[0].index
    for e in expr_list[1:]:
        shared_genes = shared_genes.intersection(e.index)
    merged_expr_all = pd.concat([e.loc[shared_genes] for e in expr_list], axis=1) if len(shared_genes) > 0 else pd.DataFrame()

    # Union-gene matrix for random-panel controls while preserving panel genes.
    union_genes = set(panel_genes)
    for e in expr_list:
        union_genes.update(e.index.tolist())
    union_genes = sorted(union_genes)
    merged_expr_union = pd.concat([e.reindex(union_genes) for e in expr_list], axis=1).fillna(0.0)

    # For fixed-panel models, avoid requiring a full transcriptome intersection.
    panel_genes = sorted(set(config.known_ncrna_biomarkers))
    merged_expr = pd.concat([e.reindex(panel_genes) for e in expr_list], axis=1).fillna(0.0)
    merged_groups = pd.concat(group_list)

    ml_results = evaluate_models(
        merged_expr,
        merged_groups,
        known_ncrnas=panel_genes,
        protein_genes=[],
        random_seed=config.ml.random_seed,
        n_splits=config.ml.n_splits,
        random_gene_repeats=config.ml.random_gene_repeats,
        bootstrap_iterations=config.ml.bootstrap_iterations,
    )
    model_summary = save_ml_results(ml_results, str(dirs["ml"]))
    export_logistic_biomarker_importance(
        merged_expr,
        merged_groups,
        known_ncrnas=panel_genes,
        outdir=str(dirs["ml"]),
        random_seed=config.ml.random_seed,
    )
    single_gene_auc = export_single_gene_vs_panel_auc(
        merged_expr,
        merged_groups,
        known_ncrnas=panel_genes,
        outdir=str(dirs["ml"]),
        random_seed=config.ml.random_seed,
        n_splits=config.ml.n_splits,
        n_repeats=max(10, config.ml.random_gene_repeats),
    )
    transportability_results = export_transportability_validation(
        dataset_artifacts,
        known_ncrnas=panel_genes,
        outdir=str(dirs["ml"]),
        random_seed=config.ml.random_seed,
        n_splits=config.ml.n_splits,
        n_repeats=max(10, config.ml.random_gene_repeats),
    )
    coeff_stability_by_dataset, coeff_direction_summary = export_coefficient_stability_by_dataset(
        dataset_artifacts,
        known_ncrnas=panel_genes,
        outdir=str(dirs["ml"]),
        random_seed=config.ml.random_seed,
    )
    permutation_validation = export_permutation_validation(
        merged_expr,
        merged_groups,
        known_ncrnas=panel_genes,
        outdir=str(dirs["ml"]),
        random_seed=config.ml.random_seed,
        n_splits=config.ml.n_splits,
        n_permutations=max(100, config.ml.permutation_iterations),
    )
    effect_direction_by_dataset, cross_disease_effect_direction, effect_direction_consistency = (
        export_cross_disease_effect_direction_consistency(
            dataset_artifacts,
            known_ncrnas=panel_genes,
            outdir=str(dirs["ml"]),
        )
    )
    framework_master_summary_table = export_framework_master_summary_table(
        dataset_artifacts=dataset_artifacts,
        known_ncrnas=panel_genes,
        outdir=str(dirs["ml"]),
        model_summary=model_summary,
        single_gene_auc=single_gene_auc,
        transportability_results=transportability_results,
        permutation_validation=permutation_validation,
        coefficient_stability_by_dataset=coeff_stability_by_dataset,
        coefficient_direction_summary=coeff_direction_summary,
        cross_disease_effect_direction=cross_disease_effect_direction,
    )

    # ========================================================================
    # NEW INTERPRETATION MODULES (Phase 2 Upgrade)
    # ========================================================================
    
    # MODULE 1: External Dataset Replication Summary
    external_replication = export_external_dataset_replication_summary(
        dataset_artifacts,
        known_ncrnas=panel_genes,
        outdir=str(dirs["ml"]),
    )
    
    # MODULE 2: Pathway Enrichment Analysis
    pathway_enrichment, _ = export_pathway_enrichment_analysis(
        known_ncrnas=panel_genes,
        outdir=str(dirs["ml"]),
    )
    
    # MODULE 3: Regulatory Network Interpretation
    regulatory_network, _ = export_regulatory_network_interpretation(
        known_ncrnas=panel_genes,
        outdir=str(dirs["ml"]),
    )
    
    # MODULE 4: Model Calibration Analysis
    calibration_metrics, _ = export_model_calibration_analysis(
        X=merged_expr.T,
        y=merged_groups.map({"control": 0, "disease": 1}).fillna(-1),
        known_ncrnas=panel_genes,
        outdir=str(dirs["ml"]),
        random_seed=config.ml.random_seed,
        n_splits=config.ml.n_splits,
    )
    
    # MODULE 5: Cross-Cohort LogFC Matrix
    logfc_matrix, _ = export_cross_cohort_logfc_matrix(
        validation_table,
        outdir=str(dirs["ml"]),
    )
    
    # MODULE 6: Gene Biological Profiles
    gene_profiles, _ = export_gene_biological_profiles(
        known_ncrnas=panel_genes,
        outdir=str(dirs["ml"]),
    )
    
    # MODULE 7: Framework Method Summary
    framework_summary_text = export_framework_method_summary(
        known_ncrnas=panel_genes,
        dataset_count=len(config.datasets),
        outdir=str(dirs["ml"]),
        panel_coverage_threshold=0.6,
    )
    
    # MODULE 8: Reproducibility Statement
    reproducibility_text = export_reproducibility_statement(
        known_ncrnas=panel_genes,
        dataset_count=len(config.datasets),
        outdir=str(dirs["ml"]),
    )

    # ════════════════════════════════════════════════════════════════════
    # NEW PHASE 2 EXTENDED MODULES (4 additional publication-level modules)
    # ════════════════════════════════════════════════════════════════════

    # MODULE 9: Additional External Dataset Replication
    additional_external_replication = export_additional_external_dataset_replication(
        outdir=str(dirs["ml"]),
        known_ncrnas=panel_genes,
        random_seed=config.ml.random_seed,
    )

    # MODULE 10: Permutation Label Validation
    permutation_label_validation = export_permutation_label_validation(
        merged_expr,
        merged_groups,
        known_ncrnas=panel_genes,
        outdir=str(dirs["ml"]),
        random_seed=config.ml.random_seed,
        n_splits=config.ml.n_splits,
        n_permutations=max(100, config.ml.permutation_iterations),
    )

    # MODULE 11: Gene Biological Profiles (Mechanistic Interpretation)
    gene_profiles_mechanistic, _ = export_gene_biological_profiles_mechanistic(
        known_ncrnas=panel_genes,
        outdir=str(dirs["ml"]),
    )

    # MODULE 12: Leave-One-Dataset-Out Validation
    lodo_validation = export_leave_one_dataset_out_validation(
        dataset_artifacts,
        known_ncrnas=panel_genes,
        outdir=str(dirs["ml"]),
        random_seed=config.ml.random_seed,
        n_splits=config.ml.n_splits,
    )

    # MODULE 13: Bootstrap confidence intervals for model performance
    bootstrap_ci = export_bootstrap_model_performance_ci(
        merged_expr,
        merged_groups,
        known_ncrnas=panel_genes,
        outdir=str(dirs["ml"]),
        model_summary=model_summary,
        random_seed=config.ml.random_seed,
        n_splits=config.ml.n_splits,
        n_bootstrap=max(1000, config.ml.bootstrap_iterations),
    )

    # MODULE 14: Decision-threshold robustness analysis
    threshold_robustness = export_decision_threshold_robustness_analysis(
        outdir=str(dirs["ml"]),
        thresholds=[0.10, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80, 0.90],
    )

    # MODULE 15: Coverage-stratified performance analysis
    coverage_stratified_performance = export_coverage_stratified_performance_analysis(
        outdir=str(dirs["ml"]),
        panel_size=len(panel_genes),
    )

    # MODULE 16: Calibration decomposition analysis
    calibration_decomposition = export_calibration_decomposition_analysis(
        outdir=str(dirs["ml"]),
        n_bins=10,
    )

    # MODULE 17: Optional covariate sensitivity analysis
    covariate_sensitivity = export_covariate_sensitivity_analysis(
        dataset_artifacts,
        known_ncrnas=panel_genes,
        outdir=str(dirs["ml"]),
        random_seed=config.ml.random_seed,
        n_splits=config.ml.n_splits,
    )

    # MODULE 18: Normalization robustness
    normalization_robustness = export_normalization_robustness_analysis(
        merged_expr,
        merged_groups,
        known_ncrnas=panel_genes,
        outdir=str(dirs["ml"]),
        random_seed=config.ml.random_seed,
        n_splits=config.ml.n_splits,
    )

    # MODULE 19: Gene ablation analysis
    gene_ablation = export_gene_ablation_analysis(
        merged_expr,
        merged_groups,
        known_ncrnas=panel_genes,
        outdir=str(dirs["ml"]),
        random_seed=config.ml.random_seed,
        n_splits=config.ml.n_splits,
    )

    # MODULE 20: Bidirectional cross-disease transfer
    cross_disease_transfer = export_bidirectional_cross_disease_transfer(
        dataset_artifacts,
        known_ncrnas=panel_genes,
        outdir=str(dirs["ml"]),
        random_seed=config.ml.random_seed,
    )

    # MODULE 21: Random-panel negative control
    random_panel_control = export_random_panel_negative_control(
        merged_expr_union,
        merged_groups,
        known_ncrnas=panel_genes,
        outdir=str(dirs["ml"]),
        random_seed=config.ml.random_seed,
        n_splits=config.ml.n_splits,
        n_random_panels=100,
    )

    visual_provenance_manifest = export_visual_provenance_manifest(
        outdir=str(dirs["ml"]),
    )

    framework_master_summary_extended_text = export_framework_master_summary_extended_text(
        outdir=str(dirs["ml"]),
        bootstrap_ci=bootstrap_ci,
        threshold_table=threshold_robustness,
        coverage_summary=coverage_stratified_performance,
        calibration_decomposition=calibration_decomposition,
        covariate_sensitivity=covariate_sensitivity,
        normalization_robustness=normalization_robustness,
        gene_ablation=gene_ablation,
        cross_disease_transfer=cross_disease_transfer,
        random_panel_control=random_panel_control,
    )
    # Baseline comparisons require shared non-panel genes across cohorts.
    if len(shared_genes) > len(config.known_ncrna_biomarkers):
        pooled_expr_for_baselines = pd.concat([e.loc[shared_genes] for e in expr_list], axis=1)
        pooled_baseline_comparison = run_pooled_panel_vs_baselines(
            pooled_expr_for_baselines,
            merged_groups,
            known_ncrnas=panel_genes,
            n_splits=config.ml.n_splits,
            random_repeats=config.ml.random_gene_repeats,
            seed=config.ml.random_seed,
        )
    else:
        pooled_baseline_comparison = pd.DataFrame()
    pooled_baseline_comparison.to_csv(dirs["ml"] / "pooled_panel_vs_baselines.csv", index=False)

    all_preds = []
    for name, res in ml_results.items():
        if not res.predictions.empty:
            all_preds.append(res.predictions)
    pred_df = pd.concat(all_preds, ignore_index=True) if all_preds else pd.DataFrame()
    if not pred_df.empty:
        plot_roc_from_predictions(pred_df, dirs["figures"] / "model_rocs", save_png=config.output.save_png, save_pdf=config.output.save_pdf, dpi=config.output.dpi)
    plot_model_comparison(model_summary, dirs["figures"] / "model_comparison", save_png=config.output.save_png, save_pdf=config.output.save_pdf, dpi=config.output.dpi)

    # Robustness on model A features
    X = merged_expr.T
    y = merged_groups.map({"control": 0, "disease": 1}).astype(int)
    features_a = [g for g in panel_genes if g in X.columns]
    seed_table = evaluate_seed_stability(X, y, features_a, seeds=[1, 7, 21, 42, 84, 123]) if len(features_a) >= 2 else pd.DataFrame()
    imbalance_table = evaluate_class_imbalance_strategies(X, y, features_a) if len(features_a) >= 2 else pd.DataFrame()
    perm_table = permutation_test_auc(
        X,
        y,
        features_a,
        n_permutations=config.ml.permutation_iterations,
        seed=config.ml.random_seed,
    ) if len(features_a) >= 2 else pd.DataFrame()

    seed_table.to_csv(dirs["robustness"] / "seed_stability.csv", index=False)
    imbalance_table.to_csv(dirs["robustness"] / "class_imbalance_strategies.csv", index=False)
    perm_table.to_csv(dirs["robustness"] / "permutation_test.csv", index=False)

    # Reusable cross-disease framework summaries.
    validation_by_disease = summarize_validation_by_disease(validation_table)
    model_transportability = summarize_model_transportability(model_summary)
    cross_disease_transportability = run_cross_disease_transportability(
        dataset_artifacts,
        known_ncrnas=panel_genes,
        random_repeats=config.ml.random_gene_repeats,
        seed=config.ml.random_seed,
    )
    panel_vs_baselines_summary = summarize_panel_vs_baselines(
        pooled_baseline_comparison,
        cross_disease_transportability,
    )

    validation_by_disease.to_csv(dirs["framework"] / "validation_by_disease.csv", index=False)
    model_transportability.to_csv(dirs["framework"] / "model_transportability.csv", index=False)
    cross_disease_transportability.to_csv(dirs["framework"] / "cross_disease_transportability.csv", index=False)
    panel_vs_baselines_summary.to_csv(dirs["framework"] / "panel_vs_baselines_summary.csv", index=False)
    plot_transportability(cross_disease_transportability, dirs["figures"] / "cross_disease_transportability", save_png=config.output.save_png, save_pdf=config.output.save_pdf, dpi=config.output.dpi)
    plot_panel_vs_baselines_summary(panel_vs_baselines_summary, dirs["figures"] / "panel_vs_baselines_summary", save_png=config.output.save_png, save_pdf=config.output.save_pdf, dpi=config.output.dpi)

    # Interpretation layer
    target_map = load_target_map(config.target_map_path)
    pathway_map = load_pathway_map(config.pathway_map_path)
    graph = build_regulatory_network(panel_genes, target_map, pathway_map)
    hubs = summarize_network_hubs(graph)
    target_genes = target_map["target_gene"].tolist() if not target_map.empty else []
    enrich = keyword_pathway_enrichment(target_genes, pathway_map)
    hubs.to_csv(dirs["interpretation"] / "network_hubs.csv", index=False)
    enrich.to_csv(dirs["interpretation"] / "keyword_enrichment.csv", index=False)
    plot_network(graph, dirs["figures"] / "ncrna_target_network", save_png=config.output.save_png, save_pdf=config.output.save_pdf, dpi=config.output.dpi)

    # Validation overview for report
    de_overview_rows = []
    for ds in config.datasets:
        ds_val = validation_table[validation_table["dataset_id"] == ds.dataset_id] if not validation_table.empty else pd.DataFrame()
        de_overview_rows.append({
            "dataset_id": ds.dataset_id,
            "disease": ds.disease,
            "role": ds.role,
            "panel_genes_present": int(ds_val["present"].sum()) if not ds_val.empty else 0,
            "panel_genes_tested": int(len(panel_genes)),
        })
    de_overview = pd.DataFrame(de_overview_rows)
    de_overview.to_csv(dirs["validation"] / "validation_overview.csv", index=False)

    write_final_summary(
        str(dirs["reports"] / "final_summary.md"),
        de_overview,
        replication_summary,
        model_summary,
        {
            "Seed stability": seed_table,
            "Class imbalance": imbalance_table,
            "Permutation test": perm_table,
        },
        validation_by_disease,
        baseline_comparison_summary=panel_vs_baselines_summary,
    )

    return {
        "validation_overview": de_overview,
        "replication_summary": replication_summary,
        "validation_by_dataset": validation_by_dataset,
        "panel_presence_after_harmonization": panel_presence_df,
        "log2fc_by_dataset": log2fc_by_dataset,
        "fdr_by_dataset": fdr_by_dataset,
        "model_summary": model_summary,
        "single_gene_auc": single_gene_auc,
        "transportability_results": transportability_results,
        "coefficient_stability_by_dataset": coeff_stability_by_dataset,
        "coefficient_direction_summary": coeff_direction_summary,
        "permutation_validation": permutation_validation,
        "effect_direction_by_dataset": effect_direction_by_dataset,
        "cross_disease_effect_direction": cross_disease_effect_direction,
        "effect_direction_consistency": effect_direction_consistency,
        "framework_master_summary_table": framework_master_summary_table,
        "robustness_seed": seed_table,
        "robustness_imbalance": imbalance_table,
        "robustness_permutation": perm_table,
        "validation_by_disease": validation_by_disease,
        "model_transportability": model_transportability,
        "biomarker_generalization": biomarker_generalization,
        "pooled_baseline_comparison": pooled_baseline_comparison,
        "cross_disease_transportability": cross_disease_transportability,
        "panel_vs_baselines_summary": panel_vs_baselines_summary,
        "hubs": hubs,
        "keyword_enrichment": enrich,
        # New interpretation modules
        "external_dataset_replication": external_replication,
        "pathway_enrichment": pathway_enrichment,
        "regulatory_network": regulatory_network,
        "calibration_metrics": calibration_metrics,
        "cross_cohort_logfc_matrix": logfc_matrix,
        "gene_biological_profiles": gene_profiles,
        "framework_method_summary_text": framework_summary_text,
        "reproducibility_statement_text": reproducibility_text,
        # Phase 2 extended modules
        "additional_external_dataset_replication": additional_external_replication,
        "permutation_label_validation": permutation_label_validation,
        "gene_biological_profiles_mechanistic": gene_profiles_mechanistic,
        "leave_one_dataset_out_validation": lodo_validation,
        "bootstrap_model_performance_ci": bootstrap_ci,
        "threshold_performance_table": threshold_robustness,
        "coverage_stratified_performance": coverage_stratified_performance,
        "calibration_decomposition_metrics": calibration_decomposition,
        "covariate_sensitivity_results": covariate_sensitivity,
        "normalization_robustness_auc_table": normalization_robustness,
        "gene_ablation_auc_table": gene_ablation,
        "cross_disease_transfer_matrix": cross_disease_transfer,
        "random_panel_auc_distribution": random_panel_control,
        "visual_provenance_manifest": visual_provenance_manifest,
        "framework_master_summary_extended_text": framework_master_summary_extended_text,
    }
