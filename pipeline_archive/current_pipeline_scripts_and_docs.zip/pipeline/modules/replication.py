"""External replication of a fixed ncRNA biomarker list."""

from __future__ import annotations

from typing import Dict, List
import numpy as np
import pandas as pd


def compute_discovery_direction(discovery_tables: Dict[str, pd.DataFrame], known: List[str]) -> pd.DataFrame:
    rows = []
    for gene in known:
        vals = []
        for _, df in discovery_tables.items():
            if gene in df.index:
                vals.append(float(df.loc[gene, "log2FC"]))
        if not vals:
            rows.append({"gene_id": gene, "expected_direction": "missing", "mean_log2FC": np.nan})
            continue
        mean_fc = float(np.mean(vals))
        rows.append({
            "gene_id": gene,
            "expected_direction": "down" if mean_fc < 0 else "up",
            "mean_log2FC": mean_fc,
        })
    return pd.DataFrame(rows)


def replicate_known_biomarkers(
    external_de_tables: Dict[str, pd.DataFrame],
    discovery_direction: pd.DataFrame,
    known: List[str],
) -> pd.DataFrame:
    expected = discovery_direction.set_index("gene_id").to_dict("index")
    rows = []

    for dataset_id, df in external_de_tables.items():
        for gene in known:
            if gene not in df.index:
                rows.append({
                    "dataset_id": dataset_id,
                    "gene_id": gene,
                    "present": False,
                    "log2FC": np.nan,
                    "pvalue": np.nan,
                    "fdr": np.nan,
                    "effect_size_hedges_g": np.nan,
                    "observed_direction": "missing",
                    "expected_direction": expected.get(gene, {}).get("expected_direction", "missing"),
                    "direction_concordant": False,
                })
                continue

            row = df.loc[gene]
            observed_direction = "down" if float(row["log2FC"]) < 0 else "up"
            expected_direction = expected.get(gene, {}).get("expected_direction", "missing")
            rows.append({
                "dataset_id": dataset_id,
                "gene_id": gene,
                "present": True,
                "log2FC": float(row["log2FC"]),
                "pvalue": float(row["pvalue"]),
                "fdr": float(row["fdr"]),
                "effect_size_hedges_g": float(row.get("effect_size_hedges_g", np.nan)),
                "observed_direction": observed_direction,
                "expected_direction": expected_direction,
                "direction_concordant": observed_direction == expected_direction,
            })

    return pd.DataFrame(rows)


def summarize_replication(replication_df: pd.DataFrame) -> pd.DataFrame:
    if replication_df.empty:
        return pd.DataFrame()
    summary = (
        replication_df.groupby("gene_id")
        .agg(
            datasets_present=("present", "sum"),
            concordant_count=("direction_concordant", "sum"),
            mean_log2FC=("log2FC", "mean"),
            min_fdr=("fdr", "min"),
        )
        .reset_index()
    )
    summary["concordance_rate"] = summary["concordant_count"] / summary["datasets_present"].replace(0, np.nan)
    return summary
