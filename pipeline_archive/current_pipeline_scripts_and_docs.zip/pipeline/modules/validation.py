"""External validation utilities for a fixed ncRNA biomarker panel."""

from __future__ import annotations

from typing import List
import numpy as np
import pandas as pd
from scipy.stats import ttest_ind
from statsmodels.stats.multitest import multipletests


def validate_fixed_biomarkers(
    expr_df: pd.DataFrame,
    groups: pd.Series,
    biomarkers: List[str],
    dataset_id: str,
    disease: str,
) -> pd.DataFrame:
    """Evaluate fixed biomarkers in one external cohort.

    This performs per-gene case/control contrast only for the supplied fixed panel.
    It does not run transcriptome-wide discovery.
    """
    rows = []
    available = [g for g in biomarkers if g in expr_df.index]

    disease_samples = groups[groups == "disease"].index
    control_samples = groups[groups == "control"].index

    for gene in biomarkers:
        if gene not in available:
            rows.append(
                {
                    "dataset_id": dataset_id,
                    "disease": disease,
                    "gene_id": gene,
                    "present": False,
                    "mean_disease": np.nan,
                    "mean_control": np.nan,
                    "log2FC": np.nan,
                    "pvalue": np.nan,
                    "effect_size_hedges_g": np.nan,
                }
            )
            continue

        dvals = expr_df.loc[gene, disease_samples].astype(float).values
        cvals = expr_df.loc[gene, control_samples].astype(float).values

        mean_d = float(np.mean(dvals))
        mean_c = float(np.mean(cvals))
        log2fc = mean_d - mean_c

        stat = ttest_ind(dvals, cvals, equal_var=False, nan_policy="omit")
        pvalue = float(stat.pvalue) if np.isfinite(stat.pvalue) else 1.0

        n1 = len(dvals)
        n2 = len(cvals)
        s1 = np.var(dvals, ddof=1) if n1 > 1 else 0.0
        s2 = np.var(cvals, ddof=1) if n2 > 1 else 0.0
        pooled = np.sqrt(((n1 - 1) * s1 + (n2 - 1) * s2) / max(n1 + n2 - 2, 1))
        cohen_d = (mean_d - mean_c) / pooled if pooled > 0 else 0.0
        correction = 1.0 - (3.0 / max(4.0 * (n1 + n2) - 9.0, 1.0))
        hedges_g = float(cohen_d * correction)

        rows.append(
            {
                "dataset_id": dataset_id,
                "disease": disease,
                "gene_id": gene,
                "present": True,
                "mean_disease": mean_d,
                "mean_control": mean_c,
                "log2FC": float(log2fc),
                "pvalue": pvalue,
                "effect_size_hedges_g": hedges_g,
            }
        )

    out = pd.DataFrame(rows)
    valid_mask = out["present"] & out["pvalue"].notna()
    out["fdr"] = np.nan
    if valid_mask.any():
        out.loc[valid_mask, "fdr"] = multipletests(out.loc[valid_mask, "pvalue"], method="fdr_bh")[1]

    out["observed_direction"] = np.where(out["log2FC"].isna(), "missing", np.where(out["log2FC"] >= 0, "up", "down"))
    return out


def summarize_external_validation(validation_table: pd.DataFrame) -> pd.DataFrame:
    if validation_table.empty:
        return pd.DataFrame()

    summary = (
        validation_table.groupby("gene_id")
        .agg(
            datasets_present=("present", "sum"),
            datasets_total=("dataset_id", "nunique"),
            mean_log2FC=("log2FC", "mean"),
            median_log2FC=("log2FC", "median"),
            min_fdr=("fdr", "min"),
        )
        .reset_index()
    )
    summary["presence_rate"] = summary["datasets_present"] / summary["datasets_total"].replace(0, np.nan)
    return summary


def summarize_external_validation_by_dataset(
    validation_table: pd.DataFrame,
    fdr_threshold: float = 0.05,
) -> pd.DataFrame:
    if validation_table.empty:
        return pd.DataFrame()

    all_sets = validation_table[["dataset_id", "disease"]].drop_duplicates()
    present = validation_table[validation_table["present"]].copy()

    if present.empty:
        out = all_sets.copy()
        out["panel_genes_present"] = 0
        out["panel_genes_significant"] = 0
        out["mean_abs_log2FC"] = np.nan
        out["mean_effect_size"] = np.nan
        return out.sort_values(["disease", "dataset_id"]).reset_index(drop=True)

    summary = (
        present.groupby(["dataset_id", "disease"])
        .agg(
            panel_genes_present=("gene_id", "count"),
            panel_genes_significant=("fdr", lambda s: int((s < fdr_threshold).sum())),
            mean_abs_log2FC=("log2FC", lambda s: float(np.mean(np.abs(s)))),
            mean_effect_size=("effect_size_hedges_g", "mean"),
        )
        .reset_index()
    )

    out = all_sets.merge(summary, on=["dataset_id", "disease"], how="left")
    out["panel_genes_present"] = out["panel_genes_present"].fillna(0).astype(int)
    out["panel_genes_significant"] = out["panel_genes_significant"].fillna(0).astype(int)
    return out.sort_values(["disease", "dataset_id"]).reset_index(drop=True)


def build_dataset_gene_matrix(validation_table: pd.DataFrame, value_col: str) -> pd.DataFrame:
    if validation_table.empty:
        return pd.DataFrame()
    if value_col not in validation_table.columns:
        raise ValueError(f"Column '{value_col}' not in validation table")

    matrix = (
        validation_table.pivot_table(
            index="gene_id",
            columns="dataset_id",
            values=value_col,
            aggfunc="mean",
        )
        .reset_index()
    )
    return matrix
