"""Configuration loading and validation for the Phase 2 validation framework."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Any
import json


@dataclass
class DatasetConfig:
    dataset_id: str
    disease: str
    counts_path: str
    metadata_path: str
    role: str = "external_validation"
    annotation_path: Optional[str] = None
    group_col: str = "condition"
    disease_label: str = "Disease"
    control_label: str = "Control"
    file_format: str = "auto"


@dataclass
class AnalysisConfig:
    fdr_threshold: float = 0.05
    min_samples_per_group: int = 3
    pseudocount: float = 1.0


@dataclass
class MLConfig:
    n_splits: int = 5
    random_seed: int = 42
    random_gene_repeats: int = 100
    bootstrap_iterations: int = 500
    permutation_iterations: int = 200
    test_size: float = 0.2
    class_weight_strategy: str = "balanced"


@dataclass
class OutputConfig:
    outdir: str = "phase2_validation_framework/outputs/framework"
    save_pdf: bool = True
    save_png: bool = True
    dpi: int = 300


@dataclass
class PipelineConfig:
    datasets: List[DatasetConfig]
    known_ncrna_biomarkers: List[str] = field(default_factory=list)
    analysis: AnalysisConfig = field(default_factory=AnalysisConfig)
    ml: MLConfig = field(default_factory=MLConfig)
    output: OutputConfig = field(default_factory=OutputConfig)
    annotation_reference_path: Optional[str] = "data/annotations/gencode_annotation.csv"
    target_map_path: Optional[str] = None
    pathway_map_path: Optional[str] = None


def _load_yaml(path: Path) -> Dict[str, Any]:
    try:
        import yaml
    except ImportError as exc:
        raise ImportError("PyYAML is required for YAML configs. Install with: pip install pyyaml") from exc

    with path.open("r", encoding="utf-8") as handle:
        return yaml.safe_load(handle)


def load_config(config_path: str) -> PipelineConfig:
    path = Path(config_path)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")

    if path.suffix.lower() in {".yaml", ".yml"}:
        raw = _load_yaml(path)
    elif path.suffix.lower() == ".json":
        raw = json.loads(path.read_text(encoding="utf-8"))
    else:
        raise ValueError("Config must be YAML (.yaml/.yml) or JSON (.json)")

    if not raw or "datasets" not in raw:
        raise ValueError("Config must define a 'datasets' list")

    datasets = []
    for item in raw["datasets"]:
        datasets.append(DatasetConfig(**item))

    cfg = PipelineConfig(
        datasets=datasets,
        known_ncrna_biomarkers=raw.get("known_ncrna_biomarkers", []),
        analysis=AnalysisConfig(**raw.get("analysis", {})),
        ml=MLConfig(**raw.get("ml", {})),
        output=OutputConfig(**raw.get("output", {})),
        annotation_reference_path=raw.get("annotation_reference_path", "data/annotations/gencode_annotation.csv"),
        target_map_path=raw.get("target_map_path"),
        pathway_map_path=raw.get("pathway_map_path"),
    )

    validate_config(cfg)
    return cfg


def validate_config(config: PipelineConfig) -> None:
    if len(config.datasets) == 0:
        raise ValueError("At least one dataset is required for Phase 2 validation")

    if len(config.known_ncrna_biomarkers) == 0:
        raise ValueError("known_ncrna_biomarkers must be provided as fixed Phase 1 inputs")

    for d in config.datasets:
        if not Path(d.counts_path).exists():
            raise FileNotFoundError(f"Missing counts file for {d.dataset_id}: {d.counts_path}")
        if not Path(d.metadata_path).exists():
            raise FileNotFoundError(f"Missing metadata file for {d.dataset_id}: {d.metadata_path}")

    if config.ml.n_splits < 3:
        raise ValueError("ml.n_splits must be >= 3")
    if not (0.0 < config.ml.test_size < 1.0):
        raise ValueError("ml.test_size must be in (0, 1)")


def ensure_output_dirs(config: PipelineConfig) -> Dict[str, Path]:
    framework_dir = Path(config.output.outdir)
    outputs_root = framework_dir.parent

    # Align all module outputs to required Phase 2 layout.
    dirs = {
        "base": framework_dir,
        "cleaned": outputs_root / "validation" / "cleaned_data",
        "validation": outputs_root / "validation" / "external_validation",
        "ml": outputs_root / "model_comparison" / "ml",
        "robustness": outputs_root / "model_comparison" / "robustness",
        "interpretation": outputs_root / "network" / "interpretation",
        "framework": framework_dir / "cross_disease_framework",
        "figures": framework_dir / "figures",
        "reports": framework_dir / "reports",
    }
    for p in dirs.values():
        p.mkdir(parents=True, exist_ok=True)

    # Ensure the required top-level output folders exist even when specific
    # modules have no outputs in a given run.
    (outputs_root / "validation").mkdir(parents=True, exist_ok=True)
    (outputs_root / "model_comparison").mkdir(parents=True, exist_ok=True)
    (outputs_root / "network").mkdir(parents=True, exist_ok=True)
    (outputs_root / "framework").mkdir(parents=True, exist_ok=True)
    return dirs
