"""
Cross-dataset biomarker analysis for multi-species, multi-disease ncRNA discovery.

This module identifies ncRNA biomarkers that are consistently dysregulated across
multiple species and/or disease conditions, helping identify robust candidates for
clinical translation as early biomarkers.

SCIENCE FAIR APPLICATION:
- Compares ncRNAs across human, mouse, zebrafish
- Compares across Alzheimer's, Parkinson's, ALS
- Identifies:
 * Pan-disease conserved biomarkers (work across multiple diseases)
 * Pan-species conserved biomarkers (work across multiple organisms)
 * Species-specific disease signatures
 * Most promising biomarker candidates
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, List, Tuple, Set
import matplotlib.pyplot as plt
import seaborn as sns


def load_biomarker_results(results_dict: Dict[str, pd.DataFrame], 
 fdr_threshold: float = 0.05) -> Dict[str, Set[str]]:
 """
 Extract significant biomarkers from each dataset.
 
 Args:
 results_dict: Dict of {dataset_name: differential_results_df}
 fdr_threshold: FDR cutoff for significance (default: 0.05)
 
 Returns:
 Dict of {dataset_name: set of significant gene IDs}
 """
 biomarkers = {}
 for dataset, results_df in results_dict.items():
 sig_genes = results_df[results_df['fdr'] < fdr_threshold].index.tolist()
 biomarkers[dataset] = set(sig_genes)
 print(f" {dataset}: {len(sig_genes)} significant biomarkers")
 
 return biomarkers


def find_conserved_biomarkers(biomarkers: Dict[str, Set[str]],
 min_datasets: int = 2) -> Set[str]:
 """
 Identify biomarkers appearing in multiple datasets (conserved).
 
 SCIENCE FAIR INTERPRETATION:
 - 2+ datasets: "Cross-validated biomarker" (promising)
 - 3+ datasets: "Highly conserved biomarker" (very promising)
 - All datasets: "Universal biomarker" (excellent candidate)
 
 Args:
 biomarkers: Dict of {dataset: set of gene_ids}
 min_datasets: Minimum number of datasets to appear in (default: 2)
 
 Returns:
 Set of conserved gene IDs
 """
 # Count how many datasets each gene appears in
 gene_counts = {}
 for dataset, genes in biomarkers.items():
 for gene in genes:
 gene_counts[gene] = gene_counts.get(gene, 0) + 1
 
 # Filter by minimum appearances
 conserved = {gene for gene, count in gene_counts.items() 
 if count >= min_datasets}
 
 print(f" Conserved (≥{min_datasets} datasets): {len(conserved)} biomarkers")
 return conserved


def identify_disease_specific_biomarkers(biomarkers: Dict[str, Set[str]],
 dataset_metadata: Dict[str, Dict]) -> Dict[str, Set[str]]:
 """
 Group biomarkers by disease.
 
 Shows which ncRNAs are dysregulated in each disease (across all species).
 
 Args:
 biomarkers: Dict of {dataset: set of gene_ids}
 dataset_metadata: Dict mapping {dataset: {species, disease}}
 
 Returns:
 Dict of {disease: set of all significant biomarkers in that disease}
 """
 disease_biomarkers = {}
 
 for dataset, genes in biomarkers.items():
 if dataset not in dataset_metadata:
 continue
 
 disease = dataset_metadata[dataset].get('disease', 'unknown')
 if disease not in disease_biomarkers:
 disease_biomarkers[disease] = set()
 
 disease_biomarkers[disease].update(genes)
 
 print(f"\n Disease-specific biomarker counts:")
 for disease, genes in sorted(disease_biomarkers.items()):
 print(f" {disease}: {len(genes)} biomarkers")
 
 return disease_biomarkers


def identify_species_specific_biomarkers(biomarkers: Dict[str, Set[str]],
 dataset_metadata: Dict[str, Dict]) -> Dict[str, Set[str]]:
 """
 Group biomarkers by species.
 
 Shows which ncRNAs are dysregulated in each species (across all diseases).
 
 Args:
 biomarkers: Dict of {dataset: set of gene_ids}
 dataset_metadata: Dict mapping {dataset: {species, disease}}
 
 Returns:
 Dict of {species: set of all significant biomarkers in that species}
 """
 species_biomarkers = {}
 
 for dataset, genes in biomarkers.items():
 if dataset not in dataset_metadata:
 continue
 
 species = dataset_metadata[dataset].get('species', 'unknown')
 if species not in species_biomarkers:
 species_biomarkers[species] = set()
 
 species_biomarkers[species].update(genes)
 
 print(f"\n Species-specific biomarker counts:")
 for species, genes in sorted(species_biomarkers.items()):
 print(f" {species}: {len(genes)} biomarkers")
 
 return species_biomarkers


def rank_biomarkers_by_impact(results_dict: Dict[str, pd.DataFrame],
 biomarkers: Dict[str, Set[str]],
 dataset_metadata: Dict[str, Dict]) -> pd.DataFrame:
 """
 Rank biomarkers by their impact across datasets.
 
 Metrics:
 - appearances: How many datasets show this as significant
 - avg_log2fc: Average fold-change across datasets
 - min_fdr: Best (lowest) FDR value across datasets
 - consistency: How consistent the direction of change is
 
 SCIENCE FAIR USE:
 Top-ranked biomarkers = best candidates for clinical translation
 
 Args:
 results_dict: Dict of {dataset: differential_results_df}
 biomarkers: Dict of {dataset: set of significant_genes}
 dataset_metadata: Dict of {dataset: {species, disease}}
 
 Returns:
 DataFrame ranked by quality metrics
 """
 # Collect all biomarker data
 biomarker_stats = {}
 
 for dataset, sig_genes in biomarkers.items():
 if dataset not in results_dict:
 continue
 
 results_df = results_dict[dataset]
 
 for gene in sig_genes:
 if gene not in results_df.index:
 continue
 
 row = results_df.loc[gene]
 
 if gene not in biomarker_stats:
 biomarker_stats[gene] = {
 'gene_id': gene,
 'appearances': 0,
 'log2fc_values': [],
 'fdr_values': [],
 'datasets': [],
 'diseases': [],
 'species': []
 }
 
 biomarker_stats[gene]['appearances'] += 1
 biomarker_stats[gene]['log2fc_values'].append(row.get('log2FC', 0))
 biomarker_stats[gene]['fdr_values'].append(row.get('fdr', 1.0))
 biomarker_stats[gene]['datasets'].append(dataset)
 
 if dataset in dataset_metadata:
 biomarker_stats[gene]['diseases'].append(dataset_metadata[dataset].get('disease'))
 biomarker_stats[gene]['species'].append(dataset_metadata[dataset].get('species'))
 
 # Calculate ranking metrics
 ranking_data = []
 for gene, stats in biomarker_stats.items():
 log2fc_values = np.array(stats['log2fc_values'])
 fdr_values = np.array(stats['fdr_values'])
 
 # Consistency: all fold-changes in same direction
 direction_consistency = 1.0 if (log2fc_values > 0).sum() == 0 or (log2fc_values < 0).sum() == 0 else 0.5
 
 # Score: higher appearances, lower FDR, more consistent
 score = (
 stats['appearances'] * 10 + # Appearances (max 30 for 3+ datasets)
 (1.0 - np.mean(fdr_values)) * 10 + # FDR (lower is better)
 np.abs(np.mean(log2fc_values)) * 2 + # Effect size
 direction_consistency * 5 # Consistency
 )
 
 ranking_data.append({
 'gene_id': gene,
 'appearances': stats['appearances'],
 'avg_log2fc': np.mean(log2fc_values),
 'min_fdr': np.min(fdr_values),
 'consistency_score': direction_consistency,
 'biomarker_score': score,
 'n_diseases': len(set(stats['diseases'])),
 'n_species': len(set(stats['species'])),
 'diseases': ','.join(sorted(set(stats['diseases']))),
 'species': ','.join(sorted(set(stats['species']))),
 })
 
 if not ranking_data:
 ranking_df = pd.DataFrame(columns=[
 'gene_id',
 'appearances',
 'avg_log2fc',
 'min_fdr',
 'consistency_score',
 'biomarker_score',
 'n_diseases',
 'n_species',
 'diseases',
 'species',
 ])
 return ranking_df

 ranking_df = pd.DataFrame(ranking_data).sort_values('biomarker_score', ascending=False)
 ranking_df.index = ranking_df['gene_id']
 
 return ranking_df


def generate_biomarker_report(ranking_df: pd.DataFrame, output_path: str, top_n: int = 20):
 """
 Generate science fair report of top biomarker candidates.
 
 Args:
 ranking_df: Ranked biomarkers from rank_biomarkers_by_impact()
 output_path: Path to save report
 top_n: Number of top candidates to highlight
 """
 report_lines = [
 "=" * 80,
 "ncRNA BIOMARKER DISCOVERY REPORT - MULTI-SPECIES, MULTI-DISEASE",
 "=" * 80,
 "",
 f"ANALYSIS DATE: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}",
 "",
 "SUMMARY STATISTICS",
 "-" * 80,
 f"Total biomarkers identified: {len(ranking_df)}",
 f"Biomarkers in 2+ datasets: {(ranking_df['appearances'] >= 2).sum() if not ranking_df.empty else 0}",
 f"Biomarkers in 3+ datasets: {(ranking_df['appearances'] >= 3).sum() if not ranking_df.empty else 0}",
 f"Biomarkers in 4+ datasets: {(ranking_df['appearances'] >= 4).sum() if not ranking_df.empty else 0}",
 "",
 f"Biomarkers targeting 2+ diseases: {(ranking_df['n_diseases'] >= 2).sum() if not ranking_df.empty else 0}",
 f"Biomarkers targeting 2+ species: {(ranking_df['n_species'] >= 2).sum() if not ranking_df.empty else 0}",
 "",
 "TOP BIOMARKER CANDIDATES FOR CLINICAL TRANSLATION",
 "-" * 80,
 f"(Top {min(top_n, len(ranking_df))} ranked by cross-dataset consistency)",
 "",
 ]

 if ranking_df.empty:
 report_lines.extend([
 "No significant biomarkers found with the current thresholds.",
 "Try increasing sample size, relaxing FDR/log2FC thresholds,",
 "or verifying dataset group labels and preprocessing.",
 "",
 ])
 
 for idx, (gene_id, row) in enumerate(ranking_df.head(top_n).iterrows(), 1):
 report_lines.extend([
 f"RANK #{idx}: {row['gene_id']}",
 f" Biomarker Score: {row['biomarker_score']:.2f}",
 f" Appearances: {int(row['appearances'])} datasets",
 f" Disease Specificity: {row['diseases']}",
 f" Species Confirmed In: {row['species']}",
 f" Average log2(FC): {row['avg_log2fc']:.3f}",
 f" Best FDR: {row['min_fdr']:.2e}",
 f" Consistency: {row['consistency_score']:.1%}",
 "",
 ])
 
 report_text = "\n".join(report_lines)
 
 with open(output_path, 'w') as f:
 f.write(report_text)
 
 print(f"\n✓ Report saved: {output_path}")
 return report_text


def visualize_biomarker_heatmap(ranking_df: pd.DataFrame, biomarkers: Dict[str, Set[str]],
 dataset_metadata: Dict[str, Dict], output_path: str, top_n: int = 50):
 """
 Create heatmap showing biomarker presence across datasets.
 
 SCIENCE FAIR USE:
 - Shows pattern of which biomarkers work in which conditions
 - Easy to visualize cross-dataset consistency
 - Ready for presentation slide
 
 Args:
 ranking_df: Ranked biomarkers
 biomarkers: Dict of {dataset: set of genes}
 dataset_metadata: Dict of {dataset: {species, disease}}
 output_path: Path to save plot
 top_n: Number of top biomarkers to show
 """
 # Get top biomarkers
 top_genes = ranking_df.head(top_n).index.tolist()
 
 # Create presence matrix
 presence_matrix = []
 row_labels = []
 
 for gene in top_genes:
 row = []
 for dataset in sorted(biomarkers.keys()):
 row.append(1 if gene in biomarkers[dataset] else 0)
 presence_matrix.append(row)
 row_labels.append(gene)
 
 presence_matrix = np.array(presence_matrix)
 
 # Create column labels with species and disease
 col_labels = []
 for dataset in sorted(biomarkers.keys()):
 meta = dataset_metadata.get(dataset, {})
 species = meta.get('species', '?')[0].upper() # First letter
 disease = meta.get('disease', '?')[:3].upper() # First 3 letters
 col_labels.append(f"{species}-{disease}")
 
 # Plot
 plt.figure(figsize=(12, max(6, len(top_genes) * 0.15)))
 
 sns.heatmap(
 presence_matrix,
 xticklabels=col_labels,
 yticklabels=row_labels,
 cmap='RdYlGn',
 cbar_kws={'label': 'Significant Biomarker'},
 linewidths=0.5
 )
 
 plt.title(f'ncRNA Biomarker Presence Across Species & Diseases\n(Top {top_n} candidates)', 
 fontsize=14, fontweight='bold')
 plt.xlabel('Species-Disease Combination')
 plt.ylabel('ncRNA Gene ID')
 plt.tight_layout()
 
 plt.savefig(output_path, dpi=300, bbox_inches='tight')
 print(f"✓ Heatmap saved: {output_path}")
 plt.close()


def visualize_biomarker_overlap(biomarkers: Dict[str, Set[str]], 
 dataset_metadata: Dict[str, Dict],
 output_path: str):
 """
 Create bar plot showing biomarker overlap between datasets.
 
 SCIENCE FAIR USE:
 - Shows which datasets have the most in common
 - Highlights which species/disease combinations are most similar
 
 Args:
 biomarkers: Dict of {dataset: set of genes}
 dataset_metadata: Dict of {dataset: {species, disease}}
 output_path: Path to save plot
 """
 # Calculate pairwise overlaps
 datasets = sorted(biomarkers.keys())
 overlap_data = []
 
 for i, ds1 in enumerate(datasets):
 for j, ds2 in enumerate(datasets):
 if i >= j:
 continue
 
 meta1 = dataset_metadata.get(ds1, {})
 meta2 = dataset_metadata.get(ds2, {})
 
 species1 = meta1.get('species', 'unknown')
 disease1 = meta1.get('disease', 'unknown')
 species2 = meta2.get('species', 'unknown')
 disease2 = meta2.get('disease', 'unknown')
 
 overlap = len(biomarkers[ds1] & biomarkers[ds2])
 overlap_pct = overlap / max(len(biomarkers[ds1]), len(biomarkers[ds2])) * 100
 
 overlap_data.append({
 'Pair': f"{species1[:4]}-{disease1[:3]} vs {species2[:4]}-{disease2[:3]}",
 'Shared_Biomarkers': overlap,
 'Overlap_Percentage': overlap_pct
 })
 
 if not overlap_data:
 print("⚠ Not enough datasets for overlap analysis")
 return
 
 overlap_df = pd.DataFrame(overlap_data).sort_values('Shared_Biomarkers', ascending=True)
 
 fig, ax = plt.subplots(figsize=(10, max(4, len(overlap_df) * 0.3)))
 
 bars = ax.barh(range(len(overlap_df)), overlap_df['Shared_Biomarkers'])
 ax.set_yticks(range(len(overlap_df)))
 ax.set_yticklabels(overlap_df['Pair'])
 ax.set_xlabel('Number of Shared Biomarkers')
 ax.set_title('ncRNA Biomarker Overlap Between Datasets\n(Conserved across species/diseases)', 
 fontsize=12, fontweight='bold')
 
 # Color bars by overlap percentage
 for bar, pct in zip(bars, overlap_df['Overlap_Percentage']):
 if pct > 50:
 bar.set_color('darkgreen')
 elif pct > 25:
 bar.set_color('orange')
 else:
 bar.set_color('lightcoral')
 
 # Add percentage labels
 for i, (bar, pct) in enumerate(zip(bars, overlap_df['Overlap_Percentage'])):
 ax.text(bar.get_width(), bar.get_y() + bar.get_height()/2, 
 f' {pct:.1f}%', ha='left', va='center', fontweight='bold')
 
 plt.tight_layout()
 plt.savefig(output_path, dpi=300, bbox_inches='tight')
 print(f"✓ Overlap plot saved: {output_path}")
 plt.close()


def summarize_biomarker_findings(ranking_df: pd.DataFrame, 
 disease_biomarkers: Dict[str, Set[str]],
 species_biomarkers: Dict[str, Set[str]]) -> str:
 """
 Generate science fair talking points summary.
 
 Returns: Multi-line string with key findings for presentation
 """
 summary = "\n" + "=" * 70 + "\n"
 summary += "KEY FINDINGS FOR SCIENCE FAIR PRESENTATION\n"
 summary += "=" * 70 + "\n\n"
 
 # Best candidates
 top_5 = ranking_df.head(5)
 summary += "🏆 TOP 5 BIOMARKER CANDIDATES:\n"
 for idx, (gene_id, row) in enumerate(top_5.iterrows(), 1):
 summary += f" {idx}. {row['gene_id']}: "
 summary += f"Found in {int(row['appearances'])} datasets, "
 summary += f"affects {int(row['n_diseases'])} diseases, "
 summary += f"{int(row['n_species'])} species\n"
 
 summary += "\n"
 
 # Disease-specific findings
 summary += "🧠 DISEASE-SPECIFIC FINDINGS:\n"
 for disease in sorted(disease_biomarkers.keys()):
 n_genes = len(disease_biomarkers[disease])
 summary += f" • {disease}: {n_genes} unique biomarkers identified\n"
 
 summary += "\n"
 
 # Species correlation
 summary += "🔬 CROSS-SPECIES CONSERVATION:\n"
 multi_species = (ranking_df['n_species'] >= 2).sum()
 summary += f" • {multi_species} biomarkers conserved across 2+ species\n"
 summary += f" • Suggests evolutionary conservation & clinical relevance\n"
 
 summary += "\n"
 
 # Pan-disease biomarkers
 summary += "⭐ PAN-DISEASE CANDIDATES (Work for multiple diseases):\n"
 pan_disease = ranking_df[ranking_df['n_diseases'] >= 2].head(10)
 if len(pan_disease) > 0:
 for gene_id, row in pan_disease.iterrows():
 summary += f" • {gene_id}: {int(row['n_diseases'])} diseases, {int(row['n_species'])} species\n"
 else:
 summary += " • None identified yet (more datasets needed)\n"
 
 summary += "\n" + "=" * 70 + "\n"
 
 return summary
