"""Figure utilities: volcano, heatmap, PCA, upset and summary plots for RNA-seq analysis."""
from typing import Sequence
import matplotlib
matplotlib.use('Agg') # Use non-interactive backend (fixes GUI issues on remote/headless systems)
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd
from pathlib import Path
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler


def volcano_plot(res_df: pd.DataFrame, out_path: str, title: str = None):
 df = res_df.copy()
 df['negLog10FDR'] = -np.log10(df['fdr'].replace(0, 1e-300))
 plt.figure(figsize=(6, 5))
 sns.scatterplot(x='log2FC', y='negLog10FDR', data=df, hue='significant', palette={True: 'red', False: 'grey'}, legend=False)
 plt.axhline(-np.log10(0.05), color='black', linestyle='--', linewidth=0.7)
 plt.xlabel('log2FC (disease - control)')
 plt.ylabel('-log10(FDR)')
 if title:
 plt.title(title)
 plt.tight_layout()
 Path(out_path).parent.mkdir(parents=True, exist_ok=True)
 plt.savefig(out_path, dpi=300)
 plt.close()


def heatmap_top_genes(logcpm_df: pd.DataFrame, top_genes: Sequence[str], metadata: pd.DataFrame, group_col: str, out_path: str):
 sel = logcpm_df.loc[logcpm_df.index.intersection(top_genes)]
 if sel.empty:
 raise ValueError('No genes available for heatmap plotting.')
 z = sel.sub(sel.mean(axis=1), axis=0).div(sel.std(axis=1).replace(0, np.nan), axis=0).fillna(0)
 samples = [s for s in logcpm_df.columns if s in metadata.index]
 group_order = metadata.loc[samples][group_col].astype(str)
 unique_groups = group_order.unique()
 palette = sns.color_palette('Set2', n_colors=len(unique_groups))
 lut = dict(zip(unique_groups, palette))
 col_colors = group_order.map(lut)
 g = sns.clustermap(z, row_cluster=True, col_cluster=False, col_colors=col_colors, cmap='vlag', xticklabels=True, yticklabels=True, figsize=(8, max(4, len(top_genes)/3)))
 for label, color in lut.items():
 g.ax_col_dendrogram.bar(0, 0, color=color, label=label)
 g.ax_col_dendrogram.legend(title=group_col, loc='center', bbox_to_anchor=(0.5, 1.1), ncol=3)
 Path(out_path).parent.mkdir(parents=True, exist_ok=True)
 plt.savefig(out_path, dpi=300, bbox_inches='tight')
 plt.close()


def upset_overlap(list_of_gene_sets: dict, out_path: str, title: str = None):
 try:
 from upsetplot import from_contents, plot
 except Exception:
 raise ImportError('upsetplot required for UpSet plots. Install with: pip install upsetplot')
 contents = from_contents(list_of_gene_sets)
 plt.figure(figsize=(8, 4))
 plot(contents)
 if title:
 plt.title(title)
 Path(out_path).parent.mkdir(parents=True, exist_ok=True)
 plt.savefig(out_path, dpi=300, bbox_inches='tight')
 plt.close()


def barplot_significant_counts(signif_counts: pd.Series, out_path: str, title: str = None):
 plt.figure(figsize=(6, 4))
 signif_counts.sort_values(ascending=False).plot(kind='bar', color='steelblue')
 plt.ylabel('Number significant ncRNAs (FDR < 0.05)')
 if title:
 plt.title(title)
 plt.tight_layout()
 Path(out_path).parent.mkdir(parents=True, exist_ok=True)
 plt.savefig(out_path, dpi=300)
 plt.close()


def pca_plot(logcpm_df: pd.DataFrame, metadata: pd.DataFrame, group_col: str, out_path: str, title: str = None):
 """
 Generate a PCA plot colored by experimental condition.
 
 Args:
 logcpm_df: Expression matrix (log2-CPM), genes × samples
 metadata: Sample metadata with group column
 group_col: Column name for grouping variable (e.g., 'Condition')
 out_path: Output file path for PNG
 title: Optional plot title
 
 Creates publication-ready PCA plot with:
 - PC1 and PC2 with variance explained
 - Color-coded by condition
 - Proper axis labels and legend
 """
 # Align samples
 samples = logcpm_df.columns.intersection(metadata.index)
 expr = logcpm_df[samples].T # Transpose: samples × genes
 groups = metadata.loc[samples, group_col].astype(str)
 
 # Standardize features (genes) before PCA
 scaler = StandardScaler()
 expr_scaled = scaler.fit_transform(expr)
 
 # Perform PCA (2 components)
 pca = PCA(n_components=2)
 pc_coords = pca.fit_transform(expr_scaled)
 
 # Extract variance explained
 var_explained = pca.explained_variance_ratio_
 
 # Create dataframe for plotting
 pca_df = pd.DataFrame({
 'PC1': pc_coords[:, 0],
 'PC2': pc_coords[:, 1],
 'Group': groups.values
 })
 
 # Plot
 plt.figure(figsize=(7, 6))
 sns.scatterplot(data=pca_df, x='PC1', y='PC2', hue='Group', 
 palette='Set2', s=100, alpha=0.8, edgecolor='black', linewidth=0.5)
 
 plt.xlabel(f'PC1 ({var_explained[0]*100:.1f}% variance)', fontsize=12)
 plt.ylabel(f'PC2 ({var_explained[1]*100:.1f}% variance)', fontsize=12)
 
 if title:
 plt.title(title, fontsize=14, fontweight='bold')
 else:
 plt.title('Principal Component Analysis (PCA)', fontsize=14, fontweight='bold')
 
 plt.legend(title=group_col, fontsize=10, title_fontsize=11, loc='best')
 plt.grid(alpha=0.3, linestyle='--')
 plt.tight_layout()
 
 Path(out_path).parent.mkdir(parents=True, exist_ok=True)
 plt.savefig(out_path, dpi=300, bbox_inches='tight')
 plt.close()


def barplot_top_genes_with_error(logcpm_df: pd.DataFrame, top_genes: list, metadata: pd.DataFrame, 
 group_col: str, out_path: str, title: str = None, top_n: int = 3):
 """
 Generate bar plots with error bars (mean ± SD) for top N genes.
 
 Args:
 logcpm_df: Expression matrix (log2-CPM), genes × samples 
 top_genes: List of gene IDs to plot
 metadata: Sample metadata with group column
 group_col: Column name for grouping variable
 out_path: Output file path for PNG
 title: Optional plot title
 top_n: Number of top genes to plot (default: 3)
 
 Creates publication-ready bar plot with:
 - Mean normalized expression per group
 - Standard deviation error bars
 - Proper axis labels with units
 - Legend identifying groups
 """
 # Align samples
 samples = logcpm_df.columns.intersection(metadata.index)
 groups = metadata.loc[samples, group_col].astype(str)
 
 # Select top N genes
 genes_to_plot = top_genes[:top_n] if len(top_genes) >= top_n else top_genes
 
 if len(genes_to_plot) == 0:
 raise ValueError("No genes available for bar plot")
 
 # Prepare data for plotting
 fig, axes = plt.subplots(1, len(genes_to_plot), figsize=(4*len(genes_to_plot), 5), 
 squeeze=False)
 axes = axes.flatten()
 
 unique_groups = groups.unique()
 colors = sns.color_palette('Set2', n_colors=len(unique_groups))
 
 for idx, gene in enumerate(genes_to_plot):
 if gene not in logcpm_df.index:
 continue
 
 expr = logcpm_df.loc[gene, samples]
 
 # Calculate mean and SD per group
 means = []
 sds = []
 labels = []
 
 for group in unique_groups:
 group_samples = groups[groups == group].index
 group_expr = expr[group_samples]
 means.append(group_expr.mean())
 sds.append(group_expr.std())
 labels.append(group)
 
 # Bar plot with error bars
 x_pos = np.arange(len(labels))
 axes[idx].bar(x_pos, means, yerr=sds, color=colors[:len(labels)], 
 alpha=0.7, capsize=5, edgecolor='black', linewidth=1)
 
 axes[idx].set_xticks(x_pos)
 axes[idx].set_xticklabels(labels, rotation=45, ha='right')
 axes[idx].set_ylabel('Normalized Expression\n(log2-CPM)', fontsize=11)
 axes[idx].set_ylim(bottom=0)
 axes[idx].set_title(f'{gene}', fontsize=12, fontweight='bold')
 axes[idx].grid(axis='y', alpha=0.3, linestyle='--')
 
 if title:
 fig.suptitle(title, fontsize=14, fontweight='bold', y=1.02)
 else:
 fig.suptitle('Top ncRNA Expression (Mean ± SD)', fontsize=14, fontweight='bold', y=1.02)
 
 plt.tight_layout()
 
 Path(out_path).parent.mkdir(parents=True, exist_ok=True)
 plt.savefig(out_path, dpi=300, bbox_inches='tight')
 plt.close()
