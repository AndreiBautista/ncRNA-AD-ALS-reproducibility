"""Differential expression analysis utilities with dual statistical methods.

This module implements two complementary approaches for detecting differentially expressed non-coding RNAs:

1. WELCH T-TEST (Default):
 - Non-parametric, assumes unequal variances between groups
 - Fast, robust to outliers
 - Suitable for smaller sample sizes and non-normal distributions
 - Log2-CPM normalized data
 
2. DESeq2 (Optional, via rpy2):
 - Negative binomial generalized linear model (GLM)
 - Estimates per-gene dispersions (accounts for mean-variance relationship)
 - Superior for count data with low sample counts per group
 - Requires raw counts (not log-normalized)
 - Requires R >= 3.6 with DESeq2 package installed

Selection: Set DE_METHOD at module top or pass method parameter to differential_expression().
"""

from statsmodels.stats.multitest import multipletests
from scipy import stats
import numpy as np
import pandas as pd

# ============================================================================
# CONFIGURATION: Select differential expression method
# ============================================================================
# Options: 'welch' (fast, default) or 'deseq2' (more robust, requires rpy2)
DE_METHOD = 'welch'


def detect_group_column(metadata: pd.DataFrame, hint: str = None) -> str:
 """
 Automatically detect the grouping column in metadata.
 
 Searches for columns with common names: 'condition', 'group', 'status', 
 'phenotype', 'disease', 'case', or uses provided hint.
 
 Args:
 metadata: DataFrame with sample metadata
 hint: Optional column name hint if auto-detection fails
 
 Returns:
 Name of detected grouping column
 
 Raises:
 ValueError: If no appropriate column found
 """
 col_lower = {c.lower(): c for c in metadata.columns}
 keywords = ['condition', 'group', 'status', 'phenotype', 'disease', 'case']
 
 if hint and hint in metadata.columns:
 return hint
 
 for kw in keywords:
 if kw in col_lower:
 col = col_lower[kw]
 print(f" → Detected grouping column: '{col}'")
 return col
 
 raise ValueError(
 f'Could not auto-detect grouping column. Available columns: {list(metadata.columns)}. '
 f'Provide column name via --group_col parameter.'
 )


def validate_groups(metadata: pd.DataFrame, group_col: str, disease_label: str = None, control_label: str = None):
 """
 Validate grouping column and infer disease/control labels if not provided.
 
 Args:
 metadata: Sample metadata
 group_col: Column name containing group assignments
 disease_label: Expected disease group label (inferred if None)
 control_label: Expected control group label (inferred if None)
 
 Returns:
 (disease_label, control_label, disease_samples, control_samples)
 
 Raises:
 ValueError: If validation fails (wrong labels, insufficient samples, etc.)
 """
 if group_col not in metadata.columns:
 raise ValueError(f"Group column '{group_col}' not found in metadata. Available: {list(metadata.columns)}")
 
 group_values = metadata[group_col].unique()
 print(f" → Found groups: {group_values} (n={len(metadata)})")
 
 # Infer labels if not provided
 if disease_label is None or control_label is None:
 counts = metadata[group_col].value_counts()
 print(f" → Group counts: {dict(counts)}")
 
 if disease_label is None:
 # Heuristic: "Disease" > "Control" alphabetically, or check for keywords
 candidates = list(counts.index)
 disease_candidate = None
 for keyword in ['disease', 'case', 'treatment', 'affected']:
 for cand in candidates:
 if keyword.lower() in str(cand).lower():
 disease_candidate = cand
 break
 if disease_candidate:
 break
 
 if disease_candidate is None:
 # Fallback: assume least common is disease (unusual group)
 disease_label = counts.idxmin()
 else:
 disease_label = disease_candidate
 
 print(f" → Inferred disease label: '{disease_label}'")
 
 if control_label is None:
 # Control should be the other group
 control_label = [g for g in candidates if g != disease_label][0] if len(candidates) > 1 else 'Control'
 print(f" → Inferred control label: '{control_label}'")
 
 # Validate presence
 if disease_label not in metadata[group_col].values:
 raise ValueError(f"Disease label '{disease_label}' not found in {group_col}. Found: {group_values}")
 if control_label not in metadata[group_col].values:
 raise ValueError(f"Control label '{control_label}' not found in {group_col}. Found: {group_values}")
 
 # Extract samples per group
 disease_samples = metadata[metadata[group_col] == disease_label].index.tolist()
 control_samples = metadata[metadata[group_col] == control_label].index.tolist()
 
 if len(disease_samples) < 2:
 raise ValueError(f"Disease group has {len(disease_samples)} sample(s); need ≥2 for statistical test.")
 if len(control_samples) < 2:
 raise ValueError(f"Control group has {len(control_samples)} sample(s); need ≥2 for statistical test.")
 
 print(f" ✓ Samples: {len(disease_samples)} disease, {len(control_samples)} control")
 return disease_label, control_label, disease_samples, control_samples


def differential_expression_welch(logcpm_df: pd.DataFrame, disease_samples: list, control_samples: list) -> pd.DataFrame:
 """
 Perform Welch two-sample t-test for each gene with comprehensive statistics.
 
 STATISTICAL METHOD:
 - Welch's t-test (Student's t-test with unequal variances) for each gene
 - Log2-CPM normalized input data
 - Formula: t = (mean_disease - mean_control) / sqrt(var_d/n_d + var_c/n_c)
 - Degrees of freedom adjusted for unequal variances (Welch–Satterthwaite)
 
 RATIONALE FOR ncRNA ANALYSIS:
 - Non-coding RNAs often have lower expression variance than mRNAs
 - Welch's test is robust to heteroscedasticity (unequal variance between groups)
 - Does NOT assume normal distribution (t-test is robust to moderate non-normality)
 - Fast computation suitable for 20K+ genes
 
 INPUTS:
 - logcpm_df: Expression matrix (log2-CPM normalized), genes × samples
 - disease_samples: List of sample IDs in disease group
 - control_samples: List of sample IDs in control group
 
 OUTPUTS:
 - DataFrame with columns: gene_id, mean_disease, mean_control, sd_disease, sd_control, 
 log2FC, test_statistic, pvalue
 """
 results = []
 for gene in logcpm_df.index:
 vals = logcpm_df.loc[gene]
 
 # Extract expression values for each group
 x = vals[disease_samples].dropna().values # disease group
 y = vals[control_samples].dropna().values # control group
 
 # Skip genes with insufficient data
 if min(len(x), len(y)) < 2:
 continue
 
 # DESCRIPTIVE STATISTICS
 # Calculate group means (log2-CPM scale)
 mean_d = np.mean(x)
 mean_c = np.mean(y)
 
 # Calculate standard deviations
 sd_d = np.std(x, ddof=1) # ddof=1 for sample SD
 sd_c = np.std(y, ddof=1)
 
 # INFERENTIAL STATISTICS
 # Log2 fold-change (already in log2 space)
 log2fc = mean_d - mean_c
 
 # Welch's t-test (equal_var=False accounts for unequal variances)
 try:
 tstat, pval = stats.ttest_ind(x, y, equal_var=False, nan_policy='omit')
 if np.isnan(pval):
 pval = 1.0
 if np.isnan(tstat):
 tstat = 0.0
 except Exception:
 pval = 1.0
 tstat = 0.0
 
 results.append((gene, mean_d, mean_c, sd_d, sd_c, log2fc, tstat, pval))
 
 res_df = pd.DataFrame(
 results, 
 columns=['gene_id', 'mean_disease', 'mean_control', 'sd_disease', 'sd_control', 
 'log2FC', 'test_statistic', 'pvalue']
 ).set_index('gene_id')
 
 return res_df


def differential_expression_deseq2(raw_counts_df: pd.DataFrame, metadata: pd.DataFrame, 
 group_col: str, disease_label: str, control_label: str) -> pd.DataFrame:
 """
 Perform DESeq2 differential expression analysis (via rpy2).
 
 STATISTICAL METHOD:
 - Negative binomial generalized linear model (GLM)
 - Estimates size factors (sequencing depth normalization)
 - Estimates per-gene dispersions (mean-variance relationship)
 - Wald test for each gene with shrinkage estimation of log2FC
 - More conservative than t-test; better handles overdispersion in count data
 
 RATIONALE FOR ncRNA ANALYSIS:
 - ncRNAs often have sparse, 0-heavy count distributions
 - DESeq2 explicitly models count-level technical variability
 - Accounts for sequencing depth per sample
 - More appropriate for whole-genome ncRNA profiling
 
 REQUIREMENTS:
 - R >= 3.6 with DESeq2 package
 - rpy2 Python package installed (pip install rpy2)
 
 INPUTS:
 - raw_counts_df: Raw (non-normalized) count matrix, genes × samples
 - metadata: Sample metadata with group assignments
 - group_col: Column name indicating treatment groups
 - disease_label: Label for disease/treatment samples
 - control_label: Label for control samples
 
 OUTPUTS:
 - DataFrame with columns: gene_id, mean_disease, mean_control, log2FC, pvalue
 """
 try:
 import rpy2
 from rpy2.robjects import pandas2ri, r
 from rpy2.robjects.packages import importr
 pandas2ri.activate()
 except ImportError:
 raise ImportError(
 "DESeq2 method requires rpy2 and R with DESeq2 package.\n"
 "Install: pip install rpy2\n"
 "Then in R: install.packages('DESeq2')"
 )
 
 try:
 # Load DESeq2 in R
 deseq2 = importr('DESeq2')
 
 # Prepare count matrix and design
 countData = raw_counts_df.astype(int)
 colData = metadata[[group_col]].copy()
 colData[group_col] = colData[group_col].astype('category')
 
 # Create DESeqDataSet
 r_count = pandas2ri.py2rpy(countData)
 r_col = pandas2ri.py2rpy(colData)
 dds = deseq2.DESeqDataSetFromMatrix(countData=r_count, colData=r_col, 
 design=r.formula(f'~{group_col}'))
 
 # Run DESeq2 pipeline (estimateSizeFactors → estimateDispersions → nbinomWaldTest)
 dds = deseq2.DESeq(dds)
 
 # Extract results for disease vs control contrast
 res_r = deseq2.results(dds, contrast=r.c(group_col, disease_label, control_label))
 res_py = pandas2ri.rpy2py(res_r)
 
 # Format output to match welch t-test output
 results_list = []
 for gene_id in res_py.index:
 row = res_py.loc[gene_id]
 results_list.append((
 gene_id,
 float(row.get('baseMean', np.nan)), # Mean count (not per-group)
 float(row['log2FoldChange']) if not pd.isna(row['log2FoldChange']) else 0.0,
 np.nan, # placeholder for mean_control (not provided by DESeq2)
 float(row['pvalue']) if not pd.isna(row['pvalue']) else 1.0
 ))
 
 # Convert to DataFrame (note: structure differs slightly from welch output)
 res_df = pd.DataFrame(
 results_list,
 columns=['gene_id', 'mean_disease', 'log2FC_deseq2', 'log2FC', 'pvalue']
 ).set_index('gene_id')
 
 res_df['mean_control'] = np.nan # DESeq2 doesn't separate group means
 
 return res_df
 
 except Exception as e:
 raise RuntimeError(f"DESeq2 analysis failed: {e}")


def differential_expression(logcpm_df: pd.DataFrame, metadata: pd.DataFrame, 
 group_col: str, disease_label: str = None, 
 control_label: str = None, method: str = None,
 raw_counts_df: pd.DataFrame = None) -> pd.DataFrame:
 """
 Main differential expression analysis dispatcher.
 
 Orchestrates group validation, sample alignment, and calls appropriate
 statistical method (Welch t-test or DESeq2).
 
 Args:
 logcpm_df (pd.DataFrame): Log2-CPM normalized counts (genes × samples)
 metadata (pd.DataFrame): Sample metadata (samples × metadata)
 group_col (str): Column name in metadata for sample grouping
 disease_label (str): Label for disease/case group (auto-inferred if None)
 control_label (str): Label for control group (auto-inferred if None)
 method (str): 'welch' or 'deseq2' (uses DE_METHOD if None)
 raw_counts_df (pd.DataFrame): Raw counts (required for DESeq2)
 
 Returns:
 pd.DataFrame: Results with columns [gene_id, mean_disease, mean_control, log2FC, pvalue]
 
 Raises:
 ValueError: If group validation fails or insufficient samples
 """
 
 # Select method
 if method is None:
 method = DE_METHOD
 method = method.lower()
 print(f" Using {method.upper()} differential expression method")
 
 # Sample alignment: find intersection of logcpm columns and metadata index
 samples = logcpm_df.columns.intersection(metadata.index)
 if len(samples) == 0:
 raise ValueError(
 f'No matching samples between expression matrix ({len(logcpm_df.columns)} samples) '
 f'and metadata ({len(metadata)} samples). Check sample name formatting.'
 )
 
 logcpm_df = logcpm_df[samples]
 meta = metadata.loc[samples]
 
 # Detect and validate groups
 if group_col is None:
 group_col = detect_group_column(meta)
 
 disease_label, control_label, disease_samples, control_samples = validate_groups(
 meta, group_col, disease_label, control_label
 )
 
 # Run selected method
 if method == 'deseq2':
 if raw_counts_df is None:
 raise ValueError('DESeq2 requires raw_counts_df parameter with non-normalized counts')
 print(f" Running DESeq2 (please wait, this is slower than Welch t-test)...")
 res_df = differential_expression_deseq2(raw_counts_df, meta, group_col, disease_label, control_label)
 else:
 # Default to Welch
 print(f" Running Welch t-test ({len(logcpm_df)} genes)...")
 res_df = differential_expression_welch(logcpm_df, disease_samples, control_samples)
 
 return res_df


def adjust_pvalues(res_df: pd.DataFrame, method: str = 'fdr_bh', alpha: float = 0.05) -> pd.DataFrame:
 """
 Apply multiple hypothesis correction to p-values.
 
 STATISTICAL METHOD:
 - Benjamini-Hochberg FDR correction (default)
 - Controls False Discovery Rate (FDR ≤ α) across all genes tested
 - Less conservative than Bonferroni; better for genome-wide studies
 
 RATIONALE:
 - When testing 20,000+ genes, many spurious discoveries occur by chance
 - FDR correction: expected proportion of false positives among rejected hypotheses ≤ α
 - More appropriate for ncRNA discovery (balance sensitivity vs specificity)
 
 INPUTS:
 - res_df: DataFrame with 'pvalue' column
 - method: 'fdr_bh' (default), 'bonferroni', 'holm', etc. (see statsmodels.stats.multitest)
 - alpha: significance threshold (default 0.05 = 5% FDR)
 
 OUTPUTS:
 - DataFrame with added columns: 'fdr' (adjusted p-values), 'significant' (bool)
 """
 pvals = res_df['pvalue'].fillna(1.0).values
 try:
 reject, pvals_corrected, _, _ = multipletests(pvals, alpha=alpha, method=method)
 except Exception as e:
 print(f" Warning: p-value adjustment failed ({e}), using raw p-values")
 pvals_corrected = pvals
 reject = pvals_corrected < alpha
 
 res_df['fdr'] = pvals_corrected
 res_df['significant'] = reject
 
 sig_count = reject.sum()
 print(f" → Multiple testing correction: {sig_count}/{len(pvals)} genes significant (FDR < {alpha})")
 
 return res_df


def save_results(res_df: pd.DataFrame, annot_df: pd.DataFrame, out_prefix: str) -> (str, pd.DataFrame):
 """
 Merge statistical results with gene annotations and save to CSV.
 
 PROCESS:
 1. Merge DE results with gene annotations (gene_name, biotype)
 2. Sort by adjusted p-value (then raw p-value, then |log2FC|)
 3. Save as publication-ready CSV (ready for import into Excel, IGV, etc.)
 
 OUTPUT COLUMNS:
 - gene_id: ENSEMBL gene identifier
 - log2FC: Log-scale fold-change (positive = upregulated in disease)
 - pvalue: Raw p-value from t-test or DESeq2
 - fdr: Adjusted p-value (Benjamini-Hochberg FDR)
 - significant: Boolean (True if FDR < 0.05)
 - gene_name: Human-readable gene name
 - biotype: RNA type (e.g., lncRNA, miRNA, snoRNA)
 
 EXAMPLE OUTPUT (first 3 rows):
 gene_id,log2FC,pvalue,fdr,significant,gene_name,biotype
 ENSG00000269981,-3.45,0.0001,0.0021,True,LINC01234,lncRNA
 ENSG00000270842,2.91,0.0003,0.0031,True,MIR9876,miRNA
 ...
 
 INPUTS:
 - res_df: DE results from differential_expression()
 - annot_df: Gene annotation with 'gene_name' and 'biotype' columns
 - out_prefix: Path prefix for output CSV
 
 OUTPUTS:
 - Tuple: (csv_path, merged_dataframe)
 """
 # Merge with annotation
 merged = res_df.merge(
 annot_df[['gene_name', 'biotype']], 
 left_index=True, 
 right_index=True, 
 how='left'
 )
 
 # Sort by significance (FDR first, then raw p-value, then effect size)
 merged.sort_values(['fdr', 'pvalue', 'log2FC'], inplace=True)
 
 # Save
 out_csv = f"{out_prefix}_differential_results.csv"
 merged.to_csv(out_csv)
 
 print(f" ✓ Results saved: {out_csv}")
 print(f" Rows: {len(merged)} | Significant (FDR<0.05): {merged['significant'].sum()}")
 
 return out_csv, merged
