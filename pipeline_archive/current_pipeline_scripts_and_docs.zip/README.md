# ncRNA Neurodegeneration Pipeline

This repository now contains two scientifically separate stages.

## Phase Separation

### Phase 1: Discovery and Candidate Selection
Phase 1 is the discovery stage and is responsible for:
- transcriptome-wide differential expression discovery
- candidate biomarker selection/ranking
- original discovery-focused visualizations (for example volcano/heatmap/overlap-style plots)

### Phase 2: Fixed-Panel Validation Framework
Phase 2 is strictly downstream of Phase 1 and assumes the biomarker panel is fixed.
It is responsible for:
- external validation of the fixed ncRNA panel across independent cohorts
- model comparison using only the fixed panel as features
- robustness testing (seed stability, class imbalance checks, permutation testing)
- optional ncRNA-target-pathway network interpretation
- reusable cross-disease framework summaries for transportability

Phase 2 does not perform any transcriptome-wide discovery, does not select new biomarkers, and does not run overlap-discovery workflows.

## Novel Contribution of Phase 2
The novel contribution of Phase 2 is not finding new markers; it is quantifying whether a pre-specified biomarker panel generalizes across diseases/cohorts under leakage-safe evaluation and robustness stress tests.
This makes Phase 2 a computational validation framework rather than a discovery pipeline.

## Entry Point (Phase 2)
Run Phase 2 with:

```bash
/Users/austinbautista/ncrna_pipeline/.venv/bin/python scripts/phase2_validation_framework/run_phase2_framework.py \
  --config config/examples/phase2_validation_config.yaml
```

## Dataset Role Mapping
To keep Phase 1 and Phase 2 separated:
- discovery only (Phase 1): GSE173955, GSE203206, GSE153960 (original ALS discovery cohort)
- external validation only (Phase 2): GSE33000 (AD), GSE124439 (ALS)

GSE124439 is an additional Phase 2 ALS external validation dataset and does not replace the original ALS discovery cohort used in Phase 1.

The example Phase 2 config includes only external-validation datasets in the runtime datasets list.
Discovery-only datasets are documented but not executed in Phase 2.

## By-Dataset Comparison Outputs (Phase 2)
Phase 2 writes dataset-comparable validation outputs to:
- phase2_validation_framework/outputs/validation/external_validation/fixed_biomarker_validation_by_dataset.csv
- phase2_validation_framework/outputs/validation/external_validation/fixed_biomarker_log2fc_by_dataset.csv
- phase2_validation_framework/outputs/validation/external_validation/fixed_biomarker_fdr_by_dataset.csv

These files make side-by-side comparison straightforward between the existing AD validation dataset and the new external dataset.

## Phase 2 Inputs and Dependencies
Required inputs for Phase 2:
- counts matrix per dataset
- metadata per dataset with disease/control labels
- fixed ncRNA biomarker list from Phase 1 (provided in config as known_ncrna_biomarkers)

Optional inputs:
- annotation file for harmonization
- ncRNA-target map
- pathway-gene map

Phase 2 has no runtime dependency on Phase 1 output files. It only depends on the fixed biomarker identities produced by Phase 1.
